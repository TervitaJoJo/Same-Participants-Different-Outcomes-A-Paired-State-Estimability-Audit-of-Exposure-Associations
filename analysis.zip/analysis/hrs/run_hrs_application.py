"""HRS external application: source reconciliation and survey-weighted state audit.
No main manuscript edits. Participant identifiers are never written to results.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import json, hashlib, importlib.util, sys, warnings
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import scipy, statsmodels
from scipy.special import softmax, logsumexp
from scipy.stats import t
from patsy import dmatrix, build_design_matrices

HERE=Path(__file__).resolve().parent
JCE=HERE.parent.parent
BASE=Path('D:/review_workspace/Statistical_Modeling')
OLD=BASE/'survey_extension'
OUT=HERE/'results'
OUT.mkdir(exist_ok=True)
sys.stdout.reconfigure(encoding='utf-8')
def module(name,p):
    s=importlib.util.spec_from_file_location(name,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
joint=module('legacy_joint',BASE/'paired_state_core/code/common.py')
binary=module('legacy_binary',BASE/'corrected_panel/code/common.py')
NAMES=['risk_M0','risk_M1','risk_S0','risk_S1','RD_M','RD_S','logOR_M','logOR_S','delta_m','C_U','C_V']
SEED=2026092801
B=500
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save_json(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2,default=lambda v: v.item() if isinstance(v,np.generic) else str(v)),encoding='utf-8')

def prepare(g,reference='noncurrent',info=None):
    z=g.copy()
    if reference=='noncurrent':z['smoke_status']=np.where(z.smoke_status==2,2,0)
    formula='C(smoke_status)*male + bs(age, df=4) + C(edu3)'
    if info is None:
        x=dmatrix(formula,z,return_type='dataframe');info=x.design_info
    X=np.asarray(build_design_matrices([info],z)[0])
    xx=[]
    for e in [0,2]:
        ze=z.copy();ze['smoke_status']=e
        xx.append(np.asarray(build_design_matrices([info],ze)[0]))
    return X,xx,info,z

def fit_joint(X,y,w,start=None):
    w=np.asarray(w,float);w=w/w.mean(); k=X.shape[1]
    if np.linalg.matrix_rank(X[w>0])<k:raise ValueError('rank_deficient_design')
    Y=np.eye(4)[y][:,1:]
    b=np.zeros((k,3)) if start is None else start.copy()
    def evaluate(b):
        eta=np.c_[np.zeros(len(y)),X@b]
        p=softmax(eta,axis=1)
        loss=np.sum(w*(logsumexp(eta,axis=1)-eta[np.arange(len(y)),y]))
        score=(X.T@(w[:,None]*(Y-p[:,1:]))).ravel(order='F')
        H=np.block([[X.T@((w*p[:,l]*((l==r)-p[:,r]))[:,None]*X) for r in range(1,4)] for l in range(1,4)])
        return loss,p,score,H
    for it in range(100):
        loss,p,score,H=evaluate(b)
        if np.max(np.abs(score))<1e-7:break
        step=np.linalg.solve(H,score).reshape((k,3),order='F')
        alpha=1.
        while alpha>1e-8:
            candidate=b+alpha*step
            eta=np.c_[np.zeros(len(y)),X@candidate]
            newloss=np.sum(w*(logsumexp(eta,axis=1)-eta[np.arange(len(y)),y]))
            if newloss<=loss+1e-10:break
            alpha*=.5
        if alpha<=1e-8:raise ValueError('line_search_failure')
        b=candidate
    else:raise ValueError('nonconvergence')
    if not np.isfinite(b).all() or np.linalg.cond(H)>1e12:raise ValueError('ill_conditioned_hessian')
    scoreobs=np.hstack([X*(w*(Y[:,l-1]-p[:,l]))[:,None] for l in range(1,4)])
    ib=scoreobs@np.linalg.inv(H)
    return b,ib,{'iterations':it,'score_max':float(abs(score).max()),'hessian_condition':float(np.linalg.cond(H))}

def marginal(X,xx,y,w,q,start=None,check=True):
    b,ib,audit=fit_joint(X,y,w,start)
    q=np.asarray(q,float);q=q/q.sum()
    means=[];ifs=[];Js=[];preds=[]
    for xe in xx:
        p=softmax(np.c_[np.zeros(len(y)),xe@b],axis=1)
        mean=q@p;J=np.zeros((4,b.size))
        for k in range(4):
            for l in range(1,4):
                J[k,(l-1)*X.shape[1]:l*X.shape[1]]=np.sum((q*p[:,k]*((k==l)-p[:,l]))[:,None]*xe,axis=0)
        means.append(mean);ifs.append(ib@J.T+q[:,None]*(p-mean));Js.append(J);preds.append(p)
    probs=np.r_[means[0],means[1]]
    if not np.all((probs>0)&(probs<1)):raise ValueError('invalid_probability')
    vals=joint.joint_metrics(probs)
    jac=np.zeros((11,8))
    for j in range(8):
        h=np.zeros(8);h[j]=1e-6
        jac[:,j]=(joint.joint_metrics(probs+h)-joint.joint_metrics(probs-h))/(2e-6)
    psi=np.column_stack(ifs)@jac.T
    audit.update(identity_error=float(abs(vals[8]-vals[9]-vals[10])),influence_identity_error=float(abs(psi[:,8]-psi[:,9]-psi[:,10]).max()),minimum_prediction=float(min(p.min() for p in preds)),max_abs_coefficient=float(abs(b).max()))
    assert audit['identity_error']<1e-10 and audit['influence_identity_error']<1e-9
    assert np.isfinite(vals).all() and np.isfinite(psi).all()
    if check:
        direction=np.arange(1,b.size+1,dtype=float);direction/=np.linalg.norm(direction)
        dif=direction.reshape(b.shape,order='F')
        pp=q@softmax(np.c_[np.zeros(len(y)),xx[0]@(b+1e-5*dif)],axis=1)
        pm=q@softmax(np.c_[np.zeros(len(y)),xx[0]@(b-1e-5*dif)],axis=1)
        audit['jacobian_error']=float(abs((pp-pm)/(2e-5)-Js[0]@direction).max())
        assert audit['jacobian_error']<1e-6
    return vals,psi,audit,b,probs

def covariance(psi,g,frame=None):
    if frame is None:
        fr=pd.DataFrame({'uid':g.uid,'stratum':1,'psu':g.household})
    else:fr=frame[['uid','stratum','psu']].copy()
    values=pd.DataFrame(psi,columns=range(psi.shape[1]));values['uid']=g.uid.to_numpy()
    fr=fr.merge(values,on='uid',how='left',validate='one_to_one').fillna({j:0 for j in range(psi.shape[1])})
    sums=fr.groupby(['stratum','psu'])[list(range(psi.shape[1]))].sum()
    V=np.zeros((psi.shape[1],psi.shape[1]));df=0
    for _,ss in sums.groupby(level=0):
        a=ss.to_numpy();m=len(a)
        assert m>=2
        a=a-a.mean(0);V+=m/(m-1)*a.T@a;df+=m-1
    return V,df

def main():
    sources=[OLD/'data/HRS_panel.pkl',OLD/'data/HRS_design.pkl',OLD/'results/joint_models.csv',OLD/'results/paired_models.csv',OLD/'03_build_panels.py',BASE/'paired_state_core/code/common.py',OLD/'audit/source_hashes.json',OLD/'audit/metadata.json']
    frozen={'started_utc':datetime.now(timezone.utc).isoformat(),'seed':SEED,'bootstrap_repetitions':B,'sources':{str(p):sha(p) for p in sources},'main_manuscripts':{p.name:sha(p) for p in [JCE/'manusript_V1.docx',JCE/'manusript_V1.doc',JCE/'manuscript_V1.1.docx']}}
    save_json(HERE/'pre_run_manifest.json',frozen)
    (HERE/'analysis_plan.md').write_text('''# HRS 2018 external application (exploratory extension)
HRS 2018 was already included in the 26-sample contextual scan. Its results are known; this is not a held-out or prospective validation. No selection by direction or significance is permitted.

Retain ages 50–79 and the source-reconciled contemporaneous outcomes. Primary contrast: current versus noncurrent smoking. Replicate the existing full-sample unweighted multinomial model; retain current versus never as reference sensitivity with former smokers in the fitted model and empirical target. The marginal model uses smoking-by-sex interaction, age B-splines (4 df), five-category RAND education. Conditional models retain linear age, sex, years of education for exact legacy comparison.

On the fixed positive-physical-weight/design-eligible sample, hold the spline basis from the full primary sample fixed. Cross fitting weights (unit or physical-measure) with target weights (unit or physical-measure), producing all four combinations. Weighted fits use the same multinomial likelihood with normalized weights. Target uncertainty is included in the influence functions. Variance sums paired influences within SECU nested in STRATUM, including zero contribution for other records in the component design frame; use t with PSU-minus-strata df. Full unweighted models retain household-clustered normal intervals.

Report all marginal risks, log ORs, Delta_m, C_U, C_V, conditional ORs and Delta_c; retain shared covariance. Apply the production checks: finite probabilities/logits/influences, state support, convergence, Hessian condition <=1e12, and estimate/influence additivity. These are computational checks, not evidence of a correct clinical model.

Run 500 rescaled stratified PSU bootstrap draws for the fully weighted model, seed 2026092801. In each stratum draw m-1 PSUs with replacement and multiply each original weight by m/(m-1) times its selection count. Hold spline knots fixed; refit and restandardize in each draw. Report every failure and the planned denominator, percentile intervals and numerical stability. Unknown real-world truth means coverage, bias and RMSE cannot be evaluated here. No bootstrap significance filtering or replacement draws.

Preserve original main documents. Do not export participant-level data. Stage result tables/figures and V1.1 integration recommendations separately.
''',encoding='utf-8')
    d=pd.read_pickle(sources[0]);frame=pd.read_pickle(sources[1]);assert d.uid.is_unique and frame.uid.is_unique
    flow=[];z=d.copy();prev=len(z)
    flow.append({'step':'Linked 2018 respondent frame','n':prev,'excluded':0})
    for label,cond in [('Age 50–79',z.age.between(50,79)),('Paired M and S',z[['M','S']].notna().all(axis=1)),('Smoking known',z.smoke_status.notna()),('Age, sex and education complete',z[['age','male','edu','edu3']].notna().all(axis=1))]:
        z=z.loc[cond.reindex(z.index)].copy();flow.append({'step':label,'n':len(z),'excluded':prev-len(z)});prev=len(z)
    g=z.reset_index(drop=True);assert len(g)==5798
    gw=g[(g.wt>0)&g.uid.isin(frame.uid)].copy().reset_index(drop=True);assert len(gw)==5648
    flow.append({'step':'Positive component weight and valid design','n':len(gw),'excluded':len(g)-len(gw)})
    pd.DataFrame(flow).to_csv(OUT/'sample_flow.csv',index=False)
    X,xx,info,_=prepare(g);Xw,xxw,_,_=prepare(gw,info=info)
    old=pd.read_csv(OLD/'results/joint_models.csv')
    results=[];audits=[];covs=[];probs=[];conditional=[];checks=[]
    cases=[('full_unweighted','noncurrent',g,X,xx,False,False,False),('full_never','never',g,*prepare(g,'never')[:2],False,False,False),('eligible_UU','noncurrent',gw,Xw,xxw,False,False,True),('eligible_WU','noncurrent',gw,Xw,xxw,True,False,True),('eligible_UW','noncurrent',gw,Xw,xxw,False,True,True),('eligible_WW','noncurrent',gw,Xw,xxw,True,True,True)]
    for case,ref,h,x,xs,fw,tw,survey in cases:
        w=h.wt.to_numpy() if fw else np.ones(len(h));q=h.wt.to_numpy() if tw else np.ones(len(h))
        vals,psi,audit,b,pr=marginal(x,xs,(2*h.M+h.S).to_numpy(int),w,q)
        V,df=covariance(psi,h,frame if survey else None);crit=t.ppf(.975,df) if survey else 1.96
        for i,name in enumerate(NAMES):
            se=np.sqrt(V[i,i]);results.append(dict(case=case,reference=ref,n=len(h),fit_weight='physical' if fw else 'unit',target_weight='physical' if tw else 'unit',metric=name,estimate=vals[i],se=se,lo=vals[i]-crit*se,hi=vals[i]+crit*se,df=df))
        for i in [8,9,10]:
            for j in [8,9,10]:covs.append(dict(case=case,row=NAMES[i],column=NAMES[j],covariance=V[i,j]))
        for e in range(2):
            for s,lab in enumerate(['00','V','U','11']):probs.append(dict(case=case,exposure=e,state=lab,probability=pr.reshape(2,4)[e,s]))
        audit.update(case=case,n=len(h),parameters=b.size,df=df,rank=int(np.linalg.matrix_rank(x)),minimum_exposure_sex_state_cell=int(h.groupby(['smoke','male']).apply(lambda hh:np.bincount((2*hh.M+hh.S).to_numpy(int),minlength=4).min(),include_groups=False).min()))
        audits.append(audit)
        if case.startswith('full_'):
            source=old[(old.programme=='HRS')&(old.reference==ref)]
            err=float(np.max(abs(source.estimate.to_numpy()-vals)));seerr=float(np.max(abs(source.se.to_numpy()-np.sqrt(np.diag(V)))));assert err<1e-8 and seerr<1e-7
            checks.append(dict(check='legacy_joint_'+ref,point_max_error=err,se_max_error=seerr))
        if case=='eligible_WW':boot_inputs=(b.copy(),vals.copy())
        print(case,'n',len(h),'Delta_m/C_U/C_V',np.round(vals[8:11],6).tolist(),flush=True)
    # Conditional comparisons exactly match legacy covariates and design variance.
    legacy=pd.read_csv(OLD/'results/paired_models.csv')
    for case,h,fw,survey,label in [('full_unweighted',g,False,False,'threshold_noncurrent_household'),('eligible_UU',gw,False,True,'weight_eligible_unweighted'),('eligible_WW',gw,True,True,'component_weighted')]:
        xb,_=binary.design(h);bm,im,cm=binary.fit_score(xb,h.M,h.wt if fw else None);bs,iss,cs=binary.fit_score(xb,h.S,h.wt if fw else None)
        assert cm and cs
        v=np.array([bm[1],bs[1],bs[1]-bm[1]]);ip=np.c_[im[:,1],iss[:,1],iss[:,1]-im[:,1]];V,df=covariance(ip,h,frame if survey else None);se=np.sqrt(np.diag(V));crit=t.ppf(.975,df) if survey else 1.96
        for j,name in enumerate(['logOR_M','logOR_S','delta_c']):conditional.append(dict(case=case,n=len(h),metric=name,estimate=v[j],se=se[j],lo=v[j]-crit*se[j],hi=v[j]+crit*se[j],df=df))
        r=legacy[(legacy.programme=='HRS')&(legacy.analysis==label)].iloc[0];assert abs(v[2]-r.delta)<1e-8 and abs(se[2]-r.se)<1e-8
    pd.DataFrame(results).to_csv(OUT/'marginal_estimates.csv',index=False);pd.DataFrame(conditional).to_csv(OUT/'conditional_estimates.csv',index=False)
    pd.DataFrame(covs).to_csv(OUT/'allocation_covariance.csv',index=False);pd.DataFrame(probs).to_csv(OUT/'standardized_state_probabilities.csv',index=False)
    save_json(OUT/'fit_diagnostics.json',audits);save_json(OUT/'legacy_reconciliation.json',checks)
    # State and weight diagnostics, no identifiers.
    cells=[]
    for scope,h in [('full',g),('eligible',gw)]:
        for group,hh in [('All',h),('Current',h[h.smoke==1]),('Noncurrent',h[h.smoke==0]),('Never',h[h.smoke_status==0]),('Former',h[h.smoke_status==1])]:
            for s,lab in enumerate(['00','V','U','11']):
                mask=(2*hh.M+hh.S)==s
                cells.append(dict(scope=scope,group=group,state=lab,n=int(mask.sum()),denominator=len(hh),percent=100*mask.mean(),weighted_percent=100*hh.loc[mask,'wt'].sum()/hh.wt.sum() if scope=='eligible' else np.nan))
    pd.DataFrame(cells).to_csv(OUT/'state_counts.csv',index=False)
    weight_summary={'n':len(gw),'weight_ess':float(gw.wt.sum()**2/(gw.wt**2).sum()),'strata':int(frame.stratum.nunique()),'psus':len(frame.groupby(['stratum','psu'])),'design_frame_n':len(frame),'min_weight':float(gw.wt.min()),'median_weight':float(gw.wt.median()),'max_weight':float(gw.wt.max()),'max_weight_share':float(gw.wt.max()/gw.wt.sum())}
    save_json(OUT/'weight_diagnostics.json',weight_summary)
    rng=np.random.default_rng(SEED);draws=[];start,point=boot_inputs
    stratum_units={s:np.sort(h.psu.unique()) for s,h in frame.groupby('stratum')}
    for rep in range(B):
        multiplier={}
        for s,units in stratum_units.items():
            m=len(units);counts=np.bincount(rng.integers(m,size=m-1),minlength=m)
            multiplier.update({(s,u):m/(m-1)*counts[k] for k,u in enumerate(units)})
        mult=np.array([multiplier[(s,u)] for s,u in zip(gw.stratum,gw.psu)]);w=gw.wt.to_numpy()*mult
        try:
            support=gw.loc[mult>0].groupby(['smoke','male']).apply(lambda a:np.bincount((2*a.M+a.S).to_numpy(int),minlength=4).min(),include_groups=False)
            if len(support)!=4 or support.min()==0:raise ValueError('zero_exposure_sex_state_cell')
            v,ip,a,_,_=marginal(Xw,xxw,(2*gw.M+gw.S).to_numpy(int),w,w,start,check=False)
            draws.append(dict(rep=rep+1,status='ok',delta_m=v[8],C_U=v[9],C_V=v[10],identity_error=a['identity_error'],hessian_condition=a['hessian_condition']))
        except Exception as exc:draws.append(dict(rep=rep+1,status=str(exc)))
        if (rep+1)%100==0:print('Bootstrap',rep+1,'/',B,flush=True)
    boot=pd.DataFrame(draws);boot.to_csv(OUT/'bootstrap_draws.csv',index=False)
    valid=boot[boot.status=='ok'];summ=[]
    for j,name in enumerate(NAMES[8:]):
        lo,hi=valid[name].quantile([.025,.975]);summ.append(dict(metric=name,point_estimate=point[j+8],successful=len(valid),planned=B,success_percent=100*len(valid)/B,bootstrap_sd=valid[name].std(),percentile_lo=lo,percentile_hi=hi))
    pd.DataFrame(summ).to_csv(OUT/'bootstrap_summary.csv',index=False)
    save_json(OUT/'completion.json',{'completed_utc':datetime.now(timezone.utc).isoformat(),'successes':len(valid),'planned':B,'failure_counts':boot.status.value_counts().to_dict(),'manuscript_hashes_unchanged':all(sha(JCE/p)==h for p,h in frozen['main_manuscripts'].items()),'source_hashes_unchanged':all(sha(Path(p))==h for p,h in frozen['sources'].items()),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'statsmodels':statsmodels.__version__})

if __name__=='__main__':main()
