# -*- coding: utf-8 -*-
"""
06_build_analysis_dataset.py
构建 CHARLS 主库分析用宽表（把详细暴露、行为改变、双结局整合到同一数据集中）
- 主结局：2011 -> 2015 新发高血压
- 时间外验结局：2011 -> 2013 新发高血压
- 行为改变治疗：2011 -> 2013 戒烟/开始运动/戒酒，结局 2013 -> 2015 新发高血压
输出：CHARLS/analysis/charls_analysis_wide.csv + 06_analysis_dataset_report.txt
"""
import pyreadstat
import pandas as pd
import numpy as np
from pathlib import Path

BASE = Path(r"D:\review_workspace\Statistical_Modeling\CHARLS")
CODE = BASE / "code"
OUT = BASE / "analysis"
OUT.mkdir(exist_ok=True)

def read(wave, fn, cols):
    f = BASE/wave/fn
    return pyreadstat.read_dta(f, usecols=cols)[0] if f.exists() else pd.DataFrame()

def clean_id(df):
    if "ID" in df.columns:
        df["ID"] = df["ID"].astype(str).str.strip()
    if "communityID" in df.columns:
        df["communityID"] = df["communityID"].astype(str).str.strip()
    return df

def num(df, cols):
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df

def bp_vars(df):
    for c in ["qa003","qa004","qa007","qa008","qa011","qa012"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df["sbp"] = df[["qa003","qa007","qa011"]].mean(axis=1, skipna=True)
    df["dbp"] = df[["qa004","qa008","qa012"]].mean(axis=1, skipna=True)
    df["ht_meas"] = (df["sbp"]>=140)|(df["dbp"]>=90)
    return df

def anthro(df):
    for c in ["qi002","ql002","qm002"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    if "qi002" in df.columns and "ql002" in df.columns:
        h = df["qi002"]/100
        df["bmi"] = df["ql002"]/(h**2)
        df["bmi"] = df["bmi"].where(df["bmi"].between(10,80))
    return df

# ---------- 2011 baseline ----------
demo11 = read("2011","demographic_background.dta", ["ID","communityID","ba002_1","rgender","bd001"])
health11 = read("2011","health_status_and_functioning.dta",
    ["ID","da007_1_","da011s1","da011s2","da059","da061","da063","da067","da068s1","da068s2","da068s3",
     "da051_2_","da051_3_"])
bio11 = read("2011","biomarkers.dta", ["ID","qa003","qa004","qa007","qa008","qa011","qa012","qi002","ql002","qm002"])
blood11 = read("2011","Blood_20140429.dta", ["ID","newglu","newhba1c","newcho","newhdl","newldl","newcrea"])
psu11 = read("2011","PSU.dta", ["communityID","urban_nbs"])

for df in [demo11, health11, bio11, blood11, psu11]:
    clean_id(df)

demo11 = num(demo11, ["ba002_1","rgender","bd001"])
demo11["age"] = 2011 - demo11["ba002_1"]
demo11["male"] = np.where(demo11["rgender"].eq(1),1.0,np.where(demo11["rgender"].eq(2),0.0,np.nan))
demo11["edu"] = demo11["bd001"]
psu11 = num(psu11, ["urban_nbs"])
psu11["urban"] = psu11["urban_nbs"]

health11 = num(health11, ["da007_1_","da011s1","da011s2","da059","da061","da063","da067","da068s1","da068s2","da068s3","da051_2_","da051_3_"])
# 2011 smoking status: 0 never, 1 former, 2 current
health11["smoke_status_11"] = np.where(health11["da061"].eq(1), 2,
                              np.where(health11["da061"].eq(2), 1,
                              np.where(health11["da059"].eq(2), 0, np.nan)))
health11["smoke_current_11"] = health11["smoke_status_11"].eq(2).astype(float)
health11["smoke_former_11"] = health11["smoke_status_11"].eq(1).astype(float)
health11["smoke_never_11"] = health11["smoke_status_11"].eq(0).astype(float)
health11["cig_per_day_11"] = health11["da063"]
# 2011 drinking
health11["drink_any_11"] = health11["da067"].isin([1,2]).astype(float)
health11["drink_monthly_11"] = health11["da067"].eq(1).astype(float)
health11["drink_liquor_11"] = health11["da068s1"].eq(1).astype(float)
health11["drink_beer_11"] = health11["da068s2"].eq(2).astype(float)
health11["drink_wine_11"] = health11["da068s3"].eq(3).astype(float)
# 2011 PA: 0 none, 1 walking only, 2 moderate or more
health11["pa_moderate_11"] = health11["da051_2_"].eq(1).astype(float)
health11["pa_walk_11"] = health11["da051_3_"].eq(1).astype(float)
health11["pa_level_11"] = np.where(health11["pa_moderate_11"].eq(1), 2,
                         np.where(health11["pa_walk_11"].eq(1), 1,
                         np.where(health11["da051_2_"].eq(2) & health11["da051_3_"].eq(2), 0, np.nan)))
health11["pa_any_11"] = health11["pa_level_11"].ge(1).astype(float)
# 2011 HT
health11["ht_dx_11"] = health11["da007_1_"].eq(1).astype(float)
health11["ht_med_11"] = (health11["da011s1"].eq(1) | health11["da011s2"].eq(2)).astype(float)

bio11 = bp_vars(bio11)
bio11 = anthro(bio11)
blood11 = num(blood11, ["newglu","newhba1c","newcho","newhdl","newldl","newcrea"])
blood11 = blood11.rename(columns={"newglu":"glu","newhba1c":"hba1c","newcho":"cho","newhdl":"hdl","newldl":"ldl","newcrea":"crea"})

base = demo11.merge(psu11[["communityID","urban"]], on="communityID", how="left")
base = base.merge(health11, on="ID", how="left").merge(bio11, on="ID", how="left").merge(blood11, on="ID", how="left")
base["ID_w23"] = base["ID"].str[:9] + base["ID"].str[9:].str.zfill(3)
base["ht_broad_11"] = (base["ht_meas"].fillna(False) | base["ht_dx_11"].eq(1) | base["ht_med_11"].eq(1))

# ---------- follow-up status function ----------
def smoke_current_fu(df):
    z = pd.to_numeric(df.get("zda059", pd.Series(np.nan, index=df.index)), errors="coerce")
    da059 = pd.to_numeric(df.get("da059", pd.Series(np.nan, index=df.index)), errors="coerce")
    da061 = pd.to_numeric(df.get("da061", pd.Series(np.nan, index=df.index)), errors="coerce")
    cur = np.where(z.notna(), z.eq(1).astype(float), da061.eq(1).astype(float))
    noncur = np.where(z.notna(), z.eq(2).astype(float),
                      (da059.eq(2) | da061.isin([2,3])).astype(float))
    out = pd.Series(np.where((cur==1)|(noncur==1), cur, np.nan), index=df.index)
    return out.astype(float)

def load_wave(wave):
    health = read(wave,"Health_Status_and_Functioning.dta",
        ["ID","zda059","da059","da061","da007_1_","da011s1","da011s2","da067","da068s1","da068s2","da068s3",
         "da051_1_","da051_2_","da051_3_"])
    bio = read(wave,"Biomarker.dta", ["ID","qa003","qa004","qa007","qa008","qa011","qa012"])
    for df in [health,bio]:
        clean_id(df)
    health = num(health, ["zda059","da059","da061","da007_1_","da011s1","da011s2","da067","da068s1","da068s2","da068s3","da051_1_","da051_2_","da051_3_"])
    health["smoke_current"] = smoke_current_fu(health)
    health["drink_any"] = health["da067"].isin([1,2]).astype(float)
    health["drink_monthly"] = health["da067"].eq(1).astype(float)
    health["drink_liquor"] = health["da068s1"].eq(1).astype(float)
    health["drink_beer"] = health["da068s2"].eq(2).astype(float)
    health["drink_wine"] = health["da068s3"].eq(3).astype(float)
    health["pa_vig_mod"] = (health["da051_1_"].eq(1) | health["da051_2_"].eq(1)).astype(float)
    health["pa_walk"] = health["da051_3_"].eq(1).astype(float)
    health["pa_level"] = np.where(health["pa_vig_mod"].eq(1), 2,
                         np.where(health["pa_walk"].eq(1), 1,
                         np.where(health["da051_1_"].eq(2) & health["da051_2_"].eq(2) & health["da051_3_"].eq(2), 0, np.nan)))
    health["pa_any"] = health["pa_level"].ge(1).astype(float)
    health["ht_dx"] = health["da007_1_"].eq(1).astype(float)
    health["ht_med"] = (health["da011s1"].eq(1) | health["da011s2"].eq(2)).astype(float)
    bio = bp_vars(bio)
    w = health.merge(bio[["ID","ht_meas"]], on="ID", how="outer")
    w["ht_broad"] = (w["ht_meas"].fillna(False) | w["ht_dx"].eq(1) | w["ht_med"].eq(1))
    return w

w13 = load_wave("2013")
w15 = load_wave("2015")

# rename wave-specific columns
w13 = w13.rename(columns={
    "smoke_current":"smoke_current_13","drink_any":"drink_any_13","drink_monthly":"drink_monthly_13",
    "drink_liquor":"drink_liquor_13","drink_beer":"drink_beer_13","drink_wine":"drink_wine_13",
    "pa_level":"pa_level_13","pa_any":"pa_any_13","ht_meas":"ht_meas_13","ht_dx":"ht_dx_13",
    "ht_med":"ht_med_13","ht_broad":"ht_broad_13"})
w15 = w15.rename(columns={
    "smoke_current":"smoke_current_15","drink_any":"drink_any_15","drink_monthly":"drink_monthly_15",
    "drink_liquor":"drink_liquor_15","drink_beer":"drink_beer_15","drink_wine":"drink_wine_15",
    "pa_level":"pa_level_15","pa_any":"pa_any_15","ht_meas":"ht_meas_15","ht_dx":"ht_dx_15",
    "ht_med":"ht_med_15","ht_broad":"ht_broad_15"})

w13_ids = ["ID"] + [c for c in w13.columns if c != "ID"]
w15_ids = ["ID"] + [c for c in w15.columns if c != "ID"]
wide = base.merge(w13[w13_ids], left_on="ID_w23", right_on="ID", how="left", suffixes=("","_13dup"))
# after merge, ID_x/ID_y issue; drop duplicate ID from right
wide = wide.drop(columns=["ID_y"], errors="ignore").rename(columns={"ID_x":"ID"})
wide = wide.merge(w15[w15_ids], left_on="ID_w23", right_on="ID", how="left", suffixes=("","_15dup"))
wide = wide.drop(columns=["ID_y"], errors="ignore").rename(columns={"ID_x":"ID"})

# ---------- behavior change 2011 -> 2013 ----------
wide["smoke_current_11"] = wide["smoke_status_11"].eq(2).astype(float)
wide["smoke_current_11"] = wide["smoke_current_11"].where(wide["smoke_status_11"].notna())
wide["smoke_change_11_13"] = np.where(wide["smoke_current_11"].eq(0) & wide["smoke_current_13"].eq(0), 0,
                             np.where(wide["smoke_current_11"].eq(1) & wide["smoke_current_13"].eq(0), 1,
                             np.where(wide["smoke_current_11"].eq(0) & wide["smoke_current_13"].eq(1), 2,
                             np.where(wide["smoke_current_11"].eq(1) & wide["smoke_current_13"].eq(1), 3, np.nan))))
wide["smoke_quit_11_13"] = (wide["smoke_current_11"].eq(1) & wide["smoke_current_13"].eq(0)).astype(float)
wide["smoke_start_11_13"] = (wide["smoke_current_11"].eq(0) & wide["smoke_current_13"].eq(1)).astype(float)

wide["drink_change_11_13"] = np.where(wide["drink_any_11"].eq(0) & wide["drink_any_13"].eq(0), 0,
                             np.where(wide["drink_any_11"].eq(1) & wide["drink_any_13"].eq(0), 1,
                             np.where(wide["drink_any_11"].eq(0) & wide["drink_any_13"].eq(1), 2,
                             np.where(wide["drink_any_11"].eq(1) & wide["drink_any_13"].eq(1), 3, np.nan))))
wide["drink_quit_11_13"] = (wide["drink_any_11"].eq(1) & wide["drink_any_13"].eq(0)).astype(float)
wide["drink_start_11_13"] = (wide["drink_any_11"].eq(0) & wide["drink_any_13"].eq(1)).astype(float)

wide["pa_change_11_13"] = np.where(wide["pa_any_11"].eq(0) & wide["pa_any_13"].eq(0), 0,
                          np.where(wide["pa_any_11"].eq(1) & wide["pa_any_13"].eq(0), 1,
                          np.where(wide["pa_any_11"].eq(0) & wide["pa_any_13"].eq(1), 2,
                          np.where(wide["pa_any_11"].eq(1) & wide["pa_any_13"].eq(1), 3, np.nan))))
wide["pa_start_11_13"] = (wide["pa_any_11"].eq(0) & wide["pa_any_13"].eq(1)).astype(float)
wide["pa_stop_11_13"] = (wide["pa_any_11"].eq(1) & wide["pa_any_13"].eq(0)).astype(float)

# ---------- outcomes and cohorts ----------
wide["y_meas_13"] = wide["ht_meas_13"].fillna(False).astype(int)
wide["y_broad_13"] = wide["ht_broad_13"].fillna(False).astype(int)
wide["y_meas_15"] = wide["ht_meas_15"].fillna(False).astype(int)
wide["y_broad_15"] = wide["ht_broad_15"].fillna(False).astype(int)

base_eligible = wide[(wide["age"]>=45) & (wide["sbp"].notna()) & (~wide["ht_broad_11"].fillna(False))].copy()
wide["cohort_11_13"] = ((wide.index.isin(base_eligible.index)) & wide["ht_meas_13"].notna()).astype(int)
wide["cohort_11_15"] = ((wide.index.isin(base_eligible.index)) & wide["ht_meas_15"].notna()).astype(int)
# 行为改变队列：2011 无高血压且可测血压，且 2013 仍无高血压且可测血压
wide["cohort_13_15"] = ((wide.index.isin(base_eligible.index)) & wide["ht_broad_13"].fillna(False).eq(False) & wide["ht_meas_13"].notna() & wide["ht_meas_15"].notna()).astype(int)

# ---------- save ----------
keep = ["ID","ID_w23","age","male","edu","urban","ht_broad_11",
        "sbp","dbp","bmi","qm002","glu","hba1c","cho","hdl","ldl","crea",
        "smoke_status_11","smoke_current_11","smoke_former_11","smoke_never_11","cig_per_day_11",
        "drink_any_11","drink_monthly_11","drink_liquor_11","drink_beer_11","drink_wine_11",
        "pa_level_11","pa_any_11",
        "smoke_current_13","drink_any_13","drink_monthly_13","drink_liquor_13","drink_beer_13","drink_wine_13","pa_level_13","pa_any_13",
        "smoke_current_15","drink_any_15","drink_monthly_15","drink_liquor_15","drink_beer_15","drink_wine_15","pa_level_15","pa_any_15",
        "smoke_change_11_13","smoke_quit_11_13","smoke_start_11_13",
        "drink_change_11_13","drink_quit_11_13","drink_start_11_13",
        "pa_change_11_13","pa_start_11_13","pa_stop_11_13",
        "ht_meas_13","ht_broad_13","y_meas_13","y_broad_13",
        "ht_meas_15","ht_broad_15","y_meas_15","y_broad_15",
        "cohort_11_13","cohort_11_15","cohort_13_15"]
keep = [c for c in keep if c in wide.columns]
wide[keep].to_csv(OUT/"charls_analysis_wide.csv", index=False, encoding="utf-8-sig")

# ---------- report ----------
lines=[]
def p(txt=""): lines.append(str(txt))
p("="*100)
p("CHARLS 分析宽表构建报告")
p(f"输出：{OUT/'charls_analysis_wide.csv'}")
p(f"总记录 n={len(wide):,}; 列数={len(keep)}")
p("")
p("各分析队列：")
for c in ["cohort_11_13","cohort_11_15","cohort_13_15"]:
    d=wide[wide[c]==1]
    p(f"  {c}: n={len(d):,}")
    if c=="cohort_11_13":
        p(f"    新发实测高血压 {int(d['y_meas_13'].sum()):,} ({100*d['y_meas_13'].mean():.2f}%); broad {int(d['y_broad_13'].sum()):,} ({100*d['y_broad_13'].mean():.2f}%)")
    if c=="cohort_11_15":
        p(f"    新发实测高血压 {int(d['y_meas_15'].sum()):,} ({100*d['y_meas_15'].mean():.2f}%); broad {int(d['y_broad_15'].sum()):,} ({100*d['y_broad_15'].mean():.2f}%)")
    if c=="cohort_13_15":
        p(f"    2013->2015 新发实测高血压 {int(d['y_meas_15'].sum()):,} ({100*d['y_meas_15'].mean():.2f}%); broad {int(d['y_broad_15'].sum()):,} ({100*d['y_broad_15'].mean():.2f}%)")
p("")
p("吸烟状态（2011 基线，45+无高血压且可测血压）")
d=wide[wide["cohort_11_15"]==1]
if len(d):
    p(f"  never {100*d['smoke_never_11'].mean():.1f}%, former {100*d['smoke_former_11'].mean():.1f}%, current {100*d['smoke_current_11'].mean():.1f}%")
    p(f"  每日吸烟量 median={d['cig_per_day_11'].median():.0f}, IQR {d['cig_per_day_11'].quantile(.25):.0f}-{d['cig_per_day_11'].quantile(.75):.0f}")
p("饮酒类型（2011，可多选）")
for c in ["drink_liquor_11","drink_beer_11","drink_wine_11"]:
    if c in d.columns:
        p(f"  {c}: {100*d[c].mean():.1f}%")
p("")
p("行为改变分布（2011->2013，在 2011 合格且 2013 可测血压人群中）")
d2=wide[(wide.index.isin(base_eligible.index)) & wide["ht_meas_13"].notna()]
for c in ["smoke_change_11_13","drink_change_11_13","pa_change_11_13"]:
    if c in d2.columns:
        p(f"  {c}: " + str(d2[c].value_counts(dropna=True).sort_index().to_dict()))
p("")
p("缺失率（cohort_11_15）")
for c in ["smoke_current_11","cig_per_day_11","drink_any_11","pa_any_11","bmi","glu","hba1c","cho","hdl","ldl","crea"]:
    if c in d.columns:
        p(f"  {c}: {d[c].isna().mean():.1%}")

report="\n".join(lines)
(CODE/"06_analysis_dataset_report.txt").write_text(report, encoding="utf-8")
print(report)