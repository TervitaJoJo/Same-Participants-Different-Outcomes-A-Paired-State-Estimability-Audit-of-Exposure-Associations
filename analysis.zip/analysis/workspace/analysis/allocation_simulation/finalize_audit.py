from pathlib import Path
import json,hashlib,traceback,warnings
import run_audited as r
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results_audited'
d=pd.read_csv(OUT/'replicate_results.csv');s=pd.read_csv(OUT/'summary.csv')
freeze=json.loads((OUT/'freeze_manifest.json').read_text(encoding='utf-8'))
checks={}
checks['audited_script_matches_frozen_hash']=hashlib.sha256((ROOT/'run_audited.py').read_bytes()).hexdigest()==freeze['script_sha256']
checks['protocol_matches_frozen_hash']=hashlib.sha256((ROOT/'protocol_v2.md').read_bytes()).hexdigest()==freeze['protocol_sha256']
checks['production_code_unchanged']=hashlib.sha256(r.SOURCE.read_bytes()).hexdigest()==freeze['source_sha256']
checks['all_manuscripts_unchanged']=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in freeze['manuscript_hashes'].items())
checks['no_duplicate_estimator_rows']=not d.duplicated(['scenario','n','replicate','method']).any()
checks['planned_dataset_count']=len(d[['scenario','n','replicate']].drop_duplicates())==10800
checks['all_cells_exactly_400_repetitions']=bool((d.groupby(['scenario','n','method']).size()==400).all())
checks['full_replicate_indices']=all(set(g.replicate)==set(range(400)) for _,g in d.groupby(['scenario','n','method']))
checks['correct_number_of_estimator_rows']=len(d)==14400
checks['failed_rows_have_no_estimates']=d[d.status!='ok'][[c for c in d if c.startswith(('est_','se_','low_','high_'))]].isna().all().all().item()
checks['all_conditional_coverages_use_estimable_denominators']=bool((s.coverage_all<=s.coverage_conditional+1e-12).all())
checks['identity_preserved']=bool(d.identity_error.max()<1e-10 and d.influence_identity_error.max()<1e-9)
recalc=r.summarize(d).sort_values(['scenario','n','method','estimand']).reset_index(drop=True)
saved=s.sort_values(['scenario','n','method','estimand']).reset_index(drop=True)
cols=['bias','bias_mcse','rmse','coverage_conditional','coverage_all','coverage_wilson_low','coverage_wilson_high','mean_interval_width','estimable_rate']
err=float(np.nanmax(abs(recalc[cols].to_numpy()-saved[cols].to_numpy())))
checks['independent_summary_recalculation']=err<1e-10
archive=ROOT/'debug_archive/initial_implementation'
archived=json.loads((archive/'archive_manifest.json').read_text())
checks['initial_debug_files_unchanged']=all(hashlib.sha256((ROOT/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in archived)

failure_details=[]
for _,row in d[d.status=='fit_or_check_failure'].iterrows():
    spec=next(x for x in r.SCENARIOS if x['name']==row.scenario)
    g=r.generate(spec,int(row.n),int(row.replicate))
    formula='smoke_status + x + I(x**2)' if row.method=='correct_quadratic' else 'smoke_status + x'
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore');r.joint.multinomial_marginal(g,formula)
        reason='not_reproduced'
    except Exception as exc:
        frames=traceback.extract_tb(exc.__traceback__)
        source_frames=[x for x in frames if Path(x.filename).resolve()==r.SOURCE.resolve()]
        frame=source_frames[-1] if source_frames else frames[-1]
        reason=f'{type(exc).__name__}: {frame.line}; {str(exc)}'
    failure_details.append({'scenario':row.scenario,'n':int(row.n),'replicate':int(row.replicate),'method':row.method,'recorded_status':row.status,'replayed_reason':reason})
pd.DataFrame(failure_details).to_csv(OUT/'fit_failure_diagnostics.csv',index=False)
checks['all_numerical_failures_reproduced']=all(x['replayed_reason']!='not_reproduced' for x in failure_details)
assert all(checks.values()),checks
report={'status':'passed','checks':checks,'summary_max_absolute_difference':err,'failure_diagnostic_replays':len(failure_details),'interpretation':'Failure-only deterministic replay diagnoses archived failures; it does not replace or extend the 400 planned repetitions per cell.'}
(OUT/'final_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
print(pd.DataFrame(failure_details).groupby('replayed_reason').size().to_string())
