from __future__ import annotations
import os
for env_name in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:
    os.environ[env_name]='1'
from pathlib import Path
import importlib.util,json,hashlib,time,platform,warnings,math
from concurrent.futures import ProcessPoolExecutor,as_completed
from datetime import datetime,timezone
import numpy as np
import pandas as pd
import scipy,statsmodels
from scipy.special import expit,logit,ndtr
from scipy.optimize import brentq
from scipy.stats import t as student_t

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent.parent
SOURCE=BASE/'paired_state_core/code/common.py'
spec=importlib.util.spec_from_file_location('manuscript_joint',SOURCE)
joint=importlib.util.module_from_spec(spec);spec.loader.exec_module(joint)
OUT=ROOT/'results_audited'
XVALUES=np.array([-1.,0.,1.]); XWEIGHTS=np.array([.25,.5,.25])
SEED=202609202
REPS=400
SIZES=[500,1000,2000]
P0=[.44,.14,.16,.26]; P1=[.39,.20,.13,.28]
SCENARIOS=[
 dict(name='moderate',p0=P0,p1=P1,prevalence=.5),
 dict(name='sparse',p0=[.52,.04,.04,.40],p1=[.47,.07,.03,.43],prevalence=.5),
 dict(name='very_sparse',p0=[.56,.002,.002,.436],p1=[.54,.004,.0015,.4545],prevalence=.5),
 dict(name='imbalanced',p0=P0,p1=P1,prevalence=.2),
 dict(name='near_boundary',p0=[.77,.14,.08,.01],p1=[.72,.22,.055,.005],prevalence=.5),
 dict(name='independent_indicators',kind='fixed_margins',theta=1.,prevalence=.5,saturated=True),
 dict(name='dependent_indicators',kind='fixed_margins',theta=8.,prevalence=.5,saturated=True),
 dict(name='nonlinear',p0=P0,p1=P1,prevalence=.5,quadratic=[1.3,-1.1,.9]),
 dict(name='clustered',p0=P0,p1=P1,prevalence=.5,cluster_size=25,rho=.4),
]
for scenario in SCENARIOS:
    goal=scenario['prevalence']
    scenario['propensity_intercept']=brentq(lambda a:np.dot(XWEIGHTS,expit(a+.8*XVALUES+.8*(XVALUES**2-.5)))-goal,-12,12)

def softmax_logits(eta):
    eta=np.column_stack([np.zeros(len(eta)),eta]);eta-=eta.max(1,keepdims=True)
    p=np.exp(eta);return p/p.sum(1,keepdims=True)

def generating_prob(s,e,x):
    e=np.asarray(e);x=np.asarray(x)
    if s.get('kind')=='fixed_margins':
        m=expit(np.where(e==0,logit(.40),logit(.48))+.6*x)
        r=expit(np.where(e==0,logit(.42),logit(.41))+.4*x)
        if s['theta']==1:
            both=m*r
        else:
            th=s['theta'];b=1+(th-1)*(m+r)
            both=2*th*m*r/(b+np.sqrt(b*b-4*(th-1)*th*m*r))
        return np.column_stack([1-m-r+both,r-both,m-both,both])
    p0=np.array(s['p0']);p1=np.array(s['p1'])
    a=np.log(p0[1:]/p0[0]);b=np.log(p1[1:]/p1[0])-a
    eta=a+e[:,None]*b+x[:,None]*np.array([.50,-.35,.65])
    if 'quadratic' in s:
        eta+=(x[:,None]**2-.5)*np.array(s['quadratic'])
    # Generating anchors are [00,U,V,11]; production code is [00,V,U,11].
    return softmax_logits(eta)[:,[0,2,1,3]]

def independent_metrics(q):
    q=np.asarray(q).reshape(2,4)
    m=q[:,2]+q[:,3];r=q[:,1]+q[:,3];u=q[:,2];v=q[:,1]
    args=[m,r,m-u,m+v]
    if any(np.any((a<=0)|(a>=1)) for a in args):
        raise ValueError('allocation logit outside strict interior')
    lm,ls,lu,lv=[np.log(a[1]/(1-a[1]))-np.log(a[0]/(1-a[0])) for a in args]
    return np.array([ls-lm,((lu-lm)+(ls-lv))/2,((lv-lm)+(ls-lu))/2])

def scenario_truth(s):
    q=np.array([XWEIGHTS@generating_prob(s,np.full(3,e),XVALUES) for e in [0,1]])
    metric=independent_metrics(q)
    prop=expit(s['propensity_intercept']+.8*XVALUES+.8*(XVALUES**2-.5))
    raw=np.array([((XWEIGHTS*(1-prop))@generating_prob(s,np.zeros(3),XVALUES))/(1-s['prevalence']),((XWEIGHTS*prop)@generating_prob(s,np.ones(3),XVALUES))/s['prevalence']])
    return {'scenario':s['name'],'delta':float(metric[0]),'CU':float(metric[1]),'CV':float(metric[2]),'standardized_probabilities_00_V_U_11':q.tolist(),'propensities':prop.tolist(),'marginal_indicator_OR':(q[:,0]*q[:,3]/(q[:,1]*q[:,2])).tolist(),'unstandardized_metrics':independent_metrics(raw).tolist(),'identity_error':float(abs(metric[0]-metric[1]-metric[2]))}

def copula_uniform(rng,clusters,rho):
    c=rng.normal(size=int(clusters.max())+1)
    return ndtr(np.sqrt(rho)*c[clusters]+np.sqrt(1-rho)*rng.normal(size=len(clusters)))

def generate(s,n,rep):
    si=[x['name'] for x in SCENARIOS].index(s['name'])
    rng=np.random.default_rng(np.random.SeedSequence([SEED,si,n,rep]))
    cluster=np.arange(n)//s.get('cluster_size',1)
    if 'cluster_size' in s:
        ux=copula_uniform(rng,cluster,s['rho'])
        ue=copula_uniform(rng,cluster,s['rho'])
        uy=copula_uniform(rng,cluster,s['rho'])
    else:
        ux=rng.random(n);ue=rng.random(n);uy=rng.random(n)
    x=XVALUES[np.searchsorted(np.cumsum(XWEIGHTS),ux)]
    e=(ue<expit(s['propensity_intercept']+.8*x+.8*(x*x-.5))).astype(int)
    q=generating_prob(s,e,x)
    y=(uy[:,None]>np.cumsum(q,axis=1)[:,:-1]).sum(1)
    g=pd.DataFrame({'smoke_status':2*e,'x':x,'M':y//2,'S':y%2,'strata':1,'cluster':cluster})
    return g

def support_check(g,saturated):
    e=(g.smoke_status.to_numpy()/2).astype(int);y=(2*g.M+g.S).to_numpy().astype(int)
    cells=np.bincount(e*4+y,minlength=8).reshape(2,4)
    if saturated:
        cells=np.bincount((e*3+(g.x.to_numpy()+1).astype(int))*4+y,minlength=24).reshape(6,4)
    if cells.min()==0:
        return 'zero_required_state_cell',int(cells.min())
    return None,int(cells.min())

def estimate(g,formula,saturated=False):
    fail,minimum=support_check(g,saturated)
    if fail:return {'status':fail,'minimum_required_cell':minimum}
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            vals,psi,audit=joint.multinomial_marginal(g,formula)
        if not np.isfinite(vals).all() or not np.isfinite(psi).all():
            return {'status':'nonfinite_estimate_or_influence','minimum_required_cell':minimum}
        if audit['hessian_condition']>1e12:
            return {'status':'ill_conditioned_hessian','minimum_required_cell':minimum}
        if not 0<audit['min_predicted_state_probability']<1:
            return {'status':'invalid_probability','minimum_required_cell':minimum}
        V,df=joint.cov_cluster(psi[:,8:11],g)
        if not np.isfinite(V).all() or np.any(np.diag(V)<=0):
            return {'status':'invalid_variance','minimum_required_cell':minimum}
        return {'status':'ok','estimate':vals[8:11],'se':np.sqrt(np.diag(V)),'df':df,'psi':psi[:,8:11],'minimum_required_cell':minimum,'audit':audit,'warning_count':len(caught)}
    except Exception as exc:
        return {'status':'fit_or_check_failure','reason':str(exc)[:240],'minimum_required_cell':minimum}

def run_batch(si,n,start,stop):
    s=SCENARIOS[si];target=scenario_truth(s);rows=[]
    for rep in range(start,stop):
        g=generate(s,n,rep)
        models=[('primary','C(smoke_status)*C(x)' if s.get('saturated') else 'smoke_status + x')]
        if s['name']=='nonlinear':models.append(('correct_quadratic','smoke_status + x + I(x**2)'))
        for model,formula in models:
            ans=estimate(g,formula,s.get('saturated',False))
            methods=[(model,1.96,ans.get('se'))]
            if s['name']=='clustered' and ans['status']=='ok':
                gp=g.assign(cluster=np.arange(n));Vi,_=joint.cov_cluster(ans['psi'],gp)
                methods.extend([('cluster_t',student_t.ppf(.975,ans['df']),ans['se']),('ignore_cluster',1.96,np.sqrt(np.diag(Vi)))])
            elif s['name']=='clustered':
                methods.extend([('cluster_t',np.nan,None),('ignore_cluster',1.96,None)])
            for method,critical,se in methods:
                row=dict(scenario=s['name'],n=n,replicate=rep,method=method,status=ans['status'],reason=ans.get('reason',''),minimum_required_cell=ans['minimum_required_cell'],clusters=g.cluster.nunique(),exposed_n=int((g.smoke_status==2).sum()),seed_entropy=f'{SEED},{si},{n},{rep}')
                for j,key in enumerate(['delta','CU','CV']):
                    row['target_'+key]=target[key]
                    row['est_'+key]=float(ans['estimate'][j]) if ans['status']=='ok' else np.nan
                    row['se_'+key]=float(se[j]) if ans['status']=='ok' else np.nan
                    row['low_'+key]=row['est_'+key]-critical*row['se_'+key]
                    row['high_'+key]=row['est_'+key]+critical*row['se_'+key]
                if ans['status']=='ok':
                    row.update(ans['audit'])
                    row.update(identity_error=abs(ans['estimate'][0]-ans['estimate'][1]-ans['estimate'][2]),influence_identity_error=float(abs(ans['psi'][:,0]-ans['psi'][:,1]-ans['psi'][:,2]).max()))
                    row['n']=n
                rows.append(row)
    return rows

def wilson(k,n):
    if not n:return np.nan,np.nan
    p=k/n;z=1.959963984540054;den=1+z*z/n
    mid=(p+z*z/(2*n))/den
    half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return mid-half,mid+half

def summarize(df):
    rows=[]
    for (scenario,n,method),g in df.groupby(['scenario','n','method'],sort=False):
        valid=g[g.status=='ok'];nv=len(valid);nr=len(g)
        for key in ['delta','CU','CV']:
            target=float(g['target_'+key].iloc[0]);error=valid['est_'+key]-target
            coverage=(valid['low_'+key].le(target)&valid['high_'+key].ge(target));nc=int(coverage.sum())
            cond=nc/nv if nv else np.nan;lo,hi=wilson(nc,nv)
            sd=error.std(ddof=1);mse=(error**2).mean();se=valid['se_'+key]
            rows.append(dict(scenario=scenario,n=n,method=method,estimand=key,target=target,repetitions=nr,estimable_n=nv,estimable_rate=nv/nr,failure_rate=1-nv/nr,bias=error.mean(),bias_mcse=sd/np.sqrt(nv) if nv else np.nan,empirical_sd=sd,standardized_bias=error.mean()/sd if sd>0 else np.nan,rmse=np.sqrt(mse),mean_se=se.mean(),root_mean_variance=np.sqrt((se**2).mean()),coverage_conditional=cond,coverage_all=nc/nr,coverage_mcse=np.sqrt(cond*(1-cond)/nv) if nv else np.nan,coverage_wilson_low=lo,coverage_wilson_high=hi,mean_interval_width=(valid['high_'+key]-valid['low_'+key]).mean(),median_minimum_required_cell=g.minimum_required_cell.median(),undercoverage_signal=bool(hi<.95) if nv else None))
    return pd.DataFrame(rows)

def freeze():
    validation=json.loads((ROOT/'pre_run_validation.json').read_text(encoding='utf-8'))
    assert validation['status']=='passed' and all(c['passed'] for c in validation['checks'])
    OUT.mkdir(exist_ok=True)
    if (OUT/'replicate_results.csv').exists():raise RuntimeError('Audited results already exist; do not silently overwrite.')
    truths=[scenario_truth(s) for s in SCENARIOS]
    (OUT/'truth.json').write_text(json.dumps(truths,indent=2),encoding='utf-8')
    manifest=dict(started_utc=datetime.now(timezone.utc).isoformat(),seed=SEED,repetitions=REPS,sizes=SIZES,scenarios=SCENARIOS,source=str(SOURCE),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),protocol_sha256=hashlib.sha256((ROOT/'protocol_v2.md').read_bytes()).hexdigest(),validation_sha256=hashlib.sha256((ROOT/'pre_run_validation.json').read_bytes()).hexdigest(),python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,statsmodels=statsmodels.__version__,manuscript_hashes={})
    for version in ['Differentiaion/manuscript_V1.docx','Differentiaion_V2/manuscript_V2.docx']:
        file=BASE.parent/'manuscript/research'/version
        manifest['manuscript_hashes'][str(file)]=hashlib.sha256(file.read_bytes()).hexdigest()
    (OUT/'freeze_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return manifest

def main():
    started=time.monotonic();manifest=freeze();rows=[];done=0
    jobs=[(si,n,start,min(start+40,REPS)) for si in range(len(SCENARIOS)) for n in SIZES for start in range(0,REPS,40)]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(run_batch,*job):job for job in jobs}
        for future in as_completed(futures):
            batch=future.result();rows.extend(batch);done+=1
            if done%20==0 or done==len(jobs):
                progress={'completed_batches':done,'total_batches':len(jobs),'completed_datasets':done*40,'elapsed_seconds':round(time.monotonic()-started,1)}
                (OUT/'progress.json').write_text(json.dumps(progress),encoding='utf-8')
                print(json.dumps(progress),flush=True)
    df=pd.DataFrame(rows).sort_values(['scenario','n','replicate','method'])
    df.to_csv(OUT/'replicate_results.csv',index=False)
    summary=summarize(df);summary.to_csv(OUT/'summary.csv',index=False)
    df[df.status!='ok'].groupby(['scenario','n','method','status']).size().rename('count').reset_index().to_csv(OUT/'failures.csv',index=False)
    checksum_checks={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in manifest['manuscript_hashes'].items()}
    complete={'status':'complete','datasets':len(SCENARIOS)*len(SIZES)*REPS,'estimator_rows':len(df),'summary_rows':len(summary),'elapsed_seconds':time.monotonic()-started,'max_identity_error':float(df.identity_error.max()),'max_influence_identity_error':float(df.influence_identity_error.max()),'manuscripts_unchanged':checksum_checks,'production_source_unchanged':hashlib.sha256(SOURCE.read_bytes()).hexdigest()==manifest['source_sha256'],'completed_utc':datetime.now(timezone.utc).isoformat()}
    (OUT/'completed.json').write_text(json.dumps(complete,indent=2),encoding='utf-8')
    print(json.dumps(complete),flush=True)

if __name__=='__main__':main()
