from pathlib import Path
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
import run_audited as r

checks=[]
def record(name,value,tolerance):
    checks.append({'check':name,'maximum_absolute_error':float(value),'tolerance':float(tolerance),'passed':bool(value<tolerance)})
    assert value<tolerance,(name,value,tolerance)

def independent_gradient(q):
    selectors=[np.array(s) for s in [[0,0,1,1],[0,1,0,1],[0,0,0,1],[0,1,1,1]]]
    grads=[]
    for s in selectors:
        p=q@s;d=np.array([-1,1])/(p*(1-p));grads.append((d[:,None]*s).ravel())
    lm,ls,lp,lu=grads
    return np.array([ls-lm,(lp-lm+ls-lu)/2,(lu-lm+ls-lp)/2])

counts=np.array([[220,80,70,130],[195,65,100,140]])
data=[]
for e in range(2):
    for y in range(4):
        for i in range(counts[e,y]):data.append((2*e,y//2,y%2))
g=pd.DataFrame(data,columns=['smoke_status','M','S']).assign(strata=1,cluster=np.arange(counts.sum()),x=0.)
ans=r.estimate(g,'smoke_status')
assert ans['status']=='ok'
q=counts/counts.sum(axis=1,keepdims=True)
record('exposure_only_point_estimates_vs_empirical_cells',np.max(abs(ans['estimate']-r.independent_metrics(q))),1e-10)
J=independent_gradient(q)
V=np.zeros((8,8))
for e in range(2):V[e*4:(e+1)*4,e*4:(e+1)*4]=(np.diag(q[e])-np.outer(q[e],q[e]))/counts[e].sum()
V*=len(g)/(len(g)-1)
expected=J@V@J.T
actual,_=r.joint.cov_cluster(ans['psi'],g)
record('exposure_only_influence_covariance_vs_closed_multinomial',np.max(abs(expected-actual)),1e-9)
record('full_influence_allocation_identity',np.max(abs(ans['psi'][:,0]-ans['psi'][:,1]-ans['psi'][:,2])),1e-9)

g=r.generate(r.SCENARIOS[0],3000,987654)
X=np.c_[np.ones(len(g)),g.smoke_status,g.x];y=(2*g.M+g.S).to_numpy()
fit=sm.MNLogit(y,X).fit(disp=False)
H=-fit.model.hessian(fit.params.ravel(order='F'))
record('covariance_matches_column_major_inverse_hessian',np.max(abs(fit.cov_params()-np.linalg.inv(H))),1e-10)
base=r.estimate(g,'smoke_status + x');assert base['status']=='ok'
diffs=[]
for index in [0,73,207,609,1704,2999]:
    without=r.estimate(g.drop(index).reset_index(drop=True),'smoke_status + x')
    assert without['status']=='ok'
    observed=(base['estimate']-without['estimate'])*(len(g)-1)/len(g)
    diffs.append(np.max(abs(observed-base['psi'][index])))
record('delete_one_full_estimator_influence_approximation',max(diffs),2e-5)

for s in r.SCENARIOS:
    truth=r.scenario_truth(s)
    record(s['name']+'_truth_identity',truth['identity_error'],1e-12)
    p=r.generating_prob(s,np.tile([0,1],3),np.repeat(r.XVALUES,2))
    record(s['name']+'_probability_normalization',np.max(abs(p.sum(1)-1)),1e-12)
    assert np.all(p>0)
    if s.get('kind')=='fixed_margins':
        or_joint=p[:,0]*p[:,3]/(p[:,1]*p[:,2])
        record(s['name']+'_conditional_OR',np.max(abs(or_joint-s['theta'])),1e-10)

t0=r.scenario_truth(r.SCENARIOS[5]);t1=r.scenario_truth(r.SCENARIOS[6])
record('dependence_pair_fixed_delta_truth',abs(t0['delta']-t1['delta']),1e-12)
q0=np.array(t0['standardized_probabilities_00_V_U_11']);q1=np.array(t1['standardized_probabilities_00_V_U_11'])
record('dependence_pair_preserves_M_margins',np.max(abs(q0[:,2:].sum(1)-q1[:,2:].sum(1))),1e-12)
record('dependence_pair_preserves_S_margins',np.max(abs(q0[:,[1,3]].sum(1)-q1[:,[1,3]].sum(1))),1e-12)

for si in [0,2,5,6,7,8]:
    rows=r.run_batch(si,500,10001,10002)
    checks.append({'check':'smoke_case_'+r.SCENARIOS[si]['name'],'statuses':[x['status'] for x in rows],'passed':True})

out=Path(__file__).resolve().parent/'pre_run_validation.json'
out.write_text(json.dumps({'status':'passed','checks':checks,'count':len(checks)},indent=2),encoding='utf-8')
print('Passed',len(checks),'numerical/structural checks; outputs:',out)
