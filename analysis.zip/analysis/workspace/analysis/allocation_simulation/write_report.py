from pathlib import Path
import json,hashlib
import pandas as pd
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results_audited'
s=pd.read_csv(OUT/'summary.csv');raw=pd.read_csv(OUT/'replicate_results.csv')
labels={'moderate':'常规中等不一致','sparse':'较稀疏U/V','very_sparse':'极稀疏U/V','imbalanced':'暴露比例20%','near_boundary':'共同阳性接近边界','independent_indicators':'指标条件独立','dependent_indicators':'指标条件相关（OR=8）','nonlinear':'遗漏非线性项','clustered':'存在社区内相关'}
methods={'primary':'主估计','correct_quadratic':'保留真实二次项','cluster_t':'聚类t区间','ignore_cluster':'忽略聚类的区间'}
def group(scenario,n,method='primary'):
    return s[(s.scenario==scenario)&(s.n==n)&(s.method==method)].set_index('estimand').loc[['delta','CU','CV']]
def pct(x):return f'{100*x:.2f}%'
def triple(x):return ' / '.join(f'{z:.4f}' for z in x)
def covtriple(x):return ' / '.join(f'{100*z:.2f}%' for z in x)
def table(keys,full=False):
    lines=['| 情景／区间方法 | n | 可估率 | 偏差：Δ / C_U / C_V | 条件覆盖率：Δ / C_U / C_V |','|---|---:|---:|---|---|']
    for scenario,n,method in keys:
        g=group(scenario,n,method)
        label=labels[scenario]+('；'+methods[method] if method!='primary' else '')
        lines.append(f'| {label} | {n:,} | {pct(g.estimable_rate.iloc[0])} | {triple(g.bias)} | {covtriple(g.coverage_conditional)} |')
    return '\n'.join(lines)

all_keys=[(sc,n,'primary') for sc in labels for n in [500,1000,2000]]
main_keys=[('moderate',500,'primary'),('moderate',2000,'primary'),('sparse',2000,'primary'),('imbalanced',2000,'primary'),('independent_indicators',2000,'primary'),('dependent_indicators',2000,'primary'),('nonlinear',2000,'primary'),('nonlinear',2000,'correct_quadratic'),('clustered',500,'primary'),('clustered',500,'cluster_t'),('clustered',2000,'primary'),('very_sparse',500,'primary'),('very_sparse',2000,'primary'),('near_boundary',500,'primary'),('near_boundary',2000,'primary')]
completed=json.loads((OUT/'completed.json').read_text())
report=f'''# U/V分配估计量有限样本模拟：首轮结果

## 核心判断

**这轮模拟为论文增加了有用的方法学证据，同时明确了不能越过的适用边界。** 在所设常规、正确指定的联合状态模型中，偏差较小，误差随样本量增大而下降，95%区间覆盖率大体接近名义水平。相关性本身没有使分配恒等式失效；极稀疏状态、少量聚类和遗漏与暴露有关的非线性项，是本轮观察到的实际风险。

这不是一项证明“任何数据都能可靠分配”的模拟，也不检验AI agent的临床诊断或纠偏能力。它检验论文中的统计估计量。**V1、V2及原有分析程序均未修改；未制作或插入图表。**

## 做了多少，如何保证比较公平

- 正式设计：9个生成情景 × 3个样本量（500、1,000、2,000）× 每格400次，共**10,800个生成数据集**。
- 非线性情景在同一数据集上比较遗漏二次项与正确模型；聚类情景比较原正态区间、聚类t区间与忽略聚类的诊断性区间。由此产生14,400行估计器结果，不计作14,400次独立模拟。
- 精确真值来自已知生成概率在三个协变量取值上的加权积分，不以拟合结果充当真值。
- 正式估计直接复用论文的联合状态程序，包含模型拟合、经验标准化及社区聚类的不确定性。
- 所有重复和失败均保留。每格400次时，接近95%的覆盖率约有1.1个百分点Monte Carlo标准误；完整汇总提供覆盖率Wilson区间，不能把几个百分点的波动当成精确适用阈值。

## 主要结果

下表的偏差单位为log OR。**条件覆盖率只针对实际可估的重复**；可估率较低时，不能单独引用该覆盖率评价性能。

{table(main_keys)}

### 1. 常规设定下，估计量有合理的有限样本表现

中等不一致和较稀疏U/V两个正确指定情景中，全部重复可估；三个量、三个样本量的条件覆盖率范围为**93.00%–96.75%**。这些情景的最大绝对平均偏差约0.011个log OR单位。

中等不一致情景中，n从500增至2,000，Δ的RMSE从0.2091降至0.1076，C_U从0.1486降至0.0769，C_V从0.1422降至0.0713。说明在这些设定下增加样本量确实提升精度。暴露比例20%的情景总体误差更大；n=500时C_V覆盖率为92.00%，应保留这一有限样本表现，不能一并写成完全校准。

### 2. 指标相关性不破坏代数分配，但会改变分配构成和数据支持

成对情景保持M、S的边际生成模型相同，将给定暴露和协变量后的M–S优势比设为1或8。两者的Δ真值均为−0.35223；C_U/C_V则分别约为−0.17420/−0.17803与−0.18607/−0.16616。这说明总差异相同，也可以对应不同的联合状态构成。

n=2,000时两个情景均100%可估；三个区间覆盖率分别为96.00%/97.00%/94.75%和95.25%/93.25%/95.75%。但n=500时，相关情景的饱和模型可估率为95.50%，条件独立情景为99.25%。因此“允许相关”并不等于“相关结构不影响有限样本支持”。

全部正式可估输出满足C_U+C_V=Δ，最大数值误差为{completed['max_identity_error']:.2e}。这一恒等式不要求M、S条件独立；本轮也没有把观测指标相关性等同于潜在临床误差的相关性。

### 3. 模型失配会产生系统偏差，增加n不能代替正确设定

在预设的非线性混杂情景中，真实Δ约−0.34609。n=2,000时，遗漏二次项的平均估计约−0.62295，偏差−0.27687。Δ、C_U、C_V覆盖率降至**30.75%、70.00%、37.00%**。

在同一批数据上，保留生成机制中的二次项，三个偏差约为−0.00046、0.00240、−0.00286，覆盖率为**96.00%、96.25%、94.25%**。这个正确模型是模拟前声明的参照，不是根据结果挑选的最佳模型；它也不意味着真实队列中必然知道正确函数形式。

分配在失配模型下仍精确加总，但加总正确不能保证估计接近总体真值。这是论文需要明确区分的两种“正确”。

### 4. 极稀疏状态会让成功拟合后的覆盖率具有误导性

极稀疏U/V情景中，可估率分别为**3.00%、16.75%、51.75%**。n=500时仅12/400次可估；这12次区间全部覆盖真值，不能据此宣称方法具有100%覆盖率。以全部400次为分母，“成功输出且覆盖”的比例仅3.00%。

共同阳性接近边界的情景，可估率随n从500至2,000由68.00%升至99.50%。主要阻断原因是所需暴露×状态单元为零，其余包括未收敛、奇异或病态Hessian。这里的结论针对当前无惩罚多项logit及其报告规则，不代表所有替代估计方法都不可能处理这些数据。

### 5. 聚类数量少时，部分分配区间偏窄

每社区25人时，n=500对应20个社区。原聚类正态区间的Δ/C_U/C_V覆盖率为95.00%/94.25%/90.75%。C_V覆盖率的Monte Carlo Wilson区间约87.51%–93.21%，支持存在欠覆盖。

换用事先列明的聚类t区间后，C_V覆盖率提高到92.75%，仍不能称为完全解决。n=2,000、80个社区时，原区间三个覆盖率为95.00%/95.75%/94.75%。这些是特定生成情景下的表现，不能据此制定“至少80个社区就一定可靠”的通用规定。

## 对论文质量的增量

现在可以增加一条有证据支持的方法学结果：**在有足够联合状态支持、合理模型设定和适当不确定性处理时，对称分配能够取得接近名义水平的覆盖率；代数恒等式并不免除对模型设定和有限样本支持的检查。**

相应的实践建议是同时检查暴露组×联合状态的数量、模型形式和有效聚类数，并报告无法估计的情景。它为“可审计的结局定义敏感性框架”提供了统计依据，不应写成“稳定消除了结局偏差”或“证明了因果贡献”。目前适合将这轮作为首轮方法学验证素材，先据结果调整叙事，不需要继续无边界扩展预测模型。

## 实现核查与变更记录

初始调试版本的梯度采用行优先参数排列，而statsmodels协方差采用列优先排列，导致区间错误。此前把异常先归因于标准化目标不一致的解释过早，**没有按该建议更换主要目标**。正式模拟仍评价总体标准化目标，并采用原论文程序完整的影响函数。

原论文程序本来就采用正确参数顺序，未受这个新模拟脚本错误影响。原四情景4,800次重复另以相同数据、相同真值进行只修复排列的重放，复现了原点估计和错误标准误，再隔离检查排列修复的作用。这批重放是调试证据，不与正式10,800次相加作为科学样本。

修订设计及增加情景在正式重复前固定，明确记录了先前调试结果已知，不追溯称为预注册。运行前34项数学／结构核对通过，闭式多项分布方差与影响函数计算一致；所有44次拟合或内部检查失败均按原种子重放核对原因，没有替换其原始结果。最终核对确认重复数、失败分母、摘要重算、源程序哈希及V1/V2哈希一致。

## 全部主情景汇总

{table(all_keys)}

所有比较方法的偏差、MCSE、RMSE、经验标准差、平均标准误、区间宽度、条件覆盖率、全部重复分母覆盖率及Wilson区间见[完整汇总CSV](results_audited/summary.csv)。原逐次数据见[逐次结果](results_audited/replicate_results.csv)。

## 文件

- [正式方案及修订理由](protocol_v2.md)
- [英文方法与结果素材](methods_results_en.md)
- [生成真值与状态概率](results_audited/truth.json)
- [运行前冻结记录](results_audited/freeze_manifest.json)
- [数学核对](pre_run_validation.json)
- [失败计数](results_audited/failures.csv)与[拟合失败诊断](results_audited/fit_failure_diagnostics.csv)
- [最终核对](results_audited/final_checks.json)
- [原四情景纠错重放](corrected_debug_replay/summary.csv)

模拟设计与报告参照：Morris, T. P., White, I. R. & Crowther, M. J. Using simulation studies to evaluate statistical methods. *Statistics in Medicine* 38, 2074–2102 (2019). https://doi.org/10.1002/sim.8086
'''
(ROOT/'report_zh.md').write_text(report,encoding='utf-8')

english='''# Simulation text for subsequent manuscript revision

These paragraphs are drafting material only. They have not been inserted into manuscript_V2.docx. Numerical results refer exclusively to the audited simulation, not the initial debugging implementation.

## Methods

We evaluated finite-sample behavior of the population-standardized definition gap and its symmetric U- and V-state allocations. Nine data-generating settings varied discordant-state frequency, exposure imbalance, joint-state boundary probabilities, dependence between the observed indicators, nonlinear covariate specification and within-cluster correlation. Each setting used sample sizes of 500, 1,000 and 2,000, with 400 repetitions per cell. A three-point covariate distribution allowed exact calculation of the population targets by integrating known generating probabilities. Exposure depended on both linear and quadratic covariate terms, and its marginal prevalence was fixed at 0.50 or 0.20.

Most settings generated the four states using multinomial logits. A paired dependence comparison held both outcome marginal models fixed while changing their conditional odds ratio from one to eight; saturated exposure-by-covariate models represented these finite-support joint distributions. The nonlinear setting compared an omitted-quadratic specification with its prespecified correctly specified counterpart on identical datasets. Clustered settings comprised 25 individuals per cluster, with Gaussian copulas inducing dependence while preserving the specified marginal probabilities.

Estimation reused the manuscript joint-state standardization routine. Influence functions included uncertainty in fitted parameters and the empirical standardization distribution, with aggregation at the participant or cluster level. Primary 95% intervals used the original normal critical value; cluster-t and participant-level intervals were retained as declared diagnostic comparators in the clustered setting. We recorded lack of support for finite unpenalized fits, nonconvergence, ill-conditioning and invalid variance rather than applying continuity corrections or selecting alternative estimators after observing performance.

Performance measures included bias, empirical standard deviation, root mean squared error, estimated standard errors, interval width and estimability. Coverage was reported both among estimable repetitions and with all planned repetitions in the denominator. Monte Carlo uncertainty was quantified using standard errors and Wilson intervals for coverage. At 400 repetitions, the Monte Carlo standard error of nominal 95% coverage is approximately 1.1 percentage points. The design was amended after an initial debugging run and fixed before the audited evaluation; original outputs and the implementation correction were preserved. No public preregistration was claimed.

## Results

Across correctly specified moderate and sparse-discordance settings, all repetitions were estimable, absolute biases were at most approximately 0.011 log-odds-ratio units, and coverage ranged from 93.00% to 96.75%. In the moderate setting, increasing the sample size from 500 to 2,000 reduced root mean squared error from 0.2091 to 0.1076 for the total gap, from 0.1486 to 0.0769 for the U allocation, and from 0.1422 to 0.0713 for the V allocation. Exposure imbalance increased uncertainty, with 92.00% coverage for the V allocation at n=500.

The dependence pair preserved the same population definition gap, −0.35223, while changing the two component allocations. At n=2,000, both settings were fully estimable; coverage for the total gap was 96.00% under conditional independence and 95.25% under conditional dependence. Dependence nevertheless affected finite-sample support: at n=500, the saturated dependent setting was estimable in 95.50% of repetitions, compared with 99.25% under independence. These comparisons concern dependence of observed indicators and do not identify dependence of errors relative to an unobserved clinical target.

Omitting a nonlinear covariate term under the specified exposure–covariate dependence produced persistent bias. At n=2,000, the total-gap bias was −0.2769, with coverage of 30.75%, 70.00% and 37.00% for the gap, U and V allocations. The prespecified correct quadratic model reduced the corresponding biases to −0.0005, 0.0024 and −0.0029, with coverage of 96.00%, 96.25% and 94.25%. The allocation identity remained exact under either fit, demonstrating that algebraic additivity and statistical accuracy are distinct properties.

Very sparse discordant states reduced estimability to 3.00%, 16.75% and 51.75% as n increased from 500 to 2,000. Reporting coverage only among successful fits would obscure this failure to return estimates. Near-boundary joint positivity similarly limited estimability to 68.00% at n=500, increasing to 99.50% at n=2,000. With 20 clusters, the V allocation's cluster-normal interval covered in 90.75% of repetitions; the declared cluster-t comparator increased this to 92.75%. With 80 clusters, cluster-normal coverage was 95.00%, 95.75% and 94.75% for the three quantities. These findings identify data-support, model-specification and small-cluster boundaries for the evaluated implementation, rather than universal sample-size thresholds.

## Interpretation boundary

The identity C_U+C_V=Delta follows from the observed joint probabilities without requiring independence of the two indicators. Accurate estimation of population-standardized probabilities and calibrated uncertainty remain separate requirements. This bounded simulation supports the implementation under specified settings and motivates explicit support and model checks; it does not establish robustness to arbitrary model misspecification, missingness, sampling designs or clinical measurement error.
'''
(ROOT/'methods_results_en.md').write_text(english,encoding='utf-8')

files=[ROOT/'report_zh.md',ROOT/'methods_results_en.md',ROOT/'protocol_v2.md',ROOT/'run_audited.py',ROOT/'pre_run_validation.json',ROOT/'README.md']+list(OUT.glob('*.json'))+list(OUT.glob('*.csv'))+[ROOT/'corrected_debug_replay/audit.json',ROOT/'corrected_debug_replay/summary.csv']
manifest={'status':'complete','authoritative_results':'results_audited','new_generated_datasets':10800,'debug_replay_datasets_not_pooled':4800,'manuscripts_modified':False,'figures_created':False,'files':[{'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(ROOT/'completion_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Report, English drafting text and completion manifest saved.')
