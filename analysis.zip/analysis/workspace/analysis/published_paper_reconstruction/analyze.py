"""Frozen-scope reconstruction, explicit QC sensitivity, paired definition contrasts."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,warnings,platform
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import expit
from scipy.optimize import minimize
from scipy.stats import chi2
import reference as r

ROOT=r.ROOT;OUT=ROOT/'results';COV=['age','male','education','urban','smoke_ever','drink','diabetes','dyslipidemia','heart','lipid_med']

def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def design(d,exposure,model):
    z=pd.DataFrame({'intercept':1.,'exposure':d[exposure]/10 if exposure=='cvai' else d[exposure]},index=d.index)
    if model>=2:z['age']=(d.age-60)/10;z['male']=d.male
    if model==3:
        for k in [1,2,3]:z['education_'+str(k)]=d.education.eq(k).astype(float)
        for c in COV[3:]:z[c]=d[c]
    return z.astype(float)

def fit(d,outcome,exposure,model,scope):
    columns=[outcome,exposure]+(COV[:2] if model==2 else COV if model==3 else [])
    g=d.dropna(subset=columns);y=g[outcome].astype(float);x=design(g,exposure,model)
    row={'scope':scope,'outcome':outcome,'exposure':exposure,'model':model,'n':len(g),'events':int(y.sum()),'prevalence':float(y.mean()) if len(g) else None}
    row['design_columns']=len(x.columns);row['rank']=int(np.linalg.matrix_rank(x)) if len(x) else 0
    if min(y.sum(),len(y)-y.sum())<10 or row['rank']<len(x.columns):return {**row,'status':'failed_count_or_rank'},None,g,x
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        try:
            result=sm.GLM(y,x,family=sm.families.Binomial()).fit(maxiter=100,tol=1e-10)
            beta=float(result.params['exposure']);se=float(result.bse['exposure'])
            warning_names=[type(w.message).__name__ for w in caught]
            good=result.converged and np.isfinite(result.params).all() and np.isfinite(result.cov_params()).all().all() and not any('PerfectSeparation' in w for w in warning_names)
            scale=10 if exposure=='cvai' else 1
            row.update(status='ok' if good else 'failed_convergence_or_separation',beta_per10_or_binary=beta,se_per10_or_binary=se,OR=float(np.exp(beta/scale)),ci_low=float(np.exp((beta-1.95996398454*se)/scale)),ci_high=float(np.exp((beta+1.95996398454*se)/scale)),OR_per10_or_binary=float(np.exp(beta)),p=float(result.pvalues['exposure']),warnings=warning_names,iterations=result.fit_history['iteration'],extreme_fitted_count=int(((result.fittedvalues<1e-8)|(result.fittedvalues>1-1e-8)).sum()))
            return row,result,g,x
        except Exception as exc:return {**row,'status':'error','error_type':type(exc).__name__,'message':str(exc)},None,g,x

def plausible(d):return d.qi002.between(100,210)&d.ql002.between(20,150)&d.qm002.between(40,150)

def variants(raw,o):
    yield 'primary_stated_SMT',o
    v=o.copy()
    for target,cols in [('sbp',['qa003','qa007','qa011']),('dbp',['qa004','qa008','qa012'])]:
        z=raw[cols].where(raw[cols].gt(0)&raw[cols].lt(993));v[target]=z.mean(axis=1)
    v['M']=r.ternary_or(v.sbp.ge(140).astype(float).where(v.sbp.notna()),v.dbp.ge(90).astype(float).where(v.dbp.notna()))
    v['SMT']=r.ternary_or(v['S'],v['M'],v['T']);yield 'available_BP_readings',v
    v=o.copy();v.loc[v.htn_med_skip.eq(1),'T']=np.nan;v.loc[v.lipid_med_skip.eq(1),'lipid_med']=np.nan
    v['SMT']=r.ternary_or(v['S'],v['M'],v['T']);yield 'medication_skips_unknown',v
    v=o.copy();v['smoke_ever']=v.smoke_current;yield 'current_smoking_covariate',v
    v=o.copy();re=raw.xrtype.eq(2);prior=raw.zda007_1_.eq(1)|raw.zda008_1_.eq(1)
    positive=re&((prior&raw.da007_w2_1_1_.eq(1))|(~prior&raw.da007_w2_1_1_.eq(2)))
    v.loc[positive|raw.da008_1_.eq(1),'S']=1.
    v['SMT']=r.ternary_or(v['S'],v['M'],v['T']);yield 'broad_reported_condition',v
    v=o.copy();v.loc[~plausible(raw),['cvai','cvai_high']]=np.nan;yield 'anthropometric_plausibility',v

def paired_bootstrap(d,raw,scope):
    common=d.age.ge(45)&d[COV+['cvai','cvai_high','S','M','T']].notna().all(axis=1)
    g=d.loc[common];rows=[]
    for target in ['S','M','MT','SMT']:
        for exposure in ['cvai','cvai_high']:
            row,_,_,_=fit(g,target,exposure,3,scope);rows.append(row)
    # Paired cluster bootstrap, fixed covariates/sample. Percentile intervals are descriptive.
    x=design(g,'cvai',3).to_numpy();ys=g[['S','M','MT','SMT']].to_numpy()
    clusters=raw.loc[g.index,'communityID'].astype(str)
    if clusters.isna().any() or clusters.eq('').any():raise ValueError('Missing community cluster')
    codes,unique=pd.factorize(clusters);k=len(unique);rng=np.random.default_rng(20260920)
    init=[sm.GLM(ys[:,j],x,family=sm.families.Binomial()).fit().params for j in range(4)]
    def calc(y,w,start):
        # Same likelihood and estimand as primary models; avoid treating a
        # Newton-CG precision-loss flag as statistical bootstrap nonconvergence.
        try:
            with warnings.catch_warnings(record=True) as ww:
                warnings.simplefilter('always')
                f=sm.GLM(y,x,family=sm.families.Binomial(),freq_weights=w).fit(start_params=start,maxiter=100,tol=1e-9)
            if not f.converged or not np.isfinite(f.params).all() or any('PerfectSeparation' in type(t.message).__name__ for t in ww):return np.nan
            return f.params[1]
        except (ValueError,np.linalg.LinAlgError):return np.nan
    bs=[]
    for i in range(500):
        w=rng.multinomial(k,np.ones(k)/k)[codes]
        bs.append([calc(ys[:,j],w,init[j]) for j in range(4)])
        if (i+1)%100==0:print(f'{scope}: {i+1}/500 paired cluster resamples',flush=True)
    a=np.array(bs);pd.DataFrame(a,columns=['S','M','MT','SMT']).to_csv(OUT/(scope+'_bootstrap.csv'),index=False)
    contrasts=[]
    for name,j,i in [('M_minus_S',1,0),('MT_minus_M',2,1),('SMT_minus_MT',3,2),('SMT_minus_M',3,1)]:
        z=a[:,j]-a[:,i];z=z[np.isfinite(z)]
        contrasts.append({'scope':scope,'contrast':name,'n':len(g),'community_clusters':k,'delta_log_OR_per10':float(init[j][1]-init[i][1]),'ci_low':float(np.quantile(z,.025)) if len(z)>=450 else None,'ci_high':float(np.quantile(z,.975)) if len(z)>=450 else None,'successful_resamples':len(z),'planned_resamples':500,'interval_type':'paired community cluster percentile; unadjusted descriptive'})
    return rows,contrasts

def rcs(d,scope):
    g=d.loc[d.age.ge(45)].dropna(subset=['SMT','cvai']+COV)
    k=np.quantile(g.cvai,[.1,.5,.9]);x=design(g,'cvai',3);v=g.cvai.to_numpy()
    term=(np.maximum(v-k[0],0)**3 -np.maximum(v-k[1],0)**3*(k[2]-k[0])/(k[2]-k[1])+np.maximum(v-k[2],0)**3*(k[1]-k[0])/(k[2]-k[1]))/(k[2]-k[0])**2
    x['nonlinear']=term/10
    with warnings.catch_warnings(record=True) as ws:
        f=sm.GLM(g.SMT,x,family=sm.families.Binomial()).fit(maxiter=100)
    return {'scope':scope,'n':len(g),'knots':k.tolist(),'nonlinearity_wald_p':float(f.pvalues['nonlinear']),'converged':bool(f.converged),'warnings':[str(w.message) for w in ws],'cutoff_discovery':'not reproduced: executable selection algorithm unavailable','reference_cutoff':108.88}

def main():
    OUT.mkdir(exist_ok=True)
    current=json.loads((ROOT/'candidate_current.json').read_text(encoding='utf-8'))
    assert current['status']['state'] in ['candidate_response_received','transport_rejected','transport_failed','no_answer']
    # Output or failure has been archived before any outcome model is fit.
    freeze=json.loads((ROOT/'freeze_manifest.json').read_text(encoding='utf-8'))
    for p,h in freeze['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
    raw=pd.read_pickle(ROOT/'organizer_only/local_input.pkl');o=pd.read_pickle(ROOT/'organizer_only/reference_output.pkl')
    rows=[];flows=[];all_variants={}
    for name,v in variants(raw,o):
        all_variants[name]=v
        flows.extend([{'scope':name,**f} for f in r.sample_flow(raw,v)])
        d=v[v.age.ge(45)&v.cvai.notna()&v.SMT.notna()]
        for exposure in ['cvai','cvai_high']:
            for model in [1,2,3]:
                row,_,_,_=fit(d,'SMT',exposure,model,name);rows.append(row)
        print(name+': models saved in memory',flush=True)
    primary=all_variants['primary_stated_SMT'];common=primary.age.ge(45)&primary[['SMT','cvai']+COV].notna().all(axis=1)
    for model in [1,2,3]:
        for exposure in ['cvai','cvai_high']:rows.append(fit(primary[common],'SMT',exposure,model,'primary_common_model_sample')[0])
    contrasts=[]
    for name,v in [('common_definitions',o),('common_definitions_plausible',all_variants['anthropometric_plausibility'])]:
        rr,cc=paired_bootstrap(v,raw,name);rows.extend(rr);contrasts.extend(cc)
    pd.DataFrame(rows).to_csv(OUT/'models.csv',index=False);pd.DataFrame(flows).to_csv(OUT/'sample_flows.csv',index=False);pd.DataFrame(contrasts).to_csv(OUT/'paired_definition_contrasts.csv',index=False)
    write(OUT/'spline_results.json',[rcs(o,'primary'),rcs(all_variants['anthropometric_plausibility'],'plausibility')])
    # Descriptive tables include variable-specific n and missingness.
    table=o.copy()
    for name,col in [('glucose_mgdl','bl_glu'),('creatinine_mgdl','bl_crea'),('uric_acid_mgdl','bl_ua'),('TG_mgdl','bl_tg'),('cholesterol_mgdl','bl_cho'),('HDL_mgdl','bl_hdl'),('LDL_mgdl','bl_ldl'),('height_cm','qi002'),('weight_kg','ql002')]:table[name]=raw[col].where(raw[col].gt(0)&raw[col].lt(993))
    desc=[]
    continuous=['age','bmi','waist','sbp','dbp','cvai','glucose_mgdl','creatinine_mgdl','uric_acid_mgdl','TG_mgdl','cholesterol_mgdl','HDL_mgdl','LDL_mgdl','height_cm','weight_kg']
    categorical=['male','education','urban','smoke_ever','drink','diabetes','dyslipidemia','heart','lipid_med']
    for scope,mask in [('primary_eligible',o.eligible.eq(1)),('primary_model3',common)]:
        for label,part in [('all',mask),('hypertension',mask&o.SMT.eq(1)),('no_hypertension',mask&o.SMT.eq(0))]:
            g=table.loc[part]
            for c in continuous:desc.append({'scope':scope,'group':label,'variable':c,'level':'continuous','n':int(g[c].count()),'missing':int(g[c].isna().sum()),'mean':g[c].mean(),'sd':g[c].std(),'median':g[c].median(),'min':g[c].min(),'max':g[c].max()})
            for c in categorical:
                for value,n in g[c].value_counts(dropna=False).items():desc.append({'scope':scope,'group':label,'variable':c,'level':str(value),'n':int(n),'group_n':len(g),'percent_of_group':100*n/len(g)})
    pd.DataFrame(desc).to_csv(OUT/'table1_reconstruction.csv',index=False)
    mask=o.age.ge(45)&o.cvai.notna();joint=o.loc[mask,['S','M','T']].fillna(-1).value_counts().reset_index(name='n');joint.to_csv(OUT/'joint_outcome_counts.csv',index=False)
    qc={'age_cvai_eligible':int(mask.sum()),'implausible_anthropometry_n':int((mask&~plausible(raw)).sum()),'height_outside_bounds':int((mask&~raw.qi002.between(100,210)).sum()),'weight_outside_bounds':int((mask&~raw.ql002.between(20,150)).sum()),'waist_outside_bounds':int((mask&~raw.qm002.between(40,150)).sum()),'tg_topcoded_n':int((mask&raw.bl_top_coding_tg.eq(1)).sum()),'not_fasting_n':int((mask&raw.bl_fasting.eq(2)).sum()),'htn_med_conflicts_n':int(o.htn_med_conflict.sum()),'lipid_med_conflicts_n':int(o.lipid_med_conflict.sum()),'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'statsmodels':sm.__version__,'created_at_utc':datetime.now(timezone.utc).isoformat(),'candidate_run_before_models':current['run']}
    write(OUT/'analysis_audit.json',qc)
    print(json.dumps(qc),flush=True)

if __name__=='__main__':main()
