from datetime import datetime,timezone
from pathlib import Path
import hashlib,json
import reference as r

def main():
    freeze=json.loads((r.ROOT/'freeze_manifest.json').read_text(encoding='utf-8'))
    for p,h in freeze['files'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
    d,join=r.load_input();o=r.transform(d)
    local=r.ROOT/'organizer_only'
    d.to_pickle(local/'local_input.pkl');o.to_pickle(local/'reference_output.pkl')
    report={'created_at_utc':datetime.now(timezone.utc).isoformat(),'joins':join,'flow':r.sample_flow(d,o),'raw_input_columns':list(d.columns),'nonmissing':o.notna().sum().to_dict(),'target_counts':{c:o.loc[o.age.ge(45)&o.cvai.notna(),c].value_counts(dropna=False).rename(index=str).to_dict() for c in ['S','M','T','SMT']},'models_computed':False}
    (local/'preflight.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'joins':join,'flow':report['flow'],'target_counts':report['target_counts'],'nonmissing':report['nonmissing']},ensure_ascii=False))

if __name__=='__main__':main()
