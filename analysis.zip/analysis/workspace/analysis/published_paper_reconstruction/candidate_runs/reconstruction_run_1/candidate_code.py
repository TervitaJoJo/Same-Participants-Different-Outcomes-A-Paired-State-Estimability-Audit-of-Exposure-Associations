import numpy as np
import pandas as pd


def physician_status(interview, prior, prior_awareness, direct, confirmation, since):
    result = pd.Series(np.nan, index=interview.index, dtype='float64')
    new = interview.eq(1)
    follow = interview.eq(2)
    positive_preload = prior.eq(1) | prior_awareness.eq(1)
    negative_route = (
        (positive_preload & confirmation.eq(2))
        | (~positive_preload & confirmation.eq(1))
    )
    result.loc[new & direct.eq(2)] = 0.0
    result.loc[new & direct.eq(1)] = 1.0
    result.loc[follow & negative_route & since.eq(2)] = 0.0
    result.loc[follow & prior.eq(1) & confirmation.eq(1)] = 1.0
    result.loc[follow & since.eq(1)] = 1.0
    return result


def medication_status(items, none_code, other_code, verified_negative):
    medicine = items.isin([1, 2]).any(axis=1)
    none_selected = items.eq(none_code).any(axis=1)
    other_selected = items.eq(other_code).any(axis=1)
    conflict = none_selected & (medicine | other_selected)
    skip = items.isna().all(axis=1) & verified_negative
    result = pd.Series(np.nan, index=items.index, dtype='float64')
    result.loc[none_selected | other_selected] = 0.0
    result.loc[medicine] = 1.0
    result.loc[skip] = 0.0
    result.loc[conflict] = np.nan
    return result, skip.astype('int64'), conflict.astype('int64')


def complete_bp_mean(readings):
    values = readings.astype('float64')
    valid = values.where(values.gt(0) & values.lt(993))
    return valid.mean(axis=1).where(valid.notna().all(axis=1))


def threshold_status(values, cutoff):
    return values.ge(cutoff).astype('float64').where(values.notna())


def ternary_or(components):
    result = pd.Series(np.nan, index=components.index, dtype='float64')
    result.loc[components.eq(0).all(axis=1)] = 0.0
    result.loc[components.eq(1).any(axis=1)] = 1.0
    return result


def transform(d):
    uid = d['ID'].astype('string').str.strip()
    if uid.isna().any() or uid.eq('').any() or uid.duplicated().any():
        raise ValueError('ID must be nonmissing, nonempty and unique after stripping.')
    uid = uid.astype(object)

    birth = d['ba002_1'].where(
        d['ba002'].eq(2),
        d['ba004_w3_1'].where(d['ba002'].eq(1))
    ).astype('float64')
    birth = birth.where(np.isfinite(birth) & birth.ge(1900) & birth.le(2015))
    age = 2015.0 - birth
    male = d['ba000_w2_3'].map({1: 1.0, 2: 0.0}).astype('float64')

    education_code = d['bd001_w2_4'].where(
        d['bd001_w2_4'].ne(12), d['edu_prior']
    )
    education = education_code.map({
        1: 0.0, 2: 1.0, 3: 1.0, 4: 1.0, 5: 2.0,
        6: 3.0, 7: 3.0, 8: 3.0, 9: 3.0, 10: 3.0, 11: 3.0
    }).astype('float64')
    urban = d['bb001_w3_2'].map({
        1: 1.0, 2: 1.0, 3: 1.0, 4: 1.0, 5: 1.0, 6: 0.0, 7: 0.0
    }).astype('float64')

    height = d['qi002'].astype('float64')
    height = height.where(np.isfinite(height) & height.gt(0) & height.le(210))
    weight = d['ql002'].astype('float64')
    weight = weight.where(np.isfinite(weight) & weight.gt(0) & weight.le(150))
    bmi = weight / ((height / 100.0) ** 2)
    bmi = bmi.where(np.isfinite(bmi))
    waist = d['qm002'].astype('float64')
    waist = waist.where(np.isfinite(waist) & waist.gt(0) & waist.lt(993))

    tg = d['bl_tg'].astype('float64')
    tg = tg.where(np.isfinite(tg) & tg.gt(0)) / 88.57
    hdl = d['bl_hdl'].astype('float64')
    hdl = hdl.where(np.isfinite(hdl) & hdl.gt(0)) / 38.67
    log_tg = np.log10(tg)
    male_cvai = (
        -267.93 + 0.68 * age + 0.03 * bmi + 4.00 * waist
        + 22.00 * log_tg - 16.32 * hdl
    )
    female_cvai = (
        -187.32 + 1.71 * age + 4.23 * bmi + 1.12 * waist
        + 39.76 * log_tg - 11.66 * hdl
    )
    cvai = male_cvai.where(male.eq(1), female_cvai.where(male.eq(0)))
    cvai = cvai.where(np.isfinite(cvai))
    cvai_high = threshold_status(cvai, 108.88)

    sbp = complete_bp_mean(d[['qa003', 'qa007', 'qa011']])
    dbp = complete_bp_mean(d[['qa004', 'qa008', 'qa012']])
    M = ternary_or(pd.concat([
        threshold_status(sbp, 140.0), threshold_status(dbp, 90.0)
    ], axis=1))

    S = physician_status(
        d['xrtype'], d['zda007_1_'], d['zda008_1_'],
        d['da007_1_'], d['da007_w2_1_1_'], d['da007_w2_2_1_']
    )
    absent_awareness = pd.Series(np.nan, index=d.index, dtype='float64')
    dyslipidemia = physician_status(
        d['xrtype'], d['zda007_2_'], absent_awareness,
        d['da007_2_'], d['da007_w2_1_2_'], d['da007_w2_2_2_']
    )
    diabetes = physician_status(
        d['xrtype'], d['zda007_3_'], absent_awareness,
        d['da007_3_'], d['da007_w2_1_3_'], d['da007_w2_2_3_']
    )
    heart = physician_status(
        d['xrtype'], d['zda007_7_'], absent_awareness,
        d['da007_7_'], d['da007_w2_1_7_'], d['da007_w2_2_7_']
    )

    T, htn_med_skip, htn_med_conflict = medication_status(
        d[['da011s1', 'da011s2', 'da011s3']],
        3, np.nan, S.eq(0) & ~d['da008_1_'].eq(1)
    )
    lipid_med, lipid_med_skip, lipid_med_conflict = medication_status(
        d[['da010_2_s1', 'da010_2_s2', 'da010_2_s3', 'da010_2_s4']],
        4, 3, dyslipidemia.eq(0)
    )
    MT = ternary_or(pd.concat([M, T], axis=1))
    SMT = ternary_or(pd.concat([S, M, T], axis=1))

    smoke_ever = d['da059'].map({1: 1.0, 2: 0.0}).astype('float64')
    smoke_ever = smoke_ever.mask(smoke_ever.isna() & d['zda059'].eq(1), 1.0)
    smoke_ever = smoke_ever.mask(d['da061'].isin([1, 2]), 1.0)
    smoke_ever = smoke_ever.mask(d['da061'].eq(3), 0.0)
    smoke_current = d['da061'].map({1: 1.0, 2: 0.0, 3: 0.0}).astype('float64')
    smoke_current = smoke_current.mask(smoke_current.isna() & smoke_ever.eq(0), 0.0)
    drink = d['da067'].map({1: 1.0, 2: 1.0, 3: 0.0}).astype('float64')
    eligible = (age.ge(45) & cvai.notna() & SMT.notna()).astype('int64')

    return pd.DataFrame({
        'uid': uid,
        'age': age,
        'male': male,
        'education': education,
        'urban': urban,
        'bmi': bmi,
        'waist': waist,
        'tg': tg,
        'hdl': hdl,
        'cvai': cvai,
        'cvai_high': cvai_high,
        'sbp': sbp,
        'dbp': dbp,
        'S': S,
        'M': M,
        'T': T,
        'MT': MT,
        'SMT': SMT,
        'smoke_ever': smoke_ever,
        'smoke_current': smoke_current,
        'drink': drink,
        'diabetes': diabetes,
        'dyslipidemia': dyslipidemia,
        'heart': heart,
        'lipid_med': lipid_med,
        'htn_med_skip': htn_med_skip,
        'lipid_med_skip': lipid_med_skip,
        'htn_med_conflict': htn_med_conflict,
        'lipid_med_conflict': lipid_med_conflict,
        'eligible': eligible
    }, index=d.index)


def sample_flow(d, o):
    if len(d) != len(o) or not d.index.equals(o.index):
        raise ValueError('o must preserve the input index and row count.')
    keep = np.ones(len(d), dtype=bool)
    result = [{'stage': 'initial', 'remaining_n': int(len(d)), 'excluded_n': 0}]
    stages = [
        ('known_age', o['age'].notna().to_numpy(dtype=bool)),
        ('age_45plus', o['age'].ge(45).to_numpy(dtype=bool)),
        ('complete_cvai', o['cvai'].notna().to_numpy(dtype=bool)),
        ('known_hypertension_SMT', o['SMT'].notna().to_numpy(dtype=bool))
    ]
    for stage, mask in stages:
        previous_n = int(keep.sum())
        keep = keep & mask
        remaining_n = int(keep.sum())
        result.append({
            'stage': stage,
            'remaining_n': remaining_n,
            'excluded_n': int(previous_n - remaining_n)
        })
    return result
