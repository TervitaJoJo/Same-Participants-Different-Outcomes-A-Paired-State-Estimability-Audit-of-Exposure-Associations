"""Meaningful data/estimation invariants, separate from numerical target matching."""
import itertools,json
from pathlib import Path
import numpy as np
import pandas as pd
import reference as r

def main():
    d=pd.read_pickle(r.ROOT/'organizer_only/local_input.pkl');o=pd.read_pickle(r.ROOT/'organizer_only/reference_output.pkl')
    checks={}
    before=d.copy(deep=True);z=r.transform(d)
    pd.testing.assert_frame_equal(d,before);checks['input_not_mutated']=True
    pd.testing.assert_frame_equal(z,o);checks['reference_reproducible']=True
    ds=d.sample(frac=1,random_state=77);pd.testing.assert_frame_equal(r.transform(ds),o.loc[ds.index]);checks['row_order_invariance']=True
    for triple in itertools.product([0.,1.,np.nan],repeat=3):
        expected=1. if 1. in triple else 0. if all(v==0 for v in triple) else np.nan
        got=r.ternary_or(*[pd.Series([v]) for v in triple])[0]
        assert (pd.isna(got) and pd.isna(expected)) or got==expected,triple
    checks['ternary_union_27_combinations']=True
    checks['no_M_positive_lost_in_SMT']=bool(o.loc[o.M.eq(1),'SMT'].eq(1).all())
    checks['no_S_positive_lost_in_SMT']=bool(o.loc[o.S.eq(1),'SMT'].eq(1).all())
    checks['no_T_positive_lost_in_MT']=bool(o.loc[o['T'].eq(1),'MT'].eq(1).all())
    for c in ['S','M','T','MT','SMT','diabetes','dyslipidemia','heart']:
        checks[c+'_valid_ternary']=bool(o[c].isna().to_numpy().__or__(o[c].isin([0,1]).to_numpy()).all())
    models=pd.read_csv(r.ROOT/'results/models.csv')
    for scope in ['common_definitions','common_definitions_plausible']:
        g=models[models.scope.eq(scope)];checks[scope+'_same_n']=g.n.nunique()==1
        checks[scope+'_monotonic_events']=bool(g[g.exposure.eq('cvai')].set_index('outcome').loc[['M','MT','SMT'],'events'].is_monotonic_increasing)
    checks['model_event_bounds']=bool(models.events.le(models.n).all() and models.events.ge(0).all())
    flow=pd.read_csv(r.ROOT/'results/sample_flows.csv')
    checks['flow_accounting']=all((g.remaining_n.shift(1).fillna(g.iloc[0].remaining_n)-g.excluded_n).eq(g.remaining_n).all() for _,g in flow.groupby('scope'))
    out={'checks':checks,'all_passed':bool(all(checks.values())),'model_failures':models.loc[models.status.ne('ok'),['scope','exposure','model','status']].to_dict('records'),'clinical_gold_standard':False,'independent_human_review':False}
    (r.ROOT/'results/integrity_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))
    assert all(checks.values())

if __name__=='__main__':main()
