from datetime import datetime,timezone
from decimal import Decimal,localcontext
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
import reference as r

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    dst=r.ROOT/'organizer_only/precision_reference';dst.mkdir(exist_ok=False)
    d=pd.read_pickle(r.ROOT/'organizer_only/local_input.pkl');old=pd.read_pickle(r.ROOT/'organizer_only/reference_output.pkl')
    x=d.copy(deep=True);numeric=x.select_dtypes(include='number').columns;x[numeric]=x[numeric].astype('float64')
    out=r.transform(x);out.to_pickle(dst/'reference_output.pkl')
    changed=[]
    for c in out:
        if c=='uid':assert out[c].eq(old[c]).all();continue
        equal=np.isclose(out[c].to_numpy(dtype=float),old[c].to_numpy(dtype=float),rtol=0,atol=1e-8,equal_nan=True)
        if not equal.all():changed.append({'field':c,'different_n':int((~equal).sum()),'max_abs_difference':float((out[c]-old[c]).abs().max())})
    assert {v['field'] for v in changed}=={'tg','hdl','cvai'}
    assert out.isna().equals(old.isna())
    assert r.sample_flow(d,out)==r.sample_flow(d,old)
    # Independent Decimal arithmetic: source values promoted exactly, then
    # analyte conversion and published formula evaluated at precision40.
    idx=out.index[out.cvai.notna()]
    selected=list(idx[::max(1,len(idx)//100)])+[out.cvai.idxmax(),out.cvai.idxmin()]
    error={'tg':0.,'hdl':0.,'cvai':0.}
    D=lambda v:Decimal.from_float(float(v))
    with localcontext() as ctx:
        ctx.prec=40
        for i in selected:
            tg=D(d.loc[i,'bl_tg'])/Decimal('88.57');hdl=D(d.loc[i,'bl_hdl'])/Decimal('38.67')
            a=D(out.loc[i,'age']);b=D(out.loc[i,'bmi']);w=D(out.loc[i,'waist'])
            if out.loc[i,'male']==1:cv=Decimal('-267.93')+Decimal('.68')*a+Decimal('.03')*b+4*w+22*tg.log10()-Decimal('16.32')*hdl
            else:cv=Decimal('-187.32')+Decimal('1.71')*a+Decimal('4.23')*b+Decimal('1.12')*w+Decimal('39.76')*tg.log10()-Decimal('11.66')*hdl
            for c,v in [('tg',tg),('hdl',hdl),('cvai',cv)]:error[c]=max(error[c],abs(out.loc[i,c]-float(v)))
    assert max(error.values())<1e-8
    info={'created_at_utc':datetime.now(timezone.utc).isoformat(),'original_reference_sha256':sha(r.ROOT/'organizer_only/reference_output.pkl'),'corrected_reference_sha256':sha(dst/'reference_output.pkl'),'reference_code_sha256':sha(r.ROOT/'reference.py'),'input_sha256':sha(r.ROOT/'organizer_only/local_input.pkl'),'changed_continuous_fields':changed,'all_labels_missingness_eligibility_flow_unchanged':True,'independent_decimal_cases':len(selected),'max_error_vs_decimal':error,'producer_script_sha256':sha(Path(__file__))}
    (dst/'manifest.json').write_text(json.dumps(info,indent=2),encoding='utf-8');print(json.dumps(info,indent=2))

if __name__=='__main__':main()
