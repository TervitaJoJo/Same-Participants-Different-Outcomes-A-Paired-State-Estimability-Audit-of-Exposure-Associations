"""Extract official source text and metadata; no participant analysis."""
from pathlib import Path
import hashlib, json, re
from datetime import datetime, timezone
import pymupdf as fitz
import pandas as pd

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
DATA=BASE/'CHARLS'/'2015'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj): p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    out=ROOT/'sources';out.mkdir(exist_ok=True)
    inventory={}
    patterns={
      'Demographic_Background':r'^(ID|communityID|ba000|ba002|ba004|bd001|bb00|xrgender|xrtype|z)',
      'Health_Status_and_Functioning':r'^(ID|xrtype|xrgender|zda007_[1237]_|zda008_|da007_[1237]_|da007_w2_[12]_[1237]_|da014_|da015_|da059|zda059|da061|da067)',
      'Biomarker':r'^(ID|qa003$|qa004$|qa007$|qa008$|qa011$|qa012$|qi002$|ql002$|qm002$)',
      'Blood':r'^(ID|bl_)', 'Sample_Infor':r'.*', 'Weights':r'.*'}
    for name,pat in patterns.items():
        path=DATA/(name+'.dta')
        with pd.read_stata(path,iterator=True,convert_categoricals=False) as r:
            labels=r.variable_labels();values=r.value_labels()
            fields=[k for k in labels if re.search(pat,k)]
            pairs={k:{'label':labels[k], 'values':{str(a):b for a,b in values.get(r._lbllist[r._varlist.index(k)],{}).items()}} for k in fields}
        inventory[name]={'file':str(path),'sha256':sha(path),'fields':pairs}
    write(out/'metadata.json',inventory)
    for name in ['CHARLS_2015_Questionnaire','CHARLS_2015_Codebook','CHARLS_2015_Biomarker_Questionnaire','CHARLS_2015_Blood_Data_Release_Note','CHARLS_2015_Release_Note']:
        path=DATA/(name+'.pdf');doc=fitz.open(path)
        pages=[{'page':i+1,'text':p.get_text()} for i,p in enumerate(doc)]
        write(out/(name+'.json'),pages)
        (out/(name+'.txt')).write_text('\n\n'.join(f"[PDF page {p['page']}]\n{p['text']}" for p in pages),encoding='utf-8')
        inventory[name]={'file':str(path),'sha256':sha(path),'pages':len(pages)}
    write(out/'source_manifest.json',{'created_at':datetime.now(timezone.utc).isoformat(),'files':inventory})
    print('Source metadata and PDF text archived; no row-level analysis.')

if __name__=='__main__':main()
