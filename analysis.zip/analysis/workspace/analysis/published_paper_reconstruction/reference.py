"""Task-local source-reviewed reference. Pure transform plus local input loader."""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
DATA=BASE/'CHARLS'/'2015'
FIELDS=['uid','age','male','education','urban','bmi','waist','tg','hdl','cvai','cvai_high','sbp','dbp','S','M','T','MT','SMT','smoke_ever','smoke_current','drink','diabetes','dyslipidemia','heart','lipid_med','htn_med_skip','lipid_med_skip','htn_med_conflict','lipid_med_conflict','eligible']

def ternary_or(*parts):
    z=pd.concat(parts,axis=1)
    return pd.Series(np.where(z.eq(1).any(axis=1),1.,np.where(z.eq(0).all(axis=1),0.,np.nan)),index=z.index)

def diagnosis(d,i):
    new=d.xrtype.eq(1); re=d.xrtype.eq(2)
    prior=d[f'zda007_{i}_'].eq(1)
    awareness=d.zda008_1_.eq(1) if i==1 else pd.Series(False,index=d.index)
    positive=prior|awareness
    verify=d[f'da007_w2_1_{i}_'];since=d[f'da007_w2_2_{i}_']
    out=pd.Series(np.nan,index=d.index)
    out.loc[new]=d.loc[new,f'da007_{i}_'].map({1:1.,2:0.})
    absent=(~positive&verify.eq(1))|(positive&verify.eq(2))
    out.loc[re&absent&since.eq(2)]=0.
    out.loc[re&((prior&verify.eq(1))|since.eq(1))]=1.
    return out

def medication(d,cols,disease,awareness,none_code):
    z=d[cols]
    pos=z.isin([1,2]).any(axis=1)
    none=z.eq(none_code).any(axis=1)
    other=z.eq(3).any(axis=1) if none_code==4 else pd.Series(False,index=d.index)
    conflict=(pos&none)|(none&other)
    # Contract excludes invalid nonmissing response values from skip inference.
    skip=z.isna().all(axis=1)&disease.eq(0)&~awareness
    out=pd.Series(np.nan,index=d.index)
    out.loc[none|other|skip]=0.
    out.loc[pos]=1.
    out.loc[conflict]=np.nan
    return out,skip.astype(int),conflict.astype(int)

def transform(d):
    o=pd.DataFrame(index=d.index)
    o['uid']=d.ID.astype(str).str.strip()
    year=d.ba004_w3_1.where(d.ba002.eq(1),d.ba002_1.where(d.ba002.eq(2)))
    year=year.where(year.between(1900,2015))
    o['age']=2015-year
    o['male']=d.ba000_w2_3.map({1:1.,2:0.})
    edu=d.bd001_w2_4.where(d.bd001_w2_4.between(1,11),d.edu_prior.where(d.bd001_w2_4.eq(12)))
    o['education']=edu.map({1:0.,2:1.,3:1.,4:1.,5:2.,6:3.,7:3.,8:3.,9:3.,10:3.,11:3.})
    o['urban']=d.bb001_w3_2.map({1:1.,2:1.,3:1.,4:1.,5:1.,6:0.,7:0.})
    height=d.qi002.where(d.qi002.gt(0)&d.qi002.le(210))
    weight=d.ql002.where(d.ql002.gt(0)&d.ql002.le(150))
    o['bmi']=weight/(height/100)**2
    o['waist']=d.qm002.where(d.qm002.gt(0)&d.qm002.lt(993))
    o['tg']=d.bl_tg.where(d.bl_tg.gt(0))/88.57
    o['hdl']=d.bl_hdl.where(d.bl_hdl.gt(0))/38.67
    men=-267.93+.68*o.age+.03*o.bmi+4*o.waist+22*np.log10(o.tg)-16.32*o.hdl
    women=-187.32+1.71*o.age+4.23*o.bmi+1.12*o.waist+39.76*np.log10(o.tg)-11.66*o.hdl
    o['cvai']=men.where(o.male.eq(1),women.where(o.male.eq(0)))
    o['cvai_high']=o.cvai.ge(108.88).astype(float).where(o.cvai.notna())
    for target,cols in [('sbp',['qa003','qa007','qa011']),('dbp',['qa004','qa008','qa012'])]:
        z=d[cols].where(d[cols].gt(0)&d[cols].lt(993))
        o[target]=z.mean(axis=1).where(z.notna().all(axis=1))
    sm=o.sbp.ge(140).astype(float).where(o.sbp.notna())
    dm=o.dbp.ge(90).astype(float).where(o.dbp.notna())
    o['S']=diagnosis(d,1);o['M']=ternary_or(sm,dm)
    o['T'],o['htn_med_skip'],o['htn_med_conflict']=medication(d,['da011s1','da011s2','da011s3'],o.S,d.da008_1_.eq(1),3)
    o['MT']=ternary_or(o['M'],o['T']);o['SMT']=ternary_or(o['S'],o['M'],o['T'])
    smoke=d.da059.map({1:1.,2:0.}).combine_first(pd.Series(1.,index=d.index).where(d.zda059.eq(1)))
    o['smoke_ever']=d.da061.map({1:1.,2:1.,3:0.}).combine_first(smoke)
    o['smoke_current']=d.da061.map({1:1.,2:0.,3:0.})
    o.loc[o.smoke_ever.eq(0),'smoke_current']=0.
    o['drink']=d.da067.map({1:1.,2:1.,3:0.})
    for name,i in [('diabetes',3),('dyslipidemia',2),('heart',7)]:o[name]=diagnosis(d,i)
    o['lipid_med'],o['lipid_med_skip'],o['lipid_med_conflict']=medication(d,[f'da010_2_s{i}' for i in range(1,5)],o.dyslipidemia,pd.Series(False,index=d.index),4)
    o['eligible']=(o.age.ge(45)&o.cvai.notna()&o.SMT.notna()).astype(int)
    return o[FIELDS]

def sample_flow(d,o):
    keep=pd.Series(True,index=o.index);rows=[]
    for label,mask in [('initial',keep.copy()),('known_age',o.age.notna()),('age_45plus',o.age.ge(45)),('complete_cvai',o.cvai.notna()),('known_hypertension_SMT',o.SMT.notna())]:
        before=int(keep.sum());keep&=mask
        rows.append({'stage':label,'remaining_n':int(keep.sum()),'excluded_n':before-int(keep.sum())})
    return rows

def read_module(path,cols):
    d=pd.read_stata(path,columns=cols,convert_categoricals=False)
    d['ID']=d.ID.astype(str).str.strip()
    assert d.ID.str.fullmatch(r'\d{11,12}').all(),str(path)
    assert d.ID.is_unique,str(path)
    return d

def load_input():
    # Only prior education is carried forward; no future harmonized covariates.
    a=read_module(BASE/'CHARLS/2011/demographic_background.dta',['ID','householdID','bd001'])
    a['ID']=a.householdID.astype(str).str.strip()+'0'+a.ID.str[-2:]
    assert a.ID.is_unique and a.ID.str.len().eq(12).all()
    b=read_module(BASE/'CHARLS/2013/Demographic_Background.dta',['ID','bd001','bd001_w2_1','bd001_w2_2','bd001_w2_3','bd001_w2_4'])
    b=b.merge(a[['ID','bd001']].rename(columns={'bd001':'edu11'}),on='ID',how='left',validate='one_to_one')
    prior=b.edu11.where(b.bd001_w2_1.eq(1)&b.bd001_w2_2.eq(2))
    correct=b.bd001_w2_1.eq(2)|b.bd001_w2_2.eq(1)
    prior=prior.where(~correct,b.bd001_w2_3.where(b.bd001_w2_3.between(1,11)))
    b['edu_prior']=b.bd001.where(b.bd001.between(1,11)).combine_first(b.bd001_w2_4.where(b.bd001_w2_4.between(1,11),prior.where(b.bd001_w2_4.eq(12))))
    demo_cols=['ID','communityID','ba000_w2_3','ba002','ba002_1','ba004_w3_1','bd001_w2_4','bb001_w3_2']
    d=read_module(DATA/'Demographic_Background.dta',demo_cols)
    info=[{'module':'Demographic_Background','rows':len(d),'matched':len(d)}]
    groups={'Health_Status_and_Functioning':['ID','xrtype','zda008_1_','da008_1_','da059','zda059','da061','da061_w3','da067']+[f'{prefix}{i}_' for i in [1,2,3,7] for prefix in ['zda007_','da007_','da007_w2_1_','da007_w2_2_']]+['da011s1','da011s2','da011s3']+[f'da010_2_s{i}' for i in range(1,5)],
            'Biomarker':['ID','qa003','qa007','qa011','qa004','qa008','qa012','qi002','ql002','qm002'],
            'Blood':['ID','bl_tg','bl_hdl','bl_top_coding_tg','bl_fasting','bl_glu','bl_crea','bl_ua','bl_cho','bl_ldl'],
            'Sample_Infor':['ID','crosssection','died','iyear','imonth']}
    for name,cols in groups.items():
        z=read_module(DATA/(name+'.dta'),cols)
        info.append({'module':name,'rows':len(z),'matched':int(d.ID.isin(z.ID).sum())})
        d=d.merge(z,on='ID',how='left',validate='one_to_one')
    d=d.merge(b[['ID','edu_prior']],on='ID',how='left',validate='one_to_one')
    info.append({'module':'education_2013_route','rows':len(b),'matched':int(d.ID.isin(b.ID).sum()),'nonmissing_prior_education':int(d.edu_prior.notna().sum())})
    return d,info
