"""Numerical implementation repair; same sample, estimand and seed."""
import shutil,json
from datetime import datetime,timezone
import analyze as a
import pandas as pd

def main():
    archive=a.ROOT/'bootstrap_initial_optimizer_archive';archive.mkdir(exist_ok=False)
    names=['common_definitions_bootstrap.csv','common_definitions_plausible_bootstrap.csv','paired_definition_contrasts.csv']
    for n in names:shutil.copy2(a.OUT/n,archive/n)
    a.write(archive/'reason.json',{'recorded_at':datetime.now(timezone.utc).isoformat(),'reason':'Newton-CG success flag rejected roughly one third of bootstrap fits, including plausible-geometry sample. Replace with the same weighted GLM IRLS estimator as main analysis; retain all 500 sampled cluster multiplicities via same seed. No threshold, sample or exposure change. Initial intervals withheld; these archived draws are superseded.'})
    raw=pd.read_pickle(a.ROOT/'organizer_only/local_input.pkl');o=pd.read_pickle(a.ROOT/'organizer_only/reference_output.pkl')
    v=o.copy();v.loc[~a.plausible(raw),['cvai','cvai_high']]=float('nan')
    contrasts=[]
    for name,d in [('common_definitions',o),('common_definitions_plausible',v)]:
        _,c=a.paired_bootstrap(d,raw,name);contrasts.extend(c)
    pd.DataFrame(contrasts).to_csv(a.OUT/'paired_definition_contrasts.csv',index=False)
    print(pd.DataFrame(contrasts).to_string(index=False))

if __name__=='__main__':main()
