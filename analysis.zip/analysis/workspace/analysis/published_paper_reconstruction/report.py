from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import reference as r

ROOT=r.ROOT;OUT=ROOT/'results'
def table(rows,cols):
    return '| '+' | '.join(cols)+' |\n| '+' | '.join(['---']*len(cols))+' |\n'+'\n'.join('| '+' | '.join(str(row[c]) for c in cols)+' |' for row in rows)

def main():
    m=pd.read_csv(OUT/'models.csv');c=pd.read_csv(OUT/'paired_definition_contrasts.csv');fl=pd.read_csv(OUT/'sample_flows.csv')
    candidate=json.loads((ROOT/'candidate_current.json').read_text(encoding='utf-8'))
    paper=ET.parse(r.BASE/'analysis/published_paper_selection_20260920/PMC12616369.xml').getroot()
    for t in paper.findall('.//table-wrap'):
        rows=[[''.join(cell.itertext()).strip() for cell in tr] for tr in t.findall('.//tr')]
        pd.DataFrame(rows).to_csv(OUT/(t.get('id')+'_published.csv'),index=False,header=False)
    refs={'cvai':[(1.011,1.010,1.013),(1.010,1.009,1.011),(1.010,1.008,1.011)],'cvai_high':[(2.189,1.993,2.405),(2.019,1.834,2.223),(1.967,1.781,2.172)]}
    compare=[]
    for _,row in m[m.scope.eq('primary_stated_SMT')].iterrows():
        original=refs[row.exposure][int(row.model)-1]
        exact=all(round(row[k],3)==v for k,v in zip(['OR','ci_low','ci_high'],original))
        compare.append({'exposure':row.exposure,'model':row.model,'published_OR':original[0],'reconstructed_OR':row.OR,'published_low':original[1],'reconstructed_low':row.ci_low,'published_high':original[2],'reconstructed_high':row.ci_high,'rounding_match':exact,'absolute_log_OR_difference':abs(np.log(row.OR)-np.log(original[0])),'n':row.n,'events':row.events})
    pd.DataFrame(compare).to_csv(OUT/'table2_published_comparison.csv',index=False)
    # Two panels use identical participants and covariates, with conventional
    # model CIs. Paired cluster-bootstrap contrast intervals are in a separate file.
    g=m[m.scope.eq('common_definitions_plausible')&m.model.eq(3)]
    order=['S','M','MT','SMT'];names=['Reported physician diagnosis','Measured blood pressure','Measurement or treatment','Diagnosis, measurement or treatment']
    colors=['#357EAF','#C16B3A','#378472','#7758A4']
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,2,figsize=(12,4.7),gridspec_kw={'width_ratios':[1,1.15]})
    for ax,exposure,title in zip(axes,['cvai','cvai_high'],['A   CVAI increase of 10 units','B   CVAI ≥108.88 versus <108.88']):
        for i,t in enumerate(order):
            row=g[g.outcome.eq(t)&g.exposure.eq(exposure)].iloc[0]
            power=10 if exposure=='cvai' else 1
            val,lo,hi=[row[k]**power for k in ['OR','ci_low','ci_high']]
            ax.errorbar(val,3-i,xerr=[[val-lo],[hi-val]],fmt='o',color=colors[i],capsize=3,ms=7,lw=1.7)
        ax.set_title(title,loc='left',fontweight='bold',pad=16)
        ax.axvline(1,color='#AAA',lw=.8,ls='--');ax.set_ylim(-.55,3.55);ax.set_xlabel('Adjusted odds ratio (95% CI)')
        ax.set_yticks(range(4),names[::-1] if ax is axes[0] else ['']*4)
        ax.grid(axis='x',alpha=.15)
    axes[0].set_xlim(.99,1.18);axes[1].set_xlim(.96,2.75)
    fig.suptitle('Outcome choice changes association strength within the same participants',x=.02,y=.99,ha='left',fontsize=14,fontweight='bold')
    fig.text(.02,.055,'CHARLS 2015 · Same 9,045 participants · Same covariates · Anthropometric-plausibility sensitivity',fontsize=10)
    fig.text(.02,.015,'Conventional unweighted logistic-model intervals; this is an outcome-definition comparison, not a clinical gold-standard correction.',fontsize=8.5,color='#555')
    fig.tight_layout(rect=[0,.11,1,.91])
    for ext in ['png','pdf','svg']:fig.savefig(OUT/('paired_definition_comparison.'+ext),dpi=210,bbox_inches='tight')
    plt.close(fig)
    # Package the original candidate task for a future explicitly identified run.
    request=json.loads((Path(candidate['run'])/'request.json').read_text(encoding='utf-8'))
    (ROOT/'candidate_prompt_for_fresh_session.txt').write_text('\n\n'.join(z['role'].upper()+'\n'+z['content'] for z in request['input']),encoding='utf-8')
    summary=[]
    for t,label in zip(order,names):
        a=g[g.outcome.eq(t)&g.exposure.eq('cvai')].iloc[0];b=g[g.outcome.eq(t)&g.exposure.eq('cvai_high')].iloc[0]
        summary.append({'结局':t,'阳性人数':int(a.events),'阳性比例':f'{a.prevalence*100:.2f}%','每10单位CVAI OR（95%CI）':f'{a.OR**10:.3f} ({a.ci_low**10:.3f}–{a.ci_high**10:.3f})','高/低CVAI OR（95%CI）':f'{b.OR:.3f} ({b.ci_low:.3f}–{b.ci_high:.3f})'})
    primary=m[m.scope.eq('primary_stated_SMT')&m.model.eq(3)];plaus=m[m.scope.eq('anthropometric_plausibility')&m.model.eq(3)]
    pairs=c[c.scope.eq('common_definitions_plausible')]
    def pair(name):
        v=pairs[pairs.contrast.eq(name)].iloc[0];return f'{v.delta_log_OR_per10:.4f}（95%区间 {v.ci_low:.4f}–{v.ci_high:.4f}）'
    text=f'''# 已发表论文复现与结局定义审计：第一轮报告

更新：2026-09-20。当前状态：本地复现和固定敏感性分析完成；精确复现未通过；新模型调用超时，候选实现评测未完成。V1、原始数据、原有 agent 和历史冻结实验未修改。

## 研究对象与本轮结论

Ma J et al. *The association between Chinese visceral adiposity index and hypertension among middle-aged and older population: a cross-sectional study based on CHARLS.* Front Cardiovasc Med. 2025;12:1664848. [DOI](https://doi.org/10.3389/fcvm.2025.1664848)。这是队列数据库的横断面分析，暴露是内脏脂肪指数 CVAI，吸烟是协变量。

本轮最有把握的结论是：在共同样本内，CVAI 与高血压的正向关联保留，但效应强度随诊断、血压测量及用药构成改变。因而可以形成一个真实论文场景下的“定义审计”案例。现在还不能写成“AI 已复刻并纠正了原论文”，也不能据此证明作者使用了错误定义。

## 1. 复现到什么程度

| 项目 | 论文报告 | 本地固定规则重建 |
| --- | ---: | ---: |
| 起始人数 | 21,095 | 21,095 |
| 年龄缺失 | 未单列 | 809 |
| 年龄小于45岁 | 497 | 1,004（已知年龄者中） |
| 因CVAI不完整排除 | 7,178 | 7,130（前一步样本内） |
| 因高血压定义未知排除 | 4,633 | 216（前一步样本内） |
| 最终描述性样本 | 8,787 | 11,936 |
| 最终描述性样本高血压阳性 | 2,626 | 5,229 |
| 完整协变量的 Model 3 样本 | 未另列 | 9,605 |
| CVAI每1单位 Model 3 OR | 1.010（1.008–1.011） | {primary[primary.exposure.eq('cvai')].iloc[0].OR:.3f}（{primary[primary.exposure.eq('cvai')].iloc[0].ci_low:.3f}–{primary[primary.exposure.eq('cvai')].iloc[0].ci_high:.3f}） |
| CVAI≥108.88 Model 3 OR | 1.967（1.781–2.172） | {primary[primary.exposure.eq('cvai_high')].iloc[0].OR:.3f}（{primary[primary.exposure.eq('cvai_high')].iloc[0].ci_low:.3f}–{primary[primary.exposure.eq('cvai_high')].iloc[0].ci_high:.3f}） |

两套样本并不相同，因此两列效应差异不能全部归因于结局定义。起始人数相同只支持起始模块一致。原文没有提供足以唯一确定年龄补全、用药跳题、缺失处理、体测清洗和完整病例排除的作者代码。按预先固定标准，**精确复现与近似复现均未通过**，不再用额外组合搜索追逐论文数字。

原文文字中 2,626/8,787 对应的比例应约为29.89%，而非其写的27.89%。这是阅读原文时组织者已经看到的算术不一致，不是本轮候选模型发现，也不单独证明分析错误。

## 2. 共同样本内最可解释的比较

下面采用同一批9,045人、完全相同的协变量和同一个拟合程序，并限制体测值处于事先写入QC修订的合理范围：身高100–210cm、体重20–150kg、腰围40–150cm。它是明确标注的敏感性分析；原始规则结果也全部保留。

S=问卷证据支持的医生诊断自报；M=三次血压均值达到阈值；T=记录的降压用药（含注明的无病路径跳题处理）；MT=M或T；SMT=S或M或T。

{table(summary,list(summary[0]))}

![共同样本结局定义比较](results/paired_definition_comparison.png)

通俗地说，同一批人中，“现场血压升高”和“过去诊断过、或正在用药、或现场血压升高”会选出不同的人，得到的关联强度也不同。CVAI高/低的OR由M的1.988变为SMT的2.353，但各定义下仍为正向关联。不能把其中一个结果直接称为真值，也不能称另一个结果的全部差距为偏倚。

对每10单位CVAI的log OR做500次共同社区重抽样（437个社区；本组500/500次配对重抽样均成功）：

- M − S：{pair('M_minus_S')}。
- MT − M：{pair('MT_minus_M')}。
- SMT − MT：{pair('SMT_minus_MT')}。
- SMT − M：{pair('SMT_minus_M')}。

本组数据中，加入用药信息对应的变化比在MT之后再加入诊断史更明显；后者区间包含0。这里是同一样本上的描述性差异，没有把各项解释为因果贡献。区间为未作多重校正的描述性配对bootstrap区间，不能选择其中显著者作验证性结论。表中单一OR区间是常规logistic模型区间，与配对社区bootstrap区间不同。

不加体测合理范围限制的共同样本为9,224人，其SMT−M每10单位log OR差为{c[(c.scope.eq('common_definitions'))&(c.contrast.eq('SMT_minus_M'))].iloc[0].delta_log_OR_per10:.4f}，方向一致；500次中不同配对有494–500次有效重抽样，具体见结果文件。

## 3. 数据和建模审计实际发现了什么

- **体测质量会影响连续CVAI模型。** 年龄与CVAI完整的12,152人中，239人落在上述宽松合理范围之外（身高23人、腰围217人，有重叠）；原始最大BMI达到211,927 kg/m²，显然不能当作可信成人体测值。不能擅自把疑似米/英寸转为厘米。本轮保留原规则，并单列范围敏感性；完全调整后的连续OR从每单位1.0069变为1.0137，不能把这个变化归功于结局修正。
- **血压读数规则会同时改变样本。** 改用至少一次有效读数后，Model 3新增24人，连续OR接近1，但固定cutoff OR仍约2.365。这一未经额外体测筛选的结果高度敏感，不能包装成“关联消失”。本轮不追加组合清洗来挑选结果。
- **用药跳题不能机械处理。** 把降压药和降脂药的路径性跳题同时改为未知后，完整协变量只剩837人，其中阳性834、阴性3；因此停止Model 3拟合，不报告不可靠效应。这是分析可行性/样本选择边界，不能视为0或未知在所有问题中哪个一概正确。
- **教育“没有变化”不是等级。** 2015教育=12通过2013确认/修改路径及必要的2011教育记录恢复；2011 ID按官方规则插入家庭拆分位。没有使用2018或2020的后验信息补2015。
- **原文阈值的生成算法不充分。** 108.88作为固定阈值可计算，但从RCS如何选出该值无法按原文唯一重现。三结点非线性检验已计算；未经体测限制P≈0.087，范围敏感性P≈0.021。均不能把相对参考点的OR=1交点当作独立验证的生物学拐点。
- 217名CVAI完整者的TG为已发布上限编码，1,794名非空腹；本轮没有虚构原始TG，也没有原文未说明的空腹筛选。两条冲突用药回答按未知处理。完整人数与异常数量见analysis_audit.json。

## 4. Agent到底完成了什么

已经固定并保存：任务边界、方法选择、官方证据页码、变量清单、源数据及代码哈希、30组边界测试、局部参考实现。模型请求为全新无上下文请求，不提供参与者数据、参考代码、论文效应量或目标人数。

本轮实际配置：gpt-6-astra / xhigh / custom provider（与历史DeepSeek运行不同，不能据此比较供应商）。请求启动后277秒超时；有传输事件，但没有任何最终答案文本，故未执行候选代码、未计算候选准确率，也没有偷偷补写候选输出。

**目前的数值结果来自组织者审查过的本地参考流程，不是本轮外部模型成功运行的证据。** 这也不是独立人工盲审。候选任务只要求实现提供的规则，教育历史与资料筛选已由本地流程完成，即使以后候选通过，也需准确界定自动化范围。

## 5. 质量核验与计算修订

- 一对一连接、输入不修改、行重排不影响结果、三态或运算27种组合、阳性集合包含关系、共同样本人数一致、筛选人数守恒检查均通过。
- 30组人工构造边界案例用于参考代码自检。候选模型未返回答案，所以这些测试不能当作它的测试通过数。
- 最初bootstrap使用的Newton-CG成功标志因数值精度问题拒绝了较多拟合；初始结果没有报告区间。已归档至bootstrap_initial_optimizer_archive，并改用与主分析一致的加权GLM IRLS重算相同500次重抽样，样本、种子、估计量未改。当前结果目录仅保留修复后的区间；原始失败抽样记录仍可追溯。
- 没有伪造2015分层变量；模型为复现原文的未加权模型，不能把表中阳性比例叫作中国全国患病率。社区重抽样也不是完整复杂抽样设计方差估计。

## 6. 当前停止点与下一步

已完成一轮有边界的本地应用验证。能够写进后续方法论文的候选内容是：“在真实已发表研究的应用场景中，源问卷路径、体测质量与结局构成需要分层审计；对共同样本更换定义可定位关联强度的变化。”不能写成“证明原论文错了”或“agent已成功纠偏”。

接下来的必要工作有两项：①模型服务可用时，明确登记一次新的运行，使用保存的同一任务包，保存首轮答案后再评测；②若要声称原论文精确复现，需取得作者完整清洗/分析代码或澄清上述选择。当前没有发现需要用户补下载的主要CHARLS模块。未获授权不向作者发送消息。

不建议此时继续扩大模型、增加数据库或改动V1。先把候选模型这一环实际完成，再决定它是否足以成为V2的一个应用示范。原先库内纠偏可行性实验的停止结论不因本轮而改变。

## 主要文件

- [固定方案](protocol.md)、[建模前QC修订](pre_model_qc_amendment.md)。
- [全部模型](results/models.csv)、[原文Table 2逐项对照](results/table2_published_comparison.csv)、[样本流程](results/sample_flows.csv)。
- [描述性表](results/table1_reconstruction.csv)、[共同样本配对差异](results/paired_definition_contrasts.csv)、[完整性核验](results/integrity_checks.json)。
- [图PDF](results/paired_definition_comparison.pdf)、[图SVG](results/paired_definition_comparison.svg)。
- [模型原始请求与失败记录](candidate_runs/20260920T122116802529Z/)、[可供全新会话使用的原任务提示词](candidate_prompt_for_fresh_session.txt)。
- organizer_only包含本地参与者衍生记录，不能作为公开补充材料或发送给外部模型。
'''
    (ROOT/'stage_report_zh.md').write_text(text,encoding='utf-8')
    report={'created_at_utc':datetime.now(timezone.utc).isoformat(),'reference_analysis':'completed','exact_replication':'not_achieved','approximate_replication':'not_achieved','candidate_evaluation':'not_scored_transport_timeout','first_request_archived_before_models':True,'independent_human_review':False,'V1_modified':False,'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.name!='completion_manifest.json'}}
    (ROOT/'completion_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Report, comparison tables, figure and completion manifest written.')

if __name__=='__main__':main()
