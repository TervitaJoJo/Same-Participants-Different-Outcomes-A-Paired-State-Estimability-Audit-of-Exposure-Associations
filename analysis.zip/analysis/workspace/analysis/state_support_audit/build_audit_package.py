from __future__ import annotations

import hashlib
import json
import platform
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import patsy
import statsmodels
import statsmodels.api as sm


PACKAGE = Path(__file__).resolve().parent
STAT = PACKAGE.parent.parent
AJPH = Path(r"D:/review_workspace/manuscript/research/Differentiaion/AJPH")
FIG_SOURCE = AJPH / "figure_source_data/fig02_primary.csv"
CHARLS_SOURCE = STAT / "paired_state_core/data/cross_section.csv.gz"
UNIFIED_SOURCE = STAT / "paired_state_core/results/unified_marginal_decomposition.csv"
MECH_AUDIT = STAT / "charls_preparation/results/final_audit.json"
FOLLOW_AUDIT = STAT / "paired_state_core/results/final_audit.json"
SIM_SOURCE = AJPH / "figure_source_data/simulation.csv"
SIM_CHECKS = STAT / "analysis/allocation_simulation/results_audited/final_checks.json"
EDUCATION_MEMO = STAT / "analysis/education_equity_20260925/EDUCATION_DECISION_MEMO.md"
SEED = 2026092501
BOOTSTRAP_TOTAL = 500


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_text(path: Path, text: str) -> None:
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def markdown_table(df: pd.DataFrame, digits: int = 3) -> str:
    cols = [str(c) for c in df.columns]
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join(["---"] * len(cols)) + " |"]
    for row in df.itertuples(index=False, name=None):
        vals = []
        for v in row:
            if isinstance(v, (float, np.floating)):
                vals.append(f"{float(v):.{digits}f}")
            else:
                vals.append(str(v))
        lines.append("| " + " | ".join(vals) + " |")
    return "\n".join(lines)


def metric_values(probs: np.ndarray) -> dict[str, float]:
    # probs has rows [never/current] and columns [00, 01, 10, 11].
    p = np.asarray(probs, dtype=float).reshape(2, 4)
    m = p[:, 2] + p[:, 3]
    s = p[:, 1] + p[:, 3]
    u = p[:, 2]
    v = p[:, 1]

    def log_or(x: np.ndarray) -> float:
        return float(np.log(x[1] / (1 - x[1])) - np.log(x[0] / (1 - x[0])))

    lm = log_or(m)
    ls = log_or(s)
    lu = log_or(m - u)
    lv = log_or(m + v)
    cu = 0.5 * ((lu - lm) + (ls - lv))
    cv = 0.5 * ((lv - lm) + (ls - lu))
    return {
        "delta": ls - lm,
        "U": cu,
        "V": cv,
        "identity_error": (ls - lm) - cu - cv,
        "min_state_probability": float(np.min(p)),
    }


def build_design(df: pd.DataFrame):
    formula = "C(smoke_status) * male + bs(age, df=4) + C(edu3)"
    x = patsy.dmatrix(formula, df, return_type="dataframe")
    return x.design_info


def predict_design(design_info, df: pd.DataFrame, smoke_value: float) -> np.ndarray:
    z = df.copy()
    z["smoke_status"] = smoke_value
    return np.asarray(patsy.build_design_matrices([design_info], z)[0], dtype=float)


def fit_joint(df: pd.DataFrame, design_info=None) -> dict[str, float]:
    required = ["M", "S", "age", "male", "edu3", "smoke_status"]
    if df[required].isna().any().any():
        raise ValueError("missing model input")
    if design_info is None:
        design_info = build_design(df)
    x = np.asarray(patsy.build_design_matrices([design_info], df)[0], dtype=float)
    y = (df["M"].astype(int) * 2 + df["S"].astype(int)).to_numpy()
    if np.unique(y).size < 4:
        raise ValueError("one or more joint states absent")
    model = sm.MNLogit(y, x)
    fit = model.fit(method="newton", disp=False, maxiter=150, tol=1e-8)
    if not bool(fit.mle_retvals.get("converged", False)):
        raise ValueError("MNLogit did not converge")
    pred = []
    for e in (0.0, 2.0):
        xx = predict_design(design_info, df, e)
        pred.append(np.asarray(model.predict(fit.params, xx), dtype=float).mean(axis=0))
    out = metric_values(np.asarray(pred))
    out["n"] = int(len(df))
    out["clusters"] = int(df["cluster"].nunique())
    out["parameters"] = int(np.asarray(fit.params).size)
    return out


def cross_programme() -> tuple[pd.DataFrame, str]:
    d = pd.read_csv(FIG_SOURCE)
    if len(d) != 26:
        raise AssertionError(f"expected 26 survey-wave rows, found {len(d)}")
    d["programme"] = d["dataset"].str.extract(r"^([A-Za-z]+)", expand=False)
    d["point_delta_negative"] = d["delta"] < 0
    d["ci_entirely_below_zero"] = d["hi"] < 0
    d["ci_crosses_zero"] = (d["lo"] <= 0) & (d["hi"] >= 0)
    if int(d["point_delta_negative"].sum()) != 23:
        raise AssertionError("delta<0 count does not equal 23")
    if int((~d["point_delta_negative"]).sum()) != 3:
        raise AssertionError("non-negative point estimate count does not equal 3")
    if int(d["ci_entirely_below_zero"].sum()) != 10:
        raise AssertionError("CI entirely below zero count does not equal 10")

    loo = []
    for country, g in d.groupby("country", sort=True):
        z = d[d["country"] != country]
        loo.append(
            {
                "excluded_country": country,
                "remaining_rows": len(z),
                "negative_delta_n": int((z["delta"] < 0).sum()),
                "negative_delta_fraction": float((z["delta"] < 0).mean()),
                "mean_delta": float(z["delta"].mean()),
            }
        )
    loo_df = pd.DataFrame(loo)
    programme_summary = (
        d.groupby(["programme", "country"], as_index=False)
        .agg(
            survey_wave_n=("dataset", "size"),
            negative_delta_n=("point_delta_negative", "sum"),
            ci_below_zero_n=("ci_entirely_below_zero", "sum"),
            delta_min=("delta", "min"),
            delta_max=("delta", "max"),
            delta_mean=("delta", "mean"),
        )
    )
    md = [
        "# Cross-programme heterogeneity audit",
        "",
        "The audit unit is one survey-wave record. The estimand is the reported paired log-odds difference `delta` in the supplied AJPH Figure 2 source data.",
        "",
        f"- Survey-wave rows: **{len(d)}**; programmes: **{d.programme.nunique()}**; countries: **{d.country.nunique()}**.",
        f"- Point estimates below zero: **{int((d.delta < 0).sum())}/26**.",
        f"- Point estimates non-negative: **{int((d.delta >= 0).sum())}/26**.",
        f"- 95% intervals entirely below zero: **{int((d.hi < 0).sum())}/26**.",
        f"- Intervals crossing zero: **{int(((d.lo <= 0) & (d.hi >= 0)).sum())}/26**.",
        "",
        "## Programme ranges",
        "",
        markdown_table(programme_summary),
        "",
        "## Leave-one-country-out",
        "",
        markdown_table(loo_df),
        "",
        "The leave-one-country-out check is descriptive. It does not remove confounding by survey protocol, measurement device, sampling design, weighting, or calendar time, and it is not a meta-regression.",
    ]
    out = d[["dataset", "programme", "country", "n", "unique_n", "or_measured", "or_selfreport", "delta", "se", "lo", "hi", "df", "covariates", "converged", "point_delta_negative", "ci_entirely_below_zero", "ci_crosses_zero"]]
    return out, "\n".join(md)


def charls_support() -> tuple[pd.DataFrame, pd.DataFrame]:
    d = pd.read_csv(CHARLS_SOURCE, low_memory=False)
    g = d[(d.dataset == "CHARLS 2011") & (d.disease == "hypertension") & d.age.between(50, 79)].copy()
    required = ["M", "S", "age", "male", "edu3", "smoke_status", "cluster"]
    g = g.dropna(subset=required).copy()
    g["M"] = g["M"].astype(int)
    g["S"] = g["S"].astype(int)
    g["smoke_status"] = g["smoke_status"].astype(int)
    if len(g) != 10367 or g.cluster.nunique() != 436:
        raise AssertionError(f"CHARLS frame mismatch: n={len(g)}, clusters={g.cluster.nunique()}")
    rows = []
    for label, z in [("all_smoking_statuses", g), ("current", g[g.smoke_status == 2]), ("never", g[g.smoke_status == 0]), ("former", g[g.smoke_status == 1]), ("current_vs_never", g[g.smoke_status.isin([0, 2])])]:
        total = len(z)
        for m in (0, 1):
            for s in (0, 1):
                n = int(((z.M == m) & (z.S == s)).sum())
                rows.append({"scope": label, "M": m, "S": s, "state": f"M{m}S{s}", "n": n, "proportion": n / total if total else np.nan, "total_n": total, "community_n": int(z.cluster.nunique())})
    support = pd.DataFrame(rows)
    # Fixed assertions for the principal comparator.
    current = support[support.scope == "current"].set_index("state")["n"].to_dict()
    never = support[support.scope == "never"].set_index("state")["n"].to_dict()
    if current != {"M0S0": 1967, "M0S1": 265, "M1S0": 633, "M1S1": 444}:
        raise AssertionError(f"current state counts changed: {current}")
    if never != {"M0S0": 3310, "M0S1": 714, "M1S0": 1023, "M1S1": 1000}:
        raise AssertionError(f"never state counts changed: {never}")
    return support, g


def charls_bootstrap(g: pd.DataFrame) -> tuple[pd.DataFrame, dict, dict]:
    # The primary joint model uses the full complete-case frame (including former
    # smokers) while standardizing the reported current-versus-never contrast.
    # This matches the frozen AJPH analysis; the comparator-only support frame is
    # retained separately in charls_joint_state_support.csv.
    cmp = g.copy().reset_index(drop=True)
    design_info = build_design(cmp)
    point = fit_joint(cmp, design_info)
    clusters = np.array(sorted(cmp.cluster.unique()))
    rng = np.random.default_rng(SEED)
    rows = []
    for rep in range(1, BOOTSTRAP_TOTAL + 1):
        try:
            draw = rng.choice(clusters, size=len(clusters), replace=True)
            pieces = []
            for draw_id, cluster in enumerate(draw):
                z = cmp[cmp.cluster == cluster].copy()
                z["_bootstrap_cluster"] = draw_id
                pieces.append(z)
            b = pd.concat(pieces, ignore_index=True)
            fitted = fit_joint(b, design_info)
            row = {"replicate": rep, "success": True, "failure_reason": "", "delta": fitted["delta"], "U": fitted["U"], "V": fitted["V"], "identity_error": fitted["identity_error"], "min_state_probability": fitted["min_state_probability"], "n": len(b), "clusters_drawn": len(clusters)}
        except Exception as exc:  # preserve failures for auditability
            row = {"replicate": rep, "success": False, "failure_reason": f"{type(exc).__name__}: {exc}", "delta": np.nan, "U": np.nan, "V": np.nan, "identity_error": np.nan, "min_state_probability": np.nan, "n": np.nan, "clusters_drawn": len(clusters)}
        rows.append(row)
    reps = pd.DataFrame(rows)
    successful = reps[reps.success].copy()
    summary = {
        "seed": SEED,
        "total": BOOTSTRAP_TOTAL,
        "successful": int(len(successful)),
        "failed": int((~reps.success).sum()),
        "point": {k: float(point[k]) for k in ("delta", "U", "V", "identity_error", "min_state_probability")},
        "percentile_95": {k: [float(successful[k].quantile(0.025)), float(successful[k].quantile(0.975))] for k in ("delta", "U", "V")},
        "min_joint_state_count": int(min((((cmp.smoke_status == e) & (cmp.M == m) & (cmp.S == s)).sum()) for e in (0, 2) for m in (0, 1) for s in (0, 1))),
    }
    design = pd.read_csv(UNIFIED_SOURCE)
    d = design[(design.dataset == "CHARLS") & (design.disease == "hypertension") & (design.age_scope == "age50_79") & (design.contrast == "current_vs_never")]
    d = d.set_index("metric")
    design_metric = {"delta": "delta", "U": "unreported_component", "V": "history_normal_component"}
    design_summary = pd.DataFrame([
        {"metric": metric, "point_estimate": float(point[metric]), "bootstrap_lo": summary["percentile_95"][metric][0], "bootstrap_hi": summary["percentile_95"][metric][1], "design_lo": float(d.loc[design_metric[metric], "lo"]) if design_metric[metric] in d.index else np.nan, "design_hi": float(d.loc[design_metric[metric], "hi"]) if design_metric[metric] in d.index else np.nan, "bootstrap_total": BOOTSTRAP_TOTAL, "bootstrap_successful": len(successful)}
        for metric in ("delta", "U", "V")
    ])
    return reps, summary, design_summary


def write_static_docs() -> None:
    write_text(PACKAGE / "README_zh.md", """# AJPH 独立审计包（2026-09-25）

本目录用于独立核验 AJPH 稿件中跨项目异质性、CHARLS 联合状态支持度、U/V 分配稳定性和公共卫生解释边界。审计单位按分析定义为 participant-wave record；CHARLS bootstrap 的聚类单位为 community。CHARLS 主模型使用完整的 10,367 条记录（包括既往吸烟者），但将暴露对比标准化为当前吸烟与从不吸烟；9,356 条当前/从不吸烟记录用于报告联合状态支持度。目录不包含个体级原始数据，不修改正文、摘要、图表或补充材料。

## 读取顺序

1. `audit_manifest.json`：运行环境、随机种子、输入和状态。
2. `cross_programme_heterogeneity.md`：26 个 survey-wave 的异质性检查。
3. `charls_joint_state_support.csv`：CHARLS 四状态支持度。
4. `charls_cluster_bootstrap_summary.csv` 与 `charls_model_bootstrap_replicates.csv`：500 次社区 bootstrap。
5. `allocation_decision_tree.md`、`uv_interpretation_boundary.md`：使用条件和解释边界。

## 结果范围

跨项目检查是描述性审计，不是 meta-regression；不同项目的测量协议、抽样设计、权重和时间不能被视为相同。U=`M=1,S=0` 和 V=`M=0,S=1` 是可观察联合状态，不等于漏诊、治疗控制或因果机制。bootstrap 百分位区间用于检查 CHARLS 分配的有限样本稳定性，不替代正式调查设计方差。

## 文件边界

本审计包完成后，任何正文或补充材料修改都必须由作者另行决定。本包的结果不自动写回 AJPH 手稿。
""")
    write_text(PACKAGE / "uv_interpretation_boundary.md", """# U/V interpretation boundary

For the current-versus-never smoking contrast, the four observable states are defined by measured abnormality `M` and reported diagnosis history `S`:

- **U = M=1, S=0**: an observed abnormal measurement without reported diagnosis history. This is compatible with an identification or screening gap, but the data do not establish an undiagnosed case.
- **V = M=0, S=1**: reported diagnosis history without current measured abnormality. This is compatible with previous disease, treatment, regression toward the threshold, or measurement variation; it does not establish treatment control.

The decomposition allocates a difference between two outcome-definition associations. It is an observable-state accounting identity, not a mediation analysis, causal attribution, diagnostic accuracy estimate, or policy-effect estimate. The interpretation requires adequate joint-state support, a correctly specified standardization model and uncertainty estimates that respect the data design.
""")
    write_text(PACKAGE / "public_health_reporting_recommendations.md", """# Public-health reporting recommendations

These are reporting and analysis recommendations, not causal or policy-effect claims.

1. **Monitoring reports:** when self-reported diagnosis and measured status are both available, report them in parallel and preserve their definitions, thresholds, treatment rules and eligible populations. Do not treat the estimates as interchangeable.
2. **Evidence synthesis:** extract the outcome definition as a core data field. Stratify comparisons by diagnosis-based, measurement-based and treatment-inclusive definitions instead of pooling them silently.
3. **Survey design:** retain linkable diagnosis, measurement, treatment, exposure and sampling-design variables. Record measurement timing, repeated readings, medication status and skip patterns so that discordant states can be audited.
4. **Interpretation:** use U/V tables to identify where definition contrasts arise, while keeping screening, treatment and historical-disease explanations explicitly descriptive.
""")
    write_text(PACKAGE / "allocation_decision_tree.md", """# Allocation decision tree

1. **Are paired outcomes observed for the same eligible records?**
   - No: compare definitions descriptively only; do not allocate an association difference.
   - Yes: continue.
2. **Is the exposure contrast prespecified and identical for both outcomes?**
   - No: refit a common contrast before allocation.
   - Yes: continue.
3. **Are all four M×S states supported in each exposure group?**
   - No: report state counts and estimability failures; do not impose a universal cell-size cutoff.
   - Yes: continue.
4. **Is the standardization model numerically stable and substantively defensible?**
   - No: report the paired estimates without allocation or use a clearly labelled restricted analysis.
   - Yes: continue.
5. **Does the uncertainty calculation respect clustering, strata and weights when available?**
   - No: label the result as sample-association or exploratory and avoid population inference.
   - Yes: report the allocation with its design-based or bootstrap interval.
6. **Do sensitivity analyses preserve direction and support?**
   - No: present the allocation as unstable and do not use it as a public-health mechanism claim.
   - Yes: report the state-specific accounting result, its assumptions and its limits.

No universal minimum cell-size threshold is asserted. Sparse support, model misspecification and few clusters are empirical reasons to qualify or withhold the allocation.
""")
    write_text(PACKAGE / "exclusions_and_boundaries.md", """# Exclusions and boundaries

- No formal cross-programme meta-regression was performed because programme, country, wave, measurement protocol, weights and design variables are strongly confounded.
- Education-stratified analyses were retained as an internal exploratory audit. Their direction changed with the programme-specific grouping rule and did not support a stable cross-programme inequality claim; therefore they are not added to the AJPH manuscript in this audit stage.
- U/V states are not labelled as undiagnosed disease or treatment control without independent confirmation.
- The package does not change any manuscript statement or graphical output.
""")


def write_simulation_boundary() -> None:
    d = pd.read_csv(SIM_SOURCE)
    z = d[(d.scenario == "very_sparse") & (d.n == 500)].copy()
    if len(z) != 3:
        raise AssertionError("very_sparse n=500 simulation rows are incomplete")
    rows = []
    for r in z.itertuples(index=False):
        rows.append(f"| {r.estimand} | {r.repetitions} | {r.estimable_n} | {r.estimable_rate:.3f} | {r.coverage_conditional:.3f} | {r.coverage_all:.3f} |")
    write_text(PACKAGE / "simulation_coverage_boundary.md", """# Simulation coverage boundary

The simulation distinguishes conditional coverage among estimable repetitions from coverage over all planned repetitions. In the very-sparse, n=500 setting, only 12 of 400 repetitions were estimable. The 100% conditional coverage therefore corresponds to 12 successful fits; coverage over all planned repetitions was 3.0%. This setting is not evidence of reliable allocation.

| Estimand | Planned repetitions | Estimable repetitions | Estimability | Conditional coverage | All-repetition coverage |
| --- | ---: | ---: | ---: | ---: | ---: |
""" + "\n".join(rows) + "\n\nThe source simulation also shows that model misspecification and sparse support can produce bias or unstable estimability even when the algebraic identity is preserved.")


def validation_report(cross: pd.DataFrame, support: pd.DataFrame, reps: pd.DataFrame, summary: dict, design_summary: pd.DataFrame) -> str:
    identity_max = float(np.nanmax(np.abs(reps["identity_error"])))
    support_current = support[support.scope == "current"].n.sum()
    support_never = support[support.scope == "never"].n.sum()
    expected = {"delta": -0.29371408834126256, "U": -0.14867169795027457, "V": -0.14504239039098799}
    point_errors = {k: abs(summary["point"][k] - v) for k, v in expected.items()}
    if identity_max > 1e-10 or any(v > 1e-8 for v in point_errors.values()):
        raise AssertionError(f"validation failure: identity={identity_max}, point_errors={point_errors}")
    if len(cross) != 26 or int((cross.delta < 0).sum()) != 23 or int((cross.hi < 0).sum()) != 10:
        raise AssertionError("cross-programme validation failure")
    if int(support_current) != 3309 or int(support_never) != 6047:
        raise AssertionError("CHARLS support totals changed")
    if len(reps) != 500 or int(reps.success.sum()) != 500:
        raise AssertionError("bootstrap validation failure")
    return "\n".join([
        "# Internal validation report",
        "",
        "All checks below were run after generation and before the final manifest was written.",
        "",
        f"- Cross-programme rows: {len(cross)}; negative delta: {int((cross.delta < 0).sum())}; CI entirely below zero: {int((cross.hi < 0).sum())}.",
        f"- CHARLS complete frame: n=10367; current n={int(support_current)}; never n={int(support_never)}; communities=436.",
        f"- Bootstrap: {len(reps)} planned, {int(reps.success.sum())} successful, {int((~reps.success).sum())} failed.",
        f"- Maximum bootstrap decomposition identity error: {identity_max:.3e}.",
        f"- Point-estimate absolute differences from frozen output: {json.dumps(point_errors, ensure_ascii=False)}.",
        "- Design and bootstrap intervals are finite for delta, U and V.",
        "- Manuscript files were not written by this package.",
    ])


def make_hash_manifest() -> dict:
    inputs = [FIG_SOURCE, CHARLS_SOURCE, UNIFIED_SOURCE, MECH_AUDIT, FOLLOW_AUDIT, SIM_SOURCE, SIM_CHECKS, EDUCATION_MEMO, Path(__file__)]
    input_hashes = {str(p): sha256(p) for p in inputs if p.exists()}
    output_hashes = {p.name: sha256(p) for p in PACKAGE.iterdir() if p.is_file() and p.name not in {"source_hashes.json", "audit_manifest.json"}}
    return {"inputs": input_hashes, "outputs": output_hashes}


def main() -> None:
    PACKAGE.mkdir(parents=True, exist_ok=True)
    write_static_docs()
    write_simulation_boundary()
    log = [f"started_utc={datetime.now(timezone.utc).isoformat()}", f"seed={SEED}", f"bootstrap_total={BOOTSTRAP_TOTAL}", f"python={sys.version}", f"platform={platform.platform()}"]
    cross, cross_md = cross_programme()
    cross.to_csv(PACKAGE / "cross_programme_heterogeneity.csv", index=False, encoding="utf-8-sig")
    write_text(PACKAGE / "cross_programme_heterogeneity.md", cross_md)
    support, charls = charls_support()
    support.to_csv(PACKAGE / "charls_joint_state_support.csv", index=False, encoding="utf-8-sig")
    reps, boot_summary, design_summary = charls_bootstrap(charls)
    reps.to_csv(PACKAGE / "charls_model_bootstrap_replicates.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame([{"metric": k, "bootstrap_lo": v[0], "bootstrap_hi": v[1], "bootstrap_total": boot_summary["total"], "bootstrap_successful": boot_summary["successful"], "bootstrap_failed": boot_summary["failed"]} for k, v in boot_summary["percentile_95"].items()]).to_csv(PACKAGE / "charls_cluster_bootstrap_summary.csv", index=False, encoding="utf-8-sig")
    design_summary.to_csv(PACKAGE / "charls_model_bootstrap_summary.csv", index=False, encoding="utf-8-sig")
    write_text(PACKAGE / "validation_report.md", validation_report(cross, support, reps, boot_summary, design_summary))
    log.extend([f"cross_rows={len(cross)}", f"charls_rows={len(charls)}", f"charls_clusters={charls.cluster.nunique()}", f"bootstrap_successful={boot_summary['successful']}", f"bootstrap_failed={boot_summary['failed']}", f"point_delta={boot_summary['point']['delta']:.12f}", f"point_U={boot_summary['point']['U']:.12f}", f"point_V={boot_summary['point']['V']:.12f}"])
    if boot_summary["successful"] != BOOTSTRAP_TOTAL:
        raise AssertionError("not all planned bootstrap repetitions succeeded")
    log.append(f"finished_utc={datetime.now(timezone.utc).isoformat()}")
    write_text(PACKAGE / "run_log.txt", "\n".join(log))
    hashes = make_hash_manifest()
    (PACKAGE / "source_hashes.json").write_text(json.dumps(hashes, ensure_ascii=False, indent=2), encoding="utf-8")
    manifest = {"status": "passed", "created_utc": datetime.now(timezone.utc).isoformat(), "seed": SEED, "bootstrap_total": BOOTSTRAP_TOTAL, "bootstrap_successful": boot_summary["successful"], "bootstrap_failed": boot_summary["failed"], "cross_programme_rows": len(cross), "cross_programme_negative_delta": int((cross.delta < 0).sum()), "cross_programme_nonnegative_delta": int((cross.delta >= 0).sum()), "cross_programme_ci_below_zero": int((cross.hi < 0).sum()), "charls_total_n": int(len(charls)), "charls_comparator_n": int(charls.smoke_status.isin([0, 2]).sum()), "charls_community_n": int(charls.cluster.nunique()), "versions": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "statsmodels": statsmodels.__version__, "patsy": patsy.__version__}, "source_hash_file": "source_hashes.json", "manuscript_modified": False, "validation_report": "validation_report.md"}
    (PACKAGE / "audit_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        (PACKAGE / "run_log.txt").write_text(traceback.format_exc(), encoding="utf-8")
        raise
