"""Read-only source reconstruction; all new outputs stay in this package."""
from pathlib import Path
import json, hashlib, platform
import numpy as np
import pandas as pd
import pyreadstat

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent
for x in ['data','results','figures']: (ROOT/x).mkdir(exist_ok=True)
SOURCES=set()
def csv(path,**kw):
    SOURCES.add(Path(path));return pd.read_csv(path,low_memory=False,**kw)
def dta(path,cols=None):
    SOURCES.add(Path(path));return pyreadstat.read_dta(str(path),usecols=cols)[0]
def uid(s):return 'CHARLS:'+pd.to_numeric(s).astype(float).astype(str)
def health(y):return next((BASE/'CHARLS'/str(y)).glob('*[Hh]ealth*[Ff]unctioning.dta'))
def status(d):
    # Explicit current/former answers override the never-smoking skip.
    return np.select([d.da061.eq(1),d.da061.eq(2),d.da061.eq(3)|d.da059.eq(2)],[2.,1.,0.],default=np.nan)
def medication(d,dis,any_med=False):
    q={'hypertension':1,'dyslipidaemia':2,'diabetes':3}[dis]
    prefix={'hypertension':'da011s','dyslipidaemia':'da010_2_s','diabetes':'da014s'}[dis]
    n=3 if dis=='hypertension' else 4
    yes=d[prefix+'2'].eq(2)
    if dis=='diabetes':yes|=d[prefix+'3'].eq(3)
    if any_med:yes|=d[prefix+'1'].eq(1)
    answered=pd.concat([d[prefix+str(i)].eq(i) for i in range(1,n+1)],axis=1).any(axis=1)
    return np.where(yes,1.,np.where(d[f'da007_{q}_'].eq(2)|answered,0.,np.nan))

def main():
    panel=csv(BASE/'corrected_panel/data/panel_diseases_bmi_corrected.csv.gz')
    ht=csv(BASE/'corrected_panel/data/hypertension_panel.csv.gz')
    h=dta(health(2011));h['ID']=h.ID.astype(str).str.strip();h['uid']=uid(h.ID)
    assert h.ID.str.fullmatch(r'\d{11}').all() and h.ID.is_unique
    h['smoke_status']=status(h)
    h['cig_day']=pd.to_numeric(h.da063,errors='coerce').where(lambda x:x.between(0,200))
    adds=[];audit=[]
    for ds,g in panel.groupby('dataset'):
        if ds=='CHARLS 2011':
            add=h[['uid','smoke_status','cig_day']].copy()
        elif ds.startswith('NHANES'):
            paths=list((BASE/'NHANES'/ds.replace('NHANES ','')).glob('SMQ*.xpt'))
            choices=[]
            for path in paths:
                _,meta=pyreadstat.read_xport(str(path),metadataonly=True)
                if {'SMQ020','SMQ040'}<=set(meta.column_names):choices.append(path)
            assert len(choices)==1,(ds,choices)
            SOURCES.add(choices[0]);s=pyreadstat.read_xport(str(choices[0]))[0]
            add=pd.DataFrame({'uid':ds+':'+s.SEQN.astype(float).astype(str),
                'smoke_status':np.select([s.SMQ040.isin([1,2]),s.SMQ040.eq(3),s.SMQ020.eq(2)&s.SMQ040.isna()],[2.,1.,0.],default=np.nan)})
        else:continue
        q=g.merge(add,on='uid',how='left',validate='many_to_one')
        known=q.smoke_status.notna()
        assert np.array_equal(q.loc[known,'smoke'].to_numpy(),q.loc[known,'smoke_status'].eq(2).astype(float).to_numpy()),ds
        for dis,z in q.groupby('disease'):
            audit.append(dict(dataset=ds,disease=dis,n=len(z),status_missing=int(z.smoke_status.isna().sum()),
                              never=int(z.smoke_status.eq(0).sum()),former=int(z.smoke_status.eq(1).sum()),current=int(z.smoke_status.eq(2).sum())))
            if ds=='CHARLS 2011':
                mh=h[['uid']].copy();mh['med']=medication(h,dis);mh['med_any']=medication(h,dis,True)
                z=z.merge(mh,on='uid',validate='one_to_one')
                for col in ['med','med_any']:
                    z['MT' if col=='med' else 'MT_any']=np.where(z.M.eq(1)|z[col].eq(1),1.,np.where(z.M.eq(0)&z[col].eq(0),0.,np.nan))
            adds.append(z)
    p=pd.concat(adds,ignore_index=True)
    p.to_csv(ROOT/'data/two_country_mechanism_panel.csv.gz',index=False)
    pd.DataFrame(audit).to_csv(ROOT/'results/smoking_category_flow.csv',index=False)
    # Verify the newly reconstructed HTN medication agrees with canonical data.
    a=p[(p.dataset=='CHARLS 2011')&(p.disease=='hypertension')].set_index('uid')
    b=ht[ht.dataset=='CHARLS 2011'].set_index('uid').loc[a.index]
    assert np.allclose(a.med,b.med,equal_nan=True)
    # Official ID bridge, without using retrospectively edited disease variables.
    harmon=BASE/'CHARLS/Harmonized_CHARLS/H_CHARLS_D_Data.dta'
    cols=['ID','ID_w1']+[f'r{w}smoken' for w in [1,2,3]]
    bridge=dta(harmon,cols);bridge.ID=bridge.ID.astype(str).str.strip();bridge.ID_w1=bridge.ID_w1.astype(str).str.strip()
    bridge=bridge[bridge.ID_w1.str.fullmatch(r'\d{11}')].copy()
    for w in [1,2,3]:bridge[f'r{w}smoken']=pd.to_numeric(bridge[f'r{w}smoken'],errors='coerce')
    assert bridge.ID_w1.is_unique and bridge.ID.is_unique
    assert (bridge.ID_w1.str[:9]+bridge.ID_w1.str[9:].str.zfill(3)).eq(bridge.ID).all()
    base=csv(BASE/'CHARLS/analysis/charls_analysis_wide.csv',dtype={'ID':'string'})
    base=base[['ID','age','male','edu','bmi']].merge(h,on='ID',how='left',validate='one_to_one')
    base=base.merge(bridge.rename(columns={'ID':'ID_followup','ID_w1':'ID'}),on='ID',how='left',validate='one_to_one')
    base['current_2011']=np.where(base.smoke_status.notna(),base.smoke_status.eq(2).astype(float),np.nan)
    for dis,i in [('hypertension',1),('dyslipidaemia',2),('diabetes',3)]:
        base[f'S2011_{dis}']=base[f'da007_{i}_'].map({1:1.,2:0.})
    selected=['ID','ID_followup','uid','age','male','edu','bmi','cig_day','current_2011','r1smoken','r2smoken','r3smoken']+[f'S2011_{d}' for d in ['hypertension','diabetes','dyslipidaemia']]
    base=base[selected]
    validation=[]
    for y,w in [(2013,2),(2015,3)]:
        raw=dta(health(y));raw.ID=raw.ID.astype(str).str.strip()
        assert raw.ID.is_unique and raw.ID.str.fullmatch(r'\d{12}').all()
        s=status(raw)
        raw[f'current_{y}']=np.where(pd.notna(s),(s==2).astype(float),np.nan)
        # Follow-up explicitly declaring never-smoking conflicts with baseline current.
        raw[f'quit_explicit_{y}']=np.select([raw.da061.eq(2),raw.da061.eq(1)],[1.,0.],default=np.nan)
        raw[f'reported_never_{y}']=pd.Series(s,index=raw.index).eq(0)
        raw[f'interview_{y}']=1
        keep=['ID',f'current_{y}',f'quit_explicit_{y}',f'reported_never_{y}',f'interview_{y}']
        for dis,i in [('hypertension',1),('dyslipidaemia',2),('diabetes',3)]:
            for stem in ['da007_','zda007_','da007_w2_1_','da007_w2_2_']:
                c=f'{stem}{i}_';raw[f'{y}_{dis}_{stem}']=raw[c];keep.append(f'{y}_{dis}_{stem}')
        # Audit the old current-smoking logic (ever-smoker preload was misused).
        old=np.where(raw.zda059.notna(),raw.zda059.map({1:1.,2:0.}),raw[f'current_{y}'])
        known=raw[f'current_{y}'].notna()
        validation.append(dict(year=y,raw_n=len(raw),new_missing=int((~known).sum()),
          old_diff_on_known=int((old[known]!=raw.loc[known,f'current_{y}']).sum()),
          old_fills_unknown=int((pd.notna(old)&~known).sum())))
        base=base.merge(raw[keep].rename(columns={'ID':'ID_followup'}),on='ID_followup',how='left',validate='one_to_one')
        both=base[f'current_{y}'].notna()&base[f'r{w}smoken'].notna()
        assert np.allclose(base.loc[both,f'current_{y}'],base.loc[both,f'r{w}smoken'])
        validation[-1]['harmonized_current_matches_on_observed']=int(both.sum())
    base.to_csv(ROOT/'data/charls_longitudinal_rebuilt.csv.gz',index=False)
    pd.DataFrame(validation).to_csv(ROOT/'results/longitudinal_coding_audit.csv',index=False)
    # Save human-readable metadata for each new raw construct.
    _,meta=pyreadstat.read_dta(str(health(2011)),metadataonly=True)
    wanted=[c for c in meta.column_names if c.startswith(('da011','da014','da010_2_')) or c in ['da059','da061','da063']]
    pd.DataFrame([dict(variable=c,label=meta.column_names_to_labels[c],values=json.dumps(meta.variable_value_labels.get(c),ensure_ascii=False)) for c in wanted]).to_csv(ROOT/'results/raw_variable_dictionary.csv',index=False,encoding='utf-8-sig')
    SOURCES.add(BASE/'CHARLS/Harmonized_CHARLS/H_CHARLS_D_do_file.do')
    manifest=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()) for p in sorted(SOURCES)]
    (ROOT/'results/input_manifest.json').write_text(json.dumps(dict(sources=manifest,python=platform.python_version(),pandas=pd.__version__,numpy=np.__version__,protocol_sha256=hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()),indent=2),encoding='utf-8')
    print(pd.DataFrame(audit).to_string(index=False));print(pd.DataFrame(validation).to_string(index=False))
    print('BUILD COMPLETE',len(p),'disease records;',len(base),'baseline cohort rows')

if __name__=='__main__':main()
