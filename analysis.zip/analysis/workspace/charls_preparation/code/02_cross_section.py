from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from patsy import dmatrix

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;RES=ROOT/'results'
sys.path.insert(0,str(BASE/'corrected_panel/code'))
from common import fit_score,design,paired
RNG=np.random.default_rng(2026091702);B=2000
CHECKS=[]
def save(rows,name):pd.DataFrame(rows).to_csv(RES/name,index=False,encoding='utf-8-sig')
def ci(v,psi):
    se=float(np.sqrt(np.sum(np.asarray(psi)**2)))
    return dict(estimate=float(v),se=se,lo=float(v-1.96*se),hi=float(v+1.96*se))

def metrics(p):
    # Axis -2 is exposure, axis -1 is joint M,S state (M*2+S).
    m=p[...,2]+p[...,3];s=p[...,1]+p[...,3];u=p[...,2];v=p[...,1]
    diff=lambda z:z[...,1]-z[...,0]
    out={'rd_S':diff(s),'rd_M':diff(m),'unreported_component':-diff(u),'history_normal_component':diff(v),
         'rd_gap':diff(s)-diff(m),'pM_noncurrent':m[...,0],'pM_current':m[...,1],
         'pS_noncurrent':s[...,0],'pS_current':s[...,1],
         'report_given_M1_noncurrent':p[...,0,3]/m[...,0],
         'report_given_M1_current':p[...,1,3]/m[...,1],
         'report_given_M0_noncurrent':p[...,0,1]/(1-m[...,0]),
         'report_given_M0_current':p[...,1,1]/(1-m[...,1])}
    err=np.max(np.abs(out['rd_S']-out['rd_M']-out['unreported_component']-out['history_normal_component']))
    assert err<1e-12
    # Symmetric two-factor decomposition on the SAME marginal log-odds scale.
    # p-U and p+V remain probabilities because M,U,V are joint-state masses.
    def L(z):
        with np.errstate(divide='ignore',invalid='ignore'):
            value=np.log(z[...,1]/(1-z[...,1]))-np.log(z[...,0]/(1-z[...,0]))
        return np.where(np.isfinite(value),value,np.nan)
    lm=L(m);ls=L(s);lu=L(m-u);lv=L(m+v)
    out.update(logOR_M=lm,logOR_S=ls,logOR_gap=ls-lm,
               logOR_unreported_component=.5*((lu-lm)+(ls-lv)),
               logOR_history_normal_component=.5*((lv-lm)+(ls-lu)))
    assert np.nanmax(np.abs(out['logOR_gap']-out['logOR_unreported_component']-out['logOR_history_normal_component']))<1e-10
    return out

def decomposition(g,label,dis,std):
    g=g.copy();n0=len(g)
    if std:
        age=pd.cut(g.age,[-np.inf,50,60,70,np.inf],right=False,labels=False)
        g['strat']=g.dataset.astype(str)+'/'+age.astype(str)+'/'+g.male.astype(str)
        tab=pd.crosstab(g.strat,g.smoke).reindex(columns=[0.,1.],fill_value=0)
        good=tab.index[tab.min(axis=1)>=10];g=g[g.strat.isin(good)].copy()
    else:g['strat']='all'
    assert len(g)>100 and not g.duplicated(['dataset','uid']).any()
    point=np.zeros((2,4));boot=np.zeros((B,2,4))
    for _,z in g.groupby('strat'):
        w=len(z)/len(g)
        for e in [0,1]:
            h=z[z.smoke==e];counts=np.bincount((h.M*2+h.S).astype(int),minlength=4)
            prob=counts/len(h);point[e]+=w*prob
            boot[:,e]+=w*RNG.multinomial(len(h),prob,size=B)/len(h)
    a=metrics(point);bs=metrics(boot)
    rows=[]
    for key,val in a.items():
        lo,hi=np.nanquantile(bs[key],[.025,.975]);valid=int(np.isfinite(bs[key]).sum())
        rows.append(dict(dataset=label,disease=dis,standardization='age_sex_cycle' if std else 'raw',
                         n_original=n0,n=len(g),excluded_common_support=n0-len(g),metric=key,estimate=val,lo=lo,hi=hi,bootstrap_valid=valid,bootstrap_total=B))
    return rows

def category_model(g,label,dis,flex=False):
    g=g.dropna(subset=['M','S','smoke_status','age','male','edu']).reset_index(drop=True)
    g['current']=g.smoke_status.eq(2).astype(float);g['former']=g.smoke_status.eq(1).astype(float)
    if flex:
        xcov=np.asarray(dmatrix('bs(age, df=4, degree=3) + C(male) + C(edu) + C(dataset)',g),float)
        # Intercept returned by patsy; put exposure(s) after it.
        X=np.column_stack([xcov[:,0],g.current,xcov[:,1:]])
    else:X,_=design(g,'current',['age','male','edu'],wave=g.dataset.nunique()>1)
    X3=np.column_stack([X[:,:2],g.former,X[:,2:]])
    outs={};covadj=np.sqrt(len(g)/(len(g)-X3.shape[1]))
    for outcome in ['M','S']:
        b,i,c=fit_score(X,g[outcome]);t,j,cc=fit_score(X3,g[outcome]);assert c and cc
        outs[outcome]=(b,i*covadj,t,j*covadj)
    rows=[]
    for outcome,(b,i,t,j) in outs.items():
        for contrast,est,psi in [('current_vs_noncurrent',b[1],i[:,1]),('current_vs_never',t[1],j[:,1]),('former_vs_never',t[2],j[:,2])]:
            rr=ci(est,psi);rows.append(dict(dataset=label,disease=dis,model='flexible_age_education' if flex else 'original_adjustment',n=len(g),outcome=outcome,contrast=contrast,
                **rr,OR=np.exp(rr['estimate']),OR_lo=np.exp(rr['lo']),OR_hi=np.exp(rr['hi'])))
    m,mi,m3,mi3=outs['M'];s,si,s3,si3=outs['S']
    delta2=s[1]-m[1];delta3=s3[1]-m3[1]
    for contrast,v,psi in [('delta_current_vs_noncurrent',delta2,si[:,1]-mi[:,1]),('delta_current_vs_never',delta3,si3[:,1]-mi3[:,1]),
                           ('delta_change_reference',delta3-delta2,si3[:,1]-mi3[:,1]-si[:,1]+mi[:,1])]:
        rows.append(dict(dataset=label,disease=dis,model='flexible_age_education' if flex else 'original_adjustment',n=len(g),outcome='S_minus_M',contrast=contrast,**ci(v,psi)))
    return rows

def treatment(g,label,dis,medcol='med'):
    cov=['age','male','edu']
    if label.startswith('HAALSI'):cov=['age','male']
    z=g.dropna(subset=['M','S',medcol,'smoke',*cov]).copy()
    if len(z)<300:return [],[]
    z['MT']=((z.M==1)|(z[medcol]==1)).astype(float)
    wave=z.dataset.nunique()>1
    a=paired(z,ref='M',cov=cov,wave=wave);b=paired(z,ref='MT',cov=cov,wave=wave)
    shift=paired(z.assign(S=z.M),ref='MT',cov=cov,wave=wave)
    rows=[dict(dataset=label,disease=dis,medication=medcol,n=len(z),delta_M=a['delta'],delta_M_lo=a['lo'],delta_M_hi=a['hi'],
       delta_MT=b['delta'],delta_MT_lo=b['lo'],delta_MT_hi=b['hi'],shift=shift['delta'],shift_lo=shift['lo'],shift_hi=shift['hi'],
       OR_S=a['or_selfreport'],OR_M=a['or_measured'],OR_MT=b['or_measured'])]
    states=[]
    for e,zz in z.groupby('smoke'):
        for m in [0,1]:
            for s in [0,1]:
                h=zz[(zz.M==m)&(zz.S==s)]
                states.append(dict(dataset=label,disease=dis,medication=medcol,smoke=e,M=m,S=s,n_exposure=len(zz),n=len(h),
                      fraction=len(h)/len(zz),treated_n=h[medcol].sum(),treated_fraction=h[medcol].mean()))
    return rows,states

def main():
    p=pd.read_csv(BASE/'corrected_panel/data/panel_diseases_bmi_corrected.csv.gz',low_memory=False)
    pp=pd.read_csv(ROOT/'data/two_country_mechanism_panel.csv.gz',low_memory=False)
    ht=pd.read_csv(BASE/'corrected_panel/data/hypertension_panel.csv.gz',low_memory=False)
    old=pd.read_csv(BASE/'corrected_panel/results/multidisease_corrected.csv')
    old=old[old.exposure=='smoke'].copy()
    old['S_protective_point']=old.or_selfreport.lt(1);old['M_protective_point']=old.or_measured.lt(1)
    old['S_lower_than_M']=old.delta.lt(0);old['delta_CI_below_zero']=old.hi.lt(0)
    save(old,'all_42_cells.csv')
    save(old.groupby('disease').agg(cells=('dataset','size'),S_protective_point=('S_protective_point','sum'),M_protective_point=('M_protective_point','sum'),S_lower_than_M=('S_lower_than_M','sum'),delta_CI_below_zero=('delta_CI_below_zero','sum')).reset_index(),'phenomenon_summary.csv')
    dec=[];cats=[];rates=[];diagnostic=[]
    for (ds,dis),g in p.groupby(['dataset','disease']):
        for std in [False,True]:dec.extend(decomposition(g,ds,dis,std))
    for label,sub in [('CHARLS 2011',pp[pp.dataset=='CHARLS 2011']),('NHANES pooled',pp[pp.dataset.str.startswith('NHANES')])]:
        for dis,g in sub.groupby('disease'):
            if label=='NHANES pooled':
                for std in [False,True]:dec.extend(decomposition(g,label,dis,std))
            cats.extend(category_model(g,label,dis));cats.extend(category_model(g,label,dis,True))
            for status,z in g.groupby('smoke_status'):
                rates.append(dict(dataset=label,disease=dis,smoke_status=status,n=len(z),mean_age=z.age.mean(),male_fraction=z.male.mean(),pM=z.M.mean(),pS=z.S.mean()))
            # Diagnostic-report contrasts within M status: descriptive, selection-sensitive.
            for m,z in g.groupby('M'):
                X,_=design(z,'smoke',['age','male','edu'],wave=z.dataset.nunique()>1)
                b,i,c=fit_score(X,z.S);assert c
                r=ci(b[1],i[:,1]*np.sqrt(len(z)/(len(z)-X.shape[1])))
                diagnostic.append(dict(dataset=label,disease=dis,M=m,n=len(z),**r,OR=np.exp(r['estimate']),OR_lo=np.exp(r['lo']),OR_hi=np.exp(r['hi'])))
            print('MECHANISM',label,dis,len(g),flush=True)
    # Per-cycle category contrasts allow heterogeneity inspection.
    for (ds,dis),g in pp[pp.dataset.str.startswith('NHANES')].groupby(['dataset','disease']):cats.extend(category_model(g,ds,dis))
    save(dec,'state_decomposition.csv');save(cats,'smoking_reference_models.csv');save(rates,'smoking_category_descriptives.csv');save(diagnostic,'report_given_measurement_models.csv')
    trs=[];states=[]
    for ds,g in ht.groupby('dataset'):
        if g.med.notna().sum()<300:continue
        a,b=treatment(g,ds,'hypertension');trs+=a;states+=b
    nh=ht[ht.dataset.str.startswith('NHANES')]
    a,b=treatment(nh,'NHANES pooled','hypertension');trs+=a;states+=b
    for dis,g in pp[pp.dataset=='CHARLS 2011'].groupby('disease'):
        if dis!='hypertension':
            a,b=treatment(g,'CHARLS 2011',dis);trs+=a;states+=b
        a,b=treatment(g,'CHARLS 2011',dis,'med_any');trs+=a;states+=b
    save(trs,'treatment_definition_models.csv');save(states,'treatment_joint_states.csv')
    # Compare canonical HTN results on the same complete medication sample.
    oldt=pd.read_csv(BASE/'corrected_panel/results/treatment_definition_comparison.csv')
    new=pd.DataFrame(trs);new=new[(new.medication=='med')&(new.disease=='hypertension')]
    v=new.merge(oldt[oldt.exposure=='smoke'],on='dataset',suffixes=('_new','_old'))
    for a,b in [('delta_M','delta_threshold'),('delta_MT','delta_treatment'),('shift_new','shift_old')]:
        err=float(np.max(np.abs(v[a]-v[b])));assert err<1e-9;CHECKS.append(dict(check=a,max_error=err))
    save(CHECKS,'cross_section_numeric_checks.csv')
    print(pd.read_csv(RES/'phenomenon_summary.csv').to_string(index=False))
    print('CROSS SECTION COMPLETE',len(dec),'decomposition rows;',len(cats),'model contrasts')

if __name__=='__main__':main()
