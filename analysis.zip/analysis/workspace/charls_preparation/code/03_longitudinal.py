from pathlib import Path
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT=Path(__file__).resolve().parents[1];RES=ROOT/'results'
def save(rows,name):pd.DataFrame(rows).to_csv(RES/name,index=False,encoding='utf-8-sig')
def fit(z,extra=False):
    cov=['age','male','edu']+(['bmi','cig_day'] if extra else [])
    q=z.dropna(subset=['exposure','quit',*cov]).copy()
    X=pd.DataFrame({'const':1.,'exposure':q.exposure,'age10':(q.age-60)/10,'male':q.male,'edu':q.edu},index=q.index)
    if extra:X['bmi']=q.bmi.where(q.bmi.between(10,70));X['cig_day']=q.cig_day
    good=X.notna().all(axis=1);X=X[good];q=q.loc[good]
    if q.exposure.nunique()<2 or q.quit.nunique()<2:return dict(n=len(q),status='insufficient_variation')
    X=X.loc[:,(X.nunique()>1)|(X.columns=='const')]
    rows=[]
    for kind,family in [('OR',sm.families.Binomial()),('RR',sm.families.Poisson())]:
        f=sm.GLM(q.quit,X,family=family).fit(cov_type='HC1',maxiter=100)
        b=f.params['exposure'];se=f.bse['exposure']
        assert f.converged and np.isfinite([b,se]).all()
        n1=int(q.exposure.sum());n0=len(q)-n1;e1=int(q.loc[q.exposure==1,'quit'].sum());e0=int(q.loc[q.exposure==0,'quit'].sum())
        rows.append(dict(n=len(q),n_diagnosed=n1,n_not_diagnosed=n0,quit_diagnosed=e1,quit_not_diagnosed=e0,
          quit_rate_diagnosed=e1/n1,quit_rate_not_diagnosed=e0/n0,measure=kind,estimate=np.exp(b),lo=np.exp(b-1.96*se),hi=np.exp(b+1.96*se),
          covariates='+'.join(X.columns[2:]),status='sparse_exposed_events' if min(e1,n1-e1)<10 else 'ok',
          predicted_mean_above_1=int((f.fittedvalues>1).sum())))
    return rows

def main():
    p=pd.read_csv(ROOT/'data/charls_longitudinal_rebuilt.csv.gz',dtype={'ID':'string','ID_followup':'string'},low_memory=False)
    p['bmi']=p.bmi.where(p.bmi.between(10,70))
    rows=[];flows=[];bounds=[];coding=[]
    for dis in ['hypertension','diabetes','dyslipidaemia']:
        s0=f'S2011_{dis}'
        # Baseline known diagnosis before a later explicit quit report.
        for year in [2015,2013]:
            z=p[p.current_2011.eq(1)].dropna(subset=[s0,'age','male','edu']).copy()
            z['exposure']=z[s0];z['quit']=z[f'quit_explicit_{year}']
            tag=f'baseline2011_diagnosis_to_quit{year}'
            for e,g in z.groupby('exposure'):
                n=len(g);obs=g.quit.notna().sum();events=g.quit.sum()
                flows.append(dict(analysis=tag,disease=dis,exposure=e,eligible_n=n,interviewed_n=int(g[f'interview_{year}'].eq(1).sum()),
                     explicit_smoking_outcome_n=obs,explicit_quit_n=events,reported_never_conflict=int(g[f'reported_never_{year}'].eq(True).sum()),
                     outcome_missing_n=n-obs,observed_fraction=obs/n,mean_age=g.age.mean(),male_fraction=g.male.mean()))
                bounds.append(dict(analysis=tag,disease=dis,exposure=e,n=n,quit_lower=events/n,quit_upper=(events+n-obs)/n))
            for extra in [False,True]:
                res=fit(z,extra)
                for rr in (res if isinstance(res,list) else [res]):rows.append(dict(analysis=tag,disease=dis,adjustment='plus_BMI_cigarettes' if extra else 'age_sex_education',**rr))
            # Separate covariate adjustment from the change in complete-case sample.
            res=fit(z.dropna(subset=['bmi','cig_day']),False)
            for rr in (res if isinstance(res,list) else [res]):rows.append(dict(analysis=tag,disease=dis,adjustment='base_model_on_expanded_complete_cases',**rr))
        # New diagnosis during 2011-2013 precedes the later 2013-2015 quit interval.
        z=p[p[s0].eq(0)&p.current_2013.eq(1)].dropna(subset=['age','male','edu']).copy()
        direct=z[f'2013_{dis}_da007_'];new=z[f'2013_{dis}_da007_w2_2_'];verify=z[f'2013_{dis}_da007_w2_1_'];pre=z[f'2013_{dis}_zda007_']
        invalid=verify.eq(2)|pre.eq(1)
        z['exposure']=np.select([direct.eq(1)|new.eq(1),direct.eq(2)|new.eq(2)],[1.,0.],default=np.nan)
        z.loc[invalid,'exposure']=np.nan
        z['quit']=z.quit_explicit_2015
        tag='new_diagnosis2011_2013_to_quit2013_2015'
        coding.append(dict(disease=dis,baseline_no_diagnosis_current2013_n=len(z),disputed_prior_record_n=int(invalid.sum()),new_diagnosis_known_n=int(z.exposure.notna().sum()),new_diagnosis_n=int(z.exposure.eq(1).sum())))
        for e,g in z.dropna(subset=['exposure']).groupby('exposure'):
            flows.append(dict(analysis=tag,disease=dis,exposure=e,eligible_n=len(g),interviewed_n=int(g.interview_2015.eq(1).sum()),explicit_smoking_outcome_n=g.quit.notna().sum(),
                explicit_quit_n=g.quit.sum(),reported_never_conflict=int(g.reported_never_2015.eq(True).sum()),outcome_missing_n=g.quit.isna().sum(),observed_fraction=g.quit.notna().mean(),mean_age=g.age.mean(),male_fraction=g.male.mean()))
        for extra in [False,True]:
            res=fit(z,extra)
            for rr in (res if isinstance(res,list) else [res]):rows.append(dict(analysis=tag,disease=dis,adjustment='plus_BMI_cigarettes' if extra else 'age_sex_education',**rr))
    save(rows,'longitudinal_quitting_models.csv');save(flows,'longitudinal_sample_flow.csv');save(bounds,'longitudinal_missing_outcome_bounds.csv');save(coding,'new_diagnosis_coding_flow.csv')
    print(pd.DataFrame(rows).query("adjustment == 'age_sex_education' and measure == 'RR'").to_string(index=False))
    print('LONGITUDINAL COMPLETE')

if __name__=='__main__':main()
