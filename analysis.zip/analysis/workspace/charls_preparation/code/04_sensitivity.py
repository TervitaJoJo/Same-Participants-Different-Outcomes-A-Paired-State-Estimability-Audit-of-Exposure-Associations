from pathlib import Path
import importlib.util
import numpy as np
import pandas as pd
from scipy.stats import t

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;RES=ROOT/'results'
spec=importlib.util.spec_from_file_location('cross',ROOT/'code/02_cross_section.py');cross=importlib.util.module_from_spec(spec);spec.loader.exec_module(cross)
def main():
    p=pd.read_csv(ROOT/'data/two_country_mechanism_panel.csv.gz',low_memory=False)
    rows=[]
    for label,z in [('CHARLS 2011',p[p.dataset=='CHARLS 2011']),('NHANES pooled',p[p.dataset.str.startswith('NHANES')])]:
        for dis,g in z.groupby('disease'):
            for subset,gg in [('male_only',g[g.male==1]),('age50_79',g[g.age.between(50,79)])]:
                for row in cross.category_model(gg,label,dis):rows.append(dict(subset=subset,**row))
    cross.save(rows,'subgroup_reference_sensitivity.csv')
    # Pooled NHANES hypertension: use verified examination weights/design IDs.
    h=pd.read_csv(BASE/'corrected_panel/data/hypertension_panel.csv.gz',low_memory=False)
    g=p[(p.dataset.str.startswith('NHANES'))&(p.disease=='hypertension')].merge(h[['dataset','uid','wt','stratum','psu']],on=['dataset','uid'],validate='one_to_one')
    g=g.dropna(subset=['wt','stratum','psu','smoke_status']);g=g[g.wt>0].reset_index(drop=True)
    g['current']=g.smoke_status.eq(2).astype(float);g['former']=g.smoke_status.eq(1).astype(float)
    X,_=cross.design(g,'current',['age','male','edu'],wave=True)
    X3=np.column_stack([X[:,:2],g.former,X[:,2:]])
    survey=[]
    def sci(v,psi):
        z=g[['dataset','stratum','psu']].copy();z['psi']=psi
        sums=z.groupby(['dataset','stratum','psu']).psi.sum();variance=0.;df=0
        for _,u in sums.groupby(level=[0,1]):
            n=len(u);assert n>=2;variance+=n/(n-1)*((u-u.mean())**2).sum();df+=n-1
        se=np.sqrt(variance);crit=t.ppf(.975,df)
        return dict(estimate=v,lo=v-crit*se,hi=v+crit*se,se=se,design_df=df)
    bs={}
    for outcome in ['M','S']:
        b,i,c=cross.fit_score(X,g[outcome],g.wt);b3,i3,c3=cross.fit_score(X3,g[outcome],g.wt);assert c and c3
        bs[outcome]=(b,i,b3,i3)
        for label,v,psi in [('current_vs_noncurrent',b[1],i[:,1]),('current_vs_never',b3[1],i3[:,1]),('former_vs_never',b3[2],i3[:,2])]:
            r=sci(v,psi);survey.append(dict(dataset='NHANES pooled',disease='hypertension',outcome=outcome,contrast=label,n=len(g),**r,OR=np.exp(v),OR_lo=np.exp(r['lo']),OR_hi=np.exp(r['hi'])))
    m,mi,m3,mi3=bs['M'];s,si,s3,si3=bs['S']
    for label,v,psi in [('delta_current_vs_noncurrent',s[1]-m[1],si[:,1]-mi[:,1]),('delta_current_vs_never',s3[1]-m3[1],si3[:,1]-mi3[:,1]),
        ('delta_change_reference',s3[1]-m3[1]-s[1]+m[1],si3[:,1]-mi3[:,1]-si[:,1]+mi[:,1])]:
        survey.append(dict(dataset='NHANES pooled',disease='hypertension',outcome='S_minus_M',contrast=label,n=len(g),**sci(v,psi)))
    cross.save(survey,'nhanes_hypertension_survey_sensitivity.csv')
    # Joint definition/reference changes on identical complete cases; no summing
    # separate mechanism percentages with overlapping participants/processes.
    joint=[]
    for label,z in [('CHARLS 2011',p[p.dataset=='CHARLS 2011']),('NHANES pooled',g)]:
        if label=='NHANES pooled':
            z=z.drop(columns=['med'],errors='ignore').merge(h[['dataset','uid','med']],on=['dataset','uid'],validate='one_to_one')
        for dis,zz in z.groupby('disease'):
            zz=zz.dropna(subset=['M','S','med','smoke_status','age','male','edu']).copy()
            zz['MT']=(zz.M.eq(1)|zz.med.eq(1)).astype(float)
            for endpoint in ['M','MT']:
                for row in cross.category_model(zz.assign(M=zz[endpoint]),label,dis):joint.append(dict(reference_endpoint=endpoint,**row))
    cross.save(joint,'joint_reference_treatment_models.csv')
    print(pd.DataFrame(survey).to_string(index=False))
    print('SENSITIVITY COMPLETE')
if __name__=='__main__':main()
