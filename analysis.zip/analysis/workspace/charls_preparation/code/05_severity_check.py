"""Descriptive reporting differences within abnormal measured states.

Adds continuous severity on identical complete cases; this is not a causal
diagnosis-access model because M may itself be affected by smoking/treatment.
"""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from patsy import dmatrix
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
sys.path.insert(0,str(BASE/'corrected_panel/code'))
from common import fit_score,design
def main():
    p=pd.read_csv(ROOT/'data/two_country_mechanism_panel.csv.gz',low_memory=False)
    p=p[p.dataset=='CHARLS 2011']
    w=pd.read_csv(BASE/'CHARLS/analysis/charls_analysis_wide.csv',dtype={'ID':'string'},low_memory=False)
    w['uid']='CHARLS:'+pd.to_numeric(w.ID).astype(float).astype(str)
    p=p.merge(w[['uid','sbp','dbp','glu','hba1c','cho','ldl']],on='uid',validate='many_to_one')
    rows=[]
    for dis,markers in [('hypertension',['sbp','dbp']),('diabetes',['glu','hba1c']),('dyslipidaemia',['cho','ldl'])]:
        g=p[(p.disease==dis)&p.M.eq(1)].dropna(subset=markers).copy()
        for extra in [False,True]:
            X,_=design(g,'smoke',['age','male','edu'])
            if extra:
                spl=np.asarray(dmatrix(' + '.join(f'bs({c}, df=3, degree=3)' for c in markers)+' - 1',g))
                X=np.column_stack([X,spl])
            b,i,c=fit_score(X,g.S);assert c
            se=np.sqrt(np.sum(i[:,1]**2)*len(g)/(len(g)-X.shape[1]))
            rows.append(dict(dataset='CHARLS 2011',disease=dis,M=1,n=len(g),n_before_complete_markers=int(((p.disease==dis)&p.M.eq(1)).sum()),
                model='plus_continuous_marker_splines' if extra else 'base_on_same_sample',markers='+'.join(markers),OR=np.exp(b[1]),lo=np.exp(b[1]-1.96*se),hi=np.exp(b[1]+1.96*se),
                condition_number=float(np.linalg.cond(X))))
    pd.DataFrame(rows).to_csv(ROOT/'results/continuous_severity_reporting_sensitivity.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__':main()
