from pathlib import Path
import json,hashlib,platform
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator
import statsmodels

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;RES=ROOT/'results';FIG=ROOT/'figures'
DIS=['hypertension','diabetes','dyslipidaemia']
ZH={'hypertension':'高血压','diabetes':'糖尿病','dyslipidaemia':'血脂异常'}
EN={'hypertension':'Hypertension','diabetes':'Diabetes','dyslipidaemia':'Dyslipidaemia'}
def read(s):return pd.read_csv(RES/s)
def tab(head,rows):return '\n'.join(['| '+' | '.join(head)+' |','|'+'|'.join(['---']*len(head))+'|']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def one(t,**kwargs):
    for k,v in kwargs.items():t=t[t[k]==v]
    assert len(t)==1,(kwargs,len(t))
    return t.iloc[0]
def interval(row,est='estimate',lo='lo',hi='hi',digits=3):return f'{row[est]:.{digits}f}（{row[lo]:.{digits}f}–{row[hi]:.{digits}f}）'
def savefig(fig,name):
    fig.savefig(FIG/f'{name}.png',dpi=220,bbox_inches='tight')
    fig.savefig(FIG/f'{name}.pdf',bbox_inches='tight');plt.close(fig)
def figures():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    c=read('smoking_reference_models.csv');c=c[(c.model=='original_adjustment')&(c.outcome=='S')]
    fig,axs=plt.subplots(1,2,figsize=(10.4,4),sharey=True)
    for ax,ds in zip(axs,['CHARLS 2011','NHANES pooled']):
        for off,contrast,color,label in [(-.12,'current_vs_noncurrent','#256b93','Current vs non-current'),(.12,'current_vs_never','#c07729','Current vs never')]:
            for y,dis in enumerate(DIS):
                r=one(c,dataset=ds,disease=dis,contrast=contrast)
                ax.errorbar(r.OR,y+off,xerr=[[r.OR-r.OR_lo],[r.OR_hi-r.OR]],fmt='o',color=color,capsize=3,label=label if y==0 else None)
        ax.axvline(1,color='.5',ls='--',lw=1);ax.set_xscale('log');ax.set_xlim(.43,1.45)
        ax.set_xticks([.5,.7,1.,1.3],labels=['0.5','0.7','1.0','1.3']);ax.xaxis.set_minor_locator(NullLocator());ax.set_yticks(range(3),[EN[d] for d in DIS]);ax.set_title(ds)
        ax.set_xlabel('Adjusted OR for reported diagnosis (95% CI)');ax.grid(axis='x',alpha=.15)
    axs[0].invert_yaxis()
    handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.52,1.06),ncol=2,fontsize=9,frameon=False)
    fig.suptitle('Changing the smoking reference group attenuates some associations',fontsize=13,y=1.14)
    fig.text(.02,-.04,'Age, sex and education adjusted; NHANES additionally adjusts for cycle. Unweighted exploratory estimates.',fontsize=9)
    fig.tight_layout();savefig(fig,'01_smoking_reference')
    d=read('state_decomposition.csv');d=d[d.standardization=='age_sex_cycle']
    fig,ax=plt.subplots(figsize=(10,5.8));labels=[]
    specs=[('logOR_gap',0,'#252525','Total S minus M'),('logOR_unreported_component',-.18,'#256b93','Abnormal without reported diagnosis'),('logOR_history_normal_component',.18,'#c07729','Reported diagnosis below threshold')]
    for y,(ds,dis) in enumerate([(ds,dis) for ds in ['CHARLS 2011','NHANES pooled'] for dis in DIS]):
        labels.append(ds+' / '+EN[dis])
        for metric,off,col,lab in specs:
            r=one(d,dataset=ds,disease=dis,metric=metric)
            ax.errorbar(r.estimate,y+off,xerr=[[r.estimate-r.lo],[r.hi-r.estimate]],fmt='o',ms=5,color=col,capsize=2,label=lab if y==0 else None)
    ax.axvline(0,color='.5',lw=1,ls='--');ax.set_yticks(range(6),labels);ax.invert_yaxis();ax.set_xlabel('Contribution to standardized marginal log OR difference (95% CI)')
    ax.legend(loc='lower left',bbox_to_anchor=(0,1.02),fontsize=9,frameon=False);ax.grid(axis='x',alpha=.15)
    fig.text(.02,-.03,'Symmetric algebraic decomposition; components add to the total. Fixed age/sex/cycle standardization; 2,000 bootstrap draws.\nComponents describe joint states, not causal mechanisms. These marginal estimates differ from regression coefficients.',fontsize=9)
    fig.tight_layout();savefig(fig,'02_state_decomposition')
    l=read('longitudinal_quitting_models.csv');l=l[(l.analysis=='baseline2011_diagnosis_to_quit2015')&(l.adjustment=='age_sex_education')&(l.measure=='RR')]
    fig,ax=plt.subplots(figsize=(8.5,3.5))
    for y,dis in enumerate(DIS):
        r=one(l,disease=dis);ax.errorbar(r.estimate,y,xerr=[[r.estimate-r.lo],[r.hi-r.estimate]],fmt='o',color='#256b93',capsize=4)
        ax.text(1.88,y,f'n = {int(r.n):,}',va='center',fontsize=9)
    ax.axvline(1,color='.5',ls='--');ax.set_yticks(range(3),[EN[d] for d in DIS]);ax.invert_yaxis();ax.set_xlim(.8,2.12)
    ax.set_xlabel('Adjusted risk ratio for reported quitting by 2015 (95% CI)')
    ax.set_title('Baseline diagnosis and subsequent quitting among current smokers (CHARLS)')
    fig.text(.02,-.04,'2011 diagnosis precedes the 2015 quit report. Adjusted for age, sex and education; robust Poisson estimates.\nComplete observed outcomes only; differential follow-up and residual confounding remain.',fontsize=9)
    fig.tight_layout();savefig(fig,'03_longitudinal_quitting')

def audit():
    a={};p=read('all_42_cells.csv');a['all_cells_retained']=len(p)==42
    d=read('state_decomposition.csv').pivot(index=['dataset','disease','standardization'],columns='metric',values='estimate')
    a['rd_identity_max_error']=float(abs(d.rd_S-d.rd_M-d.unreported_component-d.history_normal_component).max())
    a['logOR_identity_max_error']=float(abs(d.logOR_gap-d.logOR_unreported_component-d.logOR_history_normal_component).max())
    a['max_point_probability_error']=float(max(abs(d.pS_noncurrent-(1/(1+np.exp(-(np.log(d.pS_current/(1-d.pS_current))-d.logOR_S))))).max(),0))
    for k in ['rd_identity_max_error','logOR_identity_max_error','max_point_probability_error']:assert a[k]<1e-10
    assert a['all_cells_retained']
    c=read('smoking_reference_models.csv');sel=c[(c.model=='original_adjustment')&(c.contrast=='delta_current_vs_noncurrent')&(c.dataset!='NHANES pooled')]
    v=sel.merge(p,on=['dataset','disease']);a['new_vs_canonical_delta_max_error']=float(abs(v.estimate-v.delta).max());assert a['new_vs_canonical_delta_max_error']<1e-10
    ll=read('longitudinal_quitting_models.csv');assert (ll.n==ll.n_diagnosed+ll.n_not_diagnosed).all();assert (ll.quit_diagnosed<=ll.n_diagnosed).all()
    a['longitudinal_counts_consistent']=True
    manifest=json.loads((RES/'input_manifest.json').read_text());unchanged=[]
    for source in manifest['sources']:
        path=BASE/source['path'];unchanged.append(hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==source['sha256'])
    assert all(unchanged);a['all_input_hashes_unchanged']=True;a['input_files_checked']=len(unchanged)
    a['protocol_sha256_final']=hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()
    a['protocol_sha256_at_initial_build']=manifest['protocol_sha256']
    a['protocol_was_exploratorily_extended']=a['protocol_sha256_final']!=a['protocol_sha256_at_initial_build']
    a['versions']=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,statsmodels=statsmodels.__version__,matplotlib=matplotlib.__version__)
    a['output_hashes']={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(ROOT.rglob('*')) if f.is_file() and f.suffix in ['.py','.csv','.md','.png','.pdf']}
    (RES/'final_audit.json').write_text(json.dumps(a,indent=2,ensure_ascii=False),encoding='utf-8');print(json.dumps({k:v for k,v in a.items() if k!='output_hashes'},indent=2))

def report():
    c=read('smoking_reference_models.csv');base=c[c.model=='original_adjustment']
    ph=read('phenomenon_summary.csv');t=read('treatment_definition_models.csv');states=read('treatment_joint_states.csv');j=read('joint_reference_treatment_models.csv')
    l=read('longitudinal_quitting_models.csv');sev=read('continuous_severity_reporting_sensitivity.csv');dec=read('state_decomposition.csv')
    rows=[]
    for dis in DIS:
        r=one(ph,disease=dis);rows.append([ZH[dis],int(r.cells),int(r.S_protective_point),int(r.M_protective_point),int(r.S_lower_than_M),int(r.delta_CI_below_zero)])
    phenomenon=tab(['疾病','波次单元','自报 OR<1','实测 OR<1','Δ<0','Δ 的95%CI全低于0'],rows)
    rows=[]
    for dis in DIS:
        ss=base[(base.dataset=='CHARLS 2011')&(base.disease==dis)&(base.outcome=='S')]
        a=one(ss,contrast='current_vs_noncurrent');b=one(ss,contrast='current_vs_never');f=one(ss,contrast='former_vs_never')
        rows.append([ZH[dis],int(a.n),interval(a,'OR','OR_lo','OR_hi'),interval(b,'OR','OR_lo','OR_hi'),interval(f,'OR','OR_lo','OR_hi')])
    ref=tab(['CHARLS 疾病','n','当前 vs 所有非当前','当前 vs 从不','既往 vs 从不'],rows)
    rows=[]
    for dis in DIS:
        a=one(t,dataset='CHARLS 2011',disease=dis,medication='med');s=states[(states.dataset=='CHARLS 2011')&(states.disease==dis)&(states.medication=='med')&(states.M==0)&(states.S==1)]
        rows.append([ZH[dis],int(a.n),f'{int(s.treated_n.sum())}/{int(s.n.sum())}（{s.treated_n.sum()/s.n.sum():.1%}）',f'{a.delta_M:.3f}',f'{a.delta_MT:.3f}',interval(a,'shift','shift_lo','shift_hi')])
    treatment=tab(['疾病','相同样本 n','S=1/M=0中用药者','原 Δ','纳入治疗后 Δ','Δ 改变（95%CI）'],rows)
    rows=[]
    for dis in DIS:
        a=one(sev,disease=dis,model='plus_continuous_marker_splines');rows.append([ZH[dis],int(a.n),interval(a,'OR','lo','hi')])
    severity=tab(['当次异常者','n','当前 vs 非当前：报告诊断史的 OR（95%CI）'],rows)
    rows=[]
    for dis in DIS:
        a=one(l,analysis='baseline2011_diagnosis_to_quit2015',disease=dis,adjustment='age_sex_education',measure='RR')
        rows.append([ZH[dis],int(a.n),f'{int(a.quit_diagnosed)}/{int(a.n_diagnosed)}（{a.quit_rate_diagnosed:.1%}）',f'{int(a.quit_not_diagnosed)}/{int(a.n_not_diagnosed)}（{a.quit_rate_not_diagnosed:.1%}）',interval(a)])
    long=tab(['2011年诊断','随访分析 n','有诊断者戒烟','无诊断者戒烟','调整 RR（95%CI）'],rows)
    rows=[]
    for dis in DIS:
        a=one(l,analysis='new_diagnosis2011_2013_to_quit2013_2015',disease=dis,adjustment='age_sex_education',measure='RR')
        rows.append([ZH[dis],int(a.n),int(a.n_diagnosed),int(a.quit_diagnosed),interval(a)])
    incident=tab(['疾病','n','新增诊断人数','新增诊断组戒烟人数','调整 RR（95%CI）'],rows)
    rows=[]
    for ds in ['CHARLS 2011','NHANES pooled']:
        for dis in DIS:
            q=dec[(dec.dataset==ds)&(dec.disease==dis)&(dec.standardization=='age_sex_cycle')]
            a=one(q,metric='logOR_gap');u=one(q,metric='logOR_unreported_component');v=one(q,metric='logOR_history_normal_component')
            rows.append([ds,ZH[dis],interval(a),f'{u.estimate:.3f}',f'{v.estimate:.3f}'])
    decomposition=tab(['数据','疾病','边际 Δ（95%CI）','异常/无诊断项','有诊断/未超阈值项'],rows)
    rows=[]
    for dis in DIS:
        vals=[]
        for endpoint,contrast in [('M','delta_current_vs_noncurrent'),('M','delta_current_vs_never'),('MT','delta_current_vs_noncurrent'),('MT','delta_current_vs_never')]:
            a=one(j,dataset='CHARLS 2011',disease=dis,reference_endpoint=endpoint,contrast=contrast);vals.append(f'{a.estimate:.3f}')
        rows.append([ZH[dis],*vals])
    joint=tab(['疾病','原参照/阈值','从不参照/阈值','原参照/含治疗','从不参照/含治疗'],rows)
    text=f'''# 为什么会出现“吸烟的表观保护性关联”：第一轮定量机制结果

日期：2026-09-17。本文为探索性工作报告，不是定稿或因果结论。分析代码、样本流、全部反例和原始变量审计均保留；正文及校正模型未改动。

## 当前能讲到哪一步

已经形成一个有数据支撑的小故事：**疾病定义、非吸烟参照组中包含的戒烟者、以及实测状态下诊断报告的差异，共同影响观察到的吸烟关联；它们只能解释部分现象，而且不同国家、疾病并不一致。**

最有支撑的是 CHARLS 高血压：当前吸烟的实测关联 OR 约1.08，自报关联 OR 约0.76；拆分既往吸烟者和纳入治疗后，两种定义的差距缩小但仍存在。基线已诊断高血压与后来报告戒烟的关联，提供时间顺序上的支持。当前不能写“证明自报误差造成多疾病保护效应”，也不能写“保护性已被完全解释”。

## 1. 完整描述现象，不能只挑保护性结果

三病各14个数据库/波次单元，共42个单元。以下 OR 均为既有修复数据的年龄、性别、教育调整估计。“OR<1”仅指点估计，并不等于统计显著。

{phenomenon}

Δ=log OR(S)−log OR(M)。自报 OR<1、实测 OR<1、Δ<0是三个不同问题。尤其糖尿病在14个单元中有11个实测 OR 也低于1，不能把全部保护性归给自报。多个波次和疾病共享参与者，42个单元不是42项独立研究。

## 2. 参照组混合了戒烟者，确实影响关联

从 CHARLS 原始 `da059/da061` 和 NHANES 原始 `SMQ020/SMQ040` 重建当前、既往、从不吸烟。CHARLS和NHANES本轮27个疾病单元均无新增吸烟分类缺失；与修复后的二分类当前吸烟逐条一致。

在每病相同完整样本中，三分类模型同时放入当前和既往吸烟指标。下表结局均为自报诊断史，数值为调整 OR（95%CI）：

{ref}

CHARLS 三病中，既往吸烟者的自报疾病 OR 都高于从不吸烟者。将这部分人混入非当前吸烟参照组，与更强的表观保护性相一致；改用从不吸烟参照后，当前吸烟 OR 上升但仍低于1。年龄样条、分类教育、仅男性和限定50–79岁的敏感性分析均保留了这一 CHARLS 模式。参照组改变同时改变估计目标，不能将 OR 的改变直接称为“戒烟导致的偏倚百分比”。

NHANES 是必要的反例：合并八周期的高血压自报 OR 为1.159，当前 vs 从不为1.206，均未出现 CHARLS 式保护性。复杂抽样设计敏感性分别为1.134（1.059–1.215）和1.195（1.113–1.283）。各周期完整结果另存，未因方向不同排除。

![吸烟参照组](figures/01_smoking_reference.png)

## 3. “有诊断史、当次指标正常”中很多人正在接受治疗

CHARLS 按三病分别核实原始用药问题。主分析纳入西药，糖尿病另含胰岛素；中药纳入另做敏感性。S=1/M=0不能直接叫“误报”：S是诊断史，M是当前一次测量。

{treatment}

高血压的1,352名“有诊断史但当前未超阈值”者中，983人正在使用西药，占72.7%。非当前吸烟者此类状态占10.9%，当前吸烟者占7.7%；各自其中74.6%与66.7%用药。**这些人群构成差异足以改变自报与实测关联的比较。**当次指标正常与用药并存支持治疗控制的解释，但横断面不能证明每个人都是由治疗使指标降至阈值以下。

把“阈值异常或正在用药”作为扩展参照后，高血压 Δ 从−0.355变为−0.208；变化0.147（0.094–0.201）。这是疾病口径敏感性，不是“治疗解释了某个因果比例”。扩展参照含自报用药信息，也不是独立金标准。

把参照组与治疗口径在**同一完整样本**中交叉比较，得到：

{joint}

表中均为条件 log OR 差。CHARLS 高血压同时改变两者后 Δ 仍为−0.144（95%CI −0.250至−0.037）。三病的剩余差异都未被强制归零；不同模块重叠，不能把各自变化比例相加。

## 4. 已有实测异常的吸烟者，更少报告诊断史

CHARLS 中先限定当次指标异常者，再调整年龄、性别、教育；为排除“仅超过同一阈值但严重程度不同”，进一步加入每病两项连续指标的样条。各病加入指标前后保持同一样本。结果为：

{severity}

高血压指标为收缩压/舒张压，糖尿病为血糖/HbA1c，血脂异常为总胆固醇/LDL。加入连续严重程度后，当前吸烟者报告诊断史的优势比仍较低。

这支持“实际检测、诊断知晓、诊断史报告过程存在差异”的线索，但尚不能区分就医较少、疾病历程差异、记忆/报告差异等原因。对 M=1 条件化还可能引入选择偏倚，不能把该 OR 当作吸烟对诊断机会的因果效应。下一步应加入医疗利用、筛查和可及性证据。

## 5. 用精确分解给差异定量，而不是编造因果比例

定义 U=P(M=1,S=0)，V=P(M=0,S=1)，则 S 的患病率等于 M 的患病率减 U 加 V。由此可精确得到：

**RD(S)=RD(M)−RD(U)+RD(V)。**

例如 CHARLS 高血压按共同年龄/性别总体标准化后，当前减非当前吸烟的风险差为：

**自报 −3.38 个百分点 = 实测 +0.24 − “异常但无诊断史”2.08 − “有诊断史但当前正常”1.54。**

风险差不能直接与 log OR 混用。因此还用两种加入顺序平均的对称分解，将标准化边际 log OR 差拆成U、V两项：

{decomposition}

每行两项恰好加为该行边际 Δ。置信区间来自2,000次联合状态重抽样，所有分量区间见CSV/下图。标准化使用 <50、50–59、60–69、≥70岁与性别层，NHANES另按周期分层；共同支持要求每层两暴露组各至少10人，移除人数逐单元报告。这是固定样本构成下的区间，不是复杂抽样总体区间。

**须保留的限制：**CHARLS 糖尿病、血脂异常的标准化边际 Δ 区间均跨0，与原条件回归的结论强度不同。这里的年龄层、教育调整、交互处理及边际/条件目标不同，不能只选更显著的一套写正文。正式稿需统一主要估计目标，并检验性别差异及模型标准化。正负分量可相互抵消，不能输出一个稳定的“解释百分比”。

![联合状态分解](figures/02_state_decomposition.png)

## 6. 纵向资料：高血压支持“诊断在先、戒烟在后”，多疾病尚未闭环

从 CHARLS 原始2011、2013、2015问卷重建，以官方 ID_w1→ID 映射核验11位与12位ID。基线诊断采用当年记录，不使用后期回访追溯修订过的基线诊断。主要分析限定2011年当前吸烟且2015年明确报告仍吸烟/戒烟者；2015年反称“从不吸烟”的矛盾回答列为未知，不当作戒烟。

{long}

高血压调整 RR 为1.35（1.15–1.58）。进一步调整 BMI和每日烟量，完整样本减少至2,521，RR为1.25（1.03–1.52）；CSV另存同一2,521人上的基础模型，避免把样本改变误认作混杂调整效果。糖尿病和血脂异常的主要区间跨1，应报告为证据不足。

更严格地考察2011年无诊断、2013年仍吸烟者，比较2013年前新增诊断与2015年戒烟：

{incident}

三个区间均跨1；糖尿病新增诊断组仅1人戒烟，血脂异常仅5人，估计不稳定。**“新增诊断触发戒烟”尚未获得有力直接证据。**基线诊断预测后续戒烟只能作为支持性关联。

高血压已诊断组有明确2015吸烟结局的比例为77.7%，未诊断组83.1%，存在差异失访/缺失。最保守的未知结局范围分别为16.7%–39.0%与12.8%–29.7%，重叠明显；未知结局可以改变判断。需进一步处理失访与死亡，不能把完整案例关联当成因果定论。

![纵向戒烟](figures/03_longitudinal_quitting.png)

## 7. 本轮修复与质量检查

- 旧 CHARLS 纵向脚本把 `zda059` 既往曾吸烟当成当前吸烟。与原始明确当前状态相比，2013年有856条、2015年有2,572条不一致；2013年还把3,489条当前状态未知记录填成已知。新构建与官方协调库的可比较当前状态逐条一致。**这些是纵向旧代码问题，不是本轮修复后二分类横断面结果又失效。**
- 旧脚本的缺失血压/诊断布尔化问题也未沿用；本轮纵向只使用明确诊断及明确戒烟回答，不把失访、未知当无病/未戒烟。
- 42个单元全部保留；新的原模型 Δ 与修复版结果核对。风险差、log OR 分解逐单元检查恒等式；高血压治疗比较与已有修复结果一致。
- log OR 分解中 ELSA w8 糖尿病的原始样本有1/2,000次重抽样落在零概率边界，分量区间基于1,999次可估计重复并明确计数，未加伪计数。
- 原始输入散列复核，分析不改写原始数据；最终软件版本、散列和数值核查见 `results/final_audit.json`。方案在初次分析前写入，之后的探索性扩展在方案末尾逐项记录；不是预注册。

## 下一轮最值得补的工作

1. **先把高血压机制证据做完整。**在 CHARLS 加入既往筛查、门诊/住院利用、保险、城乡等可及性变量；明确因果图后区分混杂调整与描述性机制分析，并把连续严重程度结果接入。不能简单认为多放协变量就是解释机制。
2. **补失访与死亡处理，并增加纵向复现。**对2011→2015的观察概率做合理建模、进行加权与非随机缺失敏感性；核实新增诊断时间和戒烟时间。ELSA或CHARLS后续波次可增加事件，但不能以预载曾吸烟填补当前状态。
3. **统一估计目标并检查可比性。**主要结果宜明确使用标准化风险差/边际 OR中的一种，条件回归作为并列或敏感性；检验性别交互、共同年龄层、疾病/波次异质性。NHANES三病的测量组件、空腹条件、用药跳题与适用权重需完整统一，不能把本轮未加权的所有三病结果直接推广到国家总体。
4. **把故事收束为有边界的解释。**优先“高血压机制主线＋糖尿病/血脂异常的扩展与反例”，比预设“所有疾病保护性都由自报误差造成”更符合现有证据。等这些证据稳固，再决定校正模型是否独立成另一篇工作。

本轮已经完成的是定量机制分析的第一版证据包；尚未完成因果机制识别或可直接投稿的最终分析。
'''
    text=text.replace('(figures/',f'({ROOT.as_posix()}/figures/')
    (ROOT/'阶段性机制报告.md').write_text(text,encoding='utf-8')
    (ROOT/'README.md').write_text('''# 机制分析工作包

先读 `阶段性机制报告.md`；探索性方案与扩展记录见 `PROTOCOL.md`。

按顺序运行 `code/01_build.py` → `02_cross_section.py` → `03_longitudinal.py` → `04_sensitivity.py` → `05_severity_check.py` → `06_report.py`。运行前设置 OPENBLAS_NUM_THREADS=1、OMP_NUM_THREADS=1。Python路径为 python。

`data/` 含本地个体级衍生数据，请按原数据库使用协议保管；对外交流使用 `results/` 的汇总和 `figures/` 图片。没有上传参与者数据。原始数据、正文与既有校正模型未修改。

本包核心表：

- all_42_cells.csv / phenomenon_summary.csv：完整现象与反例。
- state_decomposition.csv：风险差和边际 log OR 对称分解、共同支持、重抽样区间。
- smoking_reference_models.csv：三分类参照组、原模型与灵活模型。
- treatment_definition_models.csv / treatment_joint_states.csv：治疗口径和联合状态。
- joint_reference_treatment_models.csv：相同案例下交叉比较两项改变。
- continuous_severity_reporting_sensitivity.csv：实测异常者中连续严重程度调整。
- longitudinal_quitting_models.csv / longitudinal_sample_flow.csv：纵向估计与失访。
- longitudinal_missing_outcome_bounds.csv：未知随访结局的保守范围。
- subgroup_reference_sensitivity.csv / nhanes_hypertension_survey_sensitivity.csv：敏感性。
- raw_variable_dictionary.csv / longitudinal_coding_audit.csv：变量标签与旧编码问题。
- input_manifest.json：数据构建时的来源散列及当时方案散列；final_audit.json记录最终方案版本与输出。

所有区间均为探索性点态区间；不同疾病、波次不独立。本包不报告可相加的因果解释百分比，不以使 OR 超过1为目标。
''',encoding='utf-8')

if __name__=='__main__':figures();report();audit();print('REPORT AND FIGURES COMPLETE')
