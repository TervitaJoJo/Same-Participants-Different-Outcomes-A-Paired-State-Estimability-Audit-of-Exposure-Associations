"""Moderate simulation for failure diagnosis and validation allocation.

Primary target: the crude measured-outcome log odds ratio
    beta_M = logit(P(M=1|E=1)) - logit(P(M=1|E=0)).
The observed self-report outcome is generated through exposure-specific
measurement parameters r1e=P(S=1|M=1,E=e) and r0e=P(S=1|M=0,E=e).
"""
from common import *
from scipy.special import expit, logit
import json

SEED=20260916
R=1000
SIZES=[200,500]

SCENARIOS={
 'identified_transport_ok':dict(p0=.25,p1=.35,se0=.85,se1=.90,fp0=.05,fp1=.05,
                                ext_se0=.85,ext_se1=.90,ext_fp0=.05,ext_fp1=.05),
 'weak_identification':dict(p0=.25,p1=.35,se0=.62,se1=.68,fp0=.55,fp1=.52,
                            ext_se0=.62,ext_se1=.68,ext_fp0=.55,ext_fp1=.52),
 'transport_mismatch':dict(p0=.25,p1=.35,se0=.85,se1=.90,fp0=.05,fp1=.05,
                           ext_se0=.70,ext_se1=.78,ext_fp0=.15,ext_fp1=.12),
 'rare_exposure':dict(p0=.25,p1=.33,se0=.85,se1=.90,fp0=.05,fp1=.05,
                      ext_se0=.85,ext_se1=.90,ext_fp0=.05,ext_fp1=.05),
}

def true_values(s):
    q=[];j=[]
    for e in (0,1):
        p=s[f'p{e}'];se=s[f'se{e}'];fp=s[f'fp{e}']
        q.append(se*p+fp*(1-p));j.append(se-fp)
    return dict(beta=logit(s['p1'])-logit(s['p0']),selfreport=logit(q[1])-logit(q[0]),q0=q[0],q1=q[1],j0=j[0],j1=j[1])

def expected_variance_weight(s,e):
    """Delta-method importance weight for estimating corrected p_e.

    The local validation estimates Se and false-positive rate.  The larger the
    resulting uncertainty contribution, the more records the group receives.
    """
    p=s[f'p{e}'];q=s[f'se{e}']*p+s[f'fp{e}']*(1-p);j=s[f'se{e}']-s[f'fp{e}']
    # Approximate variance of q - fp - p*j divided by j; gradients in Se/fp.
    gse=-p/j;gfp=-(1-p)/j
    return (gse*gse*s[f'se{e}']*(1-s[f'se{e}'])/max(p,1e-6)
            +gfp*gfp*s[f'fp{e}']*(1-s[f'fp{e}'])/max(1-p,1e-6))

def draw_validation(rng,s,n,allocation):
    if allocation=='simple_random':
        e=rng.binomial(1,s.get('exposure_rate',.25),n)
    elif allocation=='exposure_stratified':
        e=np.r_[np.zeros(n//2,dtype=int),np.ones(n-n//2,dtype=int)];rng.shuffle(e)
    elif allocation=='diagnostic_optimal':
        w0=expected_variance_weight(s,0);w1=expected_variance_weight(s,1)
        n1=int(round(n*np.sqrt(w1)/(np.sqrt(w0)+np.sqrt(w1))))
        e=np.r_[np.zeros(n-n1,dtype=int),np.ones(n1,dtype=int)];rng.shuffle(e)
    else: raise ValueError(allocation)
    p=np.array([s['p0'],s['p1']])[e]
    m=rng.binomial(1,p)
    se=np.array([s['se0'],s['se1']])[e];fp=np.array([s['fp0'],s['fp1']])[e]
    prob=np.where(m==1,se,fp);y=rng.binomial(1,prob)
    return e,m,y

def estimate_local(e,m,y,truth,s):
    r={}
    for z in (0,1):
        for mm,label in [(1,'se'),(0,'fp')]:
            ix=(e==z)&(m==mm);a=int(y[ix].sum());b=int(ix.sum()-a)
            r[f'{label}{z}']=(a+.5)/(a+b+1)
    p_hat=[];valid=True
    for z in (0,1):
        j=r[f'se{z}']-r[f'fp{z}']
        p=(truth[f'q{z}']-r[f'fp{z}'])/j if j>0 else np.nan
        valid=valid and np.isfinite(p) and 0<p<1
        p_hat.append(p)
    est=logit(p_hat[1])-logit(p_hat[0]) if valid else np.nan
    return dict(estimate=est,valid=valid,j_hat0=r['se0']-r['fp0'],j_hat1=r['se1']-r['fp1'],
                diagnostic_flag=(min(r['se0']-r['fp0'],r['se1']-r['fp1'])<.20 or not valid),
                abs_error=abs(est-truth['beta']) if valid else np.nan,
                error=est-truth['beta'] if valid else np.nan,**r)

def main():
    rng=np.random.default_rng(SEED);rows=[];scenario_summary=[]
    for name,s0 in SCENARIOS.items():
        s=dict(s0);s['exposure_rate']=.10 if name=='rare_exposure' else .25
        truth=true_values(s)
        # External-only diagnosis before local validation.
        ext_j=min(s['ext_se0']-s['ext_fp0'],s['ext_se1']-s['ext_fp1'])
        external_flag=ext_j<.20
        for n in SIZES:
            for allocation in ['simple_random','exposure_stratified','diagnostic_optimal']:
                for rep in range(R):
                    e,m,y=draw_validation(rng,s,n,allocation)
                    z=estimate_local(e,m,y,truth,s)
                    rows.append(dict(scenario=name,n=n,allocation=allocation,rep=rep,
                                     true_beta=truth['beta'],true_selfreport=truth['selfreport'],
                                     external_j=ext_j,external_flag=external_flag,
                                     **z))
        scenario_summary.append(dict(scenario=name,true_beta=truth['beta'],true_selfreport=truth['selfreport'],
                                     j0=truth['j0'],j1=truth['j1'],external_j=ext_j,
                                     external_diagnostic_flag=external_flag,
                                     external_parameters_mismatch=(abs(s['ext_se0']-s['se0'])+abs(s['ext_se1']-s['se1'])+abs(s['ext_fp0']-s['fp0'])+abs(s['ext_fp1']-s['fp1']))))
        print('SIM completed',name,flush=True)
    d=pd.DataFrame(rows)
    save(d,'diagnostic_allocation_simulation.csv');save(pd.DataFrame(scenario_summary),'diagnostic_allocation_scenarios.csv')
    agg=d.groupby(['scenario','n','allocation']).agg(repetitions=('rep','size'),
        valid_fraction=('valid','mean'),diagnostic_flag_fraction=('diagnostic_flag','mean'),
        mae_valid=('abs_error','mean'),bias_valid=('error','mean'),
        rmse_valid=('error',lambda x:np.sqrt(np.nanmean(x*x)))).reset_index()
    save(agg,'diagnostic_allocation_summary.csv')
    # A simple empirical value-of-diagnosis table: flagged simulations have
    # materially larger error when the rule is positive.
    diag=d.groupby(['scenario','n','allocation','diagnostic_flag']).agg(repetitions=('rep','size'),valid_fraction=('valid','mean'),mae_valid=('abs_error','mean')).reset_index()
    save(diag,'diagnostic_allocation_by_flag.csv')
    # Approximate decision rule from external parameters: reject external
    # correction when J<.20, or when the local pilot flags weak identification.
    pilot=d[d.n==200].copy()
    decision=pilot.groupby(['scenario','allocation']).agg(flag_rate=('diagnostic_flag','mean'),valid_fraction=('valid','mean'),mae_valid=('abs_error','mean')).reset_index()
    save(decision,'diagnostic_allocation_decision_summary.csv')
    settings=dict(seed=SEED,repetitions=R,sample_sizes=SIZES,scenarios=list(SCENARIOS),
                  target='crude measured-outcome logOR',diagnostic='flag if min estimated Youden index < 0.20 or inverse probability invalid',
                  allocation='diagnostic_optimal uses delta-method variance weights; exposure-stratified is fixed 50:50; simple_random uses scenario exposure rate')
    (RES/'diagnostic_allocation_settings.json').write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8')
    print(agg.round(4).to_string(index=False),flush=True)

if __name__=='__main__':main()
