"""Build the corrected analysis panel without overwriting the frozen panel.

Corrections are deliberately limited to two verified coding operations:
1) CHARLS self-report is linked by numeric ID and compared with the frozen rows;
2) NHANES current smoking treats SMQ040=1 or 2 as current smoking.
"""
from common import *
import pyreadstat

def charls_s_map():
    path=BASE/'CHARLS/2011/health_status_and_functioning.dta'
    h=pyreadstat.read_dta(str(path),usecols=['ID','da007_1_'])[0]
    h['_pid']=pd.to_numeric(h.ID,errors='coerce').astype('Int64')
    z=pd.to_numeric(h.da007_1_,errors='coerce')
    h['S_rebuilt']=np.where(z.eq(1),1.,np.where(z.eq(2),0.,np.nan))
    return h[['_pid','S_rebuilt']]

def nhanes_smoke(ds):
    path=next((BASE/'NHANES'/ds.replace('NHANES ','')).glob('SMQ*.xpt'))
    s=pd.read_sas(path,format='xport')[['SEQN','SMQ020','SMQ040']]
    q=pd.to_numeric(s.SMQ040,errors='coerce');ever=pd.to_numeric(s.SMQ020,errors='coerce')
    s['smoke_rebuilt']=np.where(q.isin([1,2]),1.,np.where(q.eq(3),0.,np.where(q.isna()&ever.eq(2),0.,np.nan)))
    return s[['SEQN','smoke_rebuilt']]

def main():
    p=pd.read_csv(DATA/'hypertension_panel.csv.gz',low_memory=False)
    audit=[]
    old_charls=p[p.dataset=='CHARLS 2011'].copy()
    w=pd.read_csv(BASE/'CHARLS/analysis/charls_analysis_wide.csv',dtype={'ID':'string'},low_memory=False)
    h=pyreadstat.read_dta(str(BASE/'CHARLS/2011/health_status_and_functioning.dta'),
                          usecols=['ID','da007_1_','da011s1','da011s2','da011s3'])[0]
    h['ID']=h.ID.astype(str).str.strip()
    w['ID']=w.ID.astype(str).str.strip()
    z=w.merge(h,on='ID',how='left',validate='one_to_one',indicator=True)
    z['M']=np.where(z[['sbp','dbp']].notna().any(axis=1),((z.sbp>=140)|(z.dbp>=90)).astype(float),np.nan)
    smoke_col='smoke_current_11' if 'smoke_current_11' in z.columns else 'smoke_current'
    s=pd.to_numeric(z.da007_1_,errors='coerce')
    z['S']=np.where(s.eq(1),1.,np.where(s.eq(2),0.,np.nan))
    z['med']=np.where(pd.to_numeric(z.da011s2,errors='coerce').eq(2),1.,
                      np.where(s.eq(2)|pd.to_numeric(z.da011s3,errors='coerce').eq(3)|
                               pd.to_numeric(z.da011s1,errors='coerce').eq(1),0.,np.nan))
    z['M_treatment']=np.where((z.M==1)|(z.med==1),1.,np.where((z.M==0)&(z.med==0),0.,np.nan))
    complete=z[['M','S',smoke_col,'age','male','edu']].notna().all(axis=1)
    old_complete=int(old_charls[['M','S','smoke','age','male','edu']].notna().all(axis=1).sum())
    charls=pd.DataFrame({'dataset':'CHARLS 2011','country':'China','uid':'CHARLS:'+z.ID,
                         'M':z.M,'S':z.S,'smoke':z[smoke_col],'age':z.age,'male':z.male,
                         'edu':z.edu,'bmi':z.bmi,'obese':np.where(z.bmi.notna(),(z.bmi>=30).astype(float),np.nan),
                         'med':z.med,'M_treatment':z.M_treatment,'wt':np.nan,'stratum':np.nan,'psu':np.nan})
    p=pd.concat([p[p.dataset!='CHARLS 2011'],charls],ignore_index=True)
    audit.append(dict(dataset='CHARLS 2011',rows=len(charls),id_matched=int(z._merge.eq('both').sum()),
                      old_complete=old_complete,new_complete=int(complete.sum()),
                      added_complete=int(complete.sum()-old_complete),
                      old_missing=int(old_charls.S.isna().sum()),new_missing=int(charls.S.isna().sum()),
                      note='string ID retained with leading zeros; 3,983 complete rows restored'))
    for ds in sorted(p.loc[p.dataset.str.startswith('NHANES'),'dataset'].unique()):
        idx=p.index[p.dataset==ds]; old=p.loc[idx,'smoke']
        sm=nhanes_smoke(ds).set_index('SEQN')
        seq=pd.to_numeric(p.loc[idx,'uid'].str.split(':').str[-1],errors='coerce')
        new=sm.reindex(seq.to_numpy()).smoke_rebuilt.to_numpy()
        assert np.isfinite(new).all(),ds
        p.loc[idx,'smoke']=new
        audit.append(dict(dataset=ds,rows=len(idx),id_matched=len(idx),old_missing=int(old.isna().sum()),new_missing=int(pd.isna(new).sum()),changed=int((old.fillna(-9).to_numpy()!=pd.Series(new,index=idx).fillna(-9).to_numpy()).sum()),old0_new1=int(((old.to_numpy()==0)&(new==1)).sum()),note='SMQ040=1/2 current'))
    for c in ['M','S','smoke','male']:
        assert set(p[c].dropna().unique())<=set([0.,1.]),c
    out=REV/'data/hypertension_panel_corrected.csv.gz'
    p.to_csv(out,index=False)
    save(pd.DataFrame(audit),'correction_reanalysis_audit.csv')
    old=[x for x in BASE.iterdir() if x.is_dir() and x.name.startswith('9')][0]
    data=next(x for x in old.iterdir() if x.is_dir() and x.name.startswith('01'))
    dz=pd.read_csv(next(data.glob('*diseases_bmi.csv')),low_memory=False)
    # Rebuild all CHARLS disease rows from the same leading-zero-preserving
    # linkage.  Definitions follow the existing harmonized disease panel.
    hh=pyreadstat.read_dta(str(BASE/'CHARLS/2011/health_status_and_functioning.dta'),
                           usecols=['ID','da007_1_','da007_2_','da007_3_'])[0]
    hh['ID']=hh.ID.astype(str).str.strip()
    cz=w.merge(hh,on='ID',how='left',validate='one_to_one')
    cz['smoke']=cz[smoke_col]
    cz['age']=cz.age;cz['male']=cz.male;cz['edu']=cz.edu;cz['pid']=cz.ID
    cz['M_htn']=np.where(cz[['sbp','dbp']].notna().any(axis=1),((cz.sbp>=140)|(cz.dbp>=90)).astype(float),np.nan)
    cz['S_htn']=np.where(pd.to_numeric(cz.da007_1_,errors='coerce').eq(1),1.,np.where(pd.to_numeric(cz.da007_1_,errors='coerce').eq(2),0.,np.nan))
    cz['M_dm']=np.where(cz[['glu','hba1c']].notna().any(axis=1),((cz.glu>=126)|(cz.hba1c>=6.5)).astype(float),np.nan)
    cz['S_dm']=np.where(pd.to_numeric(cz.da007_3_,errors='coerce').eq(1),1.,np.where(pd.to_numeric(cz.da007_3_,errors='coerce').eq(2),0.,np.nan))
    cz['M_lip']=np.where(cz[['cho','ldl']].notna().any(axis=1),((cz.cho>=240)|(cz.ldl>=160)).astype(float),np.nan)
    cz['S_lip']=np.where(pd.to_numeric(cz.da007_2_,errors='coerce').eq(1),1.,np.where(pd.to_numeric(cz.da007_2_,errors='coerce').eq(2),0.,np.nan))
    cr=[]
    for disease,mcol,scol in [('hypertension','M_htn','S_htn'),('diabetes','M_dm','S_dm'),('dyslipidaemia','M_lip','S_lip')]:
        q=cz[['pid',mcol,scol,'smoke','age','male','edu','bmi']].copy()
        q=q.rename(columns={mcol:'M',scol:'S'});q['dataset']='CHARLS 2011';q['country']='China';q['wave']='2011';q['disease']=disease
        q['obese']=np.where(q.bmi.notna(),(q.bmi>=30).astype(float),np.nan);cr.append(q)
    dz=pd.concat([dz[dz.dataset!='CHARLS 2011'],*cr],ignore_index=True)
    for ds in sorted(dz.loc[dz.dataset.str.startswith('NHANES'),'dataset'].unique()):
        idx=dz.index[dz.dataset==ds];sm=nhanes_smoke(ds).set_index('SEQN');seq=pd.to_numeric(dz.loc[idx,'pid'],errors='coerce');new=sm.reindex(seq.to_numpy()).smoke_rebuilt.to_numpy();assert np.isfinite(new).all();dz.loc[idx,'smoke']=new
    cs=charls_s_map().set_index('_pid');idx=dz.index[dz.dataset=='CHARLS 2011'];pid=pd.to_numeric(dz.loc[idx,'pid'],errors='coerce').astype('Int64');dz.loc[idx,'S']=cs.reindex(pid.to_numpy()).S_rebuilt.to_numpy()
    dz.to_csv(REV/'data/panel_diseases_bmi_corrected.csv.gz',index=False)
    print(pd.DataFrame(audit).to_string(index=False));print('wrote',out)

if __name__=='__main__':main()
