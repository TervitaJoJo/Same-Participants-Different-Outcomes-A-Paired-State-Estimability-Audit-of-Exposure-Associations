from common import *
import json

def cv(g):
    return ['age','male'] if (g.dataset.iloc[0].startswith('ENSANUT') and g.dataset.iloc[0]!='ENSANUT 2012') or g.dataset.iloc[0].startswith('HAALSI') else ['age','male','edu']

def summarise(table,influences,name):
    psi=pd.concat(influences,axis=1).fillna(0.)
    V=psi.T.to_numpy()@psi.to_numpy()
    rows=[]
    for scope,idx in [('Overall',np.arange(len(table)))]+[(c,np.flatnonzero(table.country.to_numpy()==c)) for c in sorted(table.country.unique())]:
        g=table.iloc[idx];r=correlated_meta(g.delta,V[np.ix_(idx,idx)])
        rows.append(dict(scope=scope,**r))
    save(pd.DataFrame(rows),name)
    np.save(RES/(name.replace('.csv','_sampling_covariance.npy')),V)
    return pd.DataFrame(rows)

def main():
    p=pd.read_csv(DATA/'hypertension_panel.csv.gz',low_memory=False)
    rows=[];infs=[];rob=[];flow=[]
    for ds,g in p.groupby('dataset',sort=True):
        cov=cv(g);z=g.dropna(subset=['M','S','smoke',*cov])
        r,i=paired(z,cov=cov,return_influence=True)
        rows.append(dict(dataset=ds,country=g.country.iloc[0],**r));infs.append(i.rename(ds))
        flow.append(dict(dataset=ds,available_records=len(g),paired_outcomes=int(g[['M','S']].notna().all(axis=1).sum()),complete_n=r['n']))
        a=paired(g[g.age>=50],cov=['age','male']);rob.append(dict(dataset=ds,country=g.country.iloc[0],analysis='common_age50_age_sex',**a))
        print('PRIMARY',ds,r['n'],round(r['delta'],4),flush=True)
    t=pd.DataFrame(rows);save(t,'primary_corrected.csv');save(pd.DataFrame(flow),'sample_flow_revision.csv')
    summ=summarise(t,infs,'primary_meta_correlated.csv')
    print(summ.to_string(index=False),flush=True)
    e=p[p.country=='England'].copy();e['wave_n']=e.dataset.str.extract(r'w(\d+)').astype(int)
    eu=e.sort_values('wave_n').drop_duplicates('uid')
    r1=paired(e,cov=['age','male','edu'],wave=True)
    r2=paired(eu,cov=['age','male','edu'],wave=True)
    save(pd.DataFrame([dict(analysis='all_waves_cluster_person',**r1),dict(analysis='first_record_per_person',**r2)]),'elsa_repeated_person_sensitivity.csv')
    for variant,r in [('ELSA_pooled_person_cluster',r1),('ELSA_first_person',r2)]:
        sub=pd.concat([t[t.country!='England'],pd.DataFrame([dict(dataset='ELSA collapsed',country='England',**r)])],ignore_index=True)
        rob.append(dict(dataset='Overall',country='All',analysis=variant,**meta(sub.delta,sub.se)))
    ar=pd.DataFrame(rob);save(ar,'primary_sensitivity.csv')

    # Definition change: both estimates use exactly the same participants.
    tr=[];state=[]
    for ds,g in p.groupby('dataset',sort=True):
        if g.med.notna().sum()<300:continue
        cov=cv(g)
        for exposure in ['smoke','obese']:
            z=g.dropna(subset=['M','S','med',exposure,*cov])
            if len(z)<300 or z[exposure].sum()<20:continue
            a=paired(z,exposure=exposure,cov=cov)
            b=paired(z,exposure=exposure,ref='M_treatment',cov=cov)
            shift=paired(z.assign(S=z.M),exposure=exposure,ref='M_treatment',cov=cov)
            tr.append(dict(dataset=ds,country=g.country.iloc[0],exposure=exposure,n=len(z),delta_threshold=a['delta'],se_threshold=a['se'],lo_threshold=a['lo'],hi_threshold=a['hi'],delta_treatment=b['delta'],se_treatment=b['se'],lo_treatment=b['lo'],hi_treatment=b['hi'],shift=shift['delta'],shift_lo=shift['lo'],shift_hi=shift['hi']))
        z=g.dropna(subset=['M','S','med','smoke',*cov]);discord=z[(z.M==0)&(z.S==1)]
        state.append(dict(dataset=ds,country=g.country.iloc[0],n=len(z),discordant_n=len(discord),treated_discordant=int(discord.med.sum()),fraction_treated=discord.med.mean(),prevalence_threshold=z.M.mean(),prevalence_treatment=z.M_treatment.mean(),prevalence_selfreport=z.S.mean()))
    save(pd.DataFrame(tr),'treatment_definition_comparison.csv');save(pd.DataFrame(state),'treatment_discordant_states.csv')

    # NHANES design-based linearisation for hypertension; no borrowed SE.
    wt=[]
    for ds,g in p[p.dataset.str.startswith('NHANES')].groupby('dataset'):
        g=g.dropna(subset=['M','S','smoke','age','male','edu','wt','stratum','psu']);g=g[g.wt>0]
        a=paired(g);b=paired(g,weighted=True)
        wt.append(dict(dataset=ds,n=len(g),delta_unweighted=a['delta'],lo_unweighted=a['lo'],hi_unweighted=a['hi'],delta_weighted=b['delta'],se_weighted=b['se'],lo_weighted=b['lo'],hi_weighted=b['hi'],design_df=b['df'],difference=b['delta']-a['delta'],sign_flip=np.sign(b['delta'])!=np.sign(a['delta'])))
    save(pd.DataFrame(wt),'nhanes_survey_design.csv')

    # Updated multi-disease comparison, preserving shared-person covariance.
    dz=pd.read_csv(DATA/'panel_diseases_bmi_corrected.csv.gz',low_memory=False)
    assert not dz[['dataset','disease','uid']].duplicated().any()
    dz['obese']=np.where(dz.bmi.notna(),(dz.bmi>=30).astype(float),np.nan)
    multi=[]
    for exposure in ['smoke','obese']:
        er=[];ei=[]
        for (ds,dis),g in dz.groupby(['dataset','disease'],sort=True):
            g=g.dropna(subset=['M','S',exposure,'age','male','edu'])
            if len(g)<300:continue
            r,i=paired(g,exposure=exposure,return_influence=True)
            er.append(dict(dataset=ds,disease=dis,country=g.country.iloc[0],exposure=exposure,**r));ei.append(i.rename(ds+':'+dis))
        et=pd.DataFrame(er);multi.extend(er)
        summarise(et,ei,f'multidisease_{exposure}_meta.csv')
    save(pd.DataFrame(multi),'multidisease_corrected.csv')

    # Numerical check against the independently implemented stacked GLM.
    old=module('stack_check',OLD/'code/analysis/70_complete_evidence.py')
    checks=[]
    for ds in ['NHANES 2017-2018','ELSA w9']:
        g=p[p.dataset==ds];a=paired(g);b=old.paired_stacked_logit(g,'smoke',['age','male','edu'],ds,g.country.iloc[0])
        assert abs(a['delta']-b['delta'])<1e-7
        rel=abs(a['se']/b['delta_se']-1);assert rel<.002
        checks.append(dict(dataset=ds,delta_difference=a['delta']-b['delta'],relative_se_difference=rel))
    save(pd.DataFrame(checks),'paired_estimator_validation.csv')
    print('Completed treatment, shared-person covariance, survey design and numerical checks.',flush=True)

if __name__=='__main__':main()
