from common import *
import hashlib,json
from scipy.special import logit

R=500
DRAWS=300
SIZES=[100,300,500,1000]
COUNTRY_WAVES={'China':'CHARLS 2011','England':'ELSA w9','India':'LASI w1','Mexico':'ENSANUT 2025','South Africa':'HAALSI baseline','United States':'NHANES 2017-2018'}

def split_flag(uid):
    return int(hashlib.sha256((str(SEED)+':'+str(uid)).encode()).hexdigest()[:8],16)%2

def condX(d):
    a=(d.age.to_numpy()-60)/10;e=d.smoke.to_numpy();s=d.male.to_numpy()
    return np.column_stack([np.ones(len(d)),e,a,a*a,s,e*a,e*s])

def fit_cond(train,balance):
    models={};checks=[]
    # Avoid repeated ELSA persons determining training country composition.
    train=train.sort_values('dataset').drop_duplicates('uid')
    for m in (0,1):
        d=train[train.M==m].copy();X=condX(d)
        w=np.ones(len(d))
        if balance:
            n=d.country.map(d.country.value_counts()).to_numpy();w=len(d)/d.country.nunique()/n
        f=sm.GLM(d.S,X,family=sm.families.Binomial(),freq_weights=w).fit(maxiter=100,tol=1e-9)
        assert f.converged
        models[m]=np.asarray(f.params)
        checks.append(dict(M=m,n=len(d),events=d.S.sum(),min_source_age=d.age.min(),max_source_age=d.age.max(),max_abs_beta=np.abs(f.params).max(),converged=f.converged))
    return models,checks

def cond_prediction(models,test):
    qs=[]
    for e in (0,1):
        d=test[test.smoke==e];X=condX(d)
        q=np.where(d.M.to_numpy()==1,expit(X@models[1]),expit(X@models[0]))
        qs.append(q.mean())
    return lor(*qs)

def pooled(train):
    a=rates(train)
    return {f'r{m}{e}':(a[f'a{m}{e}']+.5)/(a[f'a{m}{e}']+a[f'b{m}{e}']+1) for m in (0,1) for e in (0,1)}

def metrics(t,tag):
    cr=[]
    for (method,country),g in t.groupby(['method','country']):
        cr.append(dict(scope=tag,method=method,country=country,waves=len(g),mae_logor=g.error.abs().mean(),rmse_logor=np.sqrt(np.mean(g.error**2)),mae_or=np.mean(np.abs(np.exp(g.predicted)-np.exp(g.observed)))))
    c=pd.DataFrame(cr);save(c,f'{tag}_country_metrics.csv')
    macro=c.groupby('method')[['mae_logor','rmse_logor','mae_or']].mean().reset_index()
    macro['scope']=tag;save(macro,f'{tag}_macro_metrics.csv');return macro

def main():
    p=pd.read_csv(DATA/'hypertension_panel.csv.gz',low_memory=False)
    # Use exactly the revised primary complete-case samples.
    from importlib import import_module
    m=module('pairmodule',REV/'code/02_paired_and_treatment.py')
    p=pd.concat([g.dropna(subset=['M','S','smoke',*m.cv(g)]) for _,g in p.groupby('dataset')],ignore_index=True)
    assert len(p)==int(pd.read_csv(RES/'primary_corrected.csv').n.sum())
    p['split']=p.uid.map(split_flag)
    assert not set(p[p.split==0].uid)&set(p[p.split==1].uid)
    wave_rates={ds:rates(g) for ds,g in p.groupby('dataset')}
    rows=[];splitrows=[];modelchecks=[];external={}
    for country in sorted(p.country.unique()):
        train=p[p.country!=country];test=p[p.country==country]
        pars=pooled(train)
        external[country]=pars
        cond,ch=fit_cond(train,False);bal,ch2=fit_cond(train,True)
        for z in ch:modelchecks.append(dict(held_country=country,balance=False,**z))
        for z in ch2:modelchecks.append(dict(held_country=country,balance=True,**z))
        # Exact comparator for the original n(exposure)-weighted wave average.
        source=[wave_rates[ds] for ds in train.dataset.unique()]
        oldpars={f'r{mm}{e}':np.average([s[f'r{mm}{e}'] for s in source],weights=[s[f'n{e}'] for s in source]) for mm in (0,1) for e in (0,1)}
        for ds,g in test.groupby('dataset'):
            rr=rates(g);obs=lor(rr['q0'],rr['q1'])
            pred={'identity_no_shift':lor(rr['p0'],rr['p1']),'external_wave_average':mixture(oldpars,rr['p0'],rr['p1']),'external_pooled':mixture(pars,rr['p0'],rr['p1']),'conditional_standardized':cond_prediction(cond,g),'conditional_country_balanced':cond_prediction(bal,g)}
            for method,v in pred.items():rows.append(dict(dataset=ds,country=country,method=method,n=len(g),observed=obs,predicted=v,error=v-obs))
            cal=g[g.split==0];ev=g[g.split==1];rt=rates(ev);obs2=lor(rt['q0'],rt['q1'])
            local=pooled(cal)
            pp={'identity_no_shift':lor(rt['p0'],rt['p1']),'external_pooled':mixture(pars,rt['p0'],rt['p1']),'conditional_standardized':cond_prediction(cond,ev),'local_independent_half':mixture(local,rt['p0'],rt['p1'])}
            for method,v in pp.items():splitrows.append(dict(dataset=ds,country=country,method=method,n_calibration=len(cal),n_evaluation=len(ev),observed=obs2,predicted=v,error=v-obs2))
        print('LOCO completed',country,flush=True)
    t=pd.DataFrame(rows);st=pd.DataFrame(splitrows);save(t,'transport_predictions.csv');save(st,'independent_half_predictions.csv');save(pd.DataFrame(modelchecks),'transport_model_diagnostics.csv')
    print(metrics(t,'transport').round(4).to_string(index=False),flush=True)
    print(metrics(st,'independent_half').round(4).to_string(index=False),flush=True)
    calrows=[];delete=[]
    for method,g in t.groupby('method'):
        fit=sm.OLS(g.observed,sm.add_constant(g.predicted)).fit(cov_type='cluster',cov_kwds={'groups':g.country,'use_correction':True},use_t=True)
        ci=fit.conf_int().iloc[1]
        calrows.append(dict(method=method,slope=fit.params.iloc[1],lo=ci.iloc[0],hi=ci.iloc[1],countries=g.country.nunique(),df_inference=getattr(fit,'df_resid_inference',np.nan)))
        for c in sorted(g.country.unique()):
            gg=g[g.country!=c];f=sm.OLS(gg.observed,sm.add_constant(gg.predicted)).fit()
            delete.append(dict(method=method,deleted_country=c,slope=f.params.iloc[1]))
    save(pd.DataFrame(calrows),'calibration_country_cluster.csv');save(pd.DataFrame(delete),'calibration_delete_country.csv')

    # Fixed evaluation sets; calibration draws never see their S outcomes.
    rng=np.random.default_rng(SEED);designrows=[];designinfo=[]
    for country,ds in COUNTRY_WAVES.items():
        g=p[(p.dataset==ds)&(p.age>=50)].copy()
        pool=g[g.split==0];ev=g[g.split==1];rt=rates(ev);truth=lor(rt['q0'],rt['q1'])
        idx0=pool.index[pool.smoke==0].to_numpy();idx1=pool.index[pool.smoke==1].to_numpy()
        designinfo.append(dict(country=country,dataset=ds,calibration_pool=len(pool),evaluation_n=len(ev),pool_smokers=len(idx1),evaluation_smokers=int(ev.smoke.sum()),observed_evaluation_logor=truth))
        ext=external[country]
        for rep in range(R):
            # Nested draws within repetition for paired comparisons across n.
            random_order=rng.permutation(pool.index);order0=rng.permutation(idx0);order1=rng.permutation(idx1)
            for n in SIZES:
                if n>len(pool):continue
                for allocation in ['simple_random','exposure_stratified']:
                    if allocation=='simple_random':ix=random_order[:n]
                    else:
                        n1=min(n//2,len(order1));n0=min(n-n1,len(order0));n1=n-n0
                        ix=np.r_[order0[:n0],order1[:n1]]
                    cal=pool.loc[ix];r=rates(cal)
                    for prior_n in [0,5,20,50]:
                        parms={};draw={};empty=0
                        for mm in (0,1):
                            for e in (0,1):
                                key=f'{mm}{e}';a=r[f'a{key}'];b=r[f'b{key}']
                                empty+=int(a+b==0)
                                pa=.5 if prior_n==0 else prior_n*ext[f'r{key}']
                                pb=.5 if prior_n==0 else prior_n*(1-ext[f'r{key}'])
                                parms[f'r{key}']=(a+pa)/(a+b+pa+pb)
                                if prior_n in [0,20]:draw[key]=rng.beta(a+pa,b+pb,DRAWS)
                        pred=mixture(parms,rt['p0'],rt['p1'])
                        lo=hi=covered=np.nan
                        if prior_n in [0,20]:
                            qs=[]
                            for e in (0,1):
                                nt=int(rt[f'n{e}']);nm=int(round(rt[f'p{e}']*nt))
                                yy=rng.binomial(nm,draw[f'1{e}'])+rng.binomial(nt-nm,draw[f'0{e}'])
                                # Jeffreys smoothing solely prevents infinite predictive OR.
                                qs.append((yy+.5)/(nt+1))
                            post=logit(qs[1])-logit(qs[0]);lo,hi=np.quantile(post,[.025,.975]);covered=float(lo<=truth<=hi)
                        pp=[];valid=True
                        for e in (0,1):
                            youden=parms[f'r1{e}']-parms[f'r0{e}']
                            pe=(rt[f'q{e}']-parms[f'r0{e}'])/youden if youden>0 else np.nan
                            valid=valid and np.isfinite(pe) and 0<pe<1
                            pp.append(pe)
                        inv=lor(*pp) if valid else np.nan
                        measured_truth=lor(rt['p0'],rt['p1'])
                        designrows.append(dict(country=country,dataset=ds,rep=rep,n=n,allocation=allocation,prior_strength=prior_n,calibration_smokers=int(cal.smoke.sum()),empty_cells=empty,observed=truth,predicted=pred,error=pred-truth,within_logor_010=abs(pred-truth)<=.10,predictive_lo=lo,predictive_hi=hi,predictive_contains_observed=covered,inverse_valid=valid,inverse_logor=inv,measured_logor=measured_truth,inverse_error=inv-measured_truth if valid else np.nan,selfreport_error=truth-measured_truth,**parms))
        print('DESIGN completed',country,'pool',len(pool),'evaluation',len(ev),flush=True)
    d=pd.DataFrame(designrows);save(d,'validation_design_repetitions.csv');save(pd.DataFrame(designinfo),'validation_design_samples.csv')
    summary=d.groupby(['country','dataset','n','allocation','prior_strength']).agg(repetitions=('rep','size'),mae_logor=('error',lambda x:np.abs(x).mean()),rmse_logor=('error',lambda x:np.sqrt(np.mean(x*x))),bias_logor=('error','mean'),abs_error_q90=('error',lambda x:np.quantile(np.abs(x),.9)),success_fraction=('within_logor_010','mean'),empty_cell_fraction=('empty_cells',lambda x:np.mean(x>0)),mean_smokers=('calibration_smokers','mean'),predictive_inclusion=('predictive_contains_observed','mean')).reset_index()
    summary['success_mcse']=np.sqrt(summary.success_fraction*(1-summary.success_fraction)/summary.repetitions)
    save(summary,'validation_design_summary.csv')
    inv=d.groupby(['country','dataset','n','allocation','prior_strength']).agg(repetitions=('rep','size'),valid_fraction=('inverse_valid','mean'),mae_valid=('inverse_error',lambda x:x.abs().mean()),rmse_valid=('inverse_error',lambda x:np.sqrt(np.nanmean(x*x))),mae_selfreport=('selfreport_error',lambda x:x.abs().mean())).reset_index()
    save(inv,'inverse_validation_design_summary.csv')
    agg=summary.groupby(['n','allocation','prior_strength'])[['mae_logor','rmse_logor','success_fraction','empty_cell_fraction','predictive_inclusion']].mean().reset_index();save(agg,'validation_design_macro.csv')
    feasible=[]
    for (c,al,pr),gg in summary.groupby(['country','allocation','prior_strength']):
        passing=gg[gg.success_fraction>=.8]
        feasible.append(dict(country=c,allocation=al,prior_strength=pr,smallest_tested_n_passing_80pct=passing.n.min() if len(passing) else np.nan))
    save(pd.DataFrame(feasible),'validation_design_tested_thresholds.csv')
    (RES/'validation_settings.json').write_text(json.dumps(dict(seed=SEED,repetitions=R,posterior_predictive_draws=DRAWS,sample_sizes=SIZES,prior_strengths=[0,5,20,50],logor_tolerance=.10,success_target=.8,split='SHA256 person ID parity; fixed calibration/evaluation split',target='Forward self-report crude logOR; target measured state used; not inverse effect correction'),indent=2),encoding='utf-8')
    print(agg[agg.prior_strength.isin([0,20])].round(4).to_string(index=False),flush=True)

if __name__=='__main__':main()
