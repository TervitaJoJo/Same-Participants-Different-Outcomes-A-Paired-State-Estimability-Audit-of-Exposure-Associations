from common import *
from scipy.optimize import minimize
import json

def latentX(d):
    a=(d.age.to_numpy()-60)/10
    return np.column_stack([np.ones(len(d)),d.smoke,a,a*a,d.male])

def inverse_conditional(model,test):
    tr=module('transport_helpers',REV/'code/03_transport_and_local_validation.py')
    Z=tr.condX(test);X=latentX(test);y=test.S.to_numpy()
    a=expit(Z@model[0]);b=expit(Z@model[1]);difference=b-a
    f=sm.GLM(y,X,family=sm.families.Binomial()).fit()
    def objective(beta):
        p=expit(X@beta);q=np.clip(a+difference*p,1e-9,1-1e-9)
        nll=-np.mean(y*np.log(q)+(1-y)*np.log1p(-q))
        g=X.T@((q-y)/(q*(1-q))*difference*p*(1-p))/len(y)
        return nll,g
    starts=[np.asarray(f.params),np.zeros(X.shape[1])]
    fits=[minimize(objective,s,method='L-BFGS-B',jac=True,bounds=[(-12,12)]*len(s),options={'maxiter':1000,'ftol':1e-12,'gtol':1e-7}) for s in starts]
    fit=min(fits,key=lambda f:f.fun)
    valid=bool(fit.success and np.max(np.abs(fit.x))<11.99)
    return dict(corrected=fit.x[1],converged=bool(fit.success),boundary=bool(np.max(np.abs(fit.x))>=11.99),valid=valid,gradient_max=float(np.max(np.abs(fit.jac))),fraction_negative_youden=np.mean(difference<=0),objective=fit.fun)

def main():
    tr=module('trhelpers',REV/'code/03_transport_and_local_validation.py')
    m=module('pairhelpers',REV/'code/02_paired_and_treatment.py')
    p=pd.read_csv(DATA/'hypertension_panel.csv.gz',low_memory=False)
    p=pd.concat([g.dropna(subset=['M','S','smoke',*m.cv(g)]) for _,g in p.groupby('dataset')],ignore_index=True)
    rows=[]
    for country in sorted(p.country.unique()):
        train=p[p.country!=country];test=p[p.country==country]
        models,_=tr.fit_cond(train,False);par=tr.pooled(train)
        for ds,g in test.groupby('dataset'):
            X=latentX(g)
            bm=sm.GLM(g.M,X,family=sm.families.Binomial()).fit().params.iloc[1]
            bs=sm.GLM(g.S,X,family=sm.families.Binomial()).fit().params.iloc[1]
            fit=inverse_conditional(models,g)
            rows.append(dict(dataset=ds,country=country,method='conditional_likelihood',estimand='adjusted_logOR_age_quadratic_sex',n=len(g),truth=bm,selfreport=bs,**fit,error=fit['corrected']-bm,selfreport_error=bs-bm))
            rr=rates(g);pp=[];ok=True
            for e in (0,1):
                j=par[f'r1{e}']-par[f'r0{e}'];pe=(rr[f'q{e}']-par[f'r0{e}'])/j if j>0 else np.nan
                ok=ok and np.isfinite(pe) and 0<pe<1;pp.append(pe)
            truth=lor(rr['p0'],rr['p1']);sr=lor(rr['q0'],rr['q1']);estimate=lor(*pp) if ok else np.nan
            rows.append(dict(dataset=ds,country=country,method='external_marginal_inversion',estimand='crude_logOR',n=len(g),truth=truth,selfreport=sr,corrected=estimate,valid=ok,error=estimate-truth,selfreport_error=sr-truth))
        print('INVERSE completed',country,flush=True)
    out=pd.DataFrame(rows);save(out,'inverse_transport_predictions.csv')
    by=out.groupby(['method','country']).apply(lambda g:pd.Series(dict(waves=len(g),valid_fraction=g.valid.mean(),mae_valid=g.loc[g.valid,'error'].abs().mean(),mae_selfreport_all=g.selfreport_error.abs().mean(),mae_selfreport_same_valid=g.loc[g.valid,'selfreport_error'].abs().mean())),include_groups=False).reset_index()
    save(by,'inverse_transport_country_metrics.csv');save(by.groupby('method').mean(numeric_only=True).reset_index(),'inverse_transport_macro_metrics.csv')
    print(by.round(4).to_string(index=False),flush=True)

    # Fixed-country contrasts: descriptive cluster resampling, G=6 only.
    rng=np.random.default_rng(SEED);comparison=[]
    for module_name in ['transport','independent_half']:
        x=pd.read_csv(RES/f'{module_name}_country_metrics.csv').pivot(index='country',columns='method',values='mae_logor')
        baseline='external_pooled'
        for other in x.columns:
            if other==baseline:continue
            diff=(x[other]-x[baseline]).to_numpy();boots=diff[rng.integers(0,len(diff),(10000,len(diff)))].mean(axis=1)
            comparison.append(dict(module=module_name,method=other,reference=baseline,countries=len(diff),mae_difference=diff.mean(),country_boot_lo=np.quantile(boots,.025),country_boot_hi=np.quantile(boots,.975),countries_improved=int((diff<0).sum())))
    save(pd.DataFrame(comparison),'performance_country_contrasts.csv')
    # Additional pooling of the common >=50 age/sex sensitivity with shared IDs.
    rr=[];ii=[]
    for ds,g in p.groupby('dataset'):
        r,i=paired(g[g.age>=50],cov=['age','male'],return_influence=True)
        rr.append(dict(dataset=ds,country=g.country.iloc[0],**r));ii.append(i.rename(ds))
    m.summarise(pd.DataFrame(rr),ii,'common_age50_meta.csv')
    # Validate resampling separation and all reporting denominators.
    v={}
    v['primary_waves']=int(pd.read_csv(RES/'primary_corrected.csv').shape[0])
    v['primary_records']=int(pd.read_csv(RES/'primary_corrected.csv').n.sum())
    multi=pd.read_csv(RES/'multidisease_corrected.csv')
    v['smoking_cells']=int((multi.exposure=='smoke').sum());v['obesity_cells']=int((multi.exposure=='obese').sum())
    assert (v['primary_waves'],v['smoking_cells'],v['obesity_cells'])==(24,42,36)
    V=np.load(RES/'primary_meta_correlated_sampling_covariance.npy')
    v['sampling_covariance_min_eigenvalue']=float(np.linalg.eigvalsh(V).min())
    assert v['sampling_covariance_min_eigenvalue']>0
    v['all_primary_models_converged']=bool(pd.read_csv(RES/'primary_corrected.csv').converged.all())
    assert v['all_primary_models_converged']
    v['check_scope']='Programmatic consistency and independent stacked-model numerical comparison; not external reproduction.'
    (RES/'analysis_checks.json').write_text(json.dumps(v,indent=2),encoding='utf-8')
    print(json.dumps(v),flush=True)

if __name__=='__main__':main()
