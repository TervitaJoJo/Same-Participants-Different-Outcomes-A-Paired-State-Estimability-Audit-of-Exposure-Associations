from common import *

def main():
    inv=module('inversecheck',REV/'code/04_inverse_and_checks.py')
    tr=module('conditionalcheck',REV/'code/03_transport_and_local_validation.py')
    rng=np.random.default_rng(SEED)
    n=20000
    d=pd.DataFrame({'age':rng.uniform(45,85,n),'male':rng.binomial(1,.5,n),'smoke':rng.binomial(1,.3,n)})
    X=inv.latentX(d);Z=tr.condX(d)
    beta=np.array([-.5,.4,.3,-.05,.15])
    models={0:np.array([-2.5,.15,.05,0,.1,0,0]),1:np.array([1.2,-.2,.1,0,.05,0,0])}
    a=expit(Z@models[0]);b=expit(Z@models[1]);p=expit(X@beta)
    # Expected binomial outcomes remove Monte Carlo noise and test the likelihood itself.
    d['S']=a+(b-a)*p
    fit=inv.inverse_conditional(models,d)
    assert fit['valid'] and abs(fit['corrected']-beta[1])<1e-3
    records=[dict(check='conditional_likelihood_known_measurement_model',truth=beta[1],estimate=fit['corrected'],absolute_error=abs(fit['corrected']-beta[1]),passed=True)]
    for pe,r1,r0 in [(.2,.7,.1),(.5,.9,.2),(.05,.4,.02)]:
        q=r1*pe+r0*(1-pe);estimate=(q-r0)/(r1-r0)
        assert abs(estimate-pe)<1e-12
        records.append(dict(check='marginal_inverse_known_parameters',truth=pe,estimate=estimate,absolute_error=abs(estimate-pe),passed=True))
    save(pd.DataFrame(records),'inverse_estimator_validation.csv')
    print(pd.DataFrame(records).to_string(index=False),flush=True)

if __name__=='__main__':main()
