"""Bounded literature reconnaissance, not a systematic review."""
from pathlib import Path
import json, subprocess, sys, time, urllib.request, urllib.parse, re
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'literature';OUT.mkdir(exist_ok=True)
SCRIPT=Path('C:/review_tools/paper-lookup/scripts/paginate.py')
QUERIES={
 'transfer':'(misclassification AND (transportability OR transport OR external validation)) AND (sensitivity OR specificity)',
 'allocation':'(validation AND (optimal allocation OR two-phase OR multiwave)) AND (misclassification OR measurement error)',
 'outcome':'(outcome misclassification) AND (validation OR likelihood) AND logistic',
 'adaptive':'(adaptive OR multiwave) AND validation AND sampling AND (regression OR epidemiology)',
 'rogan':'TITLE:"Estimating prevalence from the results of a screening test"',
}
def fetch(url):
    req=urllib.request.Request(url,headers={'User-Agent':'ResearchMethodsAudit/1.0'})
    with urllib.request.urlopen(req,timeout=30) as r:return r.read()
def main():
    combined={};log=[]
    for tag,q in QUERIES.items():
        out=OUT/(tag+'.json')
        cmd=[sys.executable,str(SCRIPT),'--api','europepmc','--query',q,'--page-size','12','--max-records','12','--max-calls','1','-o',str(out)]
        run=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
        log.append(dict(tag=tag,query=q,exit_code=run.returncode,stderr=run.stderr[-1500:]))
        if out.exists():
            obj=json.loads(out.read_text(encoding='utf-8'))
            # Keep the script's full provenance envelope untouched.
            records=obj.get('records',obj.get('results',[]))
            for x in records:
                if isinstance(x,dict) and x.get('id'):combined[(x.get('source',''),x['id'])]=x
            print(tag,'keys',list(obj),'retrieved',len(records),flush=True)
        time.sleep(.5)
    (OUT/'search_log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
    # Fetch core metadata including abstracts only for all retrieved candidates
    # using a single bounded ID query rather than guessing paper content.
    refs=list(combined.values())
    if refs:
        q=' OR '.join(f'(EXT_ID:{x["id"]} AND SRC:{x["source"]})' for x in refs if x.get('source')=='MED')
        if q:
            url='https://www.ebi.ac.uk/europepmc/webservices/rest/search?'+urllib.parse.urlencode(dict(query=q,format='json',pageSize=100,resultType='core'))
            raw=fetch(url);obj=json.loads(raw);assert 'resultList' in obj and not obj.get('errCode')
            (OUT/'candidate_abstracts.json').write_bytes(raw)
            rows=obj['resultList']['result']
            (OUT/'candidate_abstracts.md').write_text('\n\n'.join(f'### {x["title"]}\n{x.get("authorString","")} ({x.get("pubYear","")}) DOI:{x.get("doi","")} PMCID:{x.get("pmcid","")}\n\n'+re.sub('<[^>]+>',' ',x.get('abstractText','No abstract supplied')) for x in rows),encoding='utf-8')
            print('Core abstracts',len(rows),flush=True)
    # Authoritative NHANES documentation, one page per included cycle.
    cycles=[('1999','SMQ'),('2005','SMQ_D'),('2007','SMQ_E'),('2009','SMQ_F'),('2011','SMQ_G'),('2013','SMQ_H'),('2015','SMQ_I'),('2017','SMQ_J')]
    docs=[]
    for year,name in cycles:
        url=f'https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/{year}/DataFiles/{name}.htm'
        try:
            raw=fetch(url);html=raw.decode('utf-8',errors='replace')
            (OUT/(name+'.html')).write_text(html,encoding='utf-8')
            pos=html.find('id="SMQ040"');section=html[pos:pos+6500] if pos>=0 else ''
            text=re.sub(r'\s+',' ',re.sub('<[^>]+>',' ',section))
            assert 'Some days' in text and 'Every day' in text and 'Not at all' in text
            docs.append(dict(cycle=year,url=url,checked=True,excerpt=text[:2200]))
        except Exception as e:docs.append(dict(cycle=year,url=url,checked=False,error=str(e)))
    (OUT/'nhanes_documentation.json').write_text(json.dumps(docs,indent=2),encoding='utf-8')
    print('NHANES documentation verified',sum(x['checked'] for x in docs),'/',len(docs),flush=True)
if __name__=='__main__':main()
