from pathlib import Path
import urllib.request, urllib.parse, json, re, time, sys, subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'literature'
sys.stdout.reconfigure(encoding='utf-8')
QUERIES=[
 'TITLE:"Leveraging External Validation Data"',
 '(TITLE:misclassification AND TITLE:validation)',
 '(TITLE:optimal AND (TITLE:validation OR TITLE:"two-phase"))',
 '(TITLE:"multiwave" AND TITLE:sampling)',
 '(TITLE:"adaptive" AND TITLE:validation AND TITLE:design)',
 'TITLE:"Bias and efficiency loss due to misclassified responses"',
 'TITLE:"Estimating prevalence from the results of a screening test"',
]
def main():
    allrows={};logs=[]
    for i,q in enumerate(QUERIES):
        url='https://www.ebi.ac.uk/europepmc/webservices/rest/search?'+urllib.parse.urlencode(dict(query=q,format='json',pageSize=12,resultType='core',sort='CITED desc'))
        with urllib.request.urlopen(url,timeout=30) as r:obj=json.load(r)
        assert not obj.get('errCode') and 'resultList' in obj
        rows=obj['resultList']['result'];logs.append(dict(query=q,url=url,total=obj['hitCount'],retrieved=len(rows)))
        (OUT/f'focused_{i}.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
        for x in rows:allrows[(x['source'],x['id'])]=x
        print(q,obj['hitCount'],flush=True)
        for x in rows:print(x.get('doi',''),x.get('pmcid',''),x['title'],flush=True)
        time.sleep(.4)
    rows=list(allrows.values())
    (OUT/'focused_abstracts.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'focused_search_log.json').write_text(json.dumps(logs,indent=2),encoding='utf-8')
    (OUT/'focused_abstracts.md').write_text('\n\n'.join(f'### {x["title"]}\n{x.get("authorString","")} ({x.get("pubYear","")}) DOI:{x.get("doi","")} PMCID:{x.get("pmcid","")}\n\n'+re.sub('<[^>]+>',' ',x.get('abstractText','No abstract supplied')) for x in rows),encoding='utf-8')
if __name__=='__main__':main()
