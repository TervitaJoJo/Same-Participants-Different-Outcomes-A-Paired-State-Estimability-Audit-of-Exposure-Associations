"""Executable METHODS_AND_SIMULATION_PROTOCOL.md; vectorized independent replicates."""
from common import *
from scipy.special import logit, expit
import itertools, json, warnings
R=500;B=400;N=10000;PILOT=80;SIZES=[200,500]
SEED_SIM=20260917

def allocate(weights,total,minimum=5):
    weights=np.asarray(weights).reshape(-1,4)
    p=weights/weights.sum(axis=1,keepdims=True)
    ideal=(total-4*minimum)*p;out=np.floor(ideal).astype(int)+minimum
    for i in range(len(out)):
        idx=np.argsort(-(ideal[i]-np.floor(ideal[i])))
        out[i,idx[:total-int(out[i].sum())]]+=1
    assert (out.sum(axis=1)==total).all() and (out>=minimum).all()
    return out.reshape(-1,2,2)

def stratified_inference(rng,counts,pi,qhat,qdraw):
    count=np.asarray(counts);success=rng.binomial(count,pi)
    a=success+.5;b=count-success+.5
    point=a/(a+b)
    post=rng.beta(a[:,None],b[:,None],size=(R,B,2,2))
    phat=(1-qhat)*point[:,:,0]+qhat*point[:,:,1]
    ppost=(1-qdraw)*post[:,:,:,0]+qdraw*post[:,:,:,1]
    est=logit(phat[:,1])-logit(phat[:,0])
    dist=logit(ppost[:,:,1])-logit(ppost[:,:,0])
    lo,hi=np.quantile(dist,[.025,.975],axis=1)
    return est,lo,hi,point,post,phat,ppost

def record(rows,scenario,budget,method,truth,est,lo,hi,interval_ok,extra=None):
    valid=np.isfinite(est);err=est-truth
    out=pd.DataFrame(dict(scenario=scenario,budget=budget,method=method,rep=np.arange(R),
                         truth=truth,estimate=est,valid=valid,error=err,abs_error=np.abs(err),
                         interval_returned=interval_ok,lo=lo,hi=hi,width=hi-lo,
                         covered=interval_ok & (lo<=truth)&(truth<=hi),
                         failure_or_abs_error_gt_05=(~valid)|(np.abs(err)>.5)))
    if extra:
        for k,v in extra.items():out[k]=v
    rows.append(out)

def main():
    rng=np.random.default_rng(SEED_SIM);rows=[];settings=[];diagnostics=[]
    for si,(level,p0,exposure,shift) in enumerate(itertools.product(range(3),[.08,.30],[.10,.30],[0.,.7])):
        f0,se0=[(.05,.85),(.15,.60),(.45,.55)][level]
        p=np.array([p0,expit(logit(p0)+np.log(1.5))])
        f=np.array([f0,f0-.03]);se=np.array([se0,se0-.03]);j=se-f
        q=f+j*p
        pi=np.column_stack([p*(1-se)/(1-q),p*se/q])
        assert np.allclose((1-q)*pi[:,0]+q*pi[:,1],p)
        truth=np.log(1.5);scenario=f'S{si+1:02d}'
        # Transport violations are fully specified before simulation outcomes.
        ext_se=expit(logit(se)+shift*np.array([-1.,1.]))
        ext_f=expit(logit(f)+shift*np.array([1.,-1.]))
        pop_e=np.array([1-exposure,exposure]);pop_es=pop_e[:,None]*np.column_stack([1-q,q])
        ne1=rng.binomial(N,exposure,R);ne=np.column_stack([N-ne1,ne1])
        sy=rng.binomial(ne,q);qhat=(sy+.5)/(ne+1)
        qdraw=rng.beta((sy+.5)[:,None,:],(ne-sy+.5)[:,None,:],size=(R,B,2))
        ext_y1=rng.binomial(250,ext_se,size=(R,2));ext_y0=rng.binomial(750,ext_f,size=(R,2))
        sr=(ext_y1+.5)/251;fr=(ext_y0+.5)/751
        sdraw=rng.beta((ext_y1+.5)[:,None,:],(250-ext_y1+.5)[:,None,:],size=(R,B,2))
        fdraw=rng.beta((ext_y0+.5)[:,None,:],(750-ext_y0+.5)[:,None,:],size=(R,B,2))
        jdraw=sdraw-fdraw;ep=(qhat-fr)/(sr-fr);epdraw=(qdraw-fdraw)/jdraw
        legal=((sr>fr)&(ep>0)&(ep<1)).all(axis=1)
        legal_draw=((jdraw>0)&(epdraw>0)&(epdraw<1)).all(axis=2)
        with np.errstate(invalid='ignore'):
            eest=np.where(legal,logit(ep[:,1])-logit(ep[:,0]),np.nan)
            edist=np.where(legal_draw,logit(epdraw[:,:,1])-logit(epdraw[:,:,0]),np.nan)
        efrac=legal_draw.mean(axis=1);eret=legal & (efrac>=.95)
        elo=np.full(R,np.nan);ehi=elo.copy()
        for i in np.flatnonzero(eret):elo[i],ehi[i]=np.quantile(edist[i,legal_draw[i]],[.025,.975])
        # One independent balanced pilot per replicate; shared across budgets.
        pilot_counts=np.full((R,2,2),20)
        _,_,_,pil_point,pil_post,pil_p,pil_pdraw=stratified_inference(rng,pilot_counts,pi,qhat,qdraw)
        pil_se=qdraw*pil_post[:,:,:,1]/pil_pdraw
        pil_f=qdraw*(1-pil_post[:,:,:,1])/(1-pil_pdraw)
        weak=(np.quantile(pil_se-pil_f,.05,axis=1)<=0).any(axis=1)
        # This is an uncertainty-aware comparison, not a true-parameter flag.
        delta=epdraw-pil_pdraw
        dlo,dhi=np.quantile(delta,[.005,.995],axis=1)
        transport=((dlo>0)|(dhi<0)).any(axis=1)
        flag=weak | (~legal) | transport
        w=np.stack([1-qhat,qhat],axis=2)
        weights=w*np.sqrt(pil_point*(1-pil_point))/(pil_p*(1-pil_p))[:,:,None]
        severe=(~legal)|(np.abs(eest-truth)>.5)
        diagnostics.append(pd.DataFrame(dict(scenario=scenario,rep=np.arange(R),true_J=float(j.min()),true_shift=shift,
            flag=flag,weak_flag=weak,incompatible_flag=~legal,transport_flag=transport,
            severe_external=severe,external_error=eest-truth)))
        settings.append(dict(scenario=scenario,level=['strong','moderate','weak'][level],p0=p[0],p1=p[1],
                             exposure=exposure,shift=shift,true_beta=truth,J=float(j.min()),q0=q[0],q1=q[1],
                             se0=se[0],se1=se[1],f0=f[0],f1=f[1],ext_se0=ext_se[0],ext_se1=ext_se[1],ext_f0=ext_f[0],ext_f1=ext_f[1]))
        for budget in SIZES:
            naive=logit(qhat[:,1])-logit(qhat[:,0]);nd=logit(qdraw[:,:,1])-logit(qdraw[:,:,0]);nl,nh=np.quantile(nd,[.025,.975],axis=1)
            record(rows,scenario,budget,'naive_selfreport',truth,naive,nl,nh,np.ones(R,dtype=bool))
            record(rows,scenario,budget,'external_inverse',truth,eest,elo,ehi,eret,dict(valid_draw_fraction=efrac))
            for method in ['local_random','local_E_balanced','local_ES_balanced','pilot_ES_balanced','pilot_adaptive']:
                if method=='local_random':
                    counts=rng.multinomial(budget,pop_es.ravel(),size=R).reshape(R,2,2)
                elif method=='local_E_balanced':
                    ones=rng.binomial(budget//2,q,size=(R,2));counts=np.stack([budget//2-ones,ones],axis=2)
                elif method=='local_ES_balanced':counts=np.full((R,2,2),budget//4)
                elif method=='pilot_ES_balanced':counts=np.full((R,2,2),(budget-PILOT)//4)
                else:counts=allocate(weights,budget-PILOT)
                est,lo,hi,_,_,_,_=stratified_inference(rng,counts,pi,qhat,qdraw)
                record(rows,scenario,budget,method,truth,est,lo,hi,np.ones(R,dtype=bool),
                       dict(pilot_cost=PILOT if method.startswith('pilot_') else 0,
                            estimation_n=counts.sum(axis=(1,2)),min_cell_n=counts.min(axis=(1,2))))
        print('Feasible SIM',scenario,settings[-1]['level'],'p0',p0,'E',exposure,'shift',shift,flush=True)
    d=pd.concat(rows,ignore_index=True);save(d,'feasible_simulation_repetitions.csv')
    s=pd.DataFrame(settings);save(s,'feasible_simulation_scenarios.csv')
    dg=pd.concat(diagnostics,ignore_index=True);save(dg,'feasible_simulation_diagnostics.csv')
    out=[]
    for keys,g in d.groupby(['scenario','budget','method']):
        ok=g[g.valid];ci=g[g.interval_returned]
        row=dict(zip(['scenario','budget','method'],keys))
        row.update(repetitions=len(g),valid_fraction=g.valid.mean(),bias_valid=ok.error.mean(),
                   mae_valid=ok.abs_error.mean(),rmse_valid=np.sqrt((ok.error**2).mean()),
                   mae_mcse=ok.abs_error.std(ddof=1)/np.sqrt(len(ok)) if len(ok)>1 else np.nan,
                   bad_fraction=g.failure_or_abs_error_gt_05.mean(),interval_fraction=g.interval_returned.mean(),
                   coverage_all=g.covered.mean(),coverage_returned=ci.covered.mean(),mean_width=ci.width.mean())
        row['bad_mcse']=np.sqrt(row['bad_fraction']*(1-row['bad_fraction'])/R)
        row['coverage_mcse']=np.sqrt(row['coverage_all']*(1-row['coverage_all'])/R);out.append(row)
    summary=pd.DataFrame(out).merge(s,on='scenario');save(summary,'feasible_simulation_summary.csv')
    contrasts=[]
    for (sc,n),g in d.groupby(['scenario','budget']):
        pivot=g.pivot(index='rep',columns='method',values='abs_error')
        for reference in ['local_random','local_E_balanced','local_ES_balanced','pilot_ES_balanced']:
            diff=pivot.pilot_adaptive-pivot[reference]
            contrasts.append(dict(scenario=sc,budget=n,reference=reference,
                mae_difference=diff.mean(),mcse=diff.std(ddof=1)/np.sqrt(R),
                lo=diff.mean()-1.96*diff.std(ddof=1)/np.sqrt(R),hi=diff.mean()+1.96*diff.std(ddof=1)/np.sqrt(R)))
    save(pd.DataFrame(contrasts).merge(s,on='scenario'),'feasible_simulation_paired_contrasts.csv')
    di=[]
    for sc,g in dg.groupby('scenario'):
        tp=int((g.flag&g.severe_external).sum());fn=int((~g.flag&g.severe_external).sum())
        fp=int((g.flag&~g.severe_external).sum());tn=int((~g.flag&~g.severe_external).sum())
        di.append(dict(scenario=sc,tp=tp,fn=fn,fp=fp,tn=tn,flag_fraction=g.flag.mean(),
                       severe_fraction=g.severe_external.mean(),sensitivity=tp/(tp+fn) if tp+fn else np.nan,
                       specificity=tn/(tn+fp) if tn+fp else np.nan,
                       unflagged_bad_fraction=fn/(fn+tn) if fn+tn else np.nan))
    save(pd.DataFrame(di).merge(s,on='scenario'),'feasible_diagnostic_performance.csv')
    (RES/'feasible_simulation_settings.json').write_text(json.dumps(dict(seed=SEED_SIM,repetitions=R,draws=B,
        scenarios=24,target_N=N,source_validation=2000,local_budgets=SIZES,pilot_cost=PILOT,
        estimand='population marginal measured-outcome logOR',protocol='METHODS_AND_SIMULATION_PROTOCOL.md',
        pilot_reused_for_estimation=False,total_method_repetitions=len(d)),indent=2),encoding='utf-8')
    assert len(d)==24*2*7*R and (d[d.method!='external_inverse'].valid).all()
    assert (d[d.method.str.startswith('pilot_')].estimation_n+d[d.method.str.startswith('pilot_')].pilot_cost==d[d.method.str.startswith('pilot_')].budget).all()
    print('Feasible simulation complete:',len(d),'method-replicates',flush=True)

if __name__=='__main__':main()
