from pathlib import Path
import urllib.request,json,subprocess,sys,time
OUT=Path(__file__).resolve().parents[1]/'literature'
PMC=['PMC10841744','PMC3454464','PMC7902311','PMC10525037','PMC7269021']
def main():
    rows=[]
    previous=OUT/'fulltext_log.json'
    if previous.exists() and not (OUT/'fulltext_initial_attempts.json').exists():
        (OUT/'fulltext_initial_attempts.json').write_bytes(previous.read_bytes())
    for pmc in PMC:
        path=OUT/(pmc+'.xml')
        url=f'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&id={pmc[3:]}&retmode=xml'
        try:
            if not path.exists():
                with urllib.request.urlopen(url,timeout=20) as r:raw=r.read()
                path.write_bytes(raw)
            else:
                url=f'https://www.ebi.ac.uk/europepmc/webservices/rest/{pmc}/fullTextXML'
            parsed=OUT/(pmc+'.parsed.json')
            cmd=[sys.executable,'C:/review_tools/paper-lookup/scripts/jats_to_text.py',str(path),'--output',str(parsed)]
            run=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
            assert run.returncode==0,run.stderr
            data=json.loads(parsed.read_text(encoding='utf-8'))
            assert data['full_text_available'] and data['section_count']>0
            text='\n\n'.join(s['title']+'\n'+s['text'] for s in data['sections'])
            (OUT/(pmc+'.txt')).write_text(text,encoding='utf-8')
            rows.append(dict(pmcid=pmc,url=url,full_text=True,characters=len(text),sections=data['section_count']))
        except Exception as e:rows.append(dict(pmcid=pmc,url=url,full_text=False,error=str(e)))
        print(rows[-1],flush=True);time.sleep(.4)
    (OUT/'fulltext_log.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
if __name__=='__main__':main()
