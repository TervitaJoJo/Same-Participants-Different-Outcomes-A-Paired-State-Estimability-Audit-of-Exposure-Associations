"""Reproducibility checks and compact comparison tables for the corrected analysis."""
from pathlib import Path
import hashlib, json, re
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
REV=ROOT/'corrected_panel'; RES=REV/'results'; DATA=REV/'data'
OLD=ROOT/'panel_reconstruction'; OLDRES=OLD/'results'

def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def main():
    primary=pd.read_csv(RES/'primary_corrected.csv')
    old=pd.read_csv(OLDRES/'primary_corrected.csv')
    multi=pd.read_csv(RES/'multidisease_corrected.csv')
    audit=pd.read_csv(RES/'correction_reanalysis_audit.csv')
    sim=pd.read_csv(RES/'feasible_simulation_repetitions.csv')
    summary=pd.read_csv(RES/'feasible_simulation_summary.csv')
    contrasts=pd.read_csv(RES/'feasible_simulation_paired_contrasts.csv')
    checks=json.loads((RES/'analysis_checks.json').read_text(encoding='utf-8'))

    assert len(primary)==24 and int(primary.n.sum())==216904
    assert int((multi.exposure=='smoke').sum())==42 and int((multi.exposure=='obese').sum())==36
    assert len(sim)==24*2*7*500 and len(summary)==24*2*7
    assert len(contrasts)==24*2*4
    assert checks['primary_records']==216904 and checks['all_primary_models_converged']
    assert int(audit.loc[audit.dataset.eq('CHARLS 2011'),'added_complete'].iloc[0])==3983
    assert int(audit.loc[audit.dataset.str.startswith('NHANES'),'old0_new1'].sum())==1545

    # Frozen-to-corrected comparison, explicitly labelled as the same analysis estimand.
    key=['dataset','country']
    c=old.merge(primary,on=key,suffixes=('_frozen','_corrected'),validate='one_to_one')
    tab=c[key+['n_frozen','n_corrected','delta_frozen','delta_corrected','se_frozen','se_corrected',
               'lo_frozen','hi_frozen','lo_corrected','hi_corrected']].copy()
    tab['n_change']=tab.n_corrected-tab.n_frozen
    tab['delta_change']=tab.delta_corrected-tab.delta_frozen
    tab['se_change']=tab.se_corrected-tab.se_frozen
    tab.to_csv(RES/'corrected_vs_frozen_primary.csv',index=False,encoding='utf-8-sig')
    overall={}
    for frame,label in [(old,'frozen'),(primary,'corrected')]:
        row=frame[frame.country.notna()].iloc[0:0]
        overall[label]=dict(waves=len(frame),records=int(frame.n.sum()))
    overall['frozen_overall_delta']=float(pd.read_csv(OLDRES/'primary_meta_correlated.csv').query("scope=='Overall'").delta.iloc[0])
    overall['corrected_overall_delta']=float(pd.read_csv(RES/'primary_meta_correlated.csv').query("scope=='Overall'").delta.iloc[0])
    (RES/'corrected_vs_frozen_overall.json').write_text(json.dumps(overall,indent=2),encoding='utf-8')

    # Analytic identity and numerical derivative check for the proposed allocation weights.
    p=np.array([.08,.11538461538461542]); q=np.array([.114,.11230769230769233])
    pi=np.array([[.011504424778761062,.6074561403508772],
                 [.02173913043478261,.9365853658536586]])
    w=np.column_stack([1-q,q]); pe=(w*pi).sum(axis=1)
    grad=np.empty((2,2)); grad[0,:]=-w[0]/(pe[0]*(1-pe[0])); grad[1,:]=w[1]/(pe[1]*(1-pe[1]))
    A=(grad**2)*pi*(1-pi)
    def theta(x):
        pp=(w*x).sum(axis=1); return np.log(pp[1]/(1-pp[1]))-np.log(pp[0]/(1-pp[0]))
    eps=1e-7; num=np.empty((2,2))
    for e in range(2):
        for s in range(2):
            xp=pi.copy();xm=pi.copy();xp[e,s]+=eps;xm[e,s]-=eps
            num[e,s]=(theta(xp)-theta(xm))/(2*eps)
    assert np.max(np.abs(grad-num))<1e-8
    # Allocation implementation only consumes pilot quantities; true pi occurs only in data generation.
    sim_code=(REV/'code/17_feasible_simulation.py').read_text(encoding='utf-8')
    assert 'weights=w*np.sqrt(pil_point*(1-pil_point))/(pil_p*(1-pil_p))[:,:,None]' in sim_code
    assert 'pi' in sim_code and 'pilot_adaptive' in sim_code
    alloc=pd.DataFrame({'stratum':['E0,S0','E0,S1','E1,S0','E1,S1'],
                        'gradient':grad.ravel(),'A':A.ravel(),'sqrt_A':np.sqrt(A).ravel()})
    alloc.to_csv(RES/'allocation_identity_check.csv',index=False,encoding='utf-8-sig')

    # Source and result provenance manifest. Raw files are public/local inputs; no contents are uploaded.
    paths=[ROOT/'CHARLS/analysis/charls_analysis_wide.csv',ROOT/'CHARLS/2011/health_status_and_functioning.dta',
           OLD/'data/hypertension_panel.csv.gz',OLD/'data/panel_diseases_bmi.csv',
           DATA/'hypertension_panel.csv.gz',REV/'data/panel_diseases_bmi_corrected.csv.gz']
    paths += sorted((ROOT/'NHANES').glob('*/SMQ*.xpt'))
    paths += [REV/'code/01_rebuild_corrected_panel.py',REV/'code/02_paired_and_treatment.py',
              REV/'code/03_transport_and_local_validation.py',REV/'code/04_inverse_and_checks.py',
              REV/'code/09_validate_inverse.py',REV/'code/17_feasible_simulation.py',REV/'code/20_quality_and_tables.py',
              REV/'code/21_make_research_figures.py']
    rows=[]
    for pth in paths:
        if pth.exists(): rows.append(dict(path=str(pth.relative_to(ROOT)),bytes=pth.stat().st_size,sha256=sha256(pth)))
    (REV/'PROVENANCE_SHA256.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')

    # Compact key metrics for report generation and later manuscript tables.
    pm=pd.read_csv(RES/'primary_meta_correlated.csv'); ms=pd.read_csv(RES/'multidisease_smoke_meta.csv'); mo=pd.read_csv(RES/'multidisease_obese_meta.csv')
    inv=pd.read_csv(RES/'inverse_transport_macro_metrics.csv'); tr=pd.read_csv(RES/'transport_macro_metrics.csv'); ih=pd.read_csv(RES/'independent_half_macro_metrics.csv')
    metrics=[
      {'family':'primary','scope':'Overall','estimand':'adjusted_logOR_delta','n_or_cells':24,'estimate':float(pm.query("scope=='Overall'").delta.iloc[0]),'lo':float(pm.query("scope=='Overall'").lo.iloc[0]),'hi':float(pm.query("scope=='Overall'").hi.iloc[0])},
      {'family':'multidisease_smoke','scope':'Overall','estimand':'adjusted_logOR_delta','n_or_cells':42,'estimate':float(ms.query("scope=='Overall'").delta.iloc[0]),'lo':float(ms.query("scope=='Overall'").lo.iloc[0]),'hi':float(ms.query("scope=='Overall'").hi.iloc[0])},
      {'family':'multidisease_obese','scope':'Overall','estimand':'adjusted_logOR_delta','n_or_cells':36,'estimate':float(mo.query("scope=='Overall'").delta.iloc[0]),'lo':float(mo.query("scope=='Overall'").lo.iloc[0]),'hi':float(mo.query("scope=='Overall'").hi.iloc[0])},
    ]
    for frame,name in [(tr,'transport_LOCO'),(ih,'independent_half')]:
        for _,r in frame.iterrows():metrics.append({'family':name,'scope':'macro','estimand':r['method'],'n_or_cells':np.nan,'estimate':float(r['mae_logor']),'lo':np.nan,'hi':np.nan})
    for _,r in inv.iterrows():metrics.append({'family':'inverse','scope':'macro','estimand':r['method'],'n_or_cells':r['waves'],'estimate':r['valid_fraction'],'lo':np.nan,'hi':np.nan})
    pd.DataFrame(metrics).to_csv(RES/'research_key_metrics.csv',index=False,encoding='utf-8-sig')
    print('QUALITY PASS',json.dumps({'primary_records':int(primary.n.sum()),'simulation_rows':len(sim),'sha_files':len(rows),'max_gradient_error':float(np.max(np.abs(grad-num)))},ensure_ascii=False))

if __name__=='__main__': main()
