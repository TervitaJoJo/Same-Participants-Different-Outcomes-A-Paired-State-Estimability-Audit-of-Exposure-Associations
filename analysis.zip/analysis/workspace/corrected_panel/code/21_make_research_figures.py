"""Make compact diagnostic figures from the canonical simulation outputs."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

REV=Path(__file__).resolve().parents[1]; RES=REV/'results'; FIG=REV/'figures'; FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':300})

def save(fig,name):
    for ext in ['png','pdf','svg']: fig.savefig(FIG/f'{name}.{ext}',bbox_inches='tight')
    plt.close(fig)

def main():
    con=pd.read_csv(RES/'feasible_simulation_paired_contrasts.csv')
    x=con[con.reference.eq('local_ES_balanced')].copy()
    order=sorted(x.scenario.unique(),key=lambda z:int(z[1:]))
    fig,ax=plt.subplots(figsize=(11,4.3))
    for color,budget in [('#2166ac',200),('#b2182b',500)]:
        g=x[x.budget.eq(budget)].set_index('scenario').loc[order].reset_index()
        xx=np.arange(len(g)) + (-.13 if budget==200 else .13)
        ax.errorbar(xx,g.mae_difference,yerr=1.96*g.mcse,fmt='o',ms=4,capsize=2,lw=1,color=color,label=f'Budget {budget}')
    ax.axhline(0,color='0.25',lw=.8)
    ax.set_xticks(np.arange(len(order))); ax.set_xticklabels(order,rotation=60,ha='right',fontsize=7)
    ax.set_ylabel('Adaptive − fixed E×S balanced MAE')
    ax.set_xlabel('Simulation scenario (ordered by J, prevalence, exposure, shift)')
    ax.set_title('Pilot-adaptive allocation versus fixed four-cell balance')
    ax.legend(frameon=False,ncol=2,loc='upper left')
    ax.text(0.99,0.03,'Negative values favor adaptive; error bars are 95% MC intervals',transform=ax.transAxes,ha='right',fontsize=8,color='0.3')
    save(fig,'figure_1_adaptive_vs_fixed')

    s=pd.read_csv(RES/'feasible_simulation_summary.csv')
    e=s[s.method.eq('external_inverse')].copy()
    e['level_shift']=e.level.str.title()+' / shift '+e['shift'].astype(str)
    # Average over the four prevalence/exposure combinations, preserving coverage definitions.
    a=e.groupby(['level','shift','budget'],as_index=False).agg(legal_fraction=('valid_fraction','mean'),
        interval_return=('interval_fraction','mean'),coverage_all=('coverage_all','mean'),bad_fraction=('bad_fraction','mean'))
    fig,axs=plt.subplots(1,3,figsize=(11,3.6),sharex=True)
    labels=[]; xpos=np.arange(6)
    for i,(level,shift) in enumerate([(l,h) for l in ['strong','moderate','weak'] for h in [0.,.7]]):
        labels.append(level.title()+'\n'+('no shift' if shift==0 else 'shift 0.7'))
    for j,(metric,ylabel) in enumerate([('legal_fraction','Legal point fraction'),('interval_return','Interval returned'),('coverage_all','Coverage across all replicates')]):
        ax=axs[j]
        for color,budget,off in [('#2166ac',200,-.12),('#b2182b',500,.12)]:
            vals=[]
            for level,shift in [(l,h) for l in ['strong','moderate','weak'] for h in [0.,.7]]:
                z=a[(a['level']==level)&np.isclose(a['shift'],shift)&(a['budget']==budget)]
                vals.append(float(z[metric].iloc[0]))
            ax.bar(xpos+off,vals,width=.23,color=color,label=f'{budget}')
        ax.set_ylim(0,1.05); ax.set_ylabel(ylabel); ax.set_xticks(xpos); ax.set_xticklabels(labels,fontsize=7)
        ax.grid(axis='y',alpha=.2)
        if j==0: ax.legend(title='Budget',frameon=False,ncol=2,fontsize=8)
    fig.suptitle('External inverse correction: validity and coverage depend on transport shift and J',y=1.02)
    fig.tight_layout(); save(fig,'figure_2_external_inverse_validity')
    print('FIGURES',*[str(p) for p in sorted(FIG.glob('figure_*png'))],sep='\n')

if __name__=='__main__':main()
