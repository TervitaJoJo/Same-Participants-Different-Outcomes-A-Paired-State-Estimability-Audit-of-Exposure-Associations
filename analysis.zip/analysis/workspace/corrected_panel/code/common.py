from pathlib import Path
import importlib.util, json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.special import expit, logit
from scipy.optimize import minimize_scalar
from scipy.stats import t as tdist

REV=Path(__file__).resolve().parents[1]
BASE=REV.parent
OLD=BASE/'legacy_panel_sources'
RES=REV/'results'; RES.mkdir(exist_ok=True)
DATA=REV/'data'; DATA.mkdir(exist_ok=True)
SEED=20260916

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def save(df,name):
    df.to_csv(RES/name,index=False,encoding='utf-8-sig')

def binary(x,yes=1,no=(0,2)):
    z=pd.to_numeric(x,errors='coerce')
    return pd.Series(np.where(z==yes,1.,np.where(z.isin(no),0.,np.nan)),index=x.index)

def fit_score(X,y,w=None):
    X=np.asarray(X,float);y=np.asarray(y,float)
    w=np.ones(len(y)) if w is None else np.asarray(w,float)/np.mean(w)
    f=sm.GLM(y,X,family=sm.families.Binomial(),freq_weights=w).fit(maxiter=100,tol=1e-9)
    mu=np.asarray(f.fittedvalues)
    bread=np.linalg.inv(X.T@((w*mu*(1-mu))[:,None]*X))
    influence=(X*(w*(y-mu))[:,None])@bread
    return np.asarray(f.params),influence, f.converged

def design(d,exposure='smoke',cov=('age','male','edu'),wave=False):
    cols=[np.ones(len(d)),d[exposure].to_numpy(float)];names=['intercept',exposure]
    for c in cov:
        if d[c].nunique()>1:
            z=d[c].to_numpy(float)
            if c=='age':z=(z-60)/10
            cols.append(z);names.append(c)
    if wave:
        dum=pd.get_dummies(d.dataset,drop_first=True,dtype=float)
        cols.extend([dum[c].to_numpy() for c in dum]);names.extend(dum.columns.tolist())
    return np.column_stack(cols),names

def paired(d,exposure='smoke',ref='M',cov=('age','male','edu'),wave=False,weighted=False,return_influence=False):
    needed=[ref,'S',exposure,*cov,'uid']
    if weighted:needed+=['wt','stratum','psu']
    z=d.dropna(subset=list(dict.fromkeys(needed))).copy()
    if weighted:z=z[z.wt>0]
    if len(z)<80 or z[exposure].nunique()<2:raise ValueError('Insufficient complete exposure variation')
    X,names=design(z,exposure,cov,wave)
    b1,i1,c1=fit_score(X,z[ref],z.wt if weighted else None)
    b2,i2,c2=fit_score(X,z.S,z.wt if weighted else None)
    psi=i2[:,1]-i1[:,1]
    if weighted:
        f=z[['stratum','psu']].copy();f['u']=psi
        sums=f.groupby(['stratum','psu']).u.sum()
        var=0.;dof=0
        for _,s in sums.groupby(level=0):
            m=len(s)
            if m<2:raise ValueError('Singleton PSU stratum')
            var+=m/(m-1)*np.sum((s-s.mean())**2);dof+=m-1
        critical=tdist.ppf(.975,dof)
    else:
        sums=pd.Series(psi).groupby(z.uid.to_numpy()).sum()
        G=len(sums);var=float(np.sum(sums**2)*G/(G-1)*(len(z)-1)/(len(z)-X.shape[1]))
        dof=G-1;critical=1.96
    delta=b2[1]-b1[1];se=np.sqrt(var)
    result=dict(n=len(z),unique_n=z.uid.nunique(),or_measured=np.exp(b1[1]),or_selfreport=np.exp(b2[1]),delta=delta,se=se,lo=delta-critical*se,hi=delta+critical*se,df=dof,covariates='+'.join(names[2:]),converged=c1 and c2)
    if return_influence:
        if weighted:raise ValueError('Survey influence export not requested')
        return result,sums*np.sqrt(G/(G-1)*(len(z)-1)/(len(z)-X.shape[1]))
    return result

def correlated_meta(y,V):
    y=np.asarray(y,float);V=np.asarray(V,float);k=len(y);one=np.ones(k)
    if k==1:return meta(y,np.sqrt(np.diag(V)))
    def get(tau):
        W=np.linalg.inv(V+tau*np.eye(k));den=one@W@one;b=(one@W@y)/den;r=y-b
        obj=.5*(np.linalg.slogdet(V+tau*np.eye(k))[1]+np.log(den)+r@W@r)
        return obj,b,den,r@W@r
    opt=minimize_scalar(lambda x:get(x)[0],bounds=(1e-10,max(.5,np.var(y)*5)),method='bounded')
    tau=opt.x
    if get(1e-10)[0]<get(tau)[0]:tau=1e-10
    _,b,den,Q=get(tau);s=np.sqrt(max(1.,Q/(k-1))/den);c=tdist.ppf(.975,k-1)
    return dict(k=k,delta=b,se=s,lo=b-c*s,hi=b+c*s,tau2=tau)

def meta(y,se):
    y=np.asarray(y,float);se=np.asarray(se,float);v=se**2
    if len(y)==1:return dict(k=1,delta=y[0],se=se[0],lo=y[0]-1.96*se[0],hi=y[0]+1.96*se[0],tau2=0)
    def obj(tau):
        w=1/(v+tau);b=np.sum(w*y)/sum(w)
        return .5*(np.log(v+tau).sum()+np.log(w.sum())+np.sum(w*(y-b)**2))
    fit=minimize_scalar(obj,bounds=(0,max(.5,np.var(y)*5)),method='bounded')
    tau=fit.x if obj(fit.x)<obj(0) else 0.
    w=1/(v+tau);b=np.sum(w*y)/sum(w)
    # Modified Hartung-Knapp avoids intervals narrower than conventional RE.
    scale=max(1.,np.sum(w*(y-b)**2)/(len(y)-1))
    s=np.sqrt(scale/sum(w));crit=tdist.ppf(.975,len(y)-1)
    return dict(k=len(y),delta=b,se=s,lo=b-crit*s,hi=b+crit*s,tau2=tau)

def rates(d):
    out={}
    for e in (0,1):
        g=d[d.smoke==e]
        out[f'n{e}']=len(g);out[f'p{e}']=g.M.mean();out[f'q{e}']=g.S.mean()
        for m in (0,1):
            h=g[g.M==m];out[f'a{m}{e}']=h.S.sum();out[f'b{m}{e}']=len(h)-h.S.sum()
            out[f'r{m}{e}']=h.S.mean()
    return out

def lor(q0,q1):
    return float(logit(np.clip(q1,1e-6,1-1e-6))-logit(np.clip(q0,1e-6,1-1e-6)))

def mixture(parameters,p0,p1):
    q0=parameters['r10']*p0+parameters['r00']*(1-p0)
    q1=parameters['r11']*p1+parameters['r01']*(1-p1)
    return lor(q0,q1)
