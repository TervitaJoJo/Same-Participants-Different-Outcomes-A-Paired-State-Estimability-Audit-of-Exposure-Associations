"""Reconcile the final evidence base for the 16 September manuscript.

This script fixes the denominator drift in earlier drafts and produces one
auditable cross-sectional hypertension frame spanning 24 survey waves.  The
paired outcome contrast is estimated in one stacked logistic model so that the
standard error of Delta includes the within-person covariance between the two
outcome definitions.

Outputs
-------
results/主结果/高血压24波次_配对效应.csv
results/主结果/高血压24波次_随机效应汇总.csv
results/机制与稳健性/机制元回归_24波次.csv
results/机制与稳健性/六折留一国家外推.csv
results/机制与稳健性/六折留一国家外推_汇总.csv
results/附表数据/样本筛选_逐波次.csv
results/附表数据/数据库筛选.csv
"""

from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat
import statsmodels.api as sm
from scipy.optimize import minimize_scalar


ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT.parent
DATA = ROOT / "data"
RES = ROOT / "results"
SEED = 20260916


def _num(x: pd.Series) -> pd.Series:
    return pd.to_numeric(x, errors="coerce")


def _fit_logit(d: pd.DataFrame, y: str, x: str, cov: list[str]) -> tuple[float, float]:
    m = d[[y, x] + cov].dropna()
    if len(m) < 80 or m[y].nunique() < 2 or m[x].nunique() < 2:
        return np.nan, np.nan
    X = sm.add_constant(m[[x] + cov].astype(float), has_constant="add")
    try:
        f = sm.GLM(m[y].astype(float), X, family=sm.families.Binomial()).fit()
        return float(f.params[x]), float(f.bse[x])
    except Exception:
        return np.nan, np.nan


def paired_stacked_logit(
    d: pd.DataFrame, exposure: str, cov: list[str], dataset: str, country: str
) -> dict:
    """Two definition-specific logistic models in one clustered likelihood."""
    v = d[["M", "S", exposure] + cov].dropna().copy()
    v = v[v[exposure].isin([0, 1])].reset_index(drop=True)
    n = len(v)
    if n < 300:
        raise ValueError(f"{dataset}: complete-case n={n} < 300")

    # A few public releases encode an unavailable education ladder as one
    # constant value.  Keeping a constant alongside the intercept makes the
    # block-diagonal Hessian singular, so retain only covariates that vary in
    # the complete analysis sample.
    active_cov = [c for c in cov if v[c].nunique(dropna=True) > 1]

    z = sm.add_constant(v[[exposure] + active_cov].astype(float), has_constant="add")
    names = list(z.columns)
    zeros = np.zeros_like(z.to_numpy(float))
    X = np.block([[z.to_numpy(float), zeros], [zeros, z.to_numpy(float)]])
    xnames = [f"M_{x}" for x in names] + [f"S_{x}" for x in names]
    y = np.r_[v["M"].to_numpy(float), v["S"].to_numpy(float)]
    groups = np.r_[np.arange(n), np.arange(n)]
    fit = sm.GLM(y, X, family=sm.families.Binomial()).fit(
        cov_type="cluster", cov_kwds={"groups": groups}
    )
    beta = pd.Series(np.asarray(fit.params), index=xnames)
    vc = pd.DataFrame(np.asarray(fit.cov_params()), index=xnames, columns=xnames)
    bm, bs = beta[f"M_{exposure}"], beta[f"S_{exposure}"]
    delta = float(bs - bm)
    var_delta = float(
        vc.loc[f"S_{exposure}", f"S_{exposure}"]
        + vc.loc[f"M_{exposure}", f"M_{exposure}"]
        - 2 * vc.loc[f"S_{exposure}", f"M_{exposure}"]
    )
    se_delta = float(np.sqrt(max(var_delta, 0)))

    tp = int(((v.M == 1) & (v.S == 1)).sum())
    fn = int(((v.M == 1) & (v.S == 0)).sum())
    fp = int(((v.M == 0) & (v.S == 1)).sum())
    tn = int(((v.M == 0) & (v.S == 0)).sum())
    by = {}
    for e in (0, 1):
        g = v[v[exposure] == e]
        pos, neg = g[g.M == 1], g[g.M == 0]
        by[f"p{e}"] = float(g.M.mean())
        by[f"se{e}"] = float(pos.S.mean()) if len(pos) else np.nan
        by[f"sp{e}"] = float(1 - neg.S.mean()) if len(neg) else np.nan
        by[f"n{e}"] = int(len(g))

    se_logor, _ = _fit_logit(v[v.M == 1], "S", exposure, active_cov)
    fp_logor, _ = _fit_logit(v[v.M == 0], "S", exposure, active_cov)
    return {
        "dataset": dataset,
        "country": country,
        "n": n,
        "n_measured_positive": tp + fn,
        "n_selfreport_positive": tp + fp,
        "sensitivity": tp / (tp + fn),
        "specificity": tn / (tn + fp),
        "or_measured": float(np.exp(bm)),
        "or_selfreport": float(np.exp(bs)),
        "delta": delta,
        "delta_se": se_delta,
        "delta_lo": delta - 1.96 * se_delta,
        "delta_hi": delta + 1.96 * se_delta,
        "or_ratio": float(np.exp(delta)),
        "diagnosis_logor_Mpos": se_logor,
        "falsepositive_logor_Mneg": fp_logor,
        "sensitivity_gap": by["se1"] - by["se0"],
        "specificity_gap": by["sp1"] - by["sp0"],
        "covariates": "+".join(active_cov),
        **by,
    }


def lasi_frame() -> tuple[pd.DataFrame, int, int]:
    p = BASE / "LASI" / "LASI_印度" / "Temp_data" / "lasi.dta"
    _, meta = pyreadstat.read_dta(str(p), metadataonly=True)
    cols = [
        c
        for c in meta.column_names
        if re.match(r"^(r1|ra)", c, re.I)
        and re.search(r"hibpe|systo|diasto|smoken|agey|gender|edu", c, re.I)
    ]
    d = pyreadstat.read_dta(str(p), usecols=cols)[0]
    raw_n = len(d)
    sy = [c for c in d if re.match(r"r1systo\d", c, re.I)]
    di = [c for c in d if re.match(r"r1diasto\d", c, re.I)]
    sbp = d[sy].apply(pd.to_numeric, errors="coerce").mean(axis=1, skipna=True)
    dbp = d[di].apply(pd.to_numeric, errors="coerce").mean(axis=1, skipna=True)
    d["M"] = np.where(
        pd.concat([sbp, dbp], axis=1).notna().any(axis=1),
        ((sbp >= 140) | (dbp >= 90)).astype(float),
        np.nan,
    )
    d["S"] = _num(d["r1hibpe"])
    d["smoke"] = _num(d["r1smoken"])
    d["age"] = _num(d["r1agey"])
    d["male"] = (_num(d["ragender"]) == 1).astype(float)
    d["edu"] = _num(d["raeduc_l"])
    d = d[(d.age >= 45) & (d.age <= 110)]
    paired_n = int(d[["M", "S"]].notna().all(axis=1).sum())
    return d, raw_n, paired_n


def haalsi_frame() -> tuple[pd.DataFrame, int, int]:
    p = (
        BASE
        / "HAALSI"
        / "HAALSI Baseline Survey"
        / "HAALSI_baseline_dataverse_14Apr2017.dta"
    )
    need = [
        "c_bs_mean_sys",
        "c_bs_mean_dia",
        "cm002",
        "cm061",
        "cm059",
        "bd002",
        "rsex",
        "c_bd_educ4",
    ]
    d = pyreadstat.read_dta(str(p), usecols=need)[0]
    raw_n = len(d)
    sbp, dbp = _num(d.c_bs_mean_sys), _num(d.c_bs_mean_dia)
    d["M"] = np.where(
        pd.concat([sbp, dbp], axis=1).notna().any(axis=1),
        ((sbp >= 140) | (dbp >= 90)).astype(float),
        np.nan,
    )
    sr = _num(d.cm002)
    d["S"] = np.where(sr == 1, 1.0, np.where(sr == 2, 0.0, np.nan))
    ever, cur = _num(d.cm059), _num(d.cm061)
    d["smoke"] = np.nan
    d.loc[cur == 1, "smoke"] = 1.0
    d.loc[(cur == 2) | (ever == 2), "smoke"] = 0.0
    d["age"] = _num(d.bd002)
    sx = _num(d.rsex)
    d["male"] = np.where(sx.notna(), (sx == 1).astype(float), np.nan)
    d["edu"] = _num(d.c_bd_educ4)
    paired_n = int(d[["M", "S"]].notna().all(axis=1).sum())
    return d, raw_n, paired_n


def mhas_screen_counts() -> tuple[int, int, int]:
    base = BASE / "MHAS" / "MHAS_墨西哥" / "Raw_data" / "wave3"
    bp = base / "Biomarkers and Anthropometric Measures" / "sect_l_biomarkers_2012.dta"
    core = base / "Core survey Data" / "sect_a_c_d_e_pc_f_h_i_em_2012.dta"
    b = pyreadstat.read_dta(
        str(bp),
        usecols=["cunicah", "np", "sist1_12", "sist2_12", "dias1_12", "dias2_12"],
    )[0]
    c = pyreadstat.read_dta(
        str(core),
        usecols=["cunicah", "np", "c4_12", "c54_12", "age_12", "sex_12"],
    )[0]
    d = b.merge(c, on=["cunicah", "np"], how="inner")
    for col in ("sist1_12", "sist2_12", "dias1_12", "dias2_12"):
        z = _num(d[col])
        d[col] = z.where((z > 40) & (z < 300))
    sbp = d[["sist1_12", "sist2_12"]].mean(axis=1, skipna=True)
    dbp = d[["dias1_12", "dias2_12"]].mean(axis=1, skipna=True)
    d["M"] = np.where(
        pd.concat([sbp, dbp], axis=1).notna().any(axis=1),
        ((sbp >= 140) | (dbp >= 90)).astype(float),
        np.nan,
    )
    sr, smk = _num(d.c4_12), _num(d.c54_12)
    d["S"] = np.where(sr == 1, 1.0, np.where(sr == 2, 0.0, np.nan))
    d["smoke"] = np.where(smk == 1, 1.0, np.where(smk.isin([0, 2]), 0.0, np.nan))
    d["age"], d["male"] = _num(d.age_12), (_num(d.sex_12) == 1).astype(float)
    age = d[(d.age >= 50) & (d.age <= 110)]
    paired = int(age[["M", "S"]].notna().all(axis=1).sum())
    final = int(age[["M", "S", "smoke", "age", "male"]].notna().all(axis=1).sum())
    return len(d), paired, final


def elsa_initial_and_paired() -> dict[str, tuple[int, int]]:
    p = BASE / "survey_panels" / "code" / "31_elsa_three_diseases.py"
    spec = importlib.util.spec_from_file_location("elsa31", p)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    out = {}
    for w, (path, wf) in mod.NURSE.items():
        if not path.exists():
            continue
        d = mod.wave_frame(w, path, wf)
        d = d[(d.age >= 50) & (d.age <= 110)]
        paired = int(d[["M_htn", "S_htn"]].notna().all(axis=1).sum())
        out[f"ELSA w{w}"] = (len(d), paired)
    return out


def reml(y: np.ndarray, se: np.ndarray, X: np.ndarray) -> dict:
    y, se, X = map(np.asarray, (y, se, X))
    n, p = X.shape

    def objective(tau2: float) -> float:
        v = se**2 + tau2
        w = 1 / v
        xtwx = X.T @ (w[:, None] * X)
        beta = np.linalg.solve(xtwx, X.T @ (w * y))
        resid = y - X @ beta
        sign, logdet = np.linalg.slogdet(xtwx)
        if sign <= 0:
            return np.inf
        return 0.5 * (np.log(v).sum() + logdet + np.sum(w * resid**2))

    upper = max(float(np.var(y) * 5), 0.5)
    opt = minimize_scalar(objective, bounds=(0, upper), method="bounded")
    tau2 = float(max(opt.x, 0))
    w = 1 / (se**2 + tau2)
    xtwx = X.T @ (w[:, None] * X)
    vcov = np.linalg.inv(xtwx)
    beta = vcov @ (X.T @ (w * y))
    return {"beta": beta, "se": np.sqrt(np.diag(vcov)), "tau2": tau2, "k": n}


def analyse_meta(t: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for label, g in [("总体", t)] + [(c, g) for c, g in t.groupby("country")]:
        if len(g) == 1:
            b = float(g.delta.iloc[0])
            s = float(g.delta_se.iloc[0])
            fit = {"tau2": 0.0}
        else:
            fit = reml(g.delta.to_numpy(), g.delta_se.to_numpy(), np.ones((len(g), 1)))
            b, s = float(fit["beta"][0]), float(fit["se"][0])
        rows.append(
            {
                "scope": label,
                "k": len(g),
                "delta": b,
                "delta_se": s,
                "delta_lo": b - 1.96 * s,
                "delta_hi": b + 1.96 * s,
                "or_ratio": np.exp(b),
                "tau2": fit["tau2"],
            }
        )

    m = t.dropna(subset=["diagnosis_logor_Mpos", "falsepositive_logor_Mneg"]).copy()
    X1 = np.column_stack([np.ones(len(m)), m.diagnosis_logor_Mpos])
    f1 = reml(m.delta.to_numpy(), m.delta_se.to_numpy(), X1)
    X2 = np.column_stack(
        [np.ones(len(m)), m.diagnosis_logor_Mpos, m.falsepositive_logor_Mneg]
    )
    f2 = reml(m.delta.to_numpy(), m.delta_se.to_numpy(), X2)
    reg = []
    for name, fit, terms in (
        ("诊断机会单参数", f1, ["截距", "实测阳性者中的诊断logOR"]),
        (
            "完整差异性错分",
            f2,
            ["截距", "实测阳性者中的诊断logOR", "实测阴性者中的自报logOR"],
        ),
    ):
        for term, b, s in zip(terms, fit["beta"], fit["se"]):
            reg.append(
                {
                    "model": name,
                    "term": term,
                    "k": fit["k"],
                    "estimate": b,
                    "se": s,
                    "lo": b - 1.96 * s,
                    "hi": b + 1.96 * s,
                    "tau2": fit["tau2"],
                }
            )
    return pd.DataFrame(rows), pd.DataFrame(reg)


def loco(t: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for hold in sorted(t.country.unique()):
        tr, te = t[t.country != hold], t[t.country == hold]
        pars = {}
        for e in (0, 1):
            pars[f"se{e}"] = float(np.average(tr[f"se{e}"], weights=tr[f"n{e}"]))
            pars[f"sp{e}"] = float(np.average(tr[f"sp{e}"], weights=tr[f"n{e}"]))
        for r in te.itertuples():
            q = {}
            for e in (0, 1):
                q[e] = pars[f"se{e}"] * getattr(r, f"p{e}") + (
                    1 - pars[f"sp{e}"]
                ) * (1 - getattr(r, f"p{e}"))
            or_pred = (q[1] / (1 - q[1])) / (q[0] / (1 - q[0]))
            # The observed target here is the crude self-report OR because the
            # mixture identity predicts a marginal 2x2 quantity.
            obs_q0 = r.se0 * r.p0 + (1 - r.sp0) * (1 - r.p0)
            obs_q1 = r.se1 * r.p1 + (1 - r.sp1) * (1 - r.p1)
            or_obs = (obs_q1 / (1 - obs_q1)) / (obs_q0 / (1 - obs_q0))
            rows.append(
                {
                    "held_out_country": hold,
                    "dataset": r.dataset,
                    "or_observed": or_obs,
                    "or_predicted": or_pred,
                    "error": or_pred - or_obs,
                    "abs_error": abs(or_pred - or_obs),
                    "log_error": np.log(or_pred) - np.log(or_obs),
                }
            )
    out = pd.DataFrame(rows)
    X = sm.add_constant(np.log(out.or_predicted))
    cal = sm.OLS(np.log(out.or_observed), X).fit()
    summ = pd.DataFrame(
        [
            {
                "folds": out.held_out_country.nunique(),
                "analyses": len(out),
                "mae_or": out.abs_error.mean(),
                "rmse_logor": np.sqrt(np.mean(out.log_error**2)),
                "calibration_intercept": cal.params.iloc[0],
                "calibration_slope": cal.params.iloc[1],
                "calibration_slope_lo": cal.conf_int().iloc[1, 0],
                "calibration_slope_hi": cal.conf_int().iloc[1, 1],
            }
        ]
    )
    return out, summ


def main() -> None:
    (RES / "主结果").mkdir(parents=True, exist_ok=True)
    (RES / "机制与稳健性").mkdir(parents=True, exist_ok=True)
    (RES / "附表数据").mkdir(parents=True, exist_ok=True)

    p = pd.read_csv(DATA / "panel_individual.csv", low_memory=False)
    dz = pd.read_csv(DATA / "panel_diseases.csv", low_memory=False)
    starts = p.groupby("dataset").size().to_dict()
    elsa_counts = elsa_initial_and_paired()

    frames: list[tuple[str, str, pd.DataFrame, list[str], int, int]] = []
    # China, Mexico and US source frames. CHARLS and NHANES use the harmonised
    # disease panel; CHNS/ENSANUT use the original hypertension panel.
    for ds, g in p.groupby("dataset", sort=False):
        if ds.startswith("CHARLS") or ds.startswith("NHANES"):
            continue
        country = "China" if ds.startswith("CHNS") else "Mexico"
        cov = ["age", "male", "edu"] if ds in {"CHNS 2009", "ENSANUT 2012"} else ["age", "male"]
        if ds.startswith("ENSANUT") and "smoke_src" in g and g["smoke_src"].notna().mean() > 0.5:
            g = g.copy()
            g["smoke"] = g["smoke_src"]
        paired_n = int(g[["M", "S"]].notna().all(axis=1).sum())
        frames.append((ds, country, g, cov, len(g), paired_n))

    h = dz[dz.disease == "hypertension"].copy()
    for ds, g in h.groupby("dataset", sort=False):
        country = str(g.country.iloc[0])
        cov = ["age", "male", "edu"]
        initial = starts.get(ds, elsa_counts.get(ds, (len(g), len(g)))[0])
        paired = (
            int(p[p.dataset == ds][["M", "S"]].notna().all(axis=1).sum())
            if ds in starts
            else elsa_counts.get(ds, (len(g), len(g)))[1]
        )
        frames.append((ds, country, g, cov, int(initial), int(paired)))

    lasi, n0, n1 = lasi_frame()
    frames.append(("LASI w1", "India", lasi, ["age", "male", "edu"], n0, n1))
    haa, n0, n1 = haalsi_frame()
    frames.append(("HAALSI baseline", "South Africa", haa, ["age", "male"], n0, n1))

    estimates, flow = [], []
    for ds, country, g, cov, initial, paired in frames:
        rec = paired_stacked_logit(g, "smoke", cov, ds, country)
        estimates.append(rec)
        flow.append(
            {
                "dataset": ds,
                "country": country,
                "eligible_source_records": initial,
                "paired_outcomes": paired,
                "complete_primary_analysis": rec["n"],
                "excluded_before_pairing": initial - paired,
                "excluded_for_exposure_covariates": paired - rec["n"],
            }
        )

    t = pd.DataFrame(estimates).sort_values(["country", "dataset"]).reset_index(drop=True)
    fl = pd.DataFrame(flow).sort_values(["country", "dataset"]).reset_index(drop=True)
    if len(t) != 24:
        raise RuntimeError(f"Expected 24 cross-sectional waves, found {len(t)}")
    t.to_csv(RES / "主结果" / "高血压24波次_配对效应.csv", index=False, encoding="utf-8-sig")
    fl.to_csv(RES / "附表数据" / "样本筛选_逐波次.csv", index=False, encoding="utf-8-sig")

    summary, reg = analyse_meta(t)
    summary.to_csv(RES / "主结果" / "高血压24波次_随机效应汇总.csv", index=False, encoding="utf-8-sig")
    reg.to_csv(RES / "机制与稳健性" / "机制元回归_24波次.csv", index=False, encoding="utf-8-sig")
    lo, los = loco(t)
    lo.to_csv(RES / "机制与稳健性" / "六折留一国家外推.csv", index=False, encoding="utf-8-sig")
    los.to_csv(RES / "机制与稳健性" / "六折留一国家外推_汇总.csv", index=False, encoding="utf-8-sig")

    m_raw, m_pair, m_final = mhas_screen_counts()
    screening = pd.DataFrame(
        [
            ("CHARLS", "纳入主分析", "同波实测血压、自报诊断、吸烟及协变量齐全", 1, "China"),
            ("CHNS", "纳入主分析", "同波实测血压、自报诊断、吸烟及协变量齐全", 1, "China"),
            ("ENSANUT", "纳入主分析", "7个波次满足配对结局要求", 7, "Mexico"),
            ("NHANES", "纳入主分析", "8个周期满足配对结局要求", 8, "United States"),
            ("ELSA", "纳入主分析", "5个护士访视波次满足配对结局要求", 5, "England"),
            ("LASI", "纳入主分析", "第1波满足配对结局要求", 1, "India"),
            ("HAALSI", "纳入主分析", "基线满足配对结局要求", 1, "South Africa"),
            ("MHAS", "排除主分析", f"2012年合并{m_raw}人，配对{m_pair}人，完整{m_final}人，低于预设n=300", 0, "Mexico"),
            ("KLoSA", "排除", "全库无实测血压", 0, "South Korea"),
            ("SHARE", "排除", "全库无实测血压", 0, "Europe"),
            ("HRS", "仅纵向验证", "实测异常与后续自报新发并非同波双结局", 0, "United States"),
        ],
        columns=["database", "decision", "reason", "included_waves", "country"],
    )
    screening.to_csv(RES / "附表数据" / "数据库筛选.csv", index=False, encoding="utf-8-sig")
    hrs_src = BASE / "H_multi_country" / "44_hrs_delta.csv"
    if hrs_src.exists():
        pd.read_csv(hrs_src).to_csv(
            RES / "机制与稳健性" / "HRS纵向验证.csv", index=False, encoding="utf-8-sig"
        )

    print(f"Cross-sectional waves: {len(t)}; primary analysis records: {t.n.sum():,}")
    print(f"Flow source records: {fl.eligible_source_records.sum():,}; paired: {fl.paired_outcomes.sum():,}")
    print(summary.round(4).to_string(index=False))
    print(reg.round(4).to_string(index=False))
    print(los.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
