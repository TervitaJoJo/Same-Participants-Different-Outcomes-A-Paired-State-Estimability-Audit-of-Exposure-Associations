"""Bayesian hierarchical meta-analysis of adjusted paired Delta estimates.

The likelihood uses the adjusted Delta and its paired-bootstrap standard error,
not crude 2x2 odds ratios.  The two measurement-process predictors are fitted
on the same log-odds scale as Delta: among measured-positive participants the
exposure coefficient describes differential diagnosis, and among
measured-negative participants it describes differential self-reporting.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import numpyro
import numpyro.distributions as dist
import pandas as pd
import statsmodels.api as sm
from numpyro.diagnostics import summary
from numpyro.infer import MCMC, NUTS


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data"
RES = ROOT / "results"
SEED = 20260916
WARMUP = int(os.environ.get("BAYES_WARMUP", "1200"))
SAMPLES = int(os.environ.get("BAYES_SAMPLES", "1200"))
CHAINS = int(os.environ.get("BAYES_CHAINS", "4"))


def logor(d: pd.DataFrame, y: str, exposure: str, cov: list[str]) -> float:
    m = d[[y, exposure] + cov].dropna()
    if len(m) < 80 or m[y].nunique() < 2 or m[exposure].nunique() < 2:
        return np.nan
    active = [c for c in cov if m[c].nunique() > 1]
    X = sm.add_constant(m[[exposure] + active].astype(float), has_constant="add")
    try:
        return float(
            sm.GLM(m[y].astype(float), X, family=sm.families.Binomial())
            .fit()
            .params[exposure]
        )
    except Exception:
        return np.nan


def mechanism_table(exposure: str) -> pd.DataFrame:
    p = pd.read_csv(DATA / "panel_diseases_bmi.csv", low_memory=False)
    if exposure == "obese":
        p = p[p.bmi.notna()].copy()
        p["obese"] = (p.bmi >= 30).astype(float)
        est = pd.read_csv(RES / "主结果" / "obesity_delta_bootstrap.csv")
    else:
        est = pd.read_csv(RES / "主结果" / "disease_delta_bootstrap.csv")
    rows = []
    for (ds, dis), g in p.groupby(["dataset", "disease"], sort=True):
        e = est[(est.dataset == ds) & (est.disease == dis)]
        if e.empty:
            continue
        g = g.dropna(subset=["M", "S", exposure, "age", "male", "edu"]).copy()
        if len(g) < 300:
            continue
        se_lor = logor(g[g.M == 1], "S", exposure, ["age", "male", "edu"])
        fp_lor = logor(g[g.M == 0], "S", exposure, ["age", "male", "edu"])
        q = e.iloc[0]
        rows.append(
            {
                "dataset": ds,
                "country": q.country,
                "disease": dis,
                "exposure": exposure,
                "n": int(q.n),
                "delta": float(q.delta),
                "delta_se": float(q.delta_se),
                "delta_lo": float(q.delta_lo),
                "delta_hi": float(q.delta_hi),
                "diagnosis_logor_Mpos": se_lor,
                "falsepositive_logor_Mneg": fp_lor,
            }
        )
    return pd.DataFrame(rows)


def model(y, se, g1, g0, dataset_id, disease_id, country_id, nd, ndis, ncty):
    alpha = numpyro.sample("alpha", dist.Normal(0.0, 0.5))
    b_g1 = numpyro.sample("b_g1", dist.Normal(0.0, 1.0))
    b_g0 = numpyro.sample("b_g0", dist.Normal(0.0, 1.0))
    d_eff = numpyro.sample("d_eff", dist.Normal(0.0, 0.30).expand([ndis - 1]))
    c_eff = numpyro.sample("c_eff", dist.Normal(0.0, 0.30).expand([ncty - 1]))
    sd_dataset = numpyro.sample("sd_dataset", dist.HalfNormal(0.30))
    sd_cell = numpyro.sample("sd_cell", dist.HalfNormal(0.30))
    with numpyro.plate("datasets", nd):
        z_dataset = numpyro.sample("z_dataset", dist.Normal(0.0, 1.0))
    with numpyro.plate("cells", len(y)):
        z_cell = numpyro.sample("z_cell", dist.Normal(0.0, 1.0))
    de = jnp.where(disease_id == 0, 0.0, d_eff[disease_id - 1])
    ce = jnp.where(country_id == 0, 0.0, c_eff[country_id - 1])
    theta = (
        alpha
        + b_g1 * g1
        + b_g0 * g0
        + de
        + ce
        + sd_dataset * z_dataset[dataset_id]
        + sd_cell * z_cell
    )
    numpyro.sample("obs", dist.Normal(theta, se), obs=y)
    numpyro.deterministic("theta", theta)


def run_one(t: pd.DataFrame, tag: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    t = t.dropna(subset=["diagnosis_logor_Mpos", "falsepositive_logor_Mneg"]).reset_index(drop=True)
    datasets = sorted(t.dataset.unique())
    diseases = sorted(t.disease.unique())
    countries = sorted(t.country.unique())
    dmap = {x: i for i, x in enumerate(datasets)}
    dismap = {x: i for i, x in enumerate(diseases)}
    cmap = {x: i for i, x in enumerate(countries)}
    g1_mean, g0_mean = t.diagnosis_logor_Mpos.mean(), t.falsepositive_logor_Mneg.mean()
    args = dict(
        y=jnp.asarray(t.delta.to_numpy(float)),
        se=jnp.asarray(t.delta_se.to_numpy(float)),
        g1=jnp.asarray((t.diagnosis_logor_Mpos - g1_mean).to_numpy(float)),
        g0=jnp.asarray((t.falsepositive_logor_Mneg - g0_mean).to_numpy(float)),
        dataset_id=jnp.asarray(t.dataset.map(dmap).to_numpy(int)),
        disease_id=jnp.asarray(t.disease.map(dismap).to_numpy(int)),
        country_id=jnp.asarray(t.country.map(cmap).to_numpy(int)),
        nd=len(datasets),
        ndis=len(diseases),
        ncty=len(countries),
    )
    t0 = time.time()
    mcmc = MCMC(
        NUTS(model, target_accept_prob=0.92),
        num_warmup=WARMUP,
        num_samples=SAMPLES,
        num_chains=CHAINS,
        chain_method="parallel" if CHAINS > 1 else "sequential",
        progress_bar=False,
    )
    mcmc.run(jax.random.PRNGKey(SEED + (1 if tag == "obesity" else 0)), **args)
    st = summary(mcmc.get_samples(group_by_chain=True), prob=0.95)
    max_rhat = max(float(np.max(v["r_hat"])) for v in st.values())
    min_ess = min(float(np.min(v["n_eff"])) for v in st.values())
    divergences = int(np.sum(mcmc.get_extra_fields()["diverging"]))
    s = mcmc.get_samples()
    theta = np.asarray(s["theta"])
    t["delta_post"] = theta.mean(axis=0)
    t["delta_post_lo"] = np.percentile(theta, 2.5, axis=0)
    t["delta_post_hi"] = np.percentile(theta, 97.5, axis=0)
    t["p_delta_gt0"] = (theta > 0).mean(axis=0)
    rows = []
    for name in ("alpha", "b_g1", "b_g0", "sd_dataset", "sd_cell"):
        v = np.asarray(s[name]).reshape(-1)
        rows.append(
            {
                "exposure": tag,
                "parameter": name,
                "posterior_median": np.median(v),
                "posterior_mean": np.mean(v),
                "lo": np.percentile(v, 2.5),
                "hi": np.percentile(v, 97.5),
                "p_gt_0": np.mean(v > 0),
                "max_rhat": max_rhat,
                "min_ess": min_ess,
                "divergences": divergences,
                "seconds": time.time() - t0,
                "cells": len(t),
            }
        )
    return t, pd.DataFrame(rows)


def main() -> None:
    cell_rows, summaries = [], []
    for exposure, tag in (("smoke", "smoking"), ("obese", "obesity")):
        t = mechanism_table(exposure)
        t.to_csv(
            RES / "机制与稳健性" / f"机制同尺度_{tag}.csv",
            index=False,
            encoding="utf-8-sig",
        )
        post, summ = run_one(t, tag)
        cell_rows.append(post)
        summaries.append(summ)
        print(tag, summ.round(4).to_string(index=False))
    pd.concat(cell_rows, ignore_index=True).to_csv(
        RES / "主结果" / "贝叶斯分层_校正Delta.csv", index=False, encoding="utf-8-sig"
    )
    pd.concat(summaries, ignore_index=True).to_csv(
        RES / "主结果" / "贝叶斯分层_汇总.csv", index=False, encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()
