"""Model-based potential impact fractions under the two outcome definitions.

For each cohort-disease cell, an adjusted logistic model is fitted for obesity,
age, sex and education.  Risks are predicted under the observed exposure and
under the counterfactual intervention BMI<30 for everyone.  The resulting
quantity is reported as a model-based potential impact fraction (PIF), not as a
causal PAF and not as DALYs.
"""

from __future__ import annotations

import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "panel_diseases_bmi.csv"
RES = ROOT / "results"
B = int(os.environ.get("GCOMP_BOOT", "200"))
SEED = 20260916


def design(d: pd.DataFrame, force_unexposed: bool = False) -> np.ndarray:
    age = (d.age.to_numpy(float) - 60.0) / 10.0
    edu = d.edu.to_numpy(float)
    edu = (edu - np.mean(edu)) / (np.std(edu) + 1e-9)
    obese = np.zeros(len(d)) if force_unexposed else d.obese.to_numpy(float)
    return np.column_stack([np.ones(len(d)), obese, age, d.male.to_numpy(float), edu])


def estimate(d: pd.DataFrame, y: str) -> tuple[float, float]:
    X = design(d)
    fit = sm.GLM(d[y].to_numpy(float), X, family=sm.families.Binomial()).fit(maxiter=60)
    risk_obs = fit.predict(X)
    risk_cf = fit.predict(design(d, force_unexposed=True))
    mean_obs = float(np.mean(risk_obs))
    mean_cf = float(np.mean(risk_cf))
    return 1 - mean_cf / mean_obs, (mean_obs - mean_cf) * 100000


def one_cell(job: tuple) -> tuple[dict, dict[str, np.ndarray]]:
    dataset, country, disease, records, seed = job
    d = pd.DataFrame(records).dropna().copy()
    d["obese"] = (d.bmi >= 30).astype(float)
    point = {}
    for y, tag in (("M", "m"), ("S", "s")):
        point[f"pif_{tag}"], point[f"cases_{tag}"] = estimate(d, y)
    rng = np.random.default_rng(seed)
    draws = {"pif_m": [], "pif_s": [], "cases_m": [], "cases_s": []}
    idx = np.arange(len(d))
    for _ in range(B):
        b = d.iloc[rng.choice(idx, size=len(idx), replace=True)].reset_index(drop=True)
        try:
            for y, tag in (("M", "m"), ("S", "s")):
                pif, cases = estimate(b, y)
                draws[f"pif_{tag}"].append(pif)
                draws[f"cases_{tag}"].append(cases)
        except Exception:
            continue
    draws = {k: np.asarray(v, float) for k, v in draws.items()}
    rec = {
        "dataset": dataset,
        "country": country,
        "disease": disease,
        "n": len(d),
        "obesity_prevalence": float(d.obese.mean()),
        "measured_prevalence": float(d.M.mean()),
        "selfreport_prevalence": float(d.S.mean()),
        "bootstrap_ok": min(len(x) for x in draws.values()),
    }
    for key, value in point.items():
        rec[key] = value
        rec[f"{key}_lo"] = float(np.percentile(draws[key], 2.5))
        rec[f"{key}_hi"] = float(np.percentile(draws[key], 97.5))
    rec["pif_ratio"] = rec["pif_s"] / rec["pif_m"] if abs(rec["pif_m"]) > 1e-9 else np.nan
    rec["cases_difference"] = rec["cases_s"] - rec["cases_m"]
    return rec, draws


def main() -> None:
    p = pd.read_csv(DATA, low_memory=False)
    p = p[p.disease.isin(["hypertension", "diabetes"]) & p.bmi.notna()].copy()
    p = p.dropna(subset=["M", "S", "bmi", "age", "male", "edu"])
    jobs = []
    for i, ((ds, dis), g) in enumerate(p.groupby(["dataset", "disease"], sort=True)):
        cols = ["M", "S", "bmi", "age", "male", "edu"]
        jobs.append((ds, g.country.iloc[0], dis, g[cols].to_dict("records"), SEED + i))
    rows, draw_bank = [], {}
    t0 = time.time()
    workers = min(6, os.cpu_count() or 2)
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(one_cell, j): (j[0], j[2]) for j in jobs}
        for i, f in enumerate(as_completed(futures), 1):
            rec, draws = f.result()
            rows.append(rec)
            draw_bank[(rec["dataset"], rec["disease"])] = draws
            print(f"[{i:02d}/{len(jobs)}] {rec['dataset']} {rec['disease']} B={rec['bootstrap_ok']}")
    cell = pd.DataFrame(rows).sort_values(["country", "disease", "dataset"])
    cell.to_csv(
        RES / "机制与稳健性" / "负担模块_g计算_逐分析集.csv",
        index=False,
        encoding="utf-8-sig",
    )

    pooled = []
    for (country, disease), g in cell.groupby(["country", "disease"], sort=True):
        weights = g.n.to_numpy(float)
        weights /= weights.sum()
        rec = {
            "country": country,
            "disease": disease,
            "datasets": len(g),
            "n": int(g.n.sum()),
        }
        for key in ("pif_m", "pif_s", "cases_m", "cases_s"):
            point = float(np.average(g[key], weights=weights))
            arrays = []
            for r in g.itertuples():
                arrays.append(draw_bank[(r.dataset, r.disease)][key][:B])
            mat = np.vstack(arrays)
            agg = np.average(mat, axis=0, weights=weights)
            rec[key] = point
            rec[f"{key}_lo"] = float(np.percentile(agg, 2.5))
            rec[f"{key}_hi"] = float(np.percentile(agg, 97.5))
        rec["pif_ratio"] = rec["pif_s"] / rec["pif_m"]
        rec["cases_difference"] = rec["cases_s"] - rec["cases_m"]
        pooled.append(rec)
    out = pd.DataFrame(pooled)
    out["rank_pif_m"] = out.pif_m.rank(ascending=False).astype(int)
    out["rank_pif_s"] = out.pif_s.rank(ascending=False).astype(int)
    out["rank_change"] = out.rank_pif_m - out.rank_pif_s
    out.to_csv(RES / "主结果" / "负担模块_g计算_国家疾病.csv", index=False, encoding="utf-8-sig")
    rho = out.pif_m.rank().corr(out.pif_s.rank(), method="spearman")
    print(f"Completed {len(cell)} cells in {time.time()-t0:.1f}s")
    print(out.round(4).to_string(index=False))
    print(
        f"Median PIF ratio={out.pif_ratio.median():.3f}; "
        f"rank changes={(out.rank_pif_m != out.rank_pif_s).sum()}/{len(out)}; "
        f"Spearman={rho:.3f}"
    )


if __name__ == "__main__":
    main()
