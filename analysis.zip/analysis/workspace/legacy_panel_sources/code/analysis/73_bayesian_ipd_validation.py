# Bayesian hierarchical IPD model of the misclassification process.
#
# The two-step analysis (fit two logistic regressions per cell, then a
# DerSimonian-Laird meta-regression on the difference) has three weaknesses:
# sparse cells drive the heterogeneity, the sensitivity gap is treated as known,
# and the intervals come from a resampling approximation.  This model replaces
# the whole thing with one joint likelihood per person.
#
# Each person contributes one of four states, (measured, self-report) equal to
# (0,0), (1,0), (0,1) or (1,1).  Under the mixture structure those four
# probabilities are determined by three latent quantities:
#
#   measured-reference disease logit p = a_c + b_c E + beta X
#   sensitivity    logit Se  = s_c + g_c E
#   specificity    logit Sp  = t_c + h_c E
#
# so the likelihood is Categorical over the four states.  Delta is not a model
# parameter: it is derived from (p, Se, Sp) after the fact, which is why the
# model can be asked the question the paper is about.
#
# Hierarchy: every coefficient is drawn from a normal distribution across cells.
# The spread of g (the exposure effect on sensitivity) is the direct answer to
# whether misclassification parameters are transportable.

from __future__ import annotations

import sys
import time
import warnings
import os
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import jax  # noqa: E402
import jax.numpy as jnp  # noqa: E402
import numpyro  # noqa: E402
import numpyro.distributions as dist  # noqa: E402
from numpyro.infer import MCMC, NUTS  # noqa: E402
from numpyro.infer.initialization import init_to_value  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "panel_diseases_bmi.csv"
RES = ROOT / "results"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# Configuration is read from the environment so the same script can be run in a
# quick screening mode and in the production mode that produced the manuscript.
WARMUP = int(os.environ.get("BAYES_WARMUP", "600"))
SAMPLES = int(os.environ.get("BAYES_SAMPLES", "600"))
CHAINS = int(os.environ.get("BAYES_CHAINS", "2"))
CAP = int(os.environ.get("BAYES_CAP", "0"))      # 0 = use every row
SEED = 20260915


def build_cells() -> list[dict]:
    p = pd.read_csv(DATA, low_memory=False)
    p = p[p["bmi"].notna()].copy()
    p["obese"] = (p["bmi"] >= 30).astype(float)
    p = p.dropna(subset=["M", "S", "obese", "age", "male", "edu"])
    cells = []
    rng = np.random.default_rng(SEED)
    for (ds, dis), g in p.groupby(["dataset", "disease"], sort=True):
        if len(g) < 300 or g["obese"].nunique() < 2:
            continue
        if CAP and len(g) > CAP:
            g = g.iloc[rng.choice(len(g), CAP, replace=False)]
        # state encoding: 0=(M0,S0) 1=(M0,S1) 2=(M1,S0) 3=(M1,S1)
        st = (2 * g["M"].to_numpy().astype(int)
              + g["S"].to_numpy().astype(int)).astype(int)
        st = np.where(g["M"].to_numpy() == 1, 2 + g["S"].to_numpy().astype(int),
                      g["S"].to_numpy().astype(int))
        cells.append({
            "dataset": ds, "disease": dis,
            "country": g["country"].iloc[0],
            "n": len(g),
            "E": g["obese"].to_numpy(float),
            "M": g["M"].to_numpy(float),
            "S": g["S"].to_numpy(float),
            "age": ((g["age"].to_numpy(float) - 60.0) / 10.0),
            "male": g["male"].to_numpy(float),
            "edu": ((g["edu"].to_numpy(float)
                     - np.nanmean(p["edu"])) / (np.nanstd(p["edu"]) + 1e-9)),
            "state": st,
        })
    return cells


def model(cells):
    k = len(cells)
    mu_a = numpyro.sample("mu_a", dist.Normal(0.0, 2.0))
    sd_a = numpyro.sample("sd_a", dist.HalfNormal(1.5))
    mu_b = numpyro.sample("mu_b", dist.Normal(0.0, 1.0))
    sd_b = numpyro.sample("sd_b", dist.HalfNormal(0.8))
    mu_s = numpyro.sample("mu_s", dist.Normal(0.0, 1.5))
    sd_s = numpyro.sample("sd_s", dist.HalfNormal(1.0))
    mu_g = numpyro.sample("mu_g", dist.Normal(0.0, 1.0))
    sd_g = numpyro.sample("sd_g", dist.HalfNormal(0.8))
    mu_t = numpyro.sample("mu_t", dist.Normal(2.0, 1.5))
    sd_t = numpyro.sample("sd_t", dist.HalfNormal(1.0))
    mu_h = numpyro.sample("mu_h", dist.Normal(0.0, 1.0))
    sd_h = numpyro.sample("sd_h", dist.HalfNormal(0.8))

    beta = numpyro.sample("beta", dist.Normal(0.0, 0.5).expand([3]))

    # non-centred parameterisation
    with numpyro.plate("cell", k):
        za = numpyro.sample("za", dist.Normal(0.0, 1.0))
        zb = numpyro.sample("zb", dist.Normal(0.0, 1.0))
        zs = numpyro.sample("zs", dist.Normal(0.0, 1.0))
        zg = numpyro.sample("zg", dist.Normal(0.0, 1.0))
        zt = numpyro.sample("zt", dist.Normal(0.0, 1.0))
        zh = numpyro.sample("zh", dist.Normal(0.0, 1.0))
    a = mu_a + sd_a * za
    b = mu_b + sd_b * zb
    s = mu_s + sd_s * zs
    g = mu_g + sd_g * zg
    t = mu_t + sd_t * zt
    h = mu_h + sd_h * zh

    for c, cell in enumerate(cells):
        E = jnp.asarray(cell["E"])
        X = jnp.stack([jnp.asarray(cell["age"]), jnp.asarray(cell["male"]),
                       jnp.asarray(cell["edu"])], axis=-1)
        logit_p = a[c] + b[c] * E + X @ beta
        logit_se = s[c] + g[c] * E
        logit_sp = t[c] + h[c] * E
        p = jax.nn.sigmoid(logit_p)
        se = jax.nn.sigmoid(logit_se)
        sp = jax.nn.sigmoid(logit_sp)
        # For M=0, S=0 has probability specificity and S=1 has
        # probability 1-specificity.  Earlier exploratory code had these two
        # states reversed, which inverted the fitted self-report association.
        probs = jnp.stack([(1 - p) * sp, (1 - p) * (1 - sp),
                           p * (1 - se), p * se], axis=-1)
        probs = probs / probs.sum(axis=-1, keepdims=True)
        numpyro.sample(f"y_{c}", dist.Categorical(probs),
                       obs=jnp.asarray(cell["state"]))
    numpyro.deterministic("b_vec", b)
    numpyro.deterministic("g_vec", g)
    numpyro.deterministic("h_vec", h)
    numpyro.deterministic("a_vec", a)
    numpyro.deterministic("s_vec", s)
    numpyro.deterministic("t_vec", t)


def closed_form(cells: list[dict]) -> dict:
    """Start the chain where the data already put it.

    With two exposure groups and three latent quantities per group, p, Se and Sp
    are identified in closed form from the observed state frequencies.  Running
    NUTS from the prior instead (which is what produced n_eff of 13 and R-hat of
    1.13 on the first attempt) leaves it wandering in a region the data excludes.
    """
    a_hat, b_hat, s_hat, g_hat, t_hat, h_hat = [], [], [], [], [], []
    for cell in cells:
        E, M, S = cell["E"], cell["M"], cell["S"]
        pe, se_, sp_ = {}, {}, {}
        for e in (0, 1):
            m = E == e
            pm = float(M[m].mean())
            pos = m & (M == 1)
            neg = m & (M == 0)
            pe[e] = pm
            se_[e] = float(S[pos].mean()) if pos.sum() else 0.7
            sp_[e] = float(1 - S[neg].mean()) if neg.sum() else 0.9
        lg = lambda x: float(np.log(np.clip(x, 1e-3, 1 - 1e-3)
                                  / (1 - np.clip(x, 1e-3, 1 - 1e-3))))
        # the model's intercept is the e = 0 group, not the mean of the two
        # groups: getting this wrong starts the chain where the data are not
        a_hat.append(lg(pe[0]))
        b_hat.append(lg(pe[1]) - lg(pe[0]))
        s_hat.append(lg(se_[0]))
        g_hat.append(lg(se_[1]) - lg(se_[0]))
        t_hat.append(lg(sp_[0]))
        h_hat.append(lg(sp_[1]) - lg(sp_[0]))
    a_hat, b_hat = np.array(a_hat), np.array(b_hat)
    s_hat, g_hat = np.array(s_hat), np.array(g_hat)
    t_hat, h_hat = np.array(t_hat), np.array(h_hat)

    def pack(x, sd):
        mu = float(np.mean(x))
        sdv = max(float(np.std(x)), 0.05)
        return mu, sdv, (x - mu) / sdv

    init = {}
    for nm, arr in (("a", a_hat), ("b", b_hat), ("s", s_hat),
                    ("g", g_hat), ("t", t_hat), ("h", h_hat)):
        mu, sdv, z = pack(arr, None)
        init[f"mu_{nm}"] = jnp.array(mu)
        init[f"sd_{nm}"] = jnp.array(sdv)
        init[f"z{nm}"] = jnp.array(z)
    init["beta"] = jnp.zeros(3)
    return init


def derive_delta(draws: dict, cells: list[dict]) -> pd.DataFrame:
    """Delta is a function of (p, Se, Sp), so it is computed from the posterior."""
    rows = []
    a = draws["a_vec"]; b = draws["b_vec"]; s = draws["s_vec"]
    g = draws["g_vec"]; t = draws["t_vec"]; h = draws["h_vec"]
    beta = draws["beta"]
    n_draw = a.shape[0]
    for c, cell in enumerate(cells):
        E = cell["E"]
        X = np.stack([cell["age"], cell["male"], cell["edu"]], axis=-1)
        ex = np.stack([(E == 0), (E == 1)])
        out = []
        for e in (0, 1):
            m = (E == e)
            lp = a[:, c, None] + b[:, c, None] * e + (X[m] @ beta.T).T
            p = 1 / (1 + np.exp(-lp))
            se = 1 / (1 + np.exp(-(s[:, c, None] + g[:, c, None] * e)))
            sp = 1 / (1 + np.exp(-(t[:, c, None] + h[:, c, None] * e)))
            pm = p.mean(axis=1)
            out.append((pm, se.mean(axis=1), sp.mean(axis=1)))
        (p0, se0, sp0), (p1, se1, sp1) = out
        q0 = se0 * p0 + (1 - sp0) * (1 - p0)
        q1 = se1 * p1 + (1 - sp1) * (1 - p1)
        eps = 1e-9
        lom = np.log((p1 / (1 - p1 + eps) + eps) / (p0 / (1 - p0 + eps) + eps))
        los = np.log((q1 / (1 - q1 + eps) + eps) / (q0 / (1 - q0 + eps) + eps))
        delta = los - lom
        rows.append({
            "dataset": cell["dataset"], "country": cell["country"],
            "disease": cell["disease"], "n": cell["n"],
            "or_m_post": float(np.exp(lom).mean()),
            "or_s_post": float(np.exp(los).mean()),
            "delta_post": float(delta.mean()),
            "delta_lo": float(np.percentile(delta, 2.5)),
            "delta_hi": float(np.percentile(delta, 97.5)),
            "p_gt_0": float((delta > 0).mean()),
            "or_ratio": float((np.exp(los) / np.exp(lom)).mean()),
        })
    return pd.DataFrame(rows)


def main() -> None:
    cells = build_cells()
    print(f"cells: {len(cells)}   total rows: {sum(c['n'] for c in cells):,}")
    t0 = time.time()
    kernel = NUTS(model, target_accept_prob=0.9)
    init = closed_form(cells)
    kernel = NUTS(model, target_accept_prob=0.9,
                  init_strategy=init_to_value(values=init))
    mcmc = MCMC(kernel, num_warmup=WARMUP, num_samples=SAMPLES,
                num_chains=CHAINS, progress_bar=False,
                chain_method="parallel" if CHAINS > 1 else "sequential")
    mcmc.run(jax.random.PRNGKey(SEED), cells)
    print(f"  sampling finished in {time.time()-t0:.0f}s")
    try:
        from numpyro.diagnostics import summary as _summary
        st = _summary(mcmc.get_samples(group_by_chain=True), prob=0.95)
        rhs = [float(np.max(v["r_hat"])) for v in st.values()]
        ess = [float(np.min(v["n_eff"])) for v in st.values()]
        div = int(np.sum(mcmc.get_extra_fields()["diverging"]))
        print(f"  convergence: max r_hat = {max(rhs):.3f}   "
              f"min n_eff = {min(ess):.0f}   divergences = {div}")
        if max(rhs) > 1.05 or min(ess) < 100:
            print("  WARNING: convergence is not adequate; treat the posterior "
                  "as indicative only")
    except Exception as exc:  # noqa: BLE001
        print("  convergence diagnostics unavailable:", exc)

    draws = mcmc.get_samples()
    keep = ["mu_b", "sd_b", "mu_g", "sd_g", "mu_h", "sd_h", "beta"]
    post = {k: np.asarray(draws[k]) for k in keep}
    t = derive_delta(draws, cells)
    t.to_csv(RES / "主结果" / "bayesian_ipd_validation.csv", index=False,
             encoding="utf-8-sig")

    direct = pd.read_csv(RES / "主结果" / "obesity_delta_bootstrap.csv")
    chk = t.merge(
        direct[["dataset", "disease", "delta"]],
        on=["dataset", "disease"],
        how="left",
        suffixes=("_ipd", "_direct"),
    )
    chk["difference"] = chk["delta_post"] - chk["delta"]
    chk.to_csv(
        RES / "机制与稳健性" / "bayesian_ipd_vs_direct.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print()
    print("=" * 100)
    print("POSTERIOR OF THE DISPLACEMENT, OBESITY EXPOSURE")
    print("=" * 100)
    print(t[["dataset", "disease", "n", "or_m_post", "or_s_post",
             "delta_post", "delta_lo", "delta_hi", "or_ratio"]]
          .round(3).to_string(index=False))
    print()
    print("=" * 100)
    print("ARE THE MISCLASSIFICATION PARAMETERS TRANSPORTABLE?")
    print("=" * 100)
    for nm, key, lab in (("暴露对敏感度的影响 g", "sd_g", "sd(g)"),
                         ("暴露对特异度的影响 h", "sd_h", "sd(h)"),
                         ("暴露对真实患病的影响 b", "sd_b", "sd(b)")):
        v = post[key]
        print(f"  {nm:<24} {lab} 后验中位数 {np.median(v):.3f}  "
              f"95% 区间 {np.percentile(v, 2.5):.3f} – "
              f"{np.percentile(v, 97.5):.3f}")
    print(f"\n  posterior mean of Delta: {t['delta_post'].mean():+.4f}   "
          f"cells with P(Delta>0) > 0.975: "
          f"{int((t['p_gt_0'] > 0.975).sum())} / {len(t)}")
    print(f"  exponentiated ratio OR_self/OR_measured, median "
          f"{t['or_ratio'].median():.2f}")
    print(f"\nelapsed {time.time()-t0:.0f}s")
    print(f"  median |IPD - direct Delta|: {chk['difference'].abs().median():.3f}")
    print("wrote", RES / "主结果" / "bayesian_ipd_validation.csv")


if __name__ == "__main__":
    main()
