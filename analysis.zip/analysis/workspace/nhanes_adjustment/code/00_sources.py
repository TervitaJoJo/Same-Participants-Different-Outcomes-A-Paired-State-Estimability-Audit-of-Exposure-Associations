from pathlib import Path
import urllib.request,re,json,hashlib
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parents[1]
for name in ['sources','results','data','figures']:(ROOT/name).mkdir(exist_ok=True)
class Plain(HTMLParser):
    def __init__(self):super().__init__();self.parts=[]
    def handle_data(self,s):
        if s.strip():self.parts.append(s.strip())
records=[];excerpt=[]
for year,suf in [('2011','G'),('2013','H')]:
    for mod in ['DIQ','SMQ']:
        url=f'https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/{year}/DataFiles/{mod}_{suf}.htm'
        p=ROOT/'sources'/f'{mod}_{suf}.htm'
        if not p.exists():
            with urllib.request.urlopen(url,timeout=30) as r:b=r.read()
            assert b'SEQN' in b and f'{mod}_{suf}'.encode() in b;p.write_bytes(b)
        txt=p.read_text(encoding='utf-8-sig');parser=Plain();parser.feed(txt);plain='\n'.join(parser.parts)
        (p.with_suffix('.txt')).write_text(plain,encoding='utf-8')
        for v in (['DIQ050','DIQ065','DIQ070','DID040','DIQ160'] if mod=='DIQ' else ['SMQ050Q','SMQ050U','SMD055']):
            # Variable-section anchor, avoiding navigation occurrences.
            match=re.search(r'<div[^>]+class="pagebreak"[^>]*>\s*<h3[^>]+id="'+v+r'"',txt)
            pos=txt.find('id="'+v+'"')
            end=txt.find('<div class="pagebreak">',pos+1)
            section=txt[pos:end if end>pos else pos+6500]
            pp=Plain();pp.feed(section);excerpt.append(f'{year} {v}\n'+ '\n'.join(pp.parts))
        records.append(dict(url=url,path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ROOT/'sources/nhanes_variable_excerpts.txt').write_text('\n\n'.join(excerpt),encoding='utf-8')
(ROOT/'results/official_sources.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
import pymupdf
for filename,needles,outfile in [('CHARLS_2018_Household_Questionnaire.pdf',['da061_w4','da062'],'charls2018_smoking_questionnaire.txt'),('CHARLS_2018_Codebook.pdf',['da062:','da062_1:','da062_2:'],'charls2018_quit_codebook.txt')]:
    doc=pymupdf.open(ROOT.parent/'CHARLS/2018'/filename);out=[]
    for i,page in enumerate(doc):
        t=page.get_text()
        if any(x in t.lower() for x in needles):out.append(f'PDF page {i+1}\n'+t)
    (ROOT/'sources'/outfile).write_text('\n\n'.join(out),encoding='utf-8');doc.close()
print('\n\n'.join(excerpt))
