from common import *
import pyreadstat
SOURCES=set();DICT=[];AUDIT=[]
def csv(p,**kw):SOURCES.add(p);return pd.read_csv(p,low_memory=False,**kw)
def raw(p,cols):
    SOURCES.add(p);func=pyreadstat.read_xport if p.suffix=='.xpt' else pyreadstat.read_dta
    d,m=func(str(p),usecols=cols)
    for c in d:DICT.append(dict(file=str(p.relative_to(BASE)),variable=c,label=m.column_names_to_labels.get(c),value_labels=json.dumps(m.variable_value_labels.get(c),ensure_ascii=False)))
    return d
def main():
    nh=csv(BASE/'mechanism_linkage_20260917/data/person_linked.csv.gz');extras=[]
    for cy,suf in [('2011-2012','G'),('2013-2014','H')]:
        a=raw(BASE/'NHANES'/cy/f'DIQ_{suf}.xpt',['SEQN','DIQ010','DIQ160','DIQ050','DIQ070','DID040'])
        b=raw(BASE/'NHANES'/cy/f'SMQ_{suf}.xpt',['SEQN','SMQ020','SMQ040','SMQ050Q','SMQ050U','SMD055'])
        z=a.merge(b,on='SEQN',how='outer',validate='one_to_one');z['uid']=cy+':'+z.SEQN.astype(int).astype(str)
        z=z.drop(columns=['SEQN','DIQ010','SMQ020','SMQ040']);extras.append(z)
    nh=nh.merge(pd.concat(extras),on='uid',how='left',validate='one_to_one')
    ins=nh.DIQ050.map({1:1.,2:0.});pill=nh.DIQ070.map({1:1.,2:0.})
    structural=nh.DIQ010.eq(2)&nh.DIQ160.eq(2)&nh.DIQ070.isna()
    pill.loc[structural]=0
    nh['med']=np.select([ins.eq(1)|pill.eq(1),ins.eq(0)&pill.eq(0)],[1.,0.],default=np.nan)
    nh['pill_structural_skip']=structural
    q=nh.SMQ050Q.where(nh.SMQ050Q.between(1,366));unit=nh.SMQ050U.map({1:1/365.25,2:7/365.25,3:1/12,4:1})
    years=q*unit;years=years.where(years.le(nh.age)&nh.smoke_status.eq(1))
    nh['quit_years']=years;nh['quit_topcode']=nh.SMQ050Q.eq(66666)&nh.smoke_status.eq(1)
    nh['smoke_duration']=np.select([nh.smoke_status.eq(0),nh.smoke_status.eq(2),years.lt(5),years.ge(5)|nh.quit_topcode,nh.smoke_status.eq(1)],[0.,1.,2.,3.,4.],default=np.nan)
    nh['ever']=nh.smoke_status.gt(0).astype(float).where(nh.smoke_status.notna())
    nh['diagnosis_age']=nh.DID040.where(nh.DID040.between(1,79)&nh.DID040.le(nh.age)&nh.S_dm.eq(1))
    nh.loc[nh.DID040.eq(666)&nh.S_dm.eq(1),'diagnosis_age']=.5
    nh['quit_age_derived']=nh.age-years
    nh['last_regular_age']=nh.SMD055.where(nh.SMD055.between(1,79)&nh.SMD055.le(nh.age)&nh.smoke_status.eq(1))
    for agecol,name in [('quit_age_derived','order_quit'),('last_regular_age','order_regular')]:
        diff=nh[agecol]-nh.diagnosis_age
        nh[name]=np.select([diff.ge(2),diff.le(-2),diff.notna()],['diagnosis_before_quit','quit_before_diagnosis','within_2y_uncertain'],default='unknown_invalid')
    nh.to_csv(ROOT/'data/nhanes_person.csv.gz',index=False)
    old=csv(BASE/'mechanism_linkage_20260917/data/disease_panel.csv.gz');panels=[];flows=[]
    for definition in ['primary','hba1c_only']:
        z=old[(old.disease=='diabetes')&(old.definition==definition)].copy()
        z=z.merge(nh[['uid',*list(pd.concat(extras).columns.drop('uid')),'med','pill_structural_skip','quit_years','quit_topcode','smoke_duration','ever','diagnosis_age','quit_age_derived','last_regular_age','order_quit','order_regular']],on='uid',validate='one_to_one')
        z['MT']=np.select([z.M.eq(1)|z.med.eq(1),z.M.eq(0)&z.med.eq(0)],[1.,0.],default=np.nan)
        z['MT_strict']=np.select([z.M.eq(1)|(z.S.eq(1)&z.med.eq(1)),z.M.eq(0)&(z.med.eq(0)|z.S.eq(0))],[1.,0.],default=np.nan)
        z['complete']=z[['bmi','income_ratio','med']].notna().all(axis=1)
        assert z.bmi.dropna().between(10,70).all() and z.income_ratio.dropna().between(0,5).all()
        for step,q in [('round5',z),('BMI_known',z[z.bmi.notna()]),('BMI_income_known',z.dropna(subset=['bmi','income_ratio'])),('all_known',z[z.complete])]:
            flows.append(dict(definition=definition,step=step,n=len(q),M_n=int(q.M.sum()),S_n=int(q.S.sum()),med_n=int(q.med.sum()),MT_n=int(q.MT.sum())))
        panels.append(z)
        for smoke,g in z.groupby('smoke_status'):
            AUDIT.append(dict(dataset='NHANES',definition=definition,check='complete_by_smoking',group=smoke,n=len(g),complete=int(g.complete.sum()),bmi_missing=int(g.bmi.isna().sum()),income_missing=int(g.income_ratio.isna().sum()),med_missing=int(g.med.isna().sum())))
    pd.concat(panels,ignore_index=True).to_csv(ROOT/'data/nhanes_panel.csv.gz',index=False);save(flows,'nhanes_sample_flow.csv')
    # New 2015 landmark with a distinct later outcome in 2018.
    p=csv(BASE/'mechanism_healthcare_20260917/data/prospective_screening.csv.gz');p=p[p.disease=='hypertension'].copy()
    b=csv(BASE/'paired_state_core/data/longitudinal.csv.gz',dtype={'ID':'string','ID_followup':'string'})
    p=p.merge(b[['uid','ID','ID_followup']],on='uid',validate='one_to_one')
    assert (p.ID.str[:9]+p.ID.str[9:].str.zfill(3)).eq(p.ID_followup).all()
    h=raw(BASE/'CHARLS/2018/Health_Status_and_Functioning.dta',['ID','da059','da061','da061_w4','da062','da062_1','da062_2'])
    h.ID=h.ID.astype(str).str.strip();assert h.ID.is_unique
    yes=h.da061.eq(1)|h.da061_w4.eq(1);quit=h.da061.eq(2)|h.da061_w4.eq(2);never=h.da059.eq(2)|h.da061_w4.eq(3)
    conflict=(yes&quit)|((yes|quit)&never)
    h['quit2018']=np.select([conflict,quit,yes],[np.nan,1.,0.],default=np.nan)
    h['never2018']=never;h['smoking_conflict2018']=conflict;h['interview2018']=1
    h['current2018_audit']=np.select([conflict,yes,quit|never],[np.nan,1.,0.],default=np.nan)
    h['quit_year2018']=h.da062_1.where(h.da062.eq(1)&h.da062_1.between(1900,2018))
    h['quit_age2018']=h.da062_2.where(h.da062.eq(2)&h.da062_2.between(1,110))
    h=h.rename(columns={'ID':'ID_followup'})
    ss=raw(BASE/'CHARLS/2018/Sample_Infor.dta',['ID','died','iyear','imonth']).rename(columns={'ID':'ID_followup','died':'died2018','iyear':'year2018','imonth':'month2018'})
    for c in ['died2018','year2018','month2018']:ss[c]=pd.to_numeric(ss[c],errors='coerce')
    hh=raw(BASE/'CHARLS/Harmonized_CHARLS/H_CHARLS_D_Data.dta',['ID','r4iwstat','r4iwy','r4iwm','r4smoken']).rename(columns={'ID':'ID_followup'})
    for c in hh.columns[1:]:hh[c]=pd.to_numeric(hh[c],errors='coerce')
    joined=h.merge(hh,on='ID_followup',how='inner',validate='one_to_one');known=joined[['current2018_audit','r4smoken']].notna().all(axis=1)
    different=int((joined.loc[known,'current2018_audit']!=joined.loc[known,'r4smoken']).sum())
    AUDIT.append(dict(dataset='CHARLS',check='2018_smoking_vs_harmonized',n=int(known.sum()),different=different));assert different==0
    p=p.merge(h,on='ID_followup',how='left',validate='one_to_one').merge(ss,on='ID_followup',how='left',validate='one_to_one').merge(hh,on='ID_followup',how='left',validate='one_to_one')
    dead=p.died2018.eq(1)|p.r4iwstat.isin([5,6]);alive=p.died2018.eq(0)|p.r4iwstat.isin([1,4])|p.interview2018.eq(1)
    p['vital2018']=np.select([dead&alive,dead,alive],['conflict','dead','alive'],default='unknown')
    p['age2015']=p.age+p.r3iwy-p.r1iwy;p['E']=p.new_diagnosis
    p['quit_time2018']=np.select([~p.quit2018.eq(1),p.quit_year2018.lt(p.r3iwy),p.quit_year2018.eq(p.r3iwy),p.quit_year2018.gt(p.year2018),p.quit_year2018.gt(p.r3iwy)&p.quit_year2018.le(p.year2018),p.quit_age2018.notna()],['not_quitter','before_landmark','same_year','after_followup','strictly_after_landmark','age_only'],default='unknown')
    hc=csv(BASE/'mechanism_healthcare_20260917/data/healthcare_long.csv.gz');hc=hc[hc.year==2015][['uid','outpatient_raw','hospital_raw','exam_recent']].rename(columns={x:x+'_2015' for x in ['outpatient_raw','hospital_raw','exam_recent']})
    p=p.merge(hc,on='uid',how='left',validate='one_to_one')
    p.to_csv(ROOT/'data/charls_landmark_source.csv.gz',index=False)
    cf=[]
    for step in ['prior_undiagnosed','diagnosis2015_known','current2015','age50_79','covariates_complete']:
        if step=='diagnosis2015_known':p=p[p.E.notna()]
        elif step=='current2015':p=p[p.smoke_status_2015.eq(2)]
        elif step=='age50_79':p=p[p.age2015.between(50,79)]
        elif step=='covariates_complete':p=p.dropna(subset=['male','edu3','public_insurance','rural_hukou','cluster'])
        cf.append(dict(step=step,n=len(p),new_diagnosis=int(p.E.eq(1).sum()),quit_known=int(p.quit2018.notna().sum()),quit_n=int(p.quit2018.sum())))
    p.to_csv(ROOT/'data/charls_landmark.csv.gz',index=False);save(cf,'charls_sample_flow.csv');save(AUDIT,'coding_audit.csv');save(DICT,'variable_dictionary.csv')
    SOURCES.update([BASE/'nhanes_robustness/code/common.py',BASE/'CHARLS/Harmonized_CHARLS/H_CHARLS_D_do_file.do',BASE/'CHARLS/2018/CHARLS_2018_Codebook.pdf',BASE/'CHARLS/2018/CHARLS_2018_Household_Questionnaire.pdf'])
    for prevdir in ['mechanism_linkage_20260917','nhanes_robustness']:
        f=BASE/prevdir/'results/output_manifest.json';SOURCES.add(f)
    (RES/'input_manifest.json').write_text(json.dumps([dict(path=str(f.relative_to(BASE)),sha256=sha(f),bytes=f.stat().st_size) for f in sorted(SOURCES)],indent=2),encoding='utf-8')
    import statsmodels,scipy,matplotlib
    (RES/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,statsmodels=statsmodels.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,pyreadstat=pyreadstat.__version__),indent=2),encoding='utf-8')
    print(pd.DataFrame(flows).to_string(index=False));print(pd.DataFrame(cf).to_string(index=False));print('BUILD COMPLETE')
if __name__=='__main__':main()
