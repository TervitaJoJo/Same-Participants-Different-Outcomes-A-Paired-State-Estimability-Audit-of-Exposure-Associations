from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def main():
    p=pd.read_csv(ROOT/'data/nhanes_panel.csv.gz',low_memory=False);rows=[];cells=[];orders=[];joint=[]
    for (definition,smoke),z in p.groupby(['definition','smoke_status']):
        for target,g in [('round5',z),('complete',z[z.complete])]:
            w=g.analysis_weight.to_numpy();ws=w.sum()
            for col in ['age','bmi','income_ratio','male','M','S','med','MT','complete']:
                obs=g[col].notna();x=g.loc[obs,col].to_numpy(float);ww=w[obs]
                rows.append(dict(definition=definition,smoke_status=smoke,target=target,variable=col,n=len(g),missing=int((~obs).sum()),mean=float(x.mean()),sd=float(x.std(ddof=1)),median=float(np.median(x)),weighted_mean=float(np.average(x,weights=ww)),min=float(x.min()),max=float(x.max()),effective_n=float(ww.sum()**2/(ww@ww))))
        g=z[z.complete]
        for (m,s,t),a in g.groupby(['M','S','med']):joint.append(dict(definition=definition,smoke_status=smoke,M=m,S=s,med=t,n=len(a),weighted_fraction=float(a.analysis_weight.sum()/g.analysis_weight.sum())))
    for definition,g in p[p.complete].groupby('definition'):
        for exposure in ['smoke_status','smoke_duration']:
            for lev,z in g.groupby(exposure):
                for y in ['M','S','MT']:
                    cells.append(dict(definition=definition,exposure=exposure,level=lev,outcome=y,n=len(z),events=int(z[y].sum()),non_events=int((1-z[y]).sum()),weighted_prevalence=float(np.average(z[y],weights=z.analysis_weight))))
        former=g[g.smoke_status.eq(1)&g.S.eq(1)]
        for order in ['order_quit','order_regular']:
            for cl,z in former.groupby(order):orders.append(dict(definition=definition,method=order,classification=cl,n=len(z),total=len(former),weighted_fraction=float(z.analysis_weight.sum()/former.analysis_weight.sum())))
    save(rows,'nhanes_descriptives.csv');save(joint,'nhanes_joint_states.csv');save(cells,'nhanes_support_cells.csv');save(orders,'nhanes_recalled_order.csv')
    c=pd.read_csv(ROOT/'data/charls_landmark.csv.gz');cf=[];ct=[];routes=[]
    for (ex,state),z in c.groupby(['E','vital2018']):
        cf.append(dict(E=ex,vital=state,n=len(z),observed=int(z.quit2018.notna().sum()),quit_n=int(z.quit2018.sum()),still_n=int(z.quit2018.eq(0).sum()),never_conflict=int(z.never2018.fillna(False).sum())))
    for ex,z in c.groupby('E'):
        for time,a in z[z.quit2018.eq(1)].groupby('quit_time2018'):ct.append(dict(E=ex,time_class=time,n=len(a)))
    for route,z in c[c.E.eq(1)].groupby('diagnosis_route',dropna=False):routes.append(dict(route=route,n=len(z)))
    save(cf,'charls_survival_flow.csv');save(ct,'charls_quit_time.csv');save(routes,'charls_diagnosis_routes.csv')
    plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
    g=p[p.definition.eq('primary')&p.complete];fig,axs=plt.subplots(1,2,figsize=(10,3.7))
    for ax,col,bins,label in zip(axs,['bmi','income_ratio'],[np.arange(10,72,2),np.arange(0,5.51,.5)],['Body mass index','Family income / poverty threshold']):
        for value,name,color in [(0,'Never','#0072B2'),(1,'Former','#009E73'),(2,'Current','#D55E00')]:
            z=g[g.smoke_status.eq(value)];ax.hist(z[col],bins=bins,weights=z.analysis_weight/z.analysis_weight.sum(),histtype='step',lw=1.7,label=name,color=color)
        ax.set_xlabel(label);ax.set_ylabel('Weighted fraction in bin');ax.legend(frameon=False)
    fig.suptitle('NHANES diabetes analysis: covariate distributions',weight='bold')
    fig.tight_layout();fig.savefig(ROOT/'figures/00_covariates.png',dpi=180);plt.close(fig)
    print('NHANES support',pd.DataFrame(cells).query("definition=='primary' and outcome=='M'").to_string(index=False));print(pd.DataFrame(cf).to_string(index=False));print(pd.DataFrame(ct).to_string(index=False))
if __name__=='__main__':main()
