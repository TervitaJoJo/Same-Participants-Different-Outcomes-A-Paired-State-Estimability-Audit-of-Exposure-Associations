from common import *
from statsmodels.stats.multitest import multipletests
BASEFORM='C(smoke_status)*male + bs(age,df=4) + C(edu3) + C(race) + C(cycle)'
EXTRA={'baseline':'','bmi':' + bs(bmi,df=3)','income':' + bs(income_ratio,df=3)','both':' + bs(bmi,df=3) + bs(income_ratio,df=3)','healthcare':' + bs(bmi,df=3) + bs(income_ratio,df=3) + insurance + usual_care + C(cycle):care12m'}
def main():
    p=pd.read_csv(ROOT/'data/nhanes_panel.csv.gz',low_memory=False);univ=pd.read_csv(ROOT/'data/nhanes_person.csv.gz',low_memory=False)
    results=[];changes=[];alloc=[];audit=[];fails=[];checks=[];gaps=[];states=[];support=[]
    def run(g,y,form,labels,exposure='smoke_status',levels=(0,2)):
        try:
            v,i,a,_=fit(g,y,form,exposure,levels,weight=g.analysis_weight)
            audit.append(dict(**labels,**a));results.extend(prev.records(v,i,g,universe=univ,**labels,n=len(g)))
            if a['max_beta']>20 or a['hessian_condition']>1e8:raise AssertionError('unstable estimates: inspect diagnostic record')
            return v,i
        except (AssertionError,ValueError,np.linalg.LinAlgError) as e:
            fails.append(dict(**labels,error=str(e)));return None
    for definition,z in p.groupby('definition',sort=False):
        z=z.reset_index(drop=True);g=z[z.complete].copy().reset_index(drop=True)
        for (sex,agebin,smoke),s in g.assign(agebin=(g.age//10)*10).groupby(['male','agebin','smoke_status']):support.append(dict(definition=definition,male=sex,agebin=agebin,smoke=smoke,n=len(s),M_events=int(s.M.sum())))
        for y in ['M','S']:
            run(z,y,BASEFORM,dict(definition=definition,sample='round5',outcome=y,exposure='smoke_status',contrast='current_vs_never',model='baseline'))
        fits={}
        for y in ['M','S','MT']:
            for model,extra in EXTRA.items():
                for lev,contrast in [(2,'current_vs_never'),(1,'former_vs_never')]:
                    labels=dict(definition=definition,sample='complete',outcome=y,exposure='smoke_status',contrast=contrast,model=model)
                    f=run(g,y,BASEFORM+extra,labels,levels=(0,lev))
                    if f is not None:fits[(y,model,contrast)]=f
            contrast='current_vs_never'
            if all((y,m,contrast) in fits for m in EXTRA):
                v0,i0=fits[(y,'baseline',contrast)];vb,ib=fits[(y,'bmi',contrast)];vs,iss=fits[(y,'income',contrast)];vf,iff=fits[(y,'both',contrast)]
                for model in EXTRA:
                    if model=='baseline':continue
                    v,i=fits[(y,model,contrast)]
                    changes.extend(prev.records((v-v0)[[2,3]],(i-i0)[:,[2,3]],g,universe=univ,names=['change_RD','change_logOR'],definition=definition,outcome=y,comparison=model+'_minus_baseline',n=len(g)))
                component_values=[.5*((vb-v0)+(vf-vs)),.5*((vs-v0)+(vf-vb))]
                component_if=[.5*((ib-i0)+(iff-iss)),.5*((iss-i0)+(iff-ib))]
                assert np.max(np.abs(sum(component_values)-(vf-v0)))<1e-12
                assert np.max(np.abs(sum(component_if)-(iff-i0)))<1e-12
                for name,v,i in zip(['BMI','income'],component_values,component_if):alloc.extend(prev.records(v[[2,3]],i[:,[2,3]],g,universe=univ,names=['allocated_RD','allocated_logOR'],definition=definition,outcome=y,component=name,n=len(g)))
                if definition=='primary' and y=='M':
                    direction=np.random.default_rng(260917).normal(size=len(g));direction-=direction.mean();eps=1e-4;vv=[]
                    for sign in [-1,1]:
                        f={m:fit(g,y,BASEFORM+EXTRA[m],weight=g.analysis_weight,multiplier=1+sign*eps*direction)[0] for m in ['baseline','bmi','income','both']}
                        vv.append(.5*((f['bmi']-f['baseline'])+(f['both']-f['income'])))
                    err=float(abs((vv[1]-vv[0])/(2*eps)-direction@component_if[0]).max());assert err<1e-6;checks.append(dict(analysis='symmetric_adjustment_allocation',error=err))
        for y in ['S','MT']:
            for model in EXTRA:
                if all((yy,model,'current_vs_never') in fits for yy in ['M',y]):
                    v,i=fits[(y,model,'current_vs_never')];v0,i0=fits[('M',model,'current_vs_never')]
                    gaps.extend(prev.records((v-v0)[[2,3]],(i-i0)[:,[2,3]],g,universe=univ,names=['difference_RD','difference_logOR'],definition=definition,comparison=y+'_minus_M',model=model,n=len(g)))
        for model in ['baseline','both']:
            run(g,'MT_strict',BASEFORM+EXTRA[model],dict(definition=definition,sample='complete',outcome='MT_strict',exposure='smoke_status',contrast='current_vs_never',model=model))
            for y in ['M','S','MT']:
                run(g,y,BASEFORM.replace('C(smoke_status)','ever')+EXTRA[model],dict(definition=definition,sample='complete',outcome=y,exposure='ever',contrast='ever_vs_never',model=model),exposure='ever',levels=(0,1))
        duration=g[g.smoke_duration.ne(4)].copy().reset_index(drop=True)
        dform='C(smoke_duration) + male + bs(age,df=4) + C(edu3) + C(race) + C(cycle)'
        for y in ['M','S','MT']:
            support_ok=all(len(a)>=30 and a[y].sum()>=10 and (1-a[y]).sum()>=10 for _,a in duration.groupby('smoke_duration'))
            for model in ['baseline','both']:
                for lev,name in [(1,'current_vs_never'),(2,'quit_under5y_vs_never'),(3,'quit_5plus_vs_never')]:
                    lab=dict(definition=definition,sample='duration_known',outcome=y,exposure='smoke_duration',contrast=name,model=model)
                    if support_ok:run(duration,y,dform+EXTRA[model],lab,exposure='smoke_duration',levels=(0,lev))
                    else:fails.append(dict(**lab,error='prespecified sparse-cell threshold'))
        print(definition,'complete=',len(g),'specifications=',len(audit),flush=True)
    af=pd.DataFrame(alloc);af['p_holm_primary_RD']=np.nan
    mask=af.definition.eq('primary')&af.metric.eq('allocated_RD');assert mask.sum()==6
    af.loc[mask,'p_holm_primary_RD']=multipletests(af.loc[mask,'p'],method='holm')[1]
    af.to_csv(RES/'nhanes_adjustment_allocation.csv',index=False,encoding='utf-8-sig')
    for rows,name in [(results,'nhanes_estimates.csv'),(changes,'nhanes_paired_changes.csv'),(gaps,'nhanes_definition_differences.csv'),(audit,'nhanes_model_audit.csv'),(checks,'nhanes_numerical_verification.csv'),(support,'nhanes_age_sex_support.csv')]:save(rows,name)
    (RES/'nhanes_unfitted.json').write_text(json.dumps(fails,indent=2),encoding='utf-8')
    r=pd.DataFrame(results);show=r.query("definition=='primary' and sample=='complete' and contrast=='current_vs_never' and metric=='logOR'").copy()
    for col in ['estimate','lo','hi']:show[col]=np.exp(show[col])
    print(show[['outcome','model','estimate','lo','hi','n']].to_string(index=False));print(af[mask].to_string(index=False));print('FAILURES',fails)
if __name__=='__main__':main()
