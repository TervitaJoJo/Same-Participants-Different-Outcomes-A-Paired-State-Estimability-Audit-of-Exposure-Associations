from common import *
def main():
    allg=pd.read_csv(ROOT/'data/charls_landmark.csv.gz',low_memory=False)
    g=allg[allg.vital2018.eq('alive')].copy().reset_index(drop=True);r=g.quit2018.notna().to_numpy()
    form='E + bs(age2015,df=3) + male + C(edu3) + public_insurance + rural_hukou'
    for c in ['outpatient_raw_2015','hospital_raw_2015']:g[c+'_cat']=g[c].fillna(-1)
    oform=form+' + C(outpatient_raw_2015_cat) + C(hospital_raw_2015_cat)'
    results=[];audit=[];fails=[];cells=[];checks=[];bounds=[];changes=[];fits={}
    def adequate(z,label):
        a=z.dropna(subset=['quit2018']);counts=pd.crosstab(a.E,a.quit2018).reindex(index=[0,1],columns=[0,1],fill_value=0)
        for ex in [0,1]:
            for y in [0,1]:cells.append(dict(sample=label,E=ex,quit=y,n=int(counts.loc[ex,y])))
        return counts.min().min()>=10
    if adequate(g,'main'):
        for method,target,ipw,cap in [('complete_cases','observed',False,None),('common_target','all',False,None),('ipw','all',True,None),('ipw_cap20','all',True,20)]:
            try:
                v,i,a,dd=fit(g,'quit2018',form,'E',(0,1),observed=r,obs_formula=oform,ipw=ipw,cap=cap,target=target)
                audit.append(dict(method=method,**a))
                assert a['max_beta']<20 and a['hessian_condition']<1e8,'unstable outcome model'
                if ipw:assert a['obs_max_beta']<20 and a['obs_hessian_condition']<1e8,'observation model separation/instability'
                results.extend(prev.records(v,i,g,method=method,n=len(g),n_observed=int(r.sum())))
                fits[method]=(v,i)
                if method=='complete_cases':
                    direction=np.random.default_rng(260918).normal(size=len(g));direction-=direction.mean();eps=1e-4
                    vv=[fit(g,'quit2018',form,'E',(0,1),observed=r,target=target,multiplier=1+sign*eps*direction)[0] for sign in [-1,1]]
                    err=float(abs((vv[1]-vv[0])/(2*eps)-direction@i).max());assert err<1e-6;checks.append(dict(analysis='charls_marginal',error=err))
            except (AssertionError,ValueError,np.linalg.LinAlgError) as e:fails.append(dict(method=method,error=str(e)))
        for method in ['ipw','ipw_cap20']:
            if method in fits:
                v,i=fits[method];v0,i0=fits['common_target'];changes.extend(prev.records((v-v0)[[2,4]],(i-i0)[:,[2,4]],g,names=['change_RD','change_logRR'],method=method+'_minus_common_target'))
    else:fails.append(dict(method='main',error='prespecified sparse-cell threshold'))
    strict=g[g.quit2018.eq(0)|g.quit_time2018.eq('strictly_after_landmark')].copy().reset_index(drop=True)
    if adequate(strict,'strict_dates'):
        try:
            v,i,a,_=fit(strict,'quit2018',form,'E',(0,1));audit.append(dict(method='strict_dates',**a))
            assert a['max_beta']<20 and a['hessian_condition']<1e8,'unstable outcome model'
            results.extend(prev.records(v,i,strict,universe=g,method='strict_dates',n=len(strict),n_observed=len(strict)))
        except (AssertionError,ValueError,np.linalg.LinAlgError) as e:fails.append(dict(method='strict_dates',error=str(e)))
    else:fails.append(dict(method='strict_dates',error='prespecified sparse-cell threshold'))
    for ex,z in g.groupby('E'):
        n=len(z);events=z.quit2018.sum();missing=z.quit2018.isna().sum()
        bounds.append(dict(E=ex,n=n,observed=n-missing,events=int(events),missing=missing,crude_min=events/n,crude_max=(events+missing)/n))
    for rows,name in [(results,'charls_estimates.csv'),(audit,'charls_model_audit.csv'),(cells,'charls_cells.csv'),(checks,'charls_numerical_verification.csv'),(bounds,'charls_survivor_bounds.csv'),(changes,'charls_paired_changes.csv')]:save(rows,name)
    (RES/'charls_unfitted.json').write_text(json.dumps(fails,indent=2),encoding='utf-8')
    rr=pd.DataFrame(results);rr=rr[rr.metric.isin(['RD','logRR'])].copy()
    print(rr.to_string(index=False));print('FAILURES',fails)
if __name__=='__main__':main()
