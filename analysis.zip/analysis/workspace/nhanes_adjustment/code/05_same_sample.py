from common import *
from importlib import import_module
nh=import_module('03_nhanes')
def main():
    p=pd.read_csv(ROOT/'data/nhanes_panel.csv.gz',low_memory=False);g=p[p.definition.eq('primary')&p.complete].copy().reset_index(drop=True)
    univ=pd.read_csv(ROOT/'data/nhanes_person.csv.gz',low_memory=False)
    g['A']=g.hba1c.ge(6.5).astype(float);g['F']=g.glu.ge(126).astype(float);assert ((g.A==1)|(g.F==1)).astype(float).eq(g.M).all()
    results=[];changes=[];audits=[];cells=[];checks=[]
    for s,z in g.groupby('smoke_status'):
        for (a,f),x in z.groupby(['A','F']):cells.append(dict(smoke_status=s,hba1c_positive=a,glucose_positive=f,n=len(x),denominator=len(z),weighted_fraction=float(x.analysis_weight.sum()/z.analysis_weight.sum())))
    for model in ['baseline','both']:
        fits={}
        for y in ['M','A','F']:
            v,i,a,_=fit(g,y,nh.BASEFORM+nh.EXTRA[model],weight=g.analysis_weight);audits.append(dict(outcome=y,model=model,**a))
            assert a['max_beta']<20 and a['hessian_condition']<1e8
            results.extend(prev.records(v,i,g,universe=univ,outcome=y,model=model,n=len(g)));fits[y]=(v,i)
        for y in ['A','F']:
            v,i=fits[y];v0,i0=fits['M']
            changes.extend(prev.records((v-v0)[[2,3]],(i-i0)[:,[2,3]],g,universe=univ,names=['difference_RD','difference_logOR'],comparison=y+'_minus_M',model=model,n=len(g)))
        if model=='both':
            direction=np.random.default_rng(260919).normal(size=len(g));direction-=direction.mean();eps=1e-4;vv=[]
            for sign in [-1,1]:
                v=fit(g,'A',nh.BASEFORM+nh.EXTRA[model],weight=g.analysis_weight,multiplier=1+sign*eps*direction)[0]
                v0=fit(g,'M',nh.BASEFORM+nh.EXTRA[model],weight=g.analysis_weight,multiplier=1+sign*eps*direction)[0];vv.append(v-v0)
            err=float(abs((vv[1]-vv[0])/(2*eps)-direction@(fits['A'][1]-fits['M'][1])).max());assert err<1e-6;checks.append(dict(analysis='paired_marker_definitions',error=err))
    for rows,name in [(results,'same_sample_estimates.csv'),(changes,'same_sample_differences.csv'),(audits,'same_sample_audit.csv'),(cells,'same_sample_marker_states.csv'),(checks,'same_sample_numerical.csv')]:save(rows,name)
    z=pd.DataFrame(results).query("metric=='logOR'").copy()
    for c in ['estimate','lo','hi']:z[c]=np.exp(z[c])
    print(z.to_string(index=False))
if __name__=='__main__':main()
