from common import *
from scipy.special import logit
def main():
    checks={};counts={}
    inputs=json.loads((RES/'input_manifest.json').read_text())
    for x in inputs:assert sha(BASE/x['path'])==x['sha256'],x['path']
    checks['input_files_unchanged']=True;counts['inputs']=len(inputs)
    oldn=0
    for dirname in ['mechanism_linkage_20260917','nhanes_robustness']:
        for x in json.loads((BASE/dirname/'results/output_manifest.json').read_text(encoding='utf-8')):
            assert sha(BASE/dirname/x['path'])==x['sha256'],x['path'];oldn+=1
    checks['previous_outputs_unchanged']=True;counts['previous_outputs']=oldn
    for x in json.loads((RES/'official_sources.json').read_text()):assert sha(ROOT/x['path'])==x['sha256']
    checks['official_source_hashes']=True
    p=pd.read_csv(ROOT/'data/nhanes_panel.csv.gz',low_memory=False)
    assert not p.duplicated(['uid','definition']).any();assert p.analysis_weight.gt(0).all()
    assert p[p.definition.eq('primary')].PHAFSTHR.add(p[p.definition.eq('primary')].PHAFSTMN/60).between(8.5,24).all()
    g=p[p.definition.eq('primary')&p.complete]
    assert len(g)==1816 and g[['M','S','MT','MT_strict','bmi','income_ratio']].notna().all().all()
    assert (g.MT>=g.M).all() and (g.MT_strict>=g.M).all() and (g.MT>=g.MT_strict).all()
    checks['sample_and_outcome_definitions']=True
    a=pd.read_csv(RES/'nhanes_estimates.csv');old=pd.read_csv(BASE/'mechanism_linkage_20260917/results/definition_gap_estimates.csv')
    errs=[]
    for definition in ['primary','hba1c_only']:
        for y in ['M','S']:
            r=a.query("sample=='round5' and model=='baseline' and metric=='logOR' and outcome==@y and definition==@definition").iloc[0]
            rr=old[(old.disease=='diabetes')&(old.definition==definition)&old.weighting.eq('survey')&old.model.eq('baseline')&old.metric.eq('logOR_'+y)].iloc[0]
            errs.append(abs(r.estimate-rr.estimate));assert abs(r.estimate-rr.estimate)<1e-9
    checks['round5_baseline_reproduced']=True;counts['maximum_reproduction_error']=max(errs)
    # Validate estimates on their native scale, independent of formatted reports.
    maxerr=0
    for fn,keys in [('nhanes_estimates.csv',['definition','sample','outcome','exposure','contrast','model']),('same_sample_estimates.csv',['outcome','model']),('charls_estimates.csv',['method'])]:
        e=pd.read_csv(RES/fn)
        for _,z in e.groupby(keys):
            z=z.set_index('metric').estimate
            expected=[z.risk1-z.risk0,logit(z.risk1)-logit(z.risk0),np.log(z.risk1/z.risk0)]
            err=np.max(abs(np.array(expected)-z[['RD','logOR','logRR']].to_numpy()));maxerr=max(maxerr,float(err));assert err<1e-10
        assert np.isfinite(e[['estimate','se','lo','hi','df']]).all().all()
    checks['effect_identities_and_finite_intervals']=True;counts['maximum_identity_error']=maxerr
    assert a.df.eq(32).all()
    allocated=pd.read_csv(RES/'nhanes_adjustment_allocation.csv');change=pd.read_csv(RES/'nhanes_paired_changes.csv')
    for (definition,y,metric),z in allocated.groupby(['definition','outcome','metric']):
        ref=change[(change.definition==definition)&(change.outcome==y)&(change.metric==metric.replace('allocated','change'))&change.comparison.eq('both_minus_baseline')].iloc[0]
        assert abs(z.estimate.sum()-ref.estimate)<1e-12
    primary=allocated[allocated.definition.eq('primary')&allocated.metric.eq('allocated_RD')]
    assert len(primary)==6 and primary.p_holm_primary_RD.notna().all()
    checks['symmetric_allocations_sum_and_Holm_complete']=True
    nhfails=json.loads((RES/'nhanes_unfitted.json').read_text());assert not nhfails
    ca=pd.read_csv(RES/'charls_model_audit.csv');cfails=json.loads((RES/'charls_unfitted.json').read_text())
    assert {x['method'] for x in cfails}=={'ipw','ipw_cap20'}
    ce=pd.read_csv(RES/'charls_estimates.csv');assert not ce.method.str.startswith('ipw').any()
    audits=pd.read_csv(RES/'nhanes_model_audit.csv');same=pd.read_csv(RES/'same_sample_audit.csv')
    assert audits.converged.all() and audits.max_beta.max()<20 and audits.hessian_condition.max()<1e8
    assert same.converged.all()
    checks['unstable_observation_models_withheld']=True
    counts.update(nhanes_logged_specs=len(audits),same_sample_specs=len(same),charls_attempted_specs=len(ca),charls_reported_specs=ce.method.nunique(),charls_withheld_specs=len(cfails))
    nums=[]
    for fn in ['nhanes_numerical_verification.csv','charls_numerical_verification.csv','same_sample_numerical.csv']:nums.extend(pd.read_csv(RES/fn).error.tolist())
    assert max(nums)<1e-6;checks['independent_perturbations']=True;counts['maximum_perturbation_error']=max(nums)
    # All history/order classification summaries keep unknown records in denominators.
    recall=pd.read_csv(RES/'nhanes_recalled_order.csv')
    for _,z in recall.groupby(['definition','method']):assert z.n.sum()==z.total.iloc[0] and abs(z.weighted_fraction.sum()-1)<1e-12
    c=pd.read_csv(ROOT/'data/charls_landmark.csv.gz');assert c.uid.is_unique
    flow=pd.read_csv(RES/'charls_survival_flow.csv');assert flow.n.sum()==len(c)==2362
    diag=c[c.E.eq(1)].copy();diag['diagnosis_time']=np.select([diag.diagnosis_year.lt(diag.iwyear),diag.diagnosis_year.eq(diag.iwyear),diag.diagnosis_year.gt(diag.iwyear)&diag.diagnosis_year.le(diag.r3iwy),diag.diagnosis_year.gt(diag.r3iwy)&diag.diagnosis_year.le(2020)],['before2013','same2013','strict_interval','after2015'],default='unknown_invalid')
    rows=[]
    for tag,z in diag.groupby('diagnosis_time'):rows.append(dict(classification=tag,n=len(z),alive=int(z.vital2018.eq('alive').sum()),quit=int(z.quit2018.sum()),strict_quit=int(z.quit_time2018.eq('strictly_after_landmark').sum())))
    save(rows,'charls_diagnosis_time_audit.csv')
    alive=c[c.vital2018.eq('alive')];strict=alive[(alive.quit2018.eq(0)|alive.quit_time2018.eq('strictly_after_landmark'))&(alive.E.eq(0)|(alive.diagnosis_year.gt(alive.iwyear)&alive.diagnosis_year.le(alive.r3iwy)))]
    table=pd.crosstab(strict.E,strict.quit2018).reindex(index=[0,1],columns=[0,1],fill_value=0)
    save([dict(E=e,quit=q,n=int(table.loc[e,q])) for e in [0,1] for q in [0,1]],'charls_strict_both_dates_cells.csv')
    assert table.loc[1,1]==9
    (RES/'charls_strict_both_dates_unfitted.json').write_text(json.dumps(dict(reason='prespecified sparse-cell threshold: 9 exposed quitting events < 10',n=len(strict)),indent=2),encoding='utf-8')
    checks['temporal_counts_and_sparse_rule']=True
    save([dict(E=e,male=m,n=len(z)) for (e,m),z in c.groupby(['E','male'])],'charls_sex_support.csv')
    result=dict(status='PASS_WITH_DOCUMENTED_LIMITATIONS',checks=checks,counts=counts,protocol_sha256=sha(ROOT/'PROTOCOL.md'),limitations=['Exploratory observational analysis; adjustment allocations are not causal mediation','BMI/income complete-case selection remains unresolved','Two CHARLS observation-weight models withheld due to separation','CHARLS exact diagnosis and quitting dates leave only 9 exposed events; adjusted model not fitted','Landmark conditions on still smoking in 2015 and known survival in 2018','Alternative HbA1c sample changes weights and selection as well as outcome definition'])
    (RES/'final_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
