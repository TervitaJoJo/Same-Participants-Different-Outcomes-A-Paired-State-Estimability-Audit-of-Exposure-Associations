from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=pd.read_csv(RES/'nhanes_estimates.csv');ALLOC=pd.read_csv(RES/'nhanes_adjustment_allocation.csv');CHANGE=pd.read_csv(RES/'nhanes_paired_changes.csv')
def one(d,**kw):
    for k,v in kw.items():d=d[d[k].eq(v)]
    assert len(d)==1,(kw,len(d));return d.iloc[0]
def mainrow(y,model='baseline',definition='primary',contrast='current_vs_never',metric='logOR',sample='complete',exposure='smoke_status'):
    return one(R,outcome=y,model=model,definition=definition,contrast=contrast,metric=metric,sample=sample,exposure=exposure)
def fx(r,exp=False,scale=1,digits=2):
    v=np.array([r.estimate,r.lo,r.hi]);v=np.exp(v) if exp else v*scale
    return f'{v[0]:.{digits}f}（{v[1]:.{digits}f}，{v[2]:.{digits}f}）'
def table(head,rows):return '\n'.join(['| '+' | '.join(head)+' |','| '+' | '.join(['---']*len(head))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows])
def link(p,label):return f'[{label}](<{p.as_posix()}>)'
def img(name,alt):return f'![{alt}]({(ROOT/"figures"/name).as_posix()})'
def export(fig,name):
    for ext in ['png','pdf']:fig.savefig(ROOT/'figures'/f'{name}.{ext}',dpi=240,bbox_inches='tight',facecolor='white')
    plt.close(fig)
def figures():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    names=['Demographics','+ BMI','+ income','+ BMI + income','+ BMI + income + healthcare']
    fig,axs=plt.subplots(1,3,figsize=(12,4.8),sharey=True)
    for ax,y,title in zip(axs,['M','S','MT'],['Measured threshold','Reported diagnosis','Measured or treated']):
        for j,(model,color) in enumerate(zip(['baseline','bmi','income','both','healthcare'],['#555555','#D55E00','#0072B2','#009E73','#7A5195'])):
            r=mainrow(y,model);v,lo,hi=np.exp([r.estimate,r.lo,r.hi]);ax.errorbar(v,j,xerr=[[v-lo],[hi-v]],fmt='o',color=color,capsize=3,ms=6)
        ax.axvline(1,color='#777777',ls='--',lw=1);ax.set_title(title,weight='bold');ax.set_xscale('log');ax.set_xticks([.4,.6,.8,1,1.2],['0.4','0.6','0.8','1.0','1.2']);ax.set_xlim(.32,1.35);ax.set_ylim(4.5,-.6);ax.set_xlabel('Current vs never: prevalence OR');ax.grid(axis='x',alpha=.15)
    axs[0].set_yticks(range(5),names)
    fig.suptitle('Diabetes associations: BMI and income adjustments move in opposite directions',weight='bold',fontsize=13)
    fig.text(.025,.025,'NHANES 2011–2014, ages 50–79; identical n = 1,816 and fasting-subsample weights in every model.\nBars: design-based t 95% intervals. Adjustment changes are descriptive, not causal mediation.',fontsize=9)
    fig.tight_layout(rect=[0,.15,1,.94]);export(fig,'01_diabetes_adjustment')
    fig,ax=plt.subplots(figsize=(9.5,4.7))
    for j,(component,color,label) in enumerate([('BMI','#D55E00','BMI allocation'),('income','#0072B2','Income allocation'),('net','#333333','Net paired change')]):
        for k,y in enumerate(['M','S','MT']):
            r=one(CHANGE,definition='primary',outcome=y,comparison='both_minus_baseline',metric='change_RD') if component=='net' else one(ALLOC,definition='primary',outcome=y,component=component,metric='allocated_RD')
            v,lo,hi=np.array([r.estimate,r.lo,r.hi])*100;ax.errorbar(v,k+(j-1)*.2,xerr=[[v-lo],[hi-v]],fmt='o',color=color,capsize=3,ms=5,label=label if k==0 else None)
    ax.axvline(0,color='#777777',lw=1,ls='--');ax.set_yticks(range(3),['Measured threshold','Reported diagnosis','Measured or treated']);ax.set_ylim(2.55,-.55);ax.set_xlim(-4.8,7);ax.set_xlabel('Change in current-minus-never prevalence difference (percentage points)');ax.grid(axis='x',alpha=.15)
    ax.legend(loc='lower left',bbox_to_anchor=(0,1),ncol=3,frameon=False,fontsize=9)
    fig.suptitle('Opposing adjustment components with an uncertain net change',weight='bold',fontsize=13)
    fig.text(.03,.02,'Two possible adjustment orders are averaged; BMI + income allocations equal the net change.\nIndividual 95% intervals are shown. These are model-based descriptive allocations, not causal contributions.',fontsize=9)
    fig.tight_layout(rect=[0,.16,1,.94]);export(fig,'02_opposing_components')
def main():
    figures();names={'M':'实测阈值 M','S':'自报诊断 S','MT':'实测或报告治疗 MT','MT_strict':'实测或确诊且治疗'}
    models={'baseline':'人口学','bmi':'＋BMI','income':'＋收入','both':'＋BMI及收入','healthcare':'再加医疗信息'}
    mainrows=[[models[m],*[fx(mainrow(y,m),exp=True) for y in ['M','S','MT']]] for m in models]
    ar=[]
    for y in ['M','S','MT']:
        bb=one(ALLOC,definition='primary',outcome=y,component='BMI',metric='allocated_RD');ii=one(ALLOC,definition='primary',outcome=y,component='income',metric='allocated_RD');net=one(CHANGE,definition='primary',outcome=y,comparison='both_minus_baseline',metric='change_RD')
        ar.append([names[y],fx(bb,scale=100),fx(ii,scale=100),fx(net,scale=100)])
    smoke=[]
    for y in ['M','S','MT']:
        smoke.append([names[y],fx(mainrow(y,contrast='former_vs_never'),exp=True),fx(mainrow(y,'both',contrast='former_vs_never'),exp=True),fx(mainrow(y,'both',exposure='ever',contrast='ever_vs_never'),exp=True)])
    duration=[]
    for y in ['M','S','MT']:
        duration.append([names[y],fx(mainrow(y,'both',exposure='smoke_duration',sample='duration_known',contrast='quit_under5y_vs_never'),exp=True),fx(mainrow(y,'both',exposure='smoke_duration',sample='duration_known',contrast='quit_5plus_vs_never'),exp=True)])
    ss=pd.read_csv(RES/'same_sample_estimates.csv');markerrows=[]
    for y,lab in [('M','HbA1c或空腹血糖'),('A','仅HbA1c'),('F','仅空腹血糖')]:markerrows.append([lab,1816,*[fx(one(ss,outcome=y,model=m,metric='logOR'),exp=True) for m in ['baseline','both']]])
    markerrows.append(['较大样本仅HbA1c，MEC权重',3958,fx(mainrow('M',definition='hba1c_only'),exp=True),fx(mainrow('M','both',definition='hba1c_only'),exp=True)])
    cf=pd.read_csv(RES/'charls_survival_flow.csv');ct=pd.read_csv(RES/'charls_estimates.csv');crows=[]
    for e,lab in [(0,'2015仍未诊断'),(1,'2015新增报告诊断')]:
        z=cf[cf.E.eq(e)];alive=z[z.vital.eq('alive')].iloc[0]
        crows.append([lab,int(z.n.sum()),int(alive.n),int(z[z.vital.eq('dead')].n.sum()),int(z[z.vital.eq('unknown')].n.sum()),int(alive.observed),int(alive.quit_n)])
    ce=[]
    for method,label in [('complete_cases','明确结局完整案例'),('common_target','标准化至全部已知存活者'),('strict_dates','仅严格戒烟年份')]:
        rr=one(ct,method=method,metric='logRR');rd=one(ct,method=method,metric='RD');ce.append([label,int(rr.n_observed),fx(rr,exp=True),fx(rd,scale=100)])
    audit=json.loads((RES/'final_audit.json').read_text());counts=audit['counts']
    text=f'''# 第六轮阶段性成果：BMI、收入与测量定义；延长诊断后戒烟随访

2026年9月17日。现有数据足够完成本轮，原始数据、既往结果和正文未改。本轮为探索性机制分析。

**本轮新增的定量解释是：NHANES糖尿病的吸烟负向关联对BMI与收入调整呈相反变化，净变化并不精确；治疗扩展和吸烟分组不足以单独解释剩余关联。CHARLS随访延长到2018年后，2015新增报告高血压且仍吸烟者未显示明确的后续戒烟增加，精确日期证据仍稀少。**

## 1. NHANES：在完全相同的人中分开比较BMI与收入

沿用第五轮2011–2014、50–79岁、双指标完整空腹样本及对应权重，先重现第五轮人口学模型在两种定义下的实测/自报OR（最大差0）。2,009人中BMI完整1,987人，BMI及收入完整1,816人，后者治疗状态均可判定。因此本轮主要模型都用同一1,816人，不把删去缺失值造成的改变说成调整贡献。单HbA1c的不同定义敏感性最终纳入3,958人。

主样本从不/既往/当前吸烟者分别916/576/324人。加权平均BMI分别29.89/29.94/27.92；家庭收入与贫困线之比分别3.35/3.33/2.16（收入比≥5合并编码为5）。当前吸烟者BMI较低，收入也较低，这两个方向对应的调整变化并不一致。

人口学模型包含三分类吸烟×性别、年龄样条、教育、种族/族裔及周期。BMI与收入分别用df3样条；后续医疗变量沿用第五轮。下表为当前相对从不吸烟的**边际标准化患病优势比OR（逐项95%CI），不是发病风险比**。

{table(['同一样本模型','实测 M','自报 S','实测或治疗 MT'],mainrows)}

实测OR从0.65变为加BMI后的0.84，负向点估计减弱；只加收入后为0.54，负向点估计增强；两者同时加入约0.74。自报和治疗扩展定义也呈类似的调整方向。医疗信息再加入后点估计改变较小。

{img('01_diabetes_adjustment.png','同一样本不同协变量模型的糖尿病OR')}

这支持BMI相关人群构成值得关注，但不能认定BMI的因果中介作用：BMI可能受吸烟、戒烟、疾病及治疗影响。收入也不能代表所有社会经济因素。OR区间跨1不等于已消除保护性，更不证明等效或无效应。

## 2. 可以分配模型变化，但不能计算因果解释百分比

用风险差RD（当前减从不）减少仅看OR尺度的歧义，保留两次拟合的配对协方差。对BMI和收入，分别按“先BMI后收入”和“先收入后BMI”计算增量，再取两种顺序的平均。这是对指定模型变化的对称代数分配，**两项之和严格等于净变化**，不是病因归因分数。

下表均为百分点及逐项95%CI：

{table(['结局','BMI分配项','收入分配项','两者净配对变化'],ar)}

实测RD从−6.34变为−4.67个百分点。BMI分配项约+3.90，收入分配项约−2.23，净变化约+1.67（−1.11，4.45）个百分点。两个分量具有相反方向，**净变化的区间仍跨0**。单独加入BMI的配对变化为+3.58（1.54，5.62）个百分点；与+3.90的差别来自对加入顺序的平均，不是数值矛盾。

对三个结局×两个RD分配项共6个探索性检验进行了Holm校正，校正p值约0.0007–0.0154；它只控制这组模型比较的多重检验，不能补救选择偏倚或赋予因果意义。置信区间仍为逐项区间。

{img('02_opposing_components.png','BMI与收入调整分配项及其净变化')}

## 3. 治疗控制、既往吸烟与戒烟时长

M为HbA1c≥6.5%或空腹血糖≥126 mg/dL；S为自报医生诊断。MT增加报告正在用胰岛素或口服降糖药者。CDC跳题核实：只有在明确无糖尿病、无糖尿病前期且符合跳题时，口服药结构性缺失才编码为无报告治疗；拒答、不知或跳题不明不当阴性。

主样本M阳性438人，MT阳性513人，增加75名阈值以下但报告治疗者。不过部分治疗可能针对糖尿病前期，故另保留更窄定义“实测阳性或自报确诊且治疗”。该定义人口学OR为{fx(mainrow('MT_strict'),exp=True,digits=3)}，BMI＋收入后为{fx(mainrow('MT_strict','both'),exp=True,digits=3)}。不能选用最接近1的定义充当校正成功。

在BMI＋收入模型中，MT与M的logOR差为0.051（−0.137，0.238），改变不明确；自报与实测的logOR差Δ为0.025（−0.243，0.294），也不足以证明存在明确口径差异或证明两者等效。治疗后控制者不自动等于自报错误。

既往吸烟单列及曾经吸烟的敏感性如下，均为OR（95%CI）：

{table(['结局','既往vs从不：人口学','既往vs从不：＋BMI收入','曾经vs从不：＋BMI收入'],smoke)}

把当前与既往合为曾经吸烟后，实测OR仍约0.76。这个比较改变了暴露定义，不能当作病后戒烟偏倚被彻底修复；但它没有支持“只要把既往吸烟加回去，负向关联就消失”。

主样本既往吸烟者中戒烟<5年75人、≥5年500人、时间未知1人。时长模型排除这1人，保留所有主分组，去掉吸烟×性别交互以限制稀疏性。BMI＋收入模型结果如下：

{table(['结局','戒烟<5年vs从不','戒烟≥5年vs从不'],duration)}

近期戒烟者点估计较高，但区间很宽，不能说已证实近期戒烟组比长期组风险高。130名既往吸烟且自报糖尿病者中，回忆时间显示29人诊断至少早于推算戒烟年龄2岁、87人戒烟至少早于诊断2岁、12人相差不足2岁、2人未知/无效；加权比例分别20.9%、73.2%、5.1%、0.7%。以最后规律吸烟年龄核查时方向近似，但该年龄不等于完全戒烟年龄。这些是病例内回忆构成，不能作为诊断导致戒烟的比例。

## 4. 不同实测指标与样本也会改变结论

较大HbA1c样本的BMI＋收入OR约1.06，而主联合定义约0.74。为分清其中的测量差异，追加了**固定主样本1,816人、固定空腹权重**的两个单指标模型；追加原因和时点已写入方案。

{table(['实测定义/样本','人数','人口学OR（95%CI）','＋BMI收入OR（95%CI）'],markerrows)}

前三行只改变测量定义，最后一行同时改变样本和权重。在同一1,816人中，单HbA1c相对联合定义的调整后logOR差约0.149（−0.004，0.302），RD差约+2.55（0.36，4.74）个百分点。尺度不同导致区间跨零情况不同，应同时保留；不能把较大样本点估计回到1全部归因于指标切换。一次生化阈值也不是临床金标准。

## 5. CHARLS延长到2018：时间顺序更清楚，但未增强正向证据

新分析以2015作为起点：2011及2013明确未诊断高血压、2015有明确新增诊断回答、2015仍吸烟、当时50–79岁。暴露是截至2015新增报告诊断，结局为2018明确戒烟。该设计排除了2015前已戒烟者，可能留下对早期诊断反应较弱的人，**估计的是继续吸烟者中的后续关联，不能代表诊断的总戒烟效应**。

{table(['2015诊断组','入组','2018已知存活','已知死亡','生存未知','吸烟结局明确','明确戒烟'],crows)}

主模型调整2015年龄、性别、教育及基线公共医保/农村户口，按社区聚类；无全国人口权重。组间协变量信息仍有限。

{table(['分析','明确结局人数','戒烟RR（95%CI）','戒烟RD（百分点，95%CI）'],ce)}

主结果RR约0.80（0.46，1.39）；严格戒烟年份RR约0.88（0.49，1.57）。区间均很宽，**未支持明确增加，也不能证明诊断没有促进戒烟的作用**。这与早前“2011已诊断预测2015戒烟”的问题、风险集和观察时段不同，不应把两个估计直接当时间趋势。

新增诊断组114名已知存活者全部有吸烟结局，未诊断组2,022人中16人未知（其中14人改报从未吸烟，与2015记录冲突）。含诊断项的观察概率模型出现分离，最大绝对系数约55.6、Hessian条件数约8.8×10^14，因此按方案不报告IPW及截尾IPW效应，失败记录完整保留。未诊断组将16人全部视为戒烟/未戒烟，其**粗戒烟比例界限**为12.61%–13.40%；诊断组为10.53%。该范围不含抽样不确定性、不作调整，也不包括死亡或生存未知者。

进一步同时要求诊断年份严格在2013访问年之后、2015访问年及以前，戒烟年份严格在2015访问年之后、2018访问年及以前：诊断组只剩9个戒烟事件，低于预设10事件的拟合门槛，因此仅报告计数。仅按波次顺序的结果不能称为精确日期已经充分验证。

本轮还发现2018问卷PDF与发布数据的戒烟年/年龄字段顺序相反。已根据官方代码本、数据标签及实际值域按发布数据编码，未凭位置套用2015规则；2018当期吸烟与协调库19,729条共同有效记录完全一致。

## 6. 这一轮对论文故事的实际推进

目前可以把解释组织为三个可分开的层次：

1. **人群构成及行为历史：**BMI与收入的调整方向相反，单一“吸烟者较少就医”的解释不够；仅将既往吸烟并回暴露组也未消除实测负向关联。
2. **结局的定义与治疗状态：**生化指标、自报历史诊断和治疗扩展定义捕捉不同状态；相同样本下定义变化可量化，但不能自动解释为测量误差被纠正。
3. **疾病发现与戒烟的时间顺序：**已有部分关联证据；延长随访后新的风险集并未给出明确正向支持，完整有序机制链仍未被识别。

本轮尚未形成“定量解释全部保护性”的因果故事。下一步质量提升应优先检验NHANES的BMI/收入完整案例选择，并在固定测量定义和目标人群下核查结果能否跨周期稳定；CHARLS则继续区分诊断后早期戒烟与2015仍吸烟者的后续戒烟。当前不需补交数据。

## 7. 复现与限制记录

{counts['inputs']}个输入文件、第四/第五轮{counts['previous_outputs']}个产物散列保持一致。NHANES记录{counts['nhanes_logged_specs']}套规格，追加同样本指标核验{counts['same_sample_specs']}套；CHARLS尝试5套，其中3套报告、2套因观察模型分离保留诊断并不报告效应，精确双日期模型另按稀疏规则不拟合。独立数值扰动最大误差{counts['maximum_perturbation_error']:.2e}，指标恒等式、分配项求和、权重与样本合计核验通过。

NHANES设计区间使用32自由度，CHARLS按社区聚类；正确权重仍不能解决完整案例选择、选择存活者或未测量混杂。所有结果为观察关联和探索性敏感性，未估计发病因果效应，未承诺期刊档次。原始个体数据及派生记录留在本地。

主要产物：

- {link(ROOT/'PROTOCOL.md','方案及按时间记录的扩展')}
- {link(RES/'nhanes_estimates.csv','NHANES全部OR、RD及分组敏感性（OR以log尺度保存）')}
- {link(RES/'nhanes_adjustment_allocation.csv','BMI/收入对称分配及Holm校正')}
- {link(RES/'nhanes_paired_changes.csv','同样本配对模型变化')}
- {link(RES/'same_sample_estimates.csv','同样本单指标核验')}
- {link(RES/'charls_estimates.csv','CHARLS延长随访效应')}
- {link(RES/'charls_diagnosis_time_audit.csv','诊断日期审计')}
- {link(RES/'charls_strict_both_dates_cells.csv','严格诊断与戒烟时间人数')}
- {link(RES/'final_audit.json','最终审计与未解决限制')}

按`00_sources.py → 01_build.py → 02_describe.py → 03_nhanes.py → 04_charls.py → 05_same_sample.py → 06_audit.py → 07_report.py`复现。两个效应脚本03/04独立；其余按依赖顺序执行。
'''
    report=ROOT/'第六轮阶段性成果.md';report.write_text(text,encoding='utf-8')
    (ROOT/'README.md').write_text(f'''# 第六轮机制分析

{link(report,'阅读阶段性成果')}。正文未修改。

Python运行`code/00_sources.py`至`07_report.py`，设置`OPENBLAS_NUM_THREADS=1`、`OMP_NUM_THREADS=1`、`PYTHONIOENCODING=utf-8`。版本见`results/environment.json`。官方NHANES代码本缓存到`sources`，其余使用现有本地数据。CHARLS问卷/代码本摘录来源与PDF页码见`sources`。

CSV中logOR/logRR需指数化，RD乘100为百分点。分配项为描述性模型变化，禁止当作因果解释百分比。保留观察模型分离及严格双日期样本不足记录。`data`含个体派生数据，不作公开补充材料。
''',encoding='utf-8')
    manifest=[dict(path=str(f.relative_to(ROOT)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(ROOT.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.name!='output_manifest.json']
    (RES/'output_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8');print(report)
if __name__=='__main__':main()
