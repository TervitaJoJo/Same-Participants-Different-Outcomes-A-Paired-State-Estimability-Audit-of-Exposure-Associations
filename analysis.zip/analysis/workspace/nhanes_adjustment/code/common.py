from pathlib import Path
import importlib.util,json,hashlib,platform
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;RES=ROOT/'results'
for p in ['data','results','figures','sources']:(ROOT/p).mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('round4_common',BASE/'nhanes_robustness/code/common.py')
prev=importlib.util.module_from_spec(spec);spec.loader.exec_module(prev)
NAMES=prev.NAMES
def save(rows,name):pd.DataFrame(rows).to_csv(RES/name,index=False,encoding='utf-8-sig')
def sha(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def fit(g,y,formula,exposure='smoke_status',levels=(0,2),**kw):
    v,i,a,d=prev.marginal(g,g[y],formula,exposure,levels,**kw)
    p=d['factual_probability'];a.update(min_probability=float(p.min()),max_probability=float(p.max()),extreme_n=int(((p<1e-6)|(p>1-1e-6)).sum()))
    return v,i,a,d
