from pathlib import Path
import urllib.request,json,hashlib
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
for name in ['sources','results','data','figures']:(ROOT/name).mkdir(exist_ok=True)
class Plain(HTMLParser):
    def __init__(self):super().__init__();self.parts=[]
    def handle_data(self,s):
        if s.strip():self.parts.append(s.strip())
records=[]
for year,suf in [('2011','G'),('2013','H')]:
    for mod in ['FASTQX','GLU']:
        url=f'https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/{year}/DataFiles/{mod}_{suf}.htm';dest=ROOT/'sources'/f'{mod}_{suf}.htm'
        existing=BASE/'mechanism_linkage_20260917/sources'/dest.name
        if not dest.exists():
            if existing.exists():b=existing.read_bytes()
            else:
                with urllib.request.urlopen(url,timeout=30) as r:b=r.read()
            assert b'SEQN' in b and f'{mod}_{suf}'.encode() in b;dest.write_bytes(b)
        parser=Plain();parser.feed(dest.read_text(encoding='utf-8-sig'));dest.with_suffix('.txt').write_text('\n'.join(parser.parts),encoding='utf-8')
        records.append(dict(url=url,path=str(dest.relative_to(ROOT)),sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
url='https://wwwn.cdc.gov/nchs/nhanes/tutorials/weighting.aspx'
dest=ROOT/'sources/weighting_tutorial.htm'
if not dest.exists():
    with urllib.request.urlopen(url,timeout=30) as r:dest.write_bytes(r.read())
parser=Plain();parser.feed(dest.read_text(encoding='utf-8-sig'));dest.with_suffix('.txt').write_text('\n'.join(parser.parts),encoding='utf-8')
records.append(dict(url=url,path=str(dest.relative_to(ROOT)),sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
(ROOT/'results/official_sources.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
for suf in ['G','H']:
    text=(ROOT/'sources'/f'FASTQX_{suf}.txt').read_text(encoding='utf-8');i=text.find('Variable Name:\nPHDSESN');print(text[i:i+1700])
