from common import *
import pyreadstat
from itertools import product

def main():
    person=BASE/'nhanes_adjustment/data/nhanes_person.csv.gz'
    p=pd.read_csv(person,low_memory=False);inputs=[person,BASE/'nhanes_selection/data/panel.csv.gz',BASE/'nhanes_robustness/code/common.py'];dictionary=[]
    pieces=[]
    for cycle,suf in [('2011-2012','G'),('2013-2014','H')]:
        paths=[BASE/'NHANES'/cycle/f'{mod}_{suf}.xpt' for mod in ['FASTQX','DEMO']];inputs.extend(paths)
        fast,meta=pyreadstat.read_xport(str(paths[0]));demo,dm=pyreadstat.read_xport(str(paths[1]))
        cols=['SEQN','PHDSESN','PHAFSTHR','PHAFSTMN','PHQ020','PHQ030','PHQ040','PHQ050','PHQ060']
        for c in cols:dictionary.append(dict(file=str(paths[0].relative_to(BASE)),variable=c,label=meta.column_names_to_labels.get(c)))
        dictionary.append(dict(file=str(paths[1].relative_to(BASE)),variable='RIDSTATR',label=dm.column_names_to_labels['RIDSTATR']))
        z=demo[['SEQN','RIDSTATR']].merge(fast[cols].rename(columns={'PHAFSTHR':'FAST_HR','PHAFSTMN':'FAST_MN'}),on='SEQN',how='left',validate='one_to_one');z['cycle']=cycle;pieces.append(z)
    p=p.merge(pd.concat(pieces),on=['cycle','SEQN'],how='left',validate='one_to_one');assert p.uid.is_unique
    p[['strata','cluster']].drop_duplicates().to_csv(ROOT/'data/design.csv',index=False)
    g=p[p.age.between(50,79)].copy();g['M']=np.where(g.hba1c.notna(),g.hba1c.ge(6.5).astype(float),np.nan);g['S']=g.S_dm
    g['w_mec']=g.WTMEC2YR/2;g['w_fast']=g.WTSAF2YR/2
    known=['hba1c','S','smoke_status','male','edu3','race'];extra=['bmi','income_ratio'];health=['insurance','usual_care','care12m']
    masks={'interview_age':pd.Series(True,index=g.index),'mec_positive':g.w_mec.gt(0)}
    masks['known_core']=masks['mec_positive']&g[known].notna().all(axis=1)
    masks['A_complete_bmi_income']=masks['known_core']&g[extra].notna().all(axis=1)
    masks['B_complete_healthcare']=masks['A_complete_bmi_income']&g[health].notna().all(axis=1)
    masks['AM_actual_morning']=masks['B_complete_healthcare']&g.PHDSESN.eq(0)
    masks['W_positive_fasting_weight']=masks['AM_actual_morning']&g.w_fast.gt(0)
    masks['F_valid_glucose']=masks['W_positive_fasting_weight']&g.glu.notna()
    flow=[];last=None
    for stage,mask in masks.items():
        z=g[mask];flow.append(dict(stage=stage,n=len(z),lost_from_previous=0 if last is None else int(last.sum()-mask.sum()),M_n=int(z.M.sum()),M_known=int(z.M.notna().sum()),S_n=int(z.S.sum()),S_known=int(z.S.notna().sum())))
        g['in_'+stage]=mask;last=mask
    expected=[4769,4609,4393,3966,3964,1959,1816,1816];assert [x['n'] for x in flow]==expected,flow
    save(flow,'sample_flow.csv')
    reasons=[]
    for stage,up,cols in [('core','mec_positive',known),('additional','known_core',extra),('healthcare','A_complete_bmi_income',health)]:
        for c in cols:reasons.append(dict(stage=stage,variable=c,denominator=int(masks[up].sum()),missing=int(g.loc[masks[up],c].isna().sum()),note='nonexclusive'))
    save(reasons,'missing_reasons.csv')
    early=[]
    # Upstream profiles are observed-variable descriptions, not imputations of outcomes.
    for step,up,down,wname in [('examination','interview_age','mec_positive','WTINT2YR'),('core_known','mec_positive','known_core','w_mec'),('bmi_income','known_core','A_complete_bmi_income','w_mec')]:
        z=g[masks[up]]
        for col in ['cycle','smoke_status','male','S','M']:
            for val,h in z.groupby(col,dropna=False):
                r=masks[down].loc[h.index];w=h[wname];early.append(dict(step=step,variable=col,level=val,n=len(h),retained=int(r.sum()),fraction=float(r.mean()),weighted_fraction=float(np.average(r,weights=w))))
    save(early,'early_selection_profiles.csv')
    a=g[masks['A_complete_bmi_income']].copy().reset_index(drop=True)
    for key,stage in [('B','B_complete_healthcare'),('AM','AM_actual_morning'),('W','W_positive_fasting_weight'),('F','F_valid_glucose')]:a[key]=a['in_'+stage]
    a['fast_hours']=a.FAST_HR+a.FAST_MN/60;a['ageband']=(a.age//10)*10
    old=pd.read_csv(inputs[1],low_memory=False)
    assert set(a.loc[a.B,'uid'])==set(old.loc[old.definition.eq('hba1c_only')&old.R,'uid'])
    assert set(a.loc[a.F,'uid'])==set(old.loc[old.definition.eq('primary')&old.R,'uid'])
    assert a.W.equals(a.F) and a.loc[a.w_fast.gt(0),'PHDSESN'].eq(0).all()
    timeaud=[]
    for orig,new in [('PHAFSTHR','FAST_HR'),('PHAFSTMN','FAST_MN')]:
        joint=p[[orig,new]].notna().all(axis=1);mismatch=~np.isclose(p.loc[joint,orig],p.loc[joint,new]);timeaud.append(dict(variable=orig,comparison=new,joint_n=int(joint.sum()),mismatched=int(mismatch.sum())));assert not mismatch.any()
    save(timeaud,'fasting_time_audit.csv')
    sampleaud=dict(age_n=len(g),A_n=len(a),B_n=int(a.B.sum()),AM_n=int(a.AM.sum()),W_n=int(a.W.sum()),F_n=int(a.F.sum()),W_equals_F=True,min_F_fast_hours=float(a.loc[a.F,'fast_hours'].min()),max_F_fast_hours=float(a.loc[a.F,'fast_hours'].max()),unknown_F_fast_hours=int(a.loc[a.F,'fast_hours'].isna().sum()),mec_positive_not_examined=int((g.w_mec.gt(0)&g.RIDSTATR.ne(2)).sum()),B_missing_session=int(a.loc[a.B,'PHDSESN'].isna().sum()))
    (RES/'sample_audit.json').write_text(json.dumps(sampleaud,indent=2),encoding='utf-8')
    a.to_csv(ROOT/'data/panel.csv.gz',index=False);g.to_csv(ROOT/'data/age_source.csv.gz',index=False)
    rows=[];b=a[a.B]
    for cols in [['cycle'],['smoke_status'],['M'],['cycle','smoke_status','M']]:
        for keys,z in b.groupby(cols):
            keys=keys if isinstance(keys,tuple) else (keys,);lab=dict(zip(cols,keys))
            for stage in ['AM','W','F']:rows.append(dict(grouping='|'.join(cols),**lab,stage=stage,n=len(z),retained=int(z[stage].sum()),fraction=float(z[stage].mean()),weighted_fraction=float(np.average(z[stage],weights=z.w_mec))))
    save(rows,'selection_by_group.csv')
    rows=[]
    for stage in STAGES:
        ww=weights(a,stage);z=a.loc[ww>0];w=ww[ww>0]
        for col in ['age','male','bmi','income_ratio','M','S']:
            rows.append(dict(stage=stage,variable=col,level='mean',n=len(z),weighted_value=float(np.average(z[col],weights=w))))
        for col in ['smoke_status','cycle','PHDSESN']:
            for val in sorted(a[col].dropna().unique()):rows.append(dict(stage=stage,variable=col,level=val,n=int(z[col].eq(val).sum()),weighted_value=float(np.average(z[col].eq(val),weights=w))))
    save(rows,'stage_descriptives.csv')
    cells=[];ranges=[];extrap=[]
    for cy,s,sex,age in product(sorted(a.cycle.unique()),[0,1,2],[0,1],[50,60,70]):
        zz=a[a.cycle.eq(cy)&a.smoke_status.eq(s)&a.male.eq(sex)&a.ageband.eq(age)]
        cells.append(dict(cycle=cy,smoke_status=s,male=sex,ageband=age,B_n=int(zz.B.sum()),F_n=int(zz.F.sum()),F_M=int(zz.loc[zz.F,'M'].sum()),F_S=int(zz.loc[zz.F,'S'].sum())))
    for cy,s in product(sorted(a.cycle.unique()),[0,1,2]):
        for col in ['age','bmi','income_ratio']:
            z=a[a.F&a.cycle.eq(cy)&a.smoke_status.eq(s)]
            target=a[a.B&a.cycle.eq(cy)&a.smoke_status.eq(s)]
            lo,hi=z[col].min(),z[col].max();outside=~target[col].between(lo,hi)
            ranges.append(dict(cycle=cy,smoke_status=s,variable=col,n=len(z),min=lo,max=hi,target_n=len(target),target_outside_n=int(outside.sum()),target_outside_weighted_fraction=float(np.average(outside,weights=target.w_mec))))
    # For counterfactual predictions everyone in B is assigned each exposure.
    for cy,s in product(sorted(a.cycle.unique()),[0,2]):
        f=a[a.F&a.cycle.eq(cy)&a.smoke_status.eq(s)];t=a[a.B&a.cycle.eq(cy)];outside=np.zeros(len(t),bool)
        for col in ['age','bmi','income_ratio']:outside|=~t[col].between(f[col].min(),f[col].max()).to_numpy()
        extrap.append(dict(cycle=cy,counterfactual_smoke=s,target_n=len(t),outside_any_univariate_range_n=int(outside.sum()),weighted_fraction=float(np.average(outside,weights=t.w_mec))))
    save(cells,'support_cells.csv');save(ranges,'support_ranges.csv');save(extrap,'counterfactual_range_support.csv');save(dictionary,'variable_dictionary.csv')
    consumption=[]
    for flag in ['PHQ020','PHQ030','PHQ040','PHQ050','PHQ060']:
        for group,mask in [('B',a.B),('F',a.F)]:
            z=a[mask];consumption.append(dict(group=group,variable=flag,yes_n=int(z[flag].eq(1).sum()),unknown_n=int((z[flag].isna()|~z[flag].isin([1,2])).sum()),n=len(z),note='descriptive_only_not_automatic_invalidity'))
    save(consumption,'intervening_consumption.csv')
    inputs.extend([BASE/'nhanes_selection/results/output_manifest.json',BASE/'nhanes_adjustment/results/output_manifest.json',ROOT/'PROTOCOL.md'])
    (RES/'input_manifest.json').write_text(json.dumps([dict(path=str(x.relative_to(BASE)),sha256=sha(x)) for x in inputs],indent=2),encoding='utf-8')
    import scipy,statsmodels,matplotlib
    (RES/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,statsmodels=statsmodels.__version__,matplotlib=matplotlib.__version__),indent=2),encoding='utf-8')
    print(pd.DataFrame(flow).to_string(index=False));print(json.dumps(sampleaud,indent=2))
if __name__=='__main__':main()
