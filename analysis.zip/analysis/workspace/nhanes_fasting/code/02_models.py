from common import *
from statsmodels.stats.multitest import multipletests

def main():
    g=pd.read_csv(ROOT/'data/panel.csv.gz',low_memory=False);univ=pd.read_csv(ROOT/'data/design.csv')
    estimates=[];changes=[];gaps=[];gapchanges=[];audits=[];failures=[];basis=[];fits={};numerical=[];stored={}
    for model,form in FORMS.items():
        des=design(g,form);X,xx,info=des
        for factor,fi in info.factor_infos.items():
            for obj in fi.state.get('transforms',{}).values():
                if hasattr(obj,'_all_knots'):basis.append(dict(model=model,term=factor.name(),knots=obj._all_knots.tolist(),degree=obj._degree))
        for target,stages in [('own',STAGES),('B_mec',['B_mec','F_mec','F_fast'])]:
            for stage in stages:
                fw=weights(g,stage);tw=fw if target=='own' else weights(g,'B_mec')
                for y in ['M','S']:
                    labels=dict(model=model,target=target,stage=stage,outcome=y)
                    try:v,i,a=marginal(g,y,des,fw,tw)
                    except Exception as e:failures.append(dict(**labels,error=repr(e)));continue
                    key=(model,target,stage,y);fits[key]=(v,i)
                    stored['|'.join(key)+'|estimate']=v;stored['|'.join(key)+'|influence']=i
                    estimates.extend(prev.records(v,i,g,universe=univ,**labels));audits.append(dict(**labels,**a))
                    # Perturb BOTH fit and target weights with independent person directions.
                    for seed in [26091708,26091709]:
                        direction=np.random.default_rng(seed).normal(size=len(g));direction-=direction.mean();eps=1e-4
                        vv=[marginal(g,y,des,fw,tw,multiplier=1+sign*eps*direction)[0] for sign in [-1,1]]
                        error=float(abs((vv[1]-vv[0])/(2*eps)-direction@i).max())
                        numerical.append(dict(**labels,seed=seed,error=error));assert error<1e-6,(labels,error)
                if (model,target,stage,'S') in fits and (model,target,stage,'M') in fits:
                    vs,ii=fits[(model,target,stage,'S')];vm,ij=fits[(model,target,stage,'M')]
                    gaps.extend(prev.records((vs-vm)[[2,3]],(ii-ij)[:,[2,3]],g,universe=univ,names=['S_minus_M_RD','S_minus_M_logOR'],model=model,target=target,stage=stage))
        for target in ['own','B_mec']:
            pairs=dict(PATH)
            if target=='own':pairs.update(healthcare=('A_mec','B_mec'),actual_morning=('B_mec','AM_mec'),positive_weight=('AM_mec','W_mec'),valid_glucose=('W_mec','F_mec'))
            for comparison,(start,end) in pairs.items():
                for y in ['M','S']:
                    if any((model,target,st,y) not in fits for st in [start,end]):continue
                    v0,i0=fits[(model,target,start,y)];v1,i1=fits[(model,target,end,y)]
                    changes.extend(prev.records((v1-v0)[[2,3]],(i1-i0)[:,[2,3]],g,universe=univ,names=['change_RD','change_logOR'],model=model,target=target,comparison=comparison,outcome=y,start=start,end=end))
                if all((model,target,st,y) in fits for st in [start,end] for y in ['M','S']):
                    vm0,im0=fits[(model,target,start,'M')];vs0,is0=fits[(model,target,start,'S')];vm1,im1=fits[(model,target,end,'M')];vs1,is1=fits[(model,target,end,'S')]
                    gapchanges.extend(prev.records((vs1-vm1-vs0+vm0)[[2,3]],(is1-im1-is0+im0)[:,[2,3]],g,universe=univ,names=['change_S_minus_M_RD','change_S_minus_M_logOR'],model=model,target=target,comparison=comparison))
        for stage in ['B_mec','F_mec','F_fast']:
            for y in ['M','S']:
                k=(model,'own',stage,y);kk=(model,'B_mec',stage,y)
                if k not in fits or kk not in fits:continue
                v,i=fits[k];vv,ii=fits[kk]
                changes.extend(prev.records((v-vv)[[2,3]],(i-ii)[:,[2,3]],g,universe=univ,names=['change_RD','change_logOR'],model=model,target='own_minus_common',comparison='target_distribution',outcome=y,start=stage,end=stage))
    for rows,name in [(estimates,'estimates.csv'),(changes,'paired_changes.csv'),(gaps,'definition_gaps.csv'),(gapchanges,'gap_changes.csv'),(audits,'model_audit.csv'),(numerical,'numerical_verification.csv')]:save(rows,name)
    (RES/'unfitted.json').write_text(json.dumps(failures,indent=2),encoding='utf-8');(RES/'fixed_basis.json').write_text(json.dumps(basis,indent=2),encoding='utf-8')
    np.savez_compressed(ROOT/'data/estimates_influences.npz',**stored)
    family=pd.DataFrame(changes).query("model=='both' and target=='own' and metric=='change_logOR' and comparison in ['sample','weight','total']").copy()
    if len(family)==6:family['p_holm']=multipletests(family.p,method='holm')[1]
    save(family,'primary_family_Holm.csv')
    z=pd.DataFrame(estimates).query("model=='both' and target=='own' and stage in ['B_mec','F_mec','F_fast'] and metric=='logOR'").copy()
    for c in ['estimate','lo','hi']:z[c]=np.exp(z[c])
    print(z.to_string(index=False));print(family[['outcome','comparison','estimate','lo','hi','p','p_holm']].to_string(index=False));print('FAILURES',failures)

if __name__=='__main__':main()
