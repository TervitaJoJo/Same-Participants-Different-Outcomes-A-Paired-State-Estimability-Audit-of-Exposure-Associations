from common import *

def main():
    checks={};counts={};g=pd.read_csv(ROOT/'data/panel.csv.gz',low_memory=False);u=pd.read_csv(ROOT/'data/design.csv')
    assert g.uid.is_unique and len(g)==3966 and len(u)==61 and u.strata.nunique()==29
    assert g[['M','S']].isin([0,1]).all().all();assert g.w_mec.gt(0).all();assert g.loc[g.F,'w_fast'].gt(0).all()
    assert g.F.equals(g.W) and (~g.F|g.AM).all() and (~g.AM|g.B).all()
    checks['definitions_domains_and_universe']=True
    for row in json.loads((RES/'input_manifest.json').read_text(encoding='utf-8')):assert sha(BASE/row['path'])==row['sha256'],row
    checks['inputs_unchanged']=True
    for package in ['nhanes_adjustment','nhanes_selection']:
        oldroot=BASE/package;m=json.loads((oldroot/'results/output_manifest.json').read_text(encoding='utf-8'))
        for r in m:assert sha(oldroot/r['path'])==r['sha256'],r
        checks[package+'_unchanged']=True;counts[package+'_file_count']=len(m)
    for r in json.loads((RES/'official_sources.json').read_text(encoding='utf-8')):assert sha(ROOT/r['path'])==r['sha256']
    checks['official_sources_hashed']=True
    estimates=pd.read_csv(RES/'estimates.csv');old7=pd.read_csv(BASE/'nhanes_selection/results/selection_estimates.csv');old6=pd.read_csv(BASE/'nhanes_adjustment/results/same_sample_estimates.csv')
    repro=[];errs=[];knots=[]
    for stage in ['B_mec','F_fast']:
        ix=g.B if stage=='B_mec' else g.F;z=g.loc[ix].copy().reset_index(drop=True);w=z['w_mec' if stage=='B_mec' else 'w_fast']
        for model,form in FORMS.items():
            for y in ['M','S']:
                v,i,a,_=prev.marginal(z,z[y],form,exposure='smoke_status',levels=(0,2),weight=w)
                rr=pd.DataFrame(prev.records(v,i,z,universe=u,stage=stage,model=model,outcome=y));repro.extend(rr.to_dict('records'))
                if stage=='B_mec':old=old7[old7.definition.eq('hba1c_only')&old7.method.eq('cc')&old7.outcome.eq(y)&old7.model.eq(model)]
                elif y=='M':old=old6[old6.outcome.eq('A')&old6.model.eq(model)]
                else:old=old7[old7.definition.eq('primary')&old7.method.eq('cc')&old7.outcome.eq(y)&old7.model.eq(model)]
                merged=rr.merge(old,on='metric',suffixes=('_new','_old'),validate='one_to_one');assert len(merged)==5
                error=max(float(abs(merged[c+'_new']-merged[c+'_old']).max()) for c in ['estimate','se','lo','hi']);assert error<1e-8;errs.append(error)
                fixed=estimates[estimates.stage.eq(stage)&estimates.model.eq(model)&estimates.outcome.eq(y)&estimates.target.eq('own')].set_index('metric')
                for metric in ['RD','logOR']:
                    row=rr[rr.metric.eq(metric)].iloc[0];knots.append(dict(stage=stage,model=model,outcome=y,metric=metric,default_basis_estimate=row.estimate,fixed_basis_estimate=fixed.loc[metric,'estimate'],fixed_minus_default=fixed.loc[metric,'estimate']-row.estimate))
    save(repro,'default_basis_reproduction.csv');save(knots,'basis_change_audit.csv')
    checks['round6_and_round7_defaults_reproduced']=True;counts['max_reproduction_error']=max(errs)
    a=pd.read_csv(RES/'model_audit.csv');assert len(a)==36 and a.converged.all() and a.max_beta.lt(20).all() and a.hessian_condition.lt(1e8).all()
    assert json.loads((RES/'unfitted.json').read_text())==[]
    checks['all_planned_models_stable']=True;counts['model_specifications']=len(a)
    assert estimates.df.eq(32).all() and np.isfinite(estimates[['estimate','se','lo','hi']]).all().all()
    changes=pd.read_csv(RES/'paired_changes.csv');maxerr=0.
    for (model,target,y),z in changes[changes.target.isin(['own','B_mec'])].groupby(['model','target','outcome']):
        for metric in ['change_RD','change_logOR']:
            zz=z[z.metric.eq(metric)].set_index('comparison').estimate;err=abs(zz['sample']+zz['weight']-zz['total']);assert err<1e-12;maxerr=max(maxerr,err)
    archive=np.load(ROOT/'data/estimates_influences.npz')
    for model in FORMS:
        for target in ['own','B_mec']:
            for y in ['M','S']:
                ii=[archive['|'.join([model,target,stage,y,'influence'])] for stage in ['B_mec','F_mec','F_fast']]
                err=float(abs((ii[1]-ii[0])+(ii[2]-ii[1])-(ii[2]-ii[0])).max());assert err<1e-12
                if target=='own':
                    assert np.allclose(archive['|'.join([model,target,'W_mec',y,'influence'])],archive['|'.join([model,target,'F_mec',y,'influence'])],atol=1e-13)
    checks['paired_path_and_influence_identity']=True;counts['max_path_identity_error']=maxerr
    ver=pd.read_csv(RES/'numerical_verification.csv');assert len(ver)==72 and ver.error.max()<1e-6
    checks['independent_directional_derivatives']=True;counts['max_perturbation_error']=float(ver.error.max())
    h=pd.read_csv(RES/'primary_family_Holm.csv');assert len(h)==6 and h.p_holm.notna().all();checks['holm_family_six']=True
    support=pd.read_csv(RES/'support_cells.csv');counts['empty_F_cells']=int(support.F_n.eq(0).sum());counts['minimum_F_cell_n']=int(support.F_n.min());counts['F_cells_under10']=int(support.F_n.lt(10).sum())
    result=dict(status='PASS_WITH_SCOPE_LIMITATIONS',checks=checks,counts=counts,protocol_sha256=sha(ROOT/'PROTOCOL.md'),limitations=['Exploratory ordered decomposition, not causal selection-bias attribution','F/MEC is a diagnostic stage and is not a nationally representative fasting estimate','Actual examination session does not identify randomized initial appointment or refusal reason','Official fasting-weight construction uncertainty is not estimated','Common-target standardization requires model extrapolation; marginal range checks are incomplete','Upstream unobserved outcomes and survival selection remain unidentified','HbA1c and historical diagnosis measure different constructs; no gold standard is claimed'])
    (RES/'final_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
