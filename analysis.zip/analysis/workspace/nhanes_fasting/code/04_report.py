from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import NullFormatter

E=pd.read_csv(RES/'estimates.csv');D=pd.read_csv(RES/'paired_changes.csv');G=pd.read_csv(RES/'definition_gaps.csv');H=pd.read_csv(RES/'primary_family_Holm.csv')
LABELS={'B_mec':'较大HbA1c样本／MEC权重','F_mec':'空腹子样本／MEC权重（诊断性对照）','F_fast':'同一空腹子样本／空腹权重'}
def one(d,**kw):
    for k,v in kw.items():d=d[d[k].eq(v)]
    assert len(d)==1,(kw,len(d));return d.iloc[0]
def est(stage,y,model='both',target='own',metric='logOR'):return one(E,stage=stage,outcome=y,model=model,target=target,metric=metric)
def change(comp,y,target='own',metric='change_logOR'):return one(D,comparison=comp,outcome=y,model='both',target=target,metric=metric)
def fx(r,exp=False,scale=1,digits=2):
    v=np.array([r.estimate,r.lo,r.hi]);v=np.exp(v) if exp else v*scale
    return f'{v[0]:.{digits}f}（{v[1]:.{digits}f}，{v[2]:.{digits}f}）'
def tab(head,rows):return '\n'.join(['| '+' | '.join(head)+' |','| '+' | '.join(['---']*len(head))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows])
def link(path,label):return f'[{label}](<{path.as_posix()}>)'
def img(name,alt):return f'![{alt}]({(ROOT/"figures"/name).as_posix()})'
def export(fig,name):
    for ext in ['png','pdf']:fig.savefig(ROOT/'figures'/f'{name}.{ext}',dpi=240,bbox_inches='tight',facecolor='white')
    plt.close(fig)

def figures():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,ax=plt.subplots(figsize=(10,9));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
    boxes=[('Interviewed, ages 50–79','4,769'),('Positive MEC examination weight','4,609'),('HbA1c, self-report, smoking and demographics known','4,393'),('A: BMI and income also complete','3,966'),('B: Healthcare variables also complete','3,964'),('AM: Actually examined in the morning','1,959'),('W: Positive fasting-subsample weight','1,816'),('F: Valid fasting glucose in the existing definition','1,816')]
    losses=['160: no positive MEC weight','216: core variables missing','427: BMI and/or income missing','2: healthcare information missing','2,005: afternoon/evening session','143: no positive fasting weight','0: no additional glucose exclusion']
    for j,((label,n),yy) in enumerate(zip(boxes,np.linspace(.91,.14,8))):
        color='#E7F1F8' if j in [4,7] else '#F4F4F4'
        ax.add_patch(FancyBboxPatch((.035,yy-.032),.665,.068,boxstyle='round,pad=0.007',facecolor=color,edgecolor='#568099' if j in [4,7] else '#AAAAAA',lw=1))
        ax.text(.052,yy+.009,label,va='center',fontsize=9.7);ax.text(.052,yy-.017,f'n = {n}',va='center',weight='bold',fontsize=10.5)
        if j<7:
            nexty=yy-.11;ax.annotate('',xy=(.35,nexty+.039),xytext=(.35,yy-.04),arrowprops=dict(arrowstyle='->',lw=1,color='#777777'))
            ax.text(.73,yy-.054,losses[j],ha='left',va='center',fontsize=9,wrap=True)
    fig.suptitle('NHANES 2011–2014: fixed-HbA1c analysis domains',fontsize=14,weight='bold',y=.99)
    fig.text(.06,.032,'Nested domains in the chosen order; exclusion counts depend on that order.\nActual examination session does not reveal original random assignment or refusal reasons.\nThe outcome stays HbA1c ≥ 6.5% at every modeled stage; F marks sample membership only.',fontsize=9)
    fig.subplots_adjust(top=.98,bottom=.08,left=.01,right=.92);export(fig,'01_sample_flow')
    fig,axs=plt.subplots(1,2,figsize=(11,4.9),sharey=True)
    for ax,y,title in zip(axs,['M','S'],['HbA1c ≥ 6.5%','Self-reported diagnosis']):
        for k,stage in enumerate(['B_mec','F_mec','F_fast']):
            for j,(target,color,label) in enumerate([('own','#0072B2','Own weighted target'),('B_mec','#D55E00','Common B/MEC target')]):
                r=est(stage,y,target=target);v,lo,hi=np.exp([r.estimate,r.lo,r.hi])
                ax.errorbar(v,k+(j-.5)*.18,xerr=[[v-lo],[hi-v]],fmt='o',color=color,capsize=3,ms=5,label=label if k==0 else None)
        ax.set_xscale('log');ax.set_xlim(.45,1.75);ax.set_xticks([.5,.75,1,1.5],['0.5','0.75','1.0','1.5']);ax.axvline(1,color='#888',lw=1,ls='--');ax.set_ylim(2.55,-.55);ax.set_title(title,weight='bold');ax.set_xlabel('Current vs never: prevalence OR');ax.grid(axis='x',alpha=.15)
        ax.xaxis.set_minor_formatter(NullFormatter())
    axs[0].set_yticks([0,1,2],['B / MEC\nn = 3,964','F / MEC*\nn = 1,816','F / fasting\nn = 1,816'])
    handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.55,.90),ncol=2,frameon=False)
    fig.suptitle('Fixed HbA1c definition: sample restriction and weight replacement',fontsize=13,weight='bold')
    fig.text(.025,.025,'Demographics + BMI + income; fixed spline basis. Survey design t 95% intervals.\n*F/MEC is a diagnostic comparison. Common-target predictions require model support/extrapolation.\nA point estimate crossing 1 is not evidence of a change in causal effect.',fontsize=9)
    fig.tight_layout(rect=[0,.19,1,.82]);export(fig,'02_fixed_definition_path')
    fig,axs=plt.subplots(1,2,figsize=(11,4.9),sharey=True)
    for ax,metric,xlabel,scale in zip(axs,['change_logOR','change_RD'],['Paired change in log prevalence OR','Paired change in prevalence difference (pp)'],[1,100]):
        for k,comp in enumerate(['sample','weight','total']):
            for j,(y,color,label) in enumerate([('M','#0072B2','HbA1c threshold'),('S','#D55E00','Self-report')]):
                r=change(comp,y,metric=metric);v,lo,hi=np.array([r.estimate,r.lo,r.hi])*scale
                ax.errorbar(v,k+(j-.5)*.20,xerr=[[v-lo],[hi-v]],fmt='o',color=color,capsize=3,ms=5,label=label if k==0 else None)
        ax.axvline(0,color='#888',ls='--',lw=1);ax.set_ylim(2.5,-.5);ax.set_xlabel(xlabel);ax.grid(axis='x',alpha=.15)
    axs[0].set_yticks([0,1,2],['Sample: F/MEC − B/MEC','Weight: F/fasting − F/MEC','Total: F/fasting − B/MEC'])
    handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.55,.90),ncol=2,frameon=False)
    fig.suptitle('Ordered path differences with covariance retained',fontsize=13,weight='bold')
    fig.text(.025,.035,'Own weighted targets; demographics + BMI + income. Individual survey t 95% intervals.\nAll six primary logOR comparisons have Holm-adjusted p > 0.05. RD is a secondary scale.\nThese are descriptive analysis-path changes, not causal contributions or explained percentages.',fontsize=9)
    fig.tight_layout(rect=[0,.20,1,.82]);export(fig,'03_paired_path_changes')

def main():
    g=pd.read_csv(ROOT/'data/panel.csv.gz',low_memory=False);a=json.loads((RES/'final_audit.json').read_text());figures()
    excluded=g[g.AM&~g.W].copy();excluded['duration_band']=pd.cut(excluded.fast_hours,[-np.inf,8,24,np.inf],right=False,labels=['less_than_8','8_to_less_than_24','24_or_more']).astype(str)
    duration=[]
    for band,z in excluded.groupby('duration_band'):duration.append(dict(band=band,n=len(z),M_n=int(z.M.sum()),S_n=int(z.S.sum()),current_n=int(z.smoke_status.eq(2).sum()),interpretation='observed_time_not_individual_exclusion_reason'))
    assert {r['band']:r['n'] for r in duration}=={'less_than_8':125,'8_to_less_than_24':14,'24_or_more':4}
    save(duration,'morning_without_fasting_weight_duration.csv')
    profiles=[]
    for group,mask in [('AM_with_weight',g.W),('AM_without_weight',g.AM&~g.W)]:
        for s,z in g[mask].groupby('smoke_status'):profiles.append(dict(group=group,smoke_status=s,n=len(z),M_n=int(z.M.sum()),S_n=int(z.S.sum()),fast_hours_median=float(z.fast_hours.median()),fast_hours_min=float(z.fast_hours.min()),fast_hours_max=float(z.fast_hours.max())))
    save(profiles,'morning_weight_status_profiles.csv')
    primary=[[LABELS[stage],str(int(g.B.sum()) if stage=='B_mec' else int(g.F.sum())),fx(est(stage,'M'),exp=True),fx(est(stage,'S'),exp=True)] for stage in ['B_mec','F_mec','F_fast']]
    path=[]
    for y,lab in [('M','HbA1c实测'),('S','自报诊断')]:
        for comp,clab in [('sample','样本变化'),('weight','权重变化'),('total','总变化')]:
            h=one(H,outcome=y,comparison=comp)
            path.append([lab,clab,fx(change(comp,y),digits=3),fx(change(comp,y,metric='change_RD'),scale=100),f'{h.p:.3f}',f'{h.p_holm:.3f}'])
    intermediate=[]
    for stage,name in [('A_mec','A：无需医疗信息完整'),('B_mec','B：增加医疗信息完整'),('AM_mec','AM：实际上午检查'),('W_mec','W：空腹权重为正'),('F_mec','F：有效血糖')]:
        intermediate.append([name,int((weights(g,stage)>0).sum()),fx(est(stage,'M'),exp=True),fx(est(stage,'S'),exp=True)])
    common=[[LABELS[stage],fx(est(stage,'M',target='B_mec'),exp=True),fx(est(stage,'S',target='B_mec'),exp=True)] for stage in ['B_mec','F_mec','F_fast']]
    baseline=[[LABELS[stage],fx(est(stage,'M',model='baseline'),exp=True),fx(est(stage,'S',model='baseline'),exp=True)] for stage in ['B_mec','F_mec','F_fast']]
    gaps=[[LABELS[stage],fx(one(G,stage=stage,model='both',target='own',metric='S_minus_M_logOR'),digits=3)] for stage in ['B_mec','F_mec','F_fast']]
    sel=pd.read_csv(RES/'selection_by_group.csv');selection=[]
    for s,lab in [(0,'从不吸烟'),(1,'既往吸烟'),(2,'当前吸烟')]:
        am=one(sel,grouping='smoke_status',smoke_status=s,stage='AM');f=one(sel,grouping='smoke_status',smoke_status=s,stage='F')
        selection.append([lab,int(f.n),int(am.retained),int(f.retained),f'{100*am.weighted_fraction:.1f}%',f'{100*f.weighted_fraction:.1f}%'])
    flow=pd.read_csv(RES/'sample_flow.csv');flowlabels=['50–79岁访谈样本','MEC权重为正','HbA1c、自报、吸烟及人口学已知','另要求BMI和收入完整（A）','另要求医疗信息完整（B）','实际上午检查（AM）','空腹权重为正（W）','既有定义下有效血糖（F）']
    flowrows=[[label,int(row.n),int(row.lost_from_previous)] for label,row in zip(flowlabels,flow.itertuples())]
    counts=a['counts'];support=pd.read_csv(RES/'counterfactual_range_support.csv')
    text=f'''# 第八轮阶段性成果：固定HbA1c后，样本与权重分别带来什么变化

2026年9月17日。现有数据足够完成本轮，正文未修改。本轮探索性分析方案在计算效应前记录；官方定义核查澄清也在模型运行前完成。已完成两套模型、两类结局、各自目标与共同目标对照，以及筛选流程、代码复现和成对不确定性核验。

**本轮最重要的增量：较大样本与空腹子样本间的HbA1c关联差异，在固定疾病定义后仍存在于点估计中；更换同一批人的权重几乎不改变HbA1c OR。主要路径为1.07 → 0.85 → 0.85。但差值区间宽，六项主要比较经Holm校正后均未达到0.05，不能写成“已经证明选择偏倚造成保护性”。**

## 1. 固定了什么，改变了什么

NHANES 2011–2014，50–79岁。M固定为HbA1c≥6.5%；S固定为原医生诊断自报（DIQ010：1为是，2/3为否）。比较当前与从不吸烟，既往吸烟单列；当前吸烟保留SMQ040=1或2的修复口径。空腹血糖只用于界定本轮F子样本，**没有参与本轮M的判定**。

主要模型调整吸烟×性别、年龄样条、教育、种族/族裔、周期，以及BMI和收入样条。基函数由上游完整样本A一次确定，随后固定。各样本先分别拟合、标准化到各自加权分布；再做同一B/MEC目标的敏感性比较。报告的是横断面患病关联，RD为标准化患病比例之差，不是发病风险或因果效应。

两周期的MEC/空腹权重均除以2。F/MEC是为了隔离计算步骤的诊断性对照，**正式空腹子样本总体推断仍应使用相应空腹权重**。权重教程说明其包含额外抽样概率与组件非应答调整；本轮没有再叠加自拟选择权重。

## 2. 主结果：固定定义后重现样本差异

{tab(['分析阶段','人数','HbA1c OR（95%CI）','自报OR（95%CI）'],primary)}

图中所有主模型单项OR区间均包含1。这里的“由1以上移到1以下”只是点估计改变，不能等同于已确认保护作用产生或消失。较大HbA1c样本未要求用药信息完整，因此为3,964人；第六轮相应治疗分析为3,958人，两者相差6人。这里与第七轮样本完全一致。

{img('02_fixed_definition_path.png','固定定义的三阶段关联与共同目标对照')}

## 3. 将变化量配对计算，而不是比较两组独立置信区间

样本项=B/MEC→F/MEC；权重项=F/MEC→F/空腹；总变化=B/MEC→F/空腹。使用同一完整调查设计中对齐的影响函数，保留同人和重叠样本协方差。下表均为末项减首项；RD单位为百分点（pp），负值表示当前吸烟关联更偏负方向。

{tab(['结局','变化项','ΔlogOR（95%CI）','ΔRD，pp（95%CI）','原始p（logOR）','Holm p（logOR）'],path)}

HbA1c的样本变化为−0.225 logOR（−0.528，0.078），同人权重变化为+0.0007（−0.049，0.050）。这定位了点估计变化出现在哪一步，**不能换算为选择偏倚的解释百分比**。它混合了随机子抽样波动、参加检查及空腹资格等构成变化，不能由公开数据分离各原因。

自报样本变化的原始p=0.037，但Holm p=0.222。自报总变化在次要RD尺度的单项区间不跨0，而在主要logOR尺度的区间包含0；两个统计量不是同一个假设检验，必须同时保留，不能选择较显著的尺度作主结论。主要探索性检验族为2个结局×3条logOR路径；所有置信区间是逐项95%区间，不是同时区间。

路径有顺序，只在logOR或RD变化量上精确相加。全体B没有对应空腹权重，无法构造反向顺序，故不作对称分配或因果归因。

{img('03_paired_path_changes.png','保留协方差的样本和权重变化量')}

## 4. 更具体地定位到哪一个筛选环节

{tab(['顺序筛选条件','保留人数','相对上一行减少'],flowrows)}

MEC权重为正后，核心变量缺失剔除216人，其中HbA1c缺失207人、自报缺失4人、吸烟缺失3人、教育缺失3人；这些原因不互斥。之后BMI缺失60人、收入缺失377人，合并剔除427人；医疗信息另缺2人。计数取决于筛选顺序，不能与其他轮次不同顺序的流失数直接相加。

在3,964名B样本中，上午1,959人、下午1,532人、晚上473人。实际上午检查不等同于最初随机安排，下午/晚上不能自动解释为拒绝空腹检查。

固定模型、全部使用MEC权重的中间诊断比较如下：

{tab(['中间样本','人数','HbA1c OR（95%CI）','自报OR（95%CI）'],intermediate)}

HbA1c点估计在B→AM时仅1.07→1.05，在AM→W时为1.05→0.85；后一步ΔlogOR=−0.208（−0.449，0.033）。自报在这两步均向负方向移动，但两个单独步骤的差值区间都包含0。W与F是完全相同的1,816人，**有效血糖这一步没有再减少人数或改变估计**。

上午检查者中143人没有正空腹权重，描述性复核显示125人记录的空腹时长<8小时、14人在8至不足24小时、4人≥24小时。该分组是时长分布描述，不能视为官方逐人排除原因。F中实际时长为8.67–23.15小时，全部已知；FASTQX与GLU共同有记录的小时及分钟完全一致。本轮保留已有有效glu定义，没有凭其他组件的示例强加新的血糖时长规则。OGTT的用药排除规则也未移植到血糖分析。

{tab(['吸烟状态','B人数','AM人数','F人数','进入AM的加权比例','进入F的加权比例'],selection)}

以上比例以B中的MEC权重为描述权重；更详细的周期×吸烟×HbA1c阳性状态表保留了全部小组。比例差异说明组成不同，不单独证明非随机选择或因果偏倚。

{img('01_sample_flow.png','本轮NHANES纳入流程')}

## 5. 共同目标人群与其他敏感性

把三种模型都标准化到同一个B/MEC人群，得到：

{tab(['拟合样本／权重','HbA1c OR（95%CI）','自报OR（95%CI）'],common)}

这与各自目标下的结果接近，说明仅改变标准化人群的边际分布不是本轮点估计移动的主要计算来源；它不证明回归模型无偏。周期×性别×吸烟×十岁年龄段共36个F支持单元均有人，最小8人，1个单元不足10人。反事实预测到当前吸烟状态时，按周期比较年龄/BMI/收入单变量范围，最多约{100*support.weighted_fraction.max():.2f}%的目标加权人群至少一项超出对应F组范围。单变量范围检查不保证联合协变量重叠，也不检验未测混杂。

只调整人口学的结果也完整保留，避免只展示某一调整模型：

{tab(['分析阶段','HbA1c OR（95%CI）','自报OR（95%CI）'],baseline)}

人口学模型中的负向关联在加入BMI和收入后减弱；这是调整后的关联变化，BMI可能同时涉及既有疾病、治疗、吸烟及行为变化，不能直接称为因果中介。

此外，Δ=logOR(S)−logOR(M)必须与OR(S)<1分开：

{tab(['分析阶段','自报−实测的ΔlogOR（95%CI）'],gaps)}

三个Δ区间均包含0，不能凭自报OR<1就认定该负关联由自报漏诊导致。一次HbA1c阈值与既往医生诊断不是同一构念；接受治疗、当前控制达标者也不能自动归为自报错误。

## 6. 对论文故事的实际影响

这一轮补上了“样本入口会怎样改变表面保护性”的量化环节。更稳妥的叙述是：**吸烟的负向患病关联对测量口径、样本入口及调整方式敏感；因此，在解释自报差异前，必须先排除这些分析条件同时变化造成的混淆。**

目前支持的是“定位变化环节并量化其不确定性”，尚不是“完整解释了保护性为什么存在”。可以保留的证据包括：同一数据中BMI/收入调整方向不同；单独对额外缺失重加权影响小（第七轮，依赖缺失假设）；固定HbA1c后仍有样本相关的点估计移动；同人权重替换对HbA1c OR影响小。不能据此推广到所有疾病和CHARLS，也不能把每个探索性变化当成机制发现。

仍未识别的问题包括更早未参加体检/未测HbA1c者的疾病状态、未观测参加原因、存活选择，以及诊断—戒烟—患病之间的完整因果顺序。当前数据足够完成本轮，不需要补数据。下一步优先把前八轮证据整理为“支持／不支持／仍未识别”的有限主线，锁定主疾病与目标估计量，再决定是否需要新分析；本轮未启动纠偏模型或新一轮扩展。

## 7. 可复现性和文件

- {counts['model_specifications']}个计划分析规格均收敛，满足预设系数及Hessian检查，没有隐藏失败模型。规格包含不同标准化目标，拟合结果有复用，不能称为36项独立验证。
- 使用29个分层、61个PSU、设计自由度32；域外影响补零。官方权重视为给定，不能恢复其构造过程的不确定性。
- 72次独立方向扰动检查最大误差{counts['max_perturbation_error']:.2e}；样本项+权重项=总变化的数值误差{counts['max_path_identity_error']:.2e}。
- 第六/七轮默认样条分析被独立复现，估计和区间最大误差{counts['max_reproduction_error']:.2e}。本轮固定基函数主结果与这些对应默认版本数值一致至浮点误差，未混入函数形式改变。
- 第六轮71个、上一轮43个清单内文件散列均未改变；原始数据和正文未覆盖。

{link(ROOT/'PROTOCOL.md','本轮分析方案')} · {link(RES/'final_audit.json','完整核验记录')} · {link(RES/'estimates.csv','全部效应估计')} · {link(RES/'paired_changes.csv','全部成对变化')} · {link(RES/'primary_family_Holm.csv','主要检验族及Holm校正')} · {link(RES/'selection_by_group.csv','详细入选构成')} · {link(ROOT/'README.md','复现说明')}

官方来源：[FASTQX 2011–2012](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2011/DataFiles/FASTQX_G.htm)、[FASTQX 2013–2014](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2013/DataFiles/FASTQX_H.htm)、[GLU 2011–2012](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2011/DataFiles/GLU_G.htm)、[GLU 2013–2014](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2013/DataFiles/GLU_H.htm)、[NHANES权重教程](https://wwwn.cdc.gov/nchs/nhanes/tutorials/weighting.aspx)。页面及纯文本已本地保存并记录SHA-256；教程中其他周期的示例人数没有用于本轮样本计数。
'''
    (ROOT/'第八轮阶段性成果.md').write_text(text,encoding='utf-8')
    readme='''# 第八轮复现说明

本包固定HbA1c阈值，比较B/MEC→F/MEC→F/空腹权重。无新数据需求，无正文修改。先读PROTOCOL.md和阶段性成果。

从项目根目录运行（PowerShell）：

```powershell
$env:PYTHONIOENCODING='utf-8'
$env:OPENBLAS_NUM_THREADS='1'
$env:OMP_NUM_THREADS='1'
& python nhanes_fasting/code/00_sources.py
& python nhanes_fasting/code/01_build.py
& python nhanes_fasting/code/02_models.py
& python nhanes_fasting/code/03_reproduce_audit.py
& python nhanes_fasting/code/04_report.py
& python nhanes_fasting/code/05_finalize.py
```

运行环境见results/environment.json；输入位置与散列见input_manifest.json。依赖前述第六/七轮数据与第四轮survey IF函数，路径均由本项目根目录解析。00_sources优先读取本地缓存；本地计算不上传个体数据。

data/panel.csv.gz为A样本，含嵌套域标记和两套权重；age_source.csv.gz保留更早流程。estimates_influences.npz用于成对协方差复核。文件包含个体层数据，仅作本地研究使用。发布用汇总表在results，图在figures（PNG/PDF）。

本分析采用官方权重给定、固定基函数、Taylor/PSU影响函数及设计t区间。主要Holm族仅六项logOR路径比较，RD与中间节点为敏感性；不作因果归因或比例解释。固定目标不保证共同支持。公开实际检查时段不能还原初始随机安排或排除原因。

05_finalize核对现有审计、检查图像/PDF并生成本包输出散列；不覆盖前七轮。
'''
    (ROOT/'README.md').write_text(readme,encoding='utf-8');print('REPORT AND THREE FIGURE PAIRS WRITTEN')

if __name__=='__main__':main()
