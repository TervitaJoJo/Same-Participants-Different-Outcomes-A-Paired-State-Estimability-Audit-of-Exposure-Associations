from common import *
import re
import fitz
from PIL import Image

def main():
    audit=json.loads((RES/'final_audit.json').read_text(encoding='utf-8'));assert all(audit['checks'].values())
    for x in json.loads((RES/'input_manifest.json').read_text(encoding='utf-8')):assert sha(BASE/x['path'])==x['sha256']
    for package in ['nhanes_adjustment','nhanes_selection']:
        old=BASE/package
        for x in json.loads((old/'results/output_manifest.json').read_text(encoding='utf-8')):assert sha(old/x['path'])==x['sha256']
    report=ROOT/'第八轮阶段性成果.md';s=report.read_text(encoding='utf-8');assert '\ufffd' not in s
    for path in re.findall(r'\]\(<?([A-Z]:/[^)>]+)>?\)',s):assert Path(path).is_file(),path
    figurecheck=[]
    for name in ['01_sample_flow','02_fixed_definition_path','03_paired_path_changes']:
        png=ROOT/'figures'/f'{name}.png';pdf=png.with_suffix('.pdf')
        with Image.open(png) as im:
            size=im.size;im.verify()
        with fitz.open(pdf) as doc:
            assert len(doc)==1 and len(doc[0].get_text())>100
            pix=doc[0].get_pixmap(matrix=fitz.Matrix(.4,.4));assert pix.width>100 and pix.height>100
            texts=doc[0].get_text();assert 'NHANES' in texts or 'HbA1c' in texts
            figurecheck.append(dict(name=name,png_dimensions=size,pdf_pages=len(doc),pdf_text_characters=len(texts),pdf_rendered=True))
    (RES/'delivery_audit.json').write_text(json.dumps(dict(report_utf8=True,report_local_links_exist=True,inputs_and_prior_packages_unchanged=True,figures=figurecheck),indent=2),encoding='utf-8')
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='output_manifest.json')
    rows=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
    (RES/'output_manifest.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False),encoding='utf-8')
    for x in json.loads((RES/'output_manifest.json').read_text(encoding='utf-8')):assert sha(ROOT/x['path'])==x['sha256']
    print(json.dumps(dict(status='DELIVERY_VERIFIED',output_files=len(files),figures=len(figurecheck),report=str(report)),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
