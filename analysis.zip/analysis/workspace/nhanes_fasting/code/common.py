from pathlib import Path
import importlib.util,json,hashlib,platform
import numpy as np
import pandas as pd
from patsy import dmatrix,build_design_matrices
from scipy.special import expit,logit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;RES=ROOT/'results'
spec=importlib.util.spec_from_file_location('round4_common',BASE/'nhanes_robustness/code/common.py');prev=importlib.util.module_from_spec(spec);spec.loader.exec_module(prev)
NAMES=prev.NAMES
BASEFORM='C(smoke_status)*male + bs(age,df=4) + C(edu3) + C(race) + C(cycle)'
FORMS={'baseline':BASEFORM,'both':BASEFORM+' + bs(bmi,df=3) + bs(income_ratio,df=3)'}
STAGES=['A_mec','B_mec','AM_mec','W_mec','F_mec','F_fast']
PATH={'sample':('B_mec','F_mec'),'weight':('F_mec','F_fast'),'total':('B_mec','F_fast')}
def save(rows,name):pd.DataFrame(rows).to_csv(RES/name,index=False,encoding='utf-8-sig')
def sha(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def weights(g,stage):
    pop,wt=stage.split('_');mask=np.ones(len(g),bool) if pop=='A' else g[pop].to_numpy(bool)
    return np.where(mask,g['w_'+wt].fillna(0).to_numpy(float),0.)
def design(g,formula):
    xd=dmatrix(formula,g,return_type='dataframe',NA_action='raise');xx=[]
    for smoke in [0,2]:
        z=g.copy();z['smoke_status']=smoke;xx.append(np.asarray(build_design_matrices([xd.design_info],z)[0]))
    return np.asarray(xd),xx,xd.design_info
def marginal(g,y,des,fitw,targetw,multiplier=None):
    """Fixed basis. Independent fit/target weights, paired empirical-target IF.

    Survey weights are treated as supplied; uncertainty in official weight
    construction is not available. Both weights receive the same perturbation.
    """
    X,xx,_=des;times=np.ones(len(g)) if multiplier is None else multiplier
    fw=np.asarray(fitw,float)*times;tw=np.asarray(targetw,float)*times
    fw=fw/(fw[fw>0].mean());yy=g[y].to_numpy(float)
    f,mu,H=prev.solve(yy,X,fw);bif=((fw*(yy-mu))[:,None]*X)@np.linalg.inv(H)
    audit=dict(n_fit=int((fw>0).sum()),n_target=int((tw>0).sum()),events=int(yy[fw>0].sum()),parameters=X.shape[1],converged=bool(f.converged),max_beta=float(abs(f.params).max()),hessian_condition=float(np.linalg.cond(H)),min_fitted_probability=float(mu[fw>0].min()),max_fitted_probability=float(mu[fw>0].max()),effective_n=float(fw.sum()**2/(fw@fw)))
    assert audit['max_beta']<20 and audit['hessian_condition']<1e8,('unstable_model',audit)
    vs=[];ifs=[];T=tw.sum()
    for x in xx:
        p=expit(x@f.params);v=float(tw@p/T);grad=np.sum((tw*p*(1-p))[:,None]*x,axis=0)/T
        vs.append(v);ifs.append(bif@grad+tw*(p-v)/T)
    a,b=vs;i,j=ifs
    vals=np.array([a,b,b-a,logit(b)-logit(a),np.log(b/a)])
    psi=np.column_stack([i,j,j-i,j/(b*(1-b))-i/(a*(1-a)),j/b-i/a])
    return vals,psi,audit
