from pathlib import Path
import hashlib,json,urllib.request,datetime
from concurrent.futures import ThreadPoolExecutor
import pyreadstat
from html.parser import HTMLParser
class Extract(HTMLParser):
    def __init__(self):super().__init__();self.parts=[];self.skip=0
    def handle_starttag(self,tag,attrs):
        if tag in ['script','style']:self.skip+=1
    def handle_endtag(self,tag):
        if tag in ['script','style']:self.skip=max(0,self.skip-1)
    def handle_data(self,data):
        if not self.skip and data.strip():self.parts.append(data.strip())
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
for d in ['data','results','sources','figures']:(ROOT/d).mkdir(exist_ok=True)

def download(item):
    cycle,suffix,module,kind=item;year=cycle[:4];name=f'{module}_{suffix}'
    url=f'https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/{year}/DataFiles/{name}.{kind}'
    path=ROOT/'sources'/f'{name}.{kind}'
    if not path.exists() or (kind=='htm' and name.encode() not in path.read_bytes()):
        with urllib.request.urlopen(url,timeout=45) as r:data=r.read()
        if kind=='xpt':assert data.startswith(b'HEADER RECORD*******LIBRARY HEADER')
        else:assert name.encode() in data and b'SEQN' in data,'Not a valid codebook'
        path.write_bytes(data)
    if kind=='htm':
        parser=Extract();parser.feed(path.read_text(encoding='utf-8-sig'))
        path.with_suffix('.txt').write_text(' '.join(parser.parts),encoding='utf-8')
    else:
        d,m=pyreadstat.read_xport(str(path));assert d.SEQN.is_unique
    return dict(url=url,file=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())

def main():
    jobs=[]
    for cycle,suffix in [('2011-2012','G'),('2013-2014','H')]:
        for module in ['HUQ','HIQ','DIQ','BPQ','DEMO','SMQ']:
            jobs.append((cycle,suffix,module,'htm'))
            if module in ['HUQ','HIQ']:jobs.append((cycle,suffix,module,'xpt'))
    with ThreadPoolExecutor(max_workers=4) as pool:manifest=list(pool.map(download,jobs))
    (ROOT/'results/download_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('Downloaded/validated',len(manifest),'public source files')
    for module in ['HUQ','DIQ','BPQ']:
        s=(ROOT/'sources'/f'{module}_G.txt').read_text(encoding='utf-8')
        variables={'HUQ':['HUQ030','HUQ051','HUQ040'],'DIQ':['DIQ180'],'BPQ':['BPQ060','BPQ070']}[module]
        for var in variables:
            start=s.find('Variable Name: '+var)
            print(s[start:start+1900])
if __name__=='__main__':main()
