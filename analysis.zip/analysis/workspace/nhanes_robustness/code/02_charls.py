from common import *

def main():
    h=pd.read_csv(BASE/'mechanism_healthcare_20260917/data/healthcare_long.csv.gz',low_memory=False)
    p=pd.read_csv(BASE/'mechanism_healthcare_20260917/data/prospective_screening.csv.gz',low_memory=False)
    effects=[];audits=[];flow=[];changes=[];scenarios=[];support=[];verification=[];cells=[];calibration=[]
    formula='C(smoke_status)*male + bs(age_wave,df=4) + C(edu3) + public_insurance + rural_hukou'
    g=h[h.year==2013].dropna(subset=['exam_recent','age_wave','male','edu3','public_insurance','rural_hukou','baseline_smoke_status']).copy().reset_index(drop=True)
    observe='C(baseline_smoke_status)*exam_recent + bs(age_wave,df=3) + male + C(edu3) + public_insurance + rural_hukou'
    rr=g.smoke_status.notna().to_numpy()
    for keys,z in g.assign(age_decade=(g.age_wave//10)*10).groupby(['male','edu3','age_decade']):
        cells.append(dict(male=keys[0],edu3=keys[1],age_decade=keys[2],n=len(z),never=int(z.smoke_status.eq(0).sum()),former=int(z.smoke_status.eq(1).sum()),current=int(z.smoke_status.eq(2).sum()),unknown=int(z.smoke_status.isna().sum())))
    tasks=[('smoking2013',g,'exam_recent','smoke_status',(0,2),formula,observe,rr)]
    for dis in DIS:
        q=p[p.disease==dis].dropna(subset=['exam_recent','age_wave','male','edu3','current_2011','public_insurance','rural_hukou']).copy()
        for state,z in q.groupby('vital_status'):flow.append(dict(analysis='prospective',disease=dis,status=state,n=len(z),outcome_known_n=int(z.new_diagnosis.notna().sum()),events=int(z.new_diagnosis.sum())))
        z=q[q.vital_status=='alive'].copy().reset_index(drop=True);z['E']=z.exam_recent
        for c in ['outpatient_raw','hospital_raw']:z[c+'_category']=z[c].fillna(-1)
        form='E + bs(age_wave,df=4) + male + C(edu3) + current_2011 + public_insurance + rural_hukou'
        oform='E + bs(age_wave,df=3) + male + C(edu3) + current_2011 + public_insurance + rural_hukou + C(outpatient_raw_category) + C(hospital_raw_category)'
        tasks.append((dis,z,'new_diagnosis','E',(0,1),form,oform,z.new_diagnosis.notna().to_numpy()))
    for name,g,y,exposure,levels,form,oform,rr in tasks:
        fits={}
        for method,target,ipw,cap in [('complete_cases','observed',False,None),('common_target','all',False,None),('ipw','all',True,None),('ipw_cap20','all',True,20)]:
            v,i,a,details=marginal(g,g[y],form,exposure,levels,rr,oform,ipw,cap,target)
            effects+=records(v,i,g,analysis=name,method=method,n=len(g),n_observed=int(rr.sum()))
            audits.append(dict(analysis=name,method=method,**a));fits[method]=(v,i)
            if method=='ipw':
                temp=pd.DataFrame(dict(observed=rr,predicted=details['observation_probability']))
                temp['bin']=pd.qcut(temp.predicted,10,duplicates='drop')
                for b,z in temp.groupby('bin',observed=True):calibration.append(dict(analysis=name,bin=str(b),n=len(z),observed_rate=z.observed.mean(),predicted_rate=z.predicted.mean()))
                for status,z in g.assign(observed=rr,observation_probability=details['observation_probability']).groupby('observed'):
                    support.append(dict(analysis=name,observed=status,n=len(z),pmin=z.observation_probability.min(),p05=z.observation_probability.quantile(.05),p50=z.observation_probability.median(),p95=z.observation_probability.quantile(.95)))
                # Independent directional perturbation of every estimating equation.
                rng=np.random.default_rng(20260917);direction=rng.normal(size=len(g));direction-=direction.mean();eps=1e-4
                vv=[]
                for sign in [-1,1]:vv.append(marginal(g,g[y],form,exposure,levels,rr,oform,True,multiplier=1+sign*eps*direction)[0])
                err=float(abs((vv[1]-vv[0])/(2*eps)-direction@i).max());assert err<1e-6
                verification.append(dict(analysis=name,derivative_error=err))
                if name in DIS:
                    for delta0,delta1 in [(1,1),(.5,2),(2,.5)]:
                        expected=expit(logit(details['factual_probability'])+np.log(np.where(g.E.eq(1),delta1,delta0)))
                        yy=np.where(rr,g[y].fillna(0),expected)
                        sv,_,_,_=marginal(g,yy,form)
                        scenarios.append(dict(disease=name,missing_odds_multiplier_no_exam=delta0,missing_odds_multiplier_exam=delta1,n=len(g),missing_n=int((~rr).sum()),risk0=sv[0],risk1=sv[1],RR=np.exp(sv[4]),RD=sv[2]))
        for method in ['ipw','ipw_cap20']:
            v,i=fits[method];v0,i0=fits['common_target']
            changes+=records((v-v0)[[2,4]],(i-i0)[:,[2,4]],g,names=['change_RD','change_logRR'],analysis=name,contrast=method+'_minus_common_target')
        print('CHARLS',name,'n=',len(g),'observed=',int(rr.sum()),flush=True)
    for year in [2013,2015]:
        z=h[(h.year==year)&h.age_wave.between(50,79)&h.male.eq(1)].dropna(subset=['smoke_status','exam_recent','edu3','public_insurance','rural_hukou']).copy()
        form='C(smoke_status) + bs(age_wave,df=4) + C(edu3) + public_insurance + rural_hukou'
        v,i,a,_=marginal(z,z.exam_recent,form,'smoke_status',(0,2));effects+=records(v,i,z,analysis=f'smoking{year}',method='men50_79',n=len(z),n_observed=len(z));audits.append(dict(analysis=f'smoking{year}',method='men50_79',**a))
    save(effects,'charls_estimates.csv');save(audits,'charls_model_audit.csv');save(flow,'charls_survival_flow.csv');save(changes,'charls_paired_changes.csv');save(scenarios,'charls_missing_outcome_scenarios.csv');save(support,'charls_observation_support.csv');save(verification,'numerical_verification.csv')
    save(cells,'charls_smoking_cells.csv');save(calibration,'charls_observation_calibration.csv')
    print(pd.DataFrame(effects).query("metric=='RD' and analysis.str.startswith('smoking')").to_string(index=False))
    print(pd.DataFrame(effects).query("metric=='logRR' and not analysis.str.startswith('smoking')").to_string(index=False))
if __name__=='__main__':main()
