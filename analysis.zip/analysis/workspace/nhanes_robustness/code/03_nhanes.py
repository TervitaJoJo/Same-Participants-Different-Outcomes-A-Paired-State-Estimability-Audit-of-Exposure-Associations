from common import *
import pyreadstat
SOURCE=[];DICT=[]

def read(path,cols):
    d,m=pyreadstat.read_xport(str(path),usecols=cols);assert d.SEQN.is_unique
    SOURCE.append(dict(path=str(path.relative_to(BASE)),sha256=sha(path)))
    for c in cols:DICT.append(dict(path=str(path.relative_to(BASE)),variable=c,label=m.column_names_to_labels.get(c)))
    return d

def build():
    out=[];checks=[]
    for cycle,suffix in [('2011-2012','G'),('2013-2014','H')]:
        dr=BASE/'NHANES'/cycle
        d=read(dr/f'DEMO_{suffix}.xpt',['SEQN','RIDAGEYR','RIAGENDR','DMDEDUC2','RIDRETH3','WTINT2YR','SDMVSTRA','SDMVPSU'])
        for mod,cols in [('SMQ',['SMQ020','SMQ040']),('DIQ',['DIQ010','DIQ180']),('BPQ',['BPQ080','BPQ060','BPQ070']),('HUQ',['HUQ030','HUQ050' if suffix=='G' else 'HUQ051']),('HIQ',['HIQ011'])]:
            path=(ROOT/'sources' if mod in ['HUQ','HIQ'] else dr)/f'{mod}_{suffix}.xpt'
            d=d.merge(read(path,['SEQN',*cols]),on='SEQN',how='left',validate='one_to_one')
        d['cycle']=cycle;d['uid']=cycle+':'+d.SEQN.astype(int).astype(str)
        d['age']=d.RIDAGEYR;d['male']=d.RIAGENDR.map({1:1.,2:0.})
        d['edu3']=d.DMDEDUC2.map({1:0.,2:0.,3:1.,4:2.,5:2.});d['race']=d.RIDRETH3.where(d.RIDRETH3.isin([1,2,3,4,6,7]))
        d['smoke_status']=np.select([d.SMQ020.eq(2),d.SMQ020.eq(1)&d.SMQ040.eq(3),d.SMQ020.eq(1)&d.SMQ040.isin([1,2])],[0.,1.,2.],default=np.nan)
        d['weight']=d.WTINT2YR/2;d['strata']=cycle+':'+d.SDMVSTRA.astype(int).astype(str);d['cluster']=d.strata+':'+d.SDMVPSU.astype(int).astype(str)
        d['insurance']=d.HIQ011.map({1:1.,2:0.})
        d['usual_care']=d.HUQ030.map({1:1.,2:0.,3:1.})
        c='HUQ050' if suffix=='G' else 'HUQ051';maxcode=5 if suffix=='G' else 8
        d['care12m']=np.select([d[c].eq(0),d[c].between(1,maxcode)],[0.,1.],default=np.nan)
        d['glucose3y']=d.DIQ180.map({1:1.,2:0.})
        d['cholesterol_ever']=d.BPQ060.map({1:1.,2:0.}).where(d.BPQ080.eq(2))
        d['cholesterol2y']=np.select([d.BPQ070.isin([1,2]),d.BPQ070.isin([3,4])|d.BPQ060.eq(2)],[1.,0.],default=np.nan)
        for diag,z in d[d.age.between(50,79)].groupby('DIQ010',dropna=False):checks.append(dict(cycle=cycle,check='glucose_test_by_reported_diabetes',diagnosis_code=diag,n=len(z),endpoint_known=int(z.glucose3y.notna().sum())))
        for diag,z in d[d.age.between(50,79)].groupby('BPQ080',dropna=False):checks.append(dict(cycle=cycle,check='cholesterol_test_by_reported_diagnosis',diagnosis_code=diag,n=len(z),endpoint_known=int(z.cholesterol2y.notna().sum()),ever_question_known=int(z.BPQ060.isin([1,2]).sum())))
        out.append(d)
    d=pd.concat(out,ignore_index=True);assert d.uid.is_unique
    d.to_csv(ROOT/'data/nhanes_questionnaire.csv.gz',index=False)
    save(checks,'nhanes_skip_audit.csv');save(DICT,'nhanes_variable_dictionary.csv')
    (RES/'nhanes_input_manifest.json').write_text(json.dumps(SOURCE,indent=2),encoding='utf-8')
    return d

def main():
    d=build();domain=d[d.age.between(50,79)&d.weight.gt(0)].copy();results=[];flow=[];audit=[];descs=[];diffs=[];support=[]
    jobs=[('usual_care','usual_care',domain),('care12m_2011','care12m',domain[domain.cycle=='2011-2012']),('care12m_2013','care12m',domain[domain.cycle=='2013-2014']),('glucose3y_no_diabetes','glucose3y',domain[domain.DIQ010.eq(2)]),('glucose3y_no_or_borderline','glucose3y',domain[domain.DIQ010.isin([2,3])]),('cholesterol_ever_no_diagnosis','cholesterol_ever',domain[domain.BPQ080.eq(2)]),('cholesterol2y_all','cholesterol2y',domain)]
    form='C(smoke_status)*male + bs(age,df=4) + C(edu3) + C(race)'
    for name,y,z in jobs:
        cols=[y,'smoke_status','age','male','edu3','race']
        universe=d[d.cycle.isin(z.cycle.unique())]
        iform=form+(' + C(cycle)' if z.cycle.nunique()>1 else '')
        g=z.dropna(subset=cols).copy()
        flow.append(dict(endpoint=name,n_age_domain=len(domain),n_eligible=len(z),n_endpoint_known=int(z[y].notna().sum()),n_primary=len(g),n_insurance_complete=int(g.insurance.notna().sum()),events=int(g[y].sum())))
        for (cy,s),gg in g.groupby(['cycle','smoke_status']):
            descs.append(dict(endpoint=name,cycle=cy,smoke_status=s,n=len(gg),events=int(gg[y].sum()),weighted_rate=np.average(gg[y],weights=gg.weight)))
        for (sex,edu,s),gg in g.groupby(['male','edu3','smoke_status']):support.append(dict(endpoint=name,male=sex,edu3=edu,smoke_status=s,n=len(gg),events=int(gg[y].sum())))
        fits={}
        gi=g.dropna(subset=['insurance']).copy()
        for label,gg,ff in [('primary',g,iform),('insurance_complete_base',gi,iform),('plus_insurance',gi,iform+' + insurance')]:
            v,i,a,_=marginal(gg,gg[y],ff,'smoke_status',(0,2),weight=gg.weight)
            results+=records(v,i,gg,universe=universe,endpoint=name,model=label,n=len(gg));audit.append(dict(endpoint=name,model=label,**a));fits[label]=(v,i)
            # Validate weighted standardization using independent case-weight perturbation.
            if name=='glucose3y_no_diabetes' and label=='primary':
                direction=np.random.default_rng(203).normal(size=len(gg));direction-=direction.mean();eps=1e-4
                vs=[marginal(gg,gg[y],ff,'smoke_status',(0,2),weight=gg.weight,multiplier=1+sign*eps*direction)[0] for sign in [-1,1]]
                error=float(abs((vs[1]-vs[0])/(2*eps)-direction@i).max());assert error<1e-6
                (RES/'nhanes_numerical_verification.json').write_text(json.dumps(dict(derivative_error=error)),encoding='utf-8')
        v,i=fits['plus_insurance'];v0,i0=fits['insurance_complete_base']
        diffs+=records((v-v0)[[2]],(i-i0)[:,[2]],gi,universe=universe,names=['change_RD'],endpoint=name,contrast='plus_insurance_minus_same_sample_base')
        print('NHANES',name,'n=',len(g),flush=True)
    save(results,'nhanes_estimates.csv');save(flow,'nhanes_sample_flow.csv');save(audit,'nhanes_model_audit.csv');save(descs,'nhanes_descriptives.csv');save(diffs,'nhanes_paired_changes.csv');save(support,'nhanes_support.csv')
    print(pd.DataFrame(results).query("metric=='RD' and model=='primary'").to_string(index=False))
if __name__=='__main__':main()
