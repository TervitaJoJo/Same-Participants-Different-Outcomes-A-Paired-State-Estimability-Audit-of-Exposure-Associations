from common import *
import platform
from importlib.metadata import version

def main():
    checks={};prior=BASE/'mechanism_healthcare_20260917'
    previous=json.loads((prior/'results/output_manifest.json').read_text(encoding='utf-8'))
    checks['previous_round_outputs_unchanged']=all(sha(prior/r['path'])==r['sha256'] for r in previous)
    originals=json.loads((prior/'results/input_manifest.json').read_text(encoding='utf-8'))
    checks['previous_round_raw_and_derived_inputs_unchanged']=all(sha(BASE/r['path'])==r['sha256'] for r in originals)
    downloads=json.loads((RES/'download_manifest.json').read_text(encoding='utf-8'))
    checks['public_downloads_intact']=all(sha(ROOT/r['file'])==r['sha256'] for r in downloads)
    checks['valid_codebook_content']=all((ROOT/r['file']).stem in (ROOT/r['file']).read_text(encoding='utf-8') and 'SEQN' in (ROOT/r['file']).read_text(encoding='utf-8') for r in downloads if r['file'].endswith('.htm'))
    manifests=[dict(path=str((prior/'data'/f).relative_to(BASE)),sha256=sha(prior/'data'/f)) for f in ['healthcare_long.csv.gz','prospective_screening.csv.gz']]
    manifests+=json.loads((RES/'nhanes_input_manifest.json').read_text(encoding='utf-8'))
    checks['inputs_match_manifest']=all(sha(BASE/r['path'])==r['sha256'] for r in manifests)
    (RES/'input_manifest.json').write_text(json.dumps(manifests,indent=2),encoding='utf-8')
    nmodel=0;metric_errors=[]
    for country,label in [('charls',['analysis','method']),('nhanes',['endpoint','model'])]:
        est=pd.read_csv(RES/f'{country}_estimates.csv');audit=pd.read_csv(RES/f'{country}_model_audit.csv');nmodel+=len(audit)
        assert np.isfinite(est[['estimate','se','lo','hi']]).all().all()
        assert audit.converged.all()
        for _,g in est.groupby(label):
            v=g.set_index('metric').estimate;a,b=v.risk0,v.risk1
            metric_errors.extend([abs(v.RD-b+a),abs(v.logOR-logit(b)+logit(a)),abs(v.logRR-np.log(b/a))])
        assert len(audit)==est.groupby(label).ngroups
    checks['all_models_converged_finite']=True;checks['metric_identities']=bool(max(metric_errors)<1e-10)
    numerical=pd.read_csv(RES/'numerical_verification.csv').derivative_error.max()
    numerical=max(numerical,json.loads((RES/'nhanes_numerical_verification.json').read_text())['derivative_error'])
    checks['independent_perturbation_inference']=bool(numerical<1e-6)
    old=pd.read_csv(prior/'results/all_standardized_models.csv');new=pd.read_csv(RES/'charls_estimates.csv');replicate=[]
    for dis in DIS:
        v=old[(old.analysis=='screening_future_diagnosis')&(old.disease==dis)&(old.scope=='main')].set_index('metric').estimate
        u=new[(new.analysis==dis)&(new.method=='complete_cases')].set_index('metric').estimate
        replicate.append(float(abs(v-u).max()))
    checks['prior_prospective_point_estimates_reproduced']=max(replicate)<1e-8
    nh=pd.read_csv(ROOT/'data/nhanes_questionnaire.csv.gz');design=nh.groupby('strata').cluster.nunique()
    checks['nhanes_strata_have_at_least_two_psus']=bool(design.ge(2).all())
    checks['unique_nhanes_person_cycle']=bool(nh.uid.is_unique)
    checks['nhanes_correct_current_smoking']=bool((nh.loc[nh.smoke_status.eq(2),'SMQ020'].eq(1)&nh.loc[nh.smoke_status.eq(2),'SMQ040'].isin([1,2])).all())
    checks['disease_skip_not_encoded_as_no_test']=bool(nh.loc[nh.DIQ010.eq(1),'glucose3y'].isna().all() and nh.loc[nh.BPQ080.eq(1),'cholesterol_ever'].isna().all())
    checks['nhanes_fractional_weights_positive']=bool(nh.weight.gt(0).all())
    fs=pd.read_csv(RES/'charls_survival_flow.csv')
    checks['deaths_not_used_as_negative_outcomes']=bool(fs[fs.status!='alive'].outcome_known_n.eq(0).all())
    smry=pd.read_csv(RES/'nhanes_sample_flow.csv');des=pd.read_csv(RES/'nhanes_descriptives.csv')
    for _,r in smry.iterrows():
        z=des[des.endpoint==r.endpoint];assert z.n.sum()==r.n_primary and z.events.sum()==r.events
    checks['descriptive_and_model_counts_match']=True
    assert all(checks.values()),checks
    audit=dict(status='PASS',checks=checks,reported_model_count=nmodel,max_identity_error=max(metric_errors),max_derivative_error=numerical,max_prior_reproduction_error=max(replicate),nhanes_design_strata=int(len(design)),nhanes_design_psus=int(design.sum()),protocol_sha256=sha(ROOT/'PROTOCOL.md'),previous_output_file_count=len(previous),limitations=['Exploratory pointwise 95% intervals; no multiplicity adjustment','CHARLS inverse observation weights require conditional ignorability and correctly specified models','Deaths and unknown survival excluded from survivor target; survival bias not removed','NHANES cross-sectional exposure/outcome histories; no causal or temporal chain inference','HUQ medical-contact definition differs across cycles; estimated separately'])
    (RES/'final_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    environment=dict(python=platform.python_version(),packages={k:version(k) for k in ['numpy','pandas','scipy','statsmodels','patsy','pyreadstat','matplotlib']})
    (RES/'environment.json').write_text(json.dumps(environment,indent=2),encoding='utf-8')
    print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
