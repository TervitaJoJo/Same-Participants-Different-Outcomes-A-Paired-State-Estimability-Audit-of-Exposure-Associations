from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1];RES=ROOT/'results';FIG=ROOT/'figures'
FIG.mkdir(exist_ok=True)

def fmt(v,lo,hi,scale=100):
    return f'{v*scale:.2f}（{lo*scale:.2f}，{hi*scale:.2f}）'
def rr(row):
    return f'{np.exp(row.estimate):.2f}（{np.exp(row.lo):.2f}，{np.exp(row.hi):.2f}）'
def one(d,**kw):
    for k,v in kw.items():d=d[d[k]==v]
    assert len(d)==1,(kw,len(d));return d.iloc[0]
def table(head,rows):
    return '\n'.join(['| '+' | '.join(head)+' |','| '+' | '.join(['---']*len(head))+' |']+['| '+' | '.join(map(str,x))+' |' for x in rows])
def link(p,label):return f'[{label}](<{p.as_posix()}>)'
def image(p,alt):return f'![{alt}]({p.as_posix()})'
def export(fig,name):
    for ext in ['png','pdf']:fig.savefig(FIG/f'{name}.{ext}',dpi=240,bbox_inches='tight',facecolor='white')
    plt.close(fig)

def figures():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    c=pd.read_csv(RES/'charls_estimates.csv');n=pd.read_csv(RES/'nhanes_estimates.csv')
    specs=[('usual_care','Usual source of care'),('care12m_2011','12-month contact, 2011–12'),('care12m_2013','12-month contact, 2013–14'),('glucose3y_no_diabetes','3-year glucose test,\nno reported diabetes'),('cholesterol_ever_no_diagnosis','Cholesterol ever,\nno reported high cholesterol'),('cholesterol2y_all','2-year cholesterol test, all')]
    fig,ax=plt.subplots(figsize=(12,6.2))
    for k,(ep,lab) in enumerate(specs):
        for off,model,title,color in [(-.14,'insurance_complete_base','Demographic adjustment','#0072B2'),(.14,'plus_insurance','Also adjusted for insurance','#D55E00')]:
            r=one(n,endpoint=ep,model=model,metric='RD');v,lo,hi=np.array([r.estimate,r.lo,r.hi])*100
            ax.errorbar(v,k+off,xerr=[[v-lo],[hi-v]],fmt='o',color=color,capsize=3,ms=5,label=title if k==0 else None)
            ax.text(4,k+off,f'{v:.2f} [{lo:.2f}, {hi:.2f}]',va='center',fontsize=9,color=color)
    ax.axvline(0,color='#666',ls='--',lw=1);ax.set_xlim(-16,12);ax.set_yticks(range(len(specs)),[x[1] for x in specs]);ax.set_ylim(len(specs)-.5,-.7)
    ax.set_xlabel('Current vs never smokers: probability difference (percentage points)')
    ax.set_title('NHANES 2011–2014: healthcare sources and reported testing',pad=44,weight='bold');ax.grid(axis='x',alpha=.18);ax.legend(loc='lower left',bbox_to_anchor=(0,1.00),frameon=False,ncol=2,fontsize=9)
    fig.text(.03,.01,'Within each row, both models use identical insurance-complete cases, ages 50–79.\nInterview-weighted estimates; bars: design-based t 95% intervals. Medical contact differs in definition across cycles.\nTesting histories and medical sources are distinct from CHARLS routine examinations; no pooled cross-country effect is estimated.',fontsize=9,va='bottom')
    fig.tight_layout(rect=[0,.16,1,1]);export(fig,'01_cross_database_contact')
    s=pd.read_csv(RES/'charls_missing_outcome_scenarios.csv')
    fig,ax=plt.subplots(figsize=(10,5));diseases=['hypertension','diabetes','dyslipidaemia'];labels=['Hypertension','Diabetes','Dyslipidaemia']
    # Exact multipliers in the legend avoid ambiguity about the two missing groups.
    for j,(dm0,dm1,name,col) in enumerate([(1,1,'Both groups ×1','#777777'),(.5,2,'No exam ×0.5; exam ×2','#0072B2'),(2,.5,'No exam ×2; exam ×0.5','#D55E00')]):
        for i,dis in enumerate(diseases):
            r=one(s,disease=dis,missing_odds_multiplier_no_exam=dm0,missing_odds_multiplier_exam=dm1)
            y=i+(j-1)*.18;ax.plot(r.RR,y,'o',color=col,ms=6,label=name if i==0 else None);ax.text(1.64,y,f'{r.RR:.2f}',va='center',fontsize=9,color=col)
    ax.axvline(1,color='#666',ls='--');ax.set_xlim(.85,1.73);ax.set_xticks([.9,1,1.1,1.2,1.3,1.4,1.5]);ax.set_yticks(range(3),labels);ax.set_ylim(2.6,-.6);ax.set_xlabel('Scenario risk ratio: exam vs no exam');ax.set_title('CHARLS: unobserved diagnosis outcomes among known survivors',weight='bold',pad=44);ax.grid(axis='x',alpha=.18)
    ax.legend(loc='lower left',bbox_to_anchor=(0,1),frameon=False,ncol=3,fontsize=9)
    fig.text(.03,.01,'Legend gives the diagnosis-odds multipliers for people whose follow-up diagnosis is unknown.\nThese are illustrative model scenarios with no confidence intervals, not observed effects or formal bounds.\nDeaths and unknown survival are outside the target population.',fontsize=9,va='bottom')
    fig.tight_layout(rect=[0,.20,1,1]);export(fig,'02_charls_missing_outcome_scenarios')
    cal=pd.read_csv(RES/'charls_observation_calibration.csv')
    fig,axs=plt.subplots(1,2,figsize=(10,4.8))
    for analysis,label,col in [('smoking2013','Smoking status 2013','#0072B2'),('hypertension','Hypertension outcome','#D55E00'),('diabetes','Diabetes outcome','#009E73'),('dyslipidaemia','Dyslipidaemia outcome','#CC79A7')]:
        z=cal[cal.analysis==analysis];ax=axs[0] if analysis=='smoking2013' else axs[1]
        ax.plot(z.predicted_rate,z.observed_rate,'o-',color=col,ms=4,label=label,lw=1)
    for ax,lim in zip(axs,[(.2,1.02),(.82,1.0)]):
        ax.plot(lim,lim,'--',color='#777',lw=1);ax.set_xlim(lim);ax.set_ylim(lim);ax.set_xlabel('Mean fitted observation probability');ax.set_ylabel('Observed fraction');ax.legend(frameon=False,fontsize=8);ax.grid(alpha=.15)
    fig.suptitle('CHARLS: observation-model calibration in fitted probability groups',weight='bold')
    fig.text(.04,.01,'Descriptive calibration in the fitting sample. Agreement does not test the MAR assumption or validate causal inference.',fontsize=9)
    fig.tight_layout(rect=[0,.10,1,.95]);export(fig,'03_observation_calibration')

def report():
    c=pd.read_csv(RES/'charls_estimates.csv');n=pd.read_csv(RES/'nhanes_estimates.csv');flow=pd.read_csv(RES/'charls_survival_flow.csv');nf=pd.read_csv(RES/'nhanes_sample_flow.csv');sc=pd.read_csv(RES/'charls_missing_outcome_scenarios.csv');audit=json.loads((RES/'final_audit.json').read_text(encoding='utf-8'))
    smoke=[]
    for method,name in [('complete_cases','完整可观测案例'),('common_target','相同目标人群'),('ipw','可观测概率加权'),('ipw_cap20','加权并截断20')]:
        r=one(c,analysis='smoking2013',method=method,metric='RD');smoke.append([name,f'{int(r.n):,}',f'{int(r.n_observed):,}',fmt(r.estimate,r.lo,r.hi)])
    surv=[]
    for dis,zh in [('hypertension','高血压'),('diabetes','糖尿病'),('dyslipidaemia','血脂异常')]:
        for method,name in [('complete_cases','完整案例'),('ipw','已知存活者加权')]:
            r=one(c,analysis=dis,method=method,metric='logRR');surv.append([zh,name,f'{int(r.n):,}',f'{int(r.n_observed):,}',rr(r)])
    men=[]
    for year in [2013,2015]:
        r=one(c,analysis=f'smoking{year}',method='men50_79',metric='RD');men.append([year,f'{int(r.n):,}',fmt(r.estimate,r.lo,r.hi)])
    nhrows=[]
    names={'usual_care':'固定医疗来源','care12m_2011':'过去12个月就医（2011–12）','care12m_2013':'过去12个月就医（2013–14）','glucose3y_no_diabetes':'未报告糖尿病，近3年血糖检查','glucose3y_no_or_borderline':'未报告糖尿病/边缘性，近3年血糖检查','cholesterol_ever_no_diagnosis':'未报告高胆固醇，曾查胆固醇','cholesterol2y_all':'过去两年胆固醇检查'}
    for ep in names:
        r=one(n,endpoint=ep,model='primary',metric='RD');rb=one(n,endpoint=ep,model='insurance_complete_base',metric='RD');ri=one(n,endpoint=ep,model='plus_insurance',metric='RD')
        nhrows.append([names[ep],f'{int(r.n):,} / {int(ri.n):,}',fmt(r.estimate,r.lo,r.hi),fmt(rb.estimate,rb.lo,rb.hi),fmt(ri.estimate,ri.lo,ri.hi)])
    scen=[]
    for dis,zh in [('hypertension','高血压'),('diabetes','糖尿病'),('dyslipidaemia','血脂异常')]:
        q=sc[sc.disease==dis]
        scen.append([zh,f"{q.iloc[0].RR:.2f}",f"{q.iloc[1].RR:.2f}",f"{q.iloc[2].RR:.2f}"])
    survival=[]
    for dis,zh in [('hypertension','高血压'),('diabetes','糖尿病'),('dyslipidaemia','血脂异常')]:
        q=flow[flow.disease==dis];a=q[q.status=='alive'].iloc[0];d=q[q.status=='dead'].iloc[0];u=q[q.status=='unknown'].iloc[0]
        survival.append([zh,f'{int(a.n):,}',f'{int(a.outcome_known_n):,}',f'{int(d.n):,}',f'{int(u.n):,}'])
    txt=f'''# 第四轮阶段性成果：缺失选择敏感性与NHANES独立复核

2026年9月17日；本轮继续围绕“吸烟者较少进入可报告诊断/检查路径”这一候选机制。已完成CHARLS缺失选择敏感性和NHANES 2011–2012、2013–2014官方公开问卷复核。未修改正文，也未把横断面NHANES结果当作CHARLS纵向因果证据。

**阶段结论：**2013 CHARLS吸烟—体检差异在可观测概率加权后由约−11.2个百分点缩小到−7.2个百分点，方向仍明确；这表明缺失选择可能放大了原始差异，但不能完全消除。CHARLS体检与后续新增糖尿病诊断的RR由1.41变为1.41，血脂异常约1.24变为1.24，高血压仍约1.02。NHANES中固定医疗来源、胆固醇检查和部分糖尿病血检指标也呈当前吸烟者较低，支持机制方向，但医疗接触题目与CHARLS常规体检不完全相同。

## 1. CHARLS 2013吸烟状态缺失

2013分析限于2011吸烟状态、2013体检、人口学和基线可及性变量已知者，共{smoke[0][1]}人；其中2013当期吸烟状态已知{smoke[0][2]}人。使用预测“吸烟状态是否可观测”的模型建立逆可观测概率权重，权重未出现极端值（最大约4.12；截断20不改变结果）。完整案例和共同目标人群的估计仍约−11个百分点；加权后为约−7.2个百分点。

{table(['估计方法','来源人数','吸烟状态已知','当前vs从不：RD（95%区间，百分点）'],smoke)}

这是在条件可忽略缺失假设下的敏感性分析，不是对缺失机制的实证证明。状态未知者与已知者的不可测差异仍可能存在；加权模型使用了体检本身来预测状态可观测性，因此结果只能理解为“按可观测模式重建的目标关联”。

男性50–79岁敏感性中，2013为{fmt(one(c,analysis='smoking2013',method='men50_79',metric='RD').estimate,one(c,analysis='smoking2013',method='men50_79',metric='RD').lo,one(c,analysis='smoking2013',method='men50_79',metric='RD').hi)}，2015为{fmt(one(c,analysis='smoking2015',method='men50_79',metric='RD').estimate,one(c,analysis='smoking2015',method='men50_79',metric='RD').lo,one(c,analysis='smoking2015',method='men50_79',metric='RD').hi)}；方向与主结果一致。这改变了人群范围，不能叫完全修复女性样本少或缺失选择。

来源人群内吸烟状态已知比例为77.9%；本轮额外要求2011吸烟状态已知，因此完整案例点估计−11.21与上一轮−10.70使用的样本不完全相同。真正同一目标人群下，加权前后差异变化为+3.98个百分点（95%区间2.00–5.97），不能把这3.98个百分点称为保护性关联的因果解释量。

## 2. 前瞻性诊断的生存/结局可观测性

死亡和生存未知者没有被填成“未新增诊断”。本轮在2015明确存活者内重新拟合结局可观测概率，并加入2013体检、人口学、2011当前吸烟、医保/户口以及2013医疗接触（缺失单列为一类）。三病权重最大分别约1.65、1.55和1.28，有效样本量仍接近已知结局人数。

{table(['疾病','方法','来源人数','结局已知','体检vs无体检：RR（95%区间）'],surv)}

与完整案例相比，加权后糖尿病RR从1.41变为1.41，血脂异常从1.24变为1.24，高血压从1.02变为1.02；点估计变化很小。这个稳定性只说明对已知存活者中、由本轮观测变量描述的结局缺失较不敏感；没有对存活概率加权，因而不能据此评价幸存者选择或死亡竞争风险已被解决。血脂异常在上一轮连续指标完整子样本中区间跨1的结果仍成立，本轮不将其升级为稳定证据。

{table(['疾病','存活者','结局已知','死亡记录','生存未知'],survival)}

在未观测诊断结局的情景分析中，糖尿病RR约1.30–1.53，血脂异常约1.11–1.39，高血压约0.91–1.13；这是把两组缺失者的诊断odds分别乘以0.5或2得到的模型情景点估计，没有置信区间，也不是正式的识别界。

{table(['疾病','缺失者沿用模型预测（×1）','体检组缺失odds×2、无体检组×0.5','无体检组缺失odds×2、体检组×0.5'],scen)}

{image(FIG/'02_charls_missing_outcome_scenarios.png','CHARLS未观测诊断结局情景分析')}

此外，2013体检早于“2013仍未报告诊断”的风险集入组条件，早期已被体检发现的人会被排除；观察到的后续诊断关联并不等于体检总体检出效应。结局仍是新增报告医生诊断，不是严格的新发疾病。

## 3. NHANES独立复核

从CDC官方公开文件读取两个周期的HUQ、HIQ、DIQ、BPQ、SMQ和人口学模块，50–79岁，使用访谈权重的一半、周期分层和PSU。官方题意显示：2011–2012的HUQ050过去12个月医疗接触包含急诊/家访；2013–2014的HUQ051明确排除急诊、家访和电话。因此两个周期的“过去12个月就医”分开估计。它们是医疗接触历史，不等同CHARLS常规体检。

{table(['NHANES指标','主分析/医保完整人数','主分析RD','医保完整样本基础RD','同样样本加医保RD'],nhrows)}

单位均为百分点，括号为95%区间。模型调整年龄样条、性别、教育、种族/族裔、周期和吸烟×性别；医保模型另加入有无保险。最后两列使用完全相同案例。图中也仅比较最后两列。

{image(FIG/'01_cross_database_contact.png','NHANES同样案例加入医保前后的检查与医疗来源差异')}

固定医疗来源的差异约−6.2个百分点；2013–2014过去12个月就医约−3.4个百分点，但区间包含0，2011–2012同样不明确。未报告糖尿病者近3年血糖检查约−7.1个百分点，基础区间仅刚刚排除0（−14.20至−0.05；探索性P=0.048），加入医保后约−5.5个百分点且区间跨0，不应称为稳定证据。未报告高胆固醇者曾查胆固醇约−6.7个百分点，加入医保后约−5.2个百分点。过去两年胆固醇检查主结果约−8.1个百分点、加医保后−6.2个百分点；该项同时包含已诊断人群中的监测，不全是筛查。

代码本身按题目跳转保留未知：已报告糖尿病者的DIQ180不用于“未检测”；已报告高胆固醇者的BPQ060不用于“未诊断者曾检测”。没有把跳题缺失填成0。

## 4. 对机制故事的含义

现在可以较稳妥地写成三层证据：

1. CHARLS中当前吸烟者报告常规体检较少，2013吸烟状态缺失选择可能放大差异；在本轮加权假设下方向仍明确。
2. 在CHARLS仍未报告诊断的风险集中，体检后新增报告诊断与疾病种类有关：糖尿病最稳定，血脂异常较弱，高血压不明确；结局选择加权后方向基本不变。
3. NHANES独立周期的医疗来源、胆固醇检查和部分糖尿病血检显示相同方向，但题目、时间窗和研究设计不同，只能作为机制方向的外部一致性支持。

这仍不是“吸烟导致少体检”或“少体检造成自报保护性”的因果中介分析。NHANES是横断面；CHARLS的加权依赖缺失模型；未观测健康意识、疾病严重度、死亡竞争风险和社会经济选择仍可能造成偏倚。

NHANES的“未报告该病”分组可能受到既往检查影响，条件分组本身会产生选择；不能把其中的血检差异外推为总体筛查效应。近3年血检也可能发生于当前吸烟状态形成之前。两库未估计可直接合并的同一效应，不进行跨库合并或强行比较百分点大小。

## 5. 审计和下一步

本轮报告的{audit['reported_model_count']}套结局模型规格均收敛；指标恒等式、样本/事件合计、跳题编码、死亡处理、NHANES每层至少两个PSU、输入散列及独立扰动影响函数检查通过。NHANES共29层、61个PSU，其中2011–2012有3层包含3个PSU；计算按实际层内PSU数进行，未假设每层恰好2个。上一轮输出和输入文件未被覆盖，CDC公开下载文件保存了网址、时间和SHA-256。

CHARLS仍未使用人口调查权重，标准化目标是明确限定的分析来源人群；NHANES采用访谈调查权重与分层PSU方差，但未额外校正少量项目缺失。CHARLS置信区间包含可观测概率模型估计的不确定性；两库均采用聚类/设计自由度的t区间。所有区间是探索性逐项95%区间，未作多重比较校正。模型收敛和数值通过不是无偏性证明。

{image(FIG/'03_observation_calibration.png','可观测概率模型在拟合样本中的校准')}

上图按拟合概率分组对照实际可观测率。它是拟合样本内的描述性检查，不能验证条件随机缺失假设。权重分布、有效样本量、吸烟分层人数与校准分组数据均已保存。

最值得继续的工作是：①针对2013缺失吸烟状态做非随机缺失情景或多重插补对照，检验本轮加权的假设敏感性；②在NHANES同一批有实测和自报的病例中，将医疗来源/保险与诊断报告差异相连接，仍把关联调整与因果解释分开；③核实更多CHARLS波次是否能增加严格有序的诊断—戒烟事件。相比继续增加同类模型，第二项更接近当前故事尚缺的“检查机会与口径差异的连接”。

本轮不需要补充数据；公开缺失模块已从CDC补齐。正文继续保留原稿，下一轮如确需更晚随访文件，会列出准确模块、年份和用途。

主要文件：

- {link(ROOT/'第四轮阶段性成果.md','第四轮阶段性报告')}
- {link(RES/'final_audit.json','最终审计')}
- {link(RES/'charls_estimates.csv','CHARLS缺失选择与存活者结局可观测加权结果')}
- {link(RES/'charls_missing_outcome_scenarios.csv','CHARLS缺失结局情景')}
- {link(RES/'nhanes_estimates.csv','NHANES加权复核结果')}
- {link(RES/'nhanes_skip_audit.csv','NHANES跳题审计')}
- {link(RES/'download_manifest.json','CDC公开文件下载与散列')}
- {link(ROOT/'PROTOCOL.md','本轮方案')}

复现顺序为`01_sources.py → 02_charls.py → 03_nhanes.py → 04_audit.py → 05_report.py`。环境和散列文件在`results`内；个体派生文件仅保留本地，不作为公开补充材料。
'''
    path=ROOT/'第四轮阶段性成果.md';path.write_text(txt,encoding='utf-8');return path

def main():
    figures();p=report()
    (ROOT/'README.md').write_text(f'''# 第四轮机制分析包

先读{link(p,'第四轮阶段性成果')}。本包完成CHARLS缺失选择敏感性、NHANES检查/医疗来源独立复核，不修改论文正文。

- `PROTOCOL.md`记录本轮效应计算前计划及根据题意作出的范围调整。
- `code/01_sources.py`下载并验证CDC公开模块/代码本；其余脚本按02至05运行。
- `data/`是本地个体派生数据，不作为公开补充材料。
- `results/`包含全部效应、样本流、支持/校准审计、输入/输出散列和软件版本。
- `sources/`保存公开XPT及官方问卷代码本。
- `figures/`提供PNG/PDF，所有图由保存的汇总结果生成。

分析需要Python、numpy、pandas、scipy、statsmodels、patsy、pyreadstat、matplotlib。设置`OPENBLAS_NUM_THREADS=1`与`OMP_NUM_THREADS=1`；依赖前一轮本地派生输入。RD乘100得到百分点，logRR/logOR须指数化。探索性区间未校正多重比较，因果解释范围见报告。
''',encoding='utf-8')
    manifest=[]
    for q in sorted(ROOT.rglob('*')):
        if not q.is_file() or '__pycache__' in q.parts or q.name=='output_manifest.json':continue
        with q.open('rb') as f:hashed=hashlib.file_digest(f,'sha256').hexdigest()
        manifest.append(dict(path=str(q.relative_to(ROOT)),bytes=q.stat().st_size,sha256=hashed))
    (RES/'output_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    print(p)
if __name__=='__main__':main()
