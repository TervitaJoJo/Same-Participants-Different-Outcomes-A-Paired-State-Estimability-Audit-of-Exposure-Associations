from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import statsmodels.api as sm
from patsy import dmatrix,build_design_matrices
from scipy.special import expit,logit
from scipy.stats import t
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;RES=ROOT/'results'
DIS=['hypertension','diabetes','dyslipidaemia'];NAMES=['risk0','risk1','RD','logOR','logRR']

def save(rows,name):pd.DataFrame(rows).to_csv(RES/name,index=False,encoding='utf-8-sig')
def sha(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def design(form,g,exposure,levels):
    x=dmatrix(form,g,return_type='dataframe',NA_action='raise');xx=[]
    for val in levels:
        z=g.copy();z[exposure]=val;xx.append(np.asarray(build_design_matrices([x.design_info],z)[0]))
    return np.asarray(x),xx

def solve(y,x,w):
    ok=w>0;xx=x[ok];yy=y[ok];ww=w[ok]
    assert np.linalg.matrix_rank(xx)==xx.shape[1],'rank deficient'
    f=sm.GLM(yy,xx,family=sm.families.Binomial(),freq_weights=ww).fit(maxiter=150,tol=1e-11)
    assert f.converged and np.isfinite(f.params).all(),'nonconverged'
    mu=expit(x@f.params);H=x.T@((w*mu*(1-mu))[:,None]*x)
    return f,mu,H

def marginal(g,y,formula,exposure='E',levels=(0,1),observed=None,obs_formula=None,ipw=False,cap=None,target='all',weight=None,multiplier=None):
    """Stacked estimating-equation IF, including fitted observation weights.

    Missing exposure is filled ONLY for design construction at R=0; counterfactual
    matrices set exposure to a known contrast level for every target participant.
    """
    g=g.copy();n=len(g);rr=np.ones(n) if observed is None else np.asarray(observed,float)
    g[exposure]=g[exposure].fillna(levels[0]);X,xx=design(formula,g,exposure,levels)
    y=np.asarray(y,float);assert np.isfinite(y[rr==1]).all();yy=np.where(rr==1,y,0.)
    w=np.ones(n) if weight is None else np.asarray(weight,float);w=w/w.mean()
    times=np.ones(n) if multiplier is None else np.asarray(multiplier,float);bw=w*times
    aa={};obsp=np.ones(n);alpha_if=None;Z=None
    if ipw:
        assert obs_formula is not None
        Z=np.asarray(dmatrix(obs_formula,g,NA_action='raise'))
        af,obsp,Ha=solve(rr,Z,bw);alpha_if=((bw*(rr-obsp))[:,None]*Z)@np.linalg.inv(Ha)
        aa=dict(obs_parameters=Z.shape[1],obs_hessian_condition=float(np.linalg.cond(Ha)),obs_max_beta=float(abs(af.params).max()),obs_min_probability=float(obsp.min()),obs_max_probability=float(obsp.max()))
    inverse=1/obsp
    if cap is not None:inverse=np.minimum(inverse,cap)
    weights=bw*rr*inverse;f,mu,H=solve(yy,X,weights)
    score=(weights*(yy-mu))[:,None]*X
    if ipw:
        active=np.ones(n) if cap is None else (1/obsp<cap).astype(float)
        J=-(X.T@((weights*(1-obsp)*(yy-mu)*active)[:,None]*Z))
        score+=alpha_if@J.T
    beta_if=score@np.linalg.inv(H)
    targetw=bw*(rr if target=='observed' else 1);total=targetw.sum();probs=[];influences=[]
    for x in xx:
        p=expit(x@f.params);v=np.sum(targetw*p)/total;grad=np.sum((targetw*p*(1-p))[:,None]*x,axis=0)/total
        probs.append(v);influences.append(beta_if@grad+targetw*(p-v)/total)
    a,b=probs;i,j=influences
    vals=np.array([a,b,b-a,logit(b)-logit(a),np.log(b/a)])
    psi=np.column_stack([i,j,j-i,j/(b*(1-b))-i/(a*(1-a)),j/b-i/a])
    actual=weights[rr==1]
    audit=dict(n_source=n,n_observed=int(rr.sum()),events=float(yy.sum()),parameters=X.shape[1],hessian_condition=float(np.linalg.cond(H)),max_beta=float(abs(f.params).max()),converged=True,weight_min=float(actual.min()),weight_p50=float(np.median(actual)),weight_p95=float(np.quantile(actual,.95)),weight_p99=float(np.quantile(actual,.99)),weight_max=float(actual.max()),effective_n=float(actual.sum()**2/(actual@actual)),capped_n=int(((1/obsp>cap)&(rr==1)).sum()) if cap is not None else 0,**aa)
    return vals,psi,audit,dict(factual_probability=mu,observation_probability=obsp,inverse=inverse)

def covariance(psi,g,universe=None):
    z=pd.DataFrame(psi);z['strata']=g.strata.to_numpy();z['cluster']=g.cluster.to_numpy()
    sums=z.groupby(['strata','cluster']).sum()
    if universe is not None:
        ix=pd.MultiIndex.from_frame(universe[['strata','cluster']].drop_duplicates());sums=sums.reindex(ix,fill_value=0)
    V=np.zeros((psi.shape[1],psi.shape[1]));df=0
    for _,z in sums.groupby(level=0):
        x=z.to_numpy();n=len(x);assert n>=2,'singleton PSU';x=x-x.mean(axis=0);V+=n/(n-1)*(x.T@x);df+=n-1
    return V,df

def records(vals,psi,g,universe=None,names=NAMES,**labels):
    V,df=covariance(psi,g,universe);se=np.sqrt(np.maximum(0,np.diag(V)));q=t.ppf(.975,df)
    return [dict(**labels,metric=k,estimate=float(v),se=float(s),lo=float(v-q*s),hi=float(v+q*s),df=df,p=float(2*t.sf(abs(v/s),df)) if s>0 and k not in ['risk0','risk1'] else np.nan) for k,v,s in zip(names,vals,se)]
