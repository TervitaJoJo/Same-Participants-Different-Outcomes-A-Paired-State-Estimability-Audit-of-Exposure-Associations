from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def main():
    source=BASE/'nhanes_adjustment/data/nhanes_panel.csv.gz';p=pd.read_csv(source,low_memory=False)
    p['R']=p[['bmi','income_ratio']].notna().all(axis=1)
    p['missing_pattern']=np.select([p.bmi.isna()&p.income_ratio.isna(),p.bmi.isna(),p.income_ratio.isna()],['both','bmi_only','income_only'],default='complete')
    # Standardization constants are fixed data-preparation choices, then held in perturbation checks.
    for definition,idx in p.groupby('definition').groups.items():
        for col in ['hba1c','glu']:
            x=p.loc[idx,col];p.loc[idx,col+'_z']=(x-x.mean())/x.std()
    p.to_csv(ROOT/'data/panel.csv.gz',index=False)
    unipath=BASE/'nhanes_adjustment/data/nhanes_person.csv.gz';u=pd.read_csv(unipath,low_memory=False)
    u[['strata','cluster']].drop_duplicates().to_csv(ROOT/'data/design.csv',index=False)
    rows=[];patterns=[];support=[];ranges=[]
    for definition,z in p.groupby('definition'):
        for var in ['cycle','smoke_status','M','S','male','edu3','race']:
            for value,g in z.groupby(var):
                rows.append(dict(definition=definition,variable=var,level=value,n=len(g),complete_n=int(g.R.sum()),complete_fraction=g.R.mean(),weighted_complete_fraction=float(np.average(g.R,weights=g.analysis_weight))))
        for pattern,g in z.groupby('missing_pattern'):patterns.append(dict(definition=definition,pattern=pattern,n=len(g),weighted_fraction=float(g.analysis_weight.sum()/z.analysis_weight.sum())))
        c=z[z.R].copy();c['ageband']=(c.age//10)*10
        for (cycle,smoke,sex,age),g in c.groupby(['cycle','smoke_status','male','ageband']):support.append(dict(definition=definition,cycle=cycle,smoke_status=smoke,male=sex,ageband=age,n=len(g),M_n=int(g.M.sum()),S_n=int(g.S.sum())))
        for (cy,smoke),g in c.groupby(['cycle','smoke_status']):
            for var in ['age','bmi','income_ratio']:ranges.append(dict(definition=definition,cycle=cy,smoke_status=smoke,variable=var,n=len(g),min=g[var].min(),p05=g[var].quantile(.05),p50=g[var].median(),p95=g[var].quantile(.95),max=g[var].max()))
    save(rows,'missingness_by_group.csv');save(patterns,'missing_patterns.csv');save(support,'cycle_support_cells.csv');save(ranges,'cycle_covariate_ranges.csv')
    inputs=[source,unipath,BASE/'nhanes_adjustment/results/output_manifest.json',BASE/'nhanes_adjustment/results/nhanes_estimates.csv',BASE/'nhanes_robustness/code/common.py']
    (RES/'input_manifest.json').write_text(json.dumps([dict(path=str(x.relative_to(BASE)),sha256=sha(x)) for x in inputs],indent=2),encoding='utf-8')
    import scipy,statsmodels
    (RES/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,statsmodels=statsmodels.__version__,matplotlib=matplotlib.__version__),indent=2),encoding='utf-8')
    plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(1,2,figsize=(9,3.7),sharey=True)
    for ax,(definition,title) in zip(axs,[('primary','Fasting glucose or HbA1c'),('hba1c_only','HbA1c only')]):
        z=p[p.definition.eq(definition)]
        for offset,(cy,color) in enumerate(zip(CYCLES,['#0072B2','#D55E00'])):
            y=[]
            for s in [0,1,2]:
                g=z[z.cycle.eq(cy)&z.smoke_status.eq(s)];y.append(100*(1-np.average(g.R,weights=g.analysis_weight)))
            ax.bar(np.arange(3)+(offset-.5)*.34,y,width=.32,label=cy,color=color)
        ax.set_xticks(range(3),['Never','Former','Current']);ax.set_title(title);ax.set_ylim(0,20);ax.legend(frameon=False)
    axs[0].set_ylabel('Weighted BMI/income missing (%)');fig.suptitle('Additional complete-case selection by smoking and cycle',weight='bold');fig.tight_layout();fig.savefig(ROOT/'figures/00_missingness.png',dpi=200);plt.close(fig)
    print(pd.DataFrame(patterns).to_string(index=False));print('BUILD COMPLETE')
if __name__=='__main__':main()
