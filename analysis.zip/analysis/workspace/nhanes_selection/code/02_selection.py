from common import *
def main():
    panel=pd.read_csv(ROOT/'data/panel.csv.gz',low_memory=False);universe=pd.read_csv(ROOT/'data/design.csv')
    effects=[];changes=[];alloc=[];adjustments=[];audits=[];observations=[];balance=[];calibration=[];checks=[];failures=[];benchmarks=[];gaps=[]
    for definition,g in panel.groupby('definition',sort=False):
        g=g.reset_index(drop=True);fits={}
        for method in ['cc','ipw','ipw_cap5']:
            try:ctx=prepare(g,method)
            except (AssertionError,ValueError,np.linalg.LinAlgError) as e:
                failures.append(dict(definition=definition,method=method,stage='observation',error=str(e)));continue
            r=ctx['r'];ww=g.analysis_weight.to_numpy();Z=dmatrix(obs_formula(definition),g,return_type='dataframe')
            if method!='cc':
                inv=ctx['inv'];prob=ctx['obsp']
                observations.append(dict(definition=definition,method=method,n=len(g),complete=int(r.sum()),missing=int((~r).sum()),inverse_min=float(inv[r].min()),inverse_p50=float(np.median(inv[r])),inverse_p95=float(np.quantile(inv[r],.95)),inverse_p99=float(np.quantile(inv[r],.99)),inverse_max=float(inv[r].max()),**ctx['oa']))
                tmp=pd.DataFrame(dict(prob=prob,R=r,w=ww));tmp['bin']=pd.qcut(tmp.prob,10,duplicates='drop')
                for key,z in tmp.groupby('bin',observed=True):calibration.append(dict(definition=definition,method=method,bin=str(key),n=len(z),predicted=np.average(z.prob,weights=z.w),observed=np.average(z.R,weights=z.w)))
            for col in Z:
                x=Z[col].to_numpy();m=np.average(x,weights=ww);sd=np.sqrt(np.average((x-m)**2,weights=ww))
                if sd<1e-10:continue
                mean=np.average(x[r],weights=ctx['tw']);balance.append(dict(definition=definition,method=method,variable=col,source_mean=m,target_mean=mean,standardized_difference=(mean-m)/sd))
            for y in ['M','S']:
                for model,extra in EXTRA.items():
                    labels=dict(definition=definition,method=method,outcome=y,model=model)
                    try:
                        v,i,a=fit(ctx,y,BASEFORM+extra);fits[(method,y,model)]=(v,i);audits.append(dict(**labels,**a));effects.extend(prev.records(v,i,g,universe=universe,**labels,n_source=len(g),n_complete=int(r.sum())))
                    except (AssertionError,ValueError,np.linalg.LinAlgError) as e:failures.append(dict(**labels,stage='outcome',error=str(e)))
                if all((method,y,m) in fits for m in EXTRA):
                    v0,i0=fits[(method,y,'baseline')];vb,ib=fits[(method,y,'bmi')];vs,iss=fits[(method,y,'income')];vf,iff=fits[(method,y,'both')]
                    for model in ['bmi','income','both']:
                        v,i=fits[(method,y,model)];adjustments.extend(prev.records((v-v0)[[2,3]],(i-i0)[:,[2,3]],g,universe=universe,names=['change_RD','change_logOR'],definition=definition,method=method,outcome=y,comparison=model+'_minus_baseline'))
                    for component,v,i in [('BMI',.5*((vb-v0)+(vf-vs)),.5*((ib-i0)+(iff-iss))),('income',.5*((vs-v0)+(vf-vb)),.5*((iss-i0)+(iff-ib)))]:alloc.extend(prev.records(v[[2,3]],i[:,[2,3]],g,universe=universe,names=['allocated_RD','allocated_logOR'],definition=definition,method=method,outcome=y,component=component))
            if method=='ipw' and (method,'M','both') in fits:
                direction=np.random.default_rng(270917).normal(size=len(g));direction-=direction.mean();eps=1e-4;values=[];allocvalues=[]
                for sign in [-1,1]:
                    pert=prepare(g,method,multiplier=1+sign*eps*direction);vf={m:fit(pert,'M',BASEFORM+e)[0] for m,e in EXTRA.items()}
                    values.append(vf['both']);allocvalues.append(.5*((vf['bmi']-vf['baseline'])+(vf['both']-vf['income'])))
                vi=fits[(method,'M','both')][1];aif=.5*(fits[(method,'M','bmi')][1]-fits[(method,'M','baseline')][1]+fits[(method,'M','both')][1]-fits[(method,'M','income')][1])
                for name,vv,ii in [('weighted_standardization',values,vi),('weighted_allocation',allocvalues,aif)]:
                    err=float(abs((vv[1]-vv[0])/(2*eps)-direction@ii).max());assert err<1e-6,(definition,name,err);checks.append(dict(definition=definition,check=name,error=err))
        for method in ['ipw','ipw_cap5']:
            for y in ['M','S']:
                for model in EXTRA:
                    if (method,y,model) in fits and ('cc',y,model) in fits:
                        v,i=fits[(method,y,model)];v0,i0=fits[('cc',y,model)]
                        changes.extend(prev.records((v-v0)[[2,3]],(i-i0)[:,[2,3]],g,universe=universe,names=['change_RD','change_logOR'],definition=definition,method=method,outcome=y,model=model,comparison=method+'_minus_cc'))
        for method in ['cc','ipw','ipw_cap5']:
            for model in EXTRA:
                if (method,'M',model) in fits and (method,'S',model) in fits:
                    v,i=fits[(method,'S',model)];v0,i0=fits[(method,'M',model)]
                    gaps.extend(prev.records((v-v0)[[2,3]],(i-i0)[:,[2,3]],g,universe=universe,names=['delta_RD','delta_logOR'],definition=definition,method=method,model=model))
        for y in ['M','S']:
            v,i,a,_=prev.marginal(g,g[y],BASEFORM,'smoke_status',(0,2),weight=g.analysis_weight)
            benchmarks.extend(prev.records(v,i,g,universe=universe,definition=definition,outcome=y,method='all_source_baseline',n=len(g)))
            for method in ['cc','ipw']:
                if (method,y,'baseline') in fits:
                    v1,i1=fits[(method,y,'baseline')]
                    benchmarks.extend(prev.records((v1-v)[[2,3]],(i1-i)[:,[2,3]],g,universe=universe,names=['change_RD','change_logOR'],definition=definition,outcome=y,method=method+'_minus_source',n=len(g)))
        print(definition,'done; source=',len(g),'complete=',int(g.R.sum()),flush=True)
    for rows,name in [(effects,'selection_estimates.csv'),(changes,'selection_paired_changes.csv'),(alloc,'adjustment_allocations.csv'),(adjustments,'within_method_changes.csv'),(audits,'selection_model_audit.csv'),(observations,'observation_model_audit.csv'),(balance,'observed_variable_balance.csv'),(calibration,'observation_calibration.csv'),(checks,'selection_numerical_verification.csv'),(benchmarks,'source_benchmarks.csv'),(gaps,'definition_gaps.csv')]:save(rows,name)
    (RES/'selection_unfitted.json').write_text(json.dumps(failures,indent=2),encoding='utf-8')
    z=pd.DataFrame(effects).query("definition=='primary' and metric=='logOR' and model in ['baseline','both']").copy()
    for col in ['estimate','lo','hi']:z[col]=np.exp(z[col])
    print(z[['method','outcome','model','estimate','lo','hi']].to_string(index=False));print('FAILURES',failures)
if __name__=='__main__':main()
