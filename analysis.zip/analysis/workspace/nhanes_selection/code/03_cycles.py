from common import *
def main():
    panel=pd.read_csv(ROOT/'data/panel.csv.gz',low_memory=False);universe=pd.read_csv(ROOT/'data/design.csv')
    effects=[];diffs=[];gaps=[];gapdiff=[];audits=[];checks=[];failures=[]
    settings=[dict(cycle=cy,smoke_status=s) for cy in CYCLES for s in [0,2]]
    for definition,g in panel.groupby('definition',sort=False):
        g=g.reset_index(drop=True)
        for method in ['cc','ipw']:
            try:ctx=prepare(g,method)
            except (AssertionError,ValueError,np.linalg.LinAlgError) as e:failures.append(dict(definition=definition,method=method,stage='observation',error=str(e)));continue
            for specification in ['shared_nuisance','all_cycle_interactions']:
                for model in ['baseline','both']:
                    inner='C(smoke_status)*male + bs(age,df=4) + C(edu3) + C(race)'+EXTRA[model]
                    form=inner+' + C(cycle)*C(smoke_status)' if specification=='shared_nuisance' else 'C(cycle)*('+inner+')'
                    fits={}
                    for y in ['M','S']:
                        labels=dict(definition=definition,method=method,specification=specification,model=model,outcome=y)
                        try:
                            v,i,a=standardized(ctx,y,form,settings);audits.append(dict(**labels,**a));cs=[]
                            for k,cy in enumerate(CYCLES):
                                vv,ii=contrast(v,i,2*k,2*k+1);cs.append((vv,ii));effects.extend(prev.records(vv,ii,g,universe=universe,**labels,cycle=cy,n_source=len(g),n_complete=int(g.R.sum())))
                            fits[y]=cs
                            vd,di=cs[1][0]-cs[0][0],cs[1][1]-cs[0][1]
                            diffs.extend(prev.records(vd[[2,3]],di[:,[2,3]],g,universe=universe,names=['cycle_difference_RD','cycle_difference_logOR'],**labels))
                            if definition=='primary' and method=='ipw' and specification=='shared_nuisance' and model=='both' and y=='M':
                                direction=np.random.default_rng(270918).normal(size=len(g));direction-=direction.mean();eps=1e-4;values=[]
                                for sign in [-1,1]:
                                    c=prepare(g,method,multiplier=1+sign*eps*direction);pv,pi,_=standardized(c,y,form,settings)
                                    va=contrast(pv,pi,0,1)[0];vb=contrast(pv,pi,2,3)[0];values.append(vb-va)
                                err=float(abs((values[1]-values[0])/(2*eps)-direction@di).max());assert err<1e-6;checks.append(dict(check='common_target_cycle_difference',error=err))
                        except (AssertionError,ValueError,np.linalg.LinAlgError) as e:failures.append(dict(**labels,stage='outcome',error=str(e)))
                    if set(fits)=={'M','S'}:
                        gv=[];gi=[]
                        for k,cy in enumerate(CYCLES):
                            v0,i0=fits['M'][k];v1,i1=fits['S'][k];dv=(v1-v0)[[2,3]];ii=(i1-i0)[:,[2,3]];gv.append(dv);gi.append(ii)
                            gaps.extend(prev.records(dv,ii,g,universe=universe,names=['delta_RD','delta_logOR'],definition=definition,method=method,specification=specification,model=model,cycle=cy))
                        gapdiff.extend(prev.records(gv[1]-gv[0],gi[1]-gi[0],g,universe=universe,names=['cycle_change_delta_RD','cycle_change_delta_logOR'],definition=definition,method=method,specification=specification,model=model))
            print('cycles',definition,method,'done',flush=True)
    for rows,name in [(effects,'cycle_estimates.csv'),(diffs,'cycle_differences.csv'),(gaps,'cycle_definition_gaps.csv'),(gapdiff,'cycle_gap_differences.csv'),(audits,'cycle_model_audit.csv'),(checks,'cycle_numerical_verification.csv')]:save(rows,name)
    (RES/'cycle_unfitted.json').write_text(json.dumps(failures,indent=2),encoding='utf-8')
    z=pd.DataFrame(effects).query("definition=='primary' and method=='ipw' and specification=='shared_nuisance' and model=='both' and metric=='logOR'").copy()
    for col in ['estimate','lo','hi']:z[col]=np.exp(z[col])
    print(z[['outcome','cycle','estimate','lo','hi']].to_string(index=False));print('FAILURES',failures)
if __name__=='__main__':main()
