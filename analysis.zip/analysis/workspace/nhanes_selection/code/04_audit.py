from common import *
from statsmodels.stats.multitest import multipletests
def main():
    checks={};counts={}
    inputs=json.loads((RES/'input_manifest.json').read_text())
    for x in inputs:assert sha(BASE/x['path'])==x['sha256'],x['path']
    checks['inputs_unchanged']=True;counts['input_count']=len(inputs)
    oldroot=BASE/'nhanes_adjustment';manifest=json.loads((oldroot/'results/output_manifest.json').read_text(encoding='utf-8'))
    for x in manifest:assert sha(oldroot/x['path'])==x['sha256'],x['path']
    checks['round6_outputs_unchanged']=True;counts['round6_output_count']=len(manifest)
    p=pd.read_csv(ROOT/'data/panel.csv.gz',low_memory=False);assert not p.duplicated(['definition','uid']).any()
    assert p.analysis_weight.gt(0).all()
    assert np.array_equal(p.R,p[['bmi','income_ratio']].notna().all(axis=1))
    assert p.groupby('definition').size().to_dict()=={'hba1c_only':4388,'primary':2009}
    assert p.groupby('definition').R.sum().to_dict()=={'hba1c_only':3964,'primary':1816}
    checks['sample_and_R_definition']=True
    e=pd.read_csv(RES/'selection_estimates.csv');old=pd.read_csv(oldroot/'results/nhanes_estimates.csv')
    cc=e[e.definition.eq('primary')&e.method.eq('cc')]
    old=old[old.definition.eq('primary')&old['sample'].eq('complete')&old.exposure.eq('smoke_status')&old.contrast.eq('current_vs_never')&old.outcome.isin(['M','S'])&old.model.isin(EXTRA)]
    merged=cc.merge(old,on=['outcome','model','metric'],validate='one_to_one',suffixes=('_new','_old'));assert len(merged)==40
    errors=[]
    for field in ['estimate','se','lo','hi']:
        err=float((merged[field+'_new']-merged[field+'_old']).abs().max());assert err<1e-8,(field,err);errors.append(err)
    checks['round6_primary_estimates_and_intervals_reproduced']=True;counts['max_reproduction_error']=max(errors)
    for fn in ['selection_unfitted.json','cycle_unfitted.json']:assert json.loads((RES/fn).read_text())==[]
    audits=[]
    for fn in ['selection_model_audit.csv','cycle_model_audit.csv']:
        a=pd.read_csv(RES/fn);assert a.converged.all() and a.max_beta.lt(20).all() and a.hessian_condition.lt(1e8).all();audits.append(a)
    checks['all_reported_models_stable_by_prespecified_checks']=True;counts['model_specs']=sum(len(a) for a in audits)
    inverse=pd.read_csv(RES/'observation_model_audit.csv');assert inverse.inverse_max.lt(5).all()
    aa=e[e.method.eq('ipw')].merge(e[e.method.eq('ipw_cap5')],on=['definition','outcome','model','metric'],suffixes=('_a','_b'),validate='one_to_one')
    assert np.allclose(aa.estimate_a,aa.estimate_b,atol=1e-12);checks['cap5_inactive_and_results_identical']=True
    maxerr=0
    for fn,cols in [('selection_estimates.csv',['definition','method','outcome','model']),('cycle_estimates.csv',['definition','method','specification','outcome','model','cycle'])]:
        t=pd.read_csv(RES/fn);assert np.isfinite(t[['estimate','se','lo','hi']]).all().all() and t.df.eq(32).all()
        for _,a in t.groupby(cols):
            a=a.set_index('metric').estimate;expected=[a.risk1-a.risk0,logit(a.risk1)-logit(a.risk0),np.log(a.risk1/a.risk0)]
            err=float(np.max(abs(np.array(expected)-a[['RD','logOR','logRR']].to_numpy())));assert err<1e-10;maxerr=max(maxerr,err)
    checks['effect_identities_design_df_and_finite_intervals']=True;counts['max_identity_error']=maxerr
    al=pd.read_csv(RES/'adjustment_allocations.csv');ch=pd.read_csv(RES/'within_method_changes.csv')
    for (de,method,y,metric),z in al.groupby(['definition','method','outcome','metric']):
        ref=ch[ch.definition.eq(de)&ch.method.eq(method)&ch.outcome.eq(y)&ch.comparison.eq('both_minus_baseline')&ch.metric.eq(metric.replace('allocated','change'))].iloc[0]
        assert abs(z.estimate.sum()-ref.estimate)<1e-12
    checks['allocation_identity']=True
    cy=pd.read_csv(RES/'cycle_estimates.csv');di=pd.read_csv(RES/'cycle_differences.csv')
    for (de,method,spec,mo,y),z in cy.groupby(['definition','method','specification','model','outcome']):
        for metric in ['RD','logOR']:
            vals=z[z.metric.eq(metric)].set_index('cycle').estimate;ref=di[di.definition.eq(de)&di.method.eq(method)&di.specification.eq(spec)&di.model.eq(mo)&di.outcome.eq(y)&di.metric.eq('cycle_difference_'+metric)].iloc[0]
            assert abs((vals[CYCLES[1]]-vals[CYCLES[0]])-ref.estimate)<1e-12
    checks['cycle_contrasts_identity']=True
    numerical=[]
    for fn in ['selection_numerical_verification.csv','cycle_numerical_verification.csv']:numerical.extend(pd.read_csv(RES/fn).error.tolist())
    assert max(numerical)<1e-6;checks['independent_reweighted_perturbations']=True;counts['max_perturbation_error']=max(numerical)
    sp=pd.read_csv(RES/'selection_paired_changes.csv');family=[]
    for y in ['M','S']:
        rr=sp[sp.definition.eq('primary')&sp.method.eq('ipw')&sp.outcome.eq(y)&sp.model.eq('both')&sp.metric.eq('change_logOR')].iloc[0]
        family.append(dict(test='IPW_minus_CC',outcome=y,estimate=rr.estimate,lo=rr.lo,hi=rr.hi,p=rr.p))
        rr=di[di.definition.eq('primary')&di.method.eq('ipw')&di.specification.eq('shared_nuisance')&di.outcome.eq(y)&di.model.eq('both')&di.metric.eq('cycle_difference_logOR')].iloc[0]
        family.append(dict(test='cycle_difference',outcome=y,estimate=rr.estimate,lo=rr.lo,hi=rr.hi,p=rr.p))
    family=pd.DataFrame(family);family['p_holm']=multipletests(family.p,method='holm')[1];family.to_csv(RES/'primary_family_Holm.csv',index=False)
    result=dict(status='PASS_WITH_SCOPE_LIMITATIONS',checks=checks,counts=counts,protocol_sha256=sha(ROOT/'PROTOCOL.md'),limitations=['Only additional BMI/income missingness is addressed; earlier selection remains','IPW requires a sufficient observation model, conditional missing-at-random and positivity','Cycle estimates share a common pooled covariate target; no causal period effect','Non-significant differences do not establish equivalence','HbA1c sensitivity uses a different sample and laboratory weight'])
    (RES/'final_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2));print(family.to_string(index=False))
if __name__=='__main__':main()
