from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
E=pd.read_csv(RES/'selection_estimates.csv');C=pd.read_csv(RES/'cycle_estimates.csv');DI=pd.read_csv(RES/'cycle_differences.csv')
def one(d,**kw):
    for k,v in kw.items():d=d[d[k].eq(v)]
    assert len(d)==1,(kw,len(d));return d.iloc[0]
def fx(r,exp=False,scale=1,digits=2):
    v=np.array([r.estimate,r.lo,r.hi]);v=np.exp(v) if exp else v*scale
    return f'{v[0]:.{digits}f}（{v[1]:.{digits}f}，{v[2]:.{digits}f}）'
def tab(head,rows):return '\n'.join(['| '+' | '.join(head)+' |','| '+' | '.join(['---']*len(head))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows])
def link(p,label):return f'[{label}](<{p.as_posix()}>)'
def img(name,alt):return f'![{alt}]({(ROOT/"figures"/name).as_posix()})'
def er(y,method,model,definition='primary'):return one(E,definition=definition,outcome=y,method=method,model=model,metric='logOR')
def cr(y,cy,definition='primary',spec='shared_nuisance',method='ipw'):
    return one(C,definition=definition,method=method,specification=spec,model='both',outcome=y,cycle=cy,metric='logOR')
def export(fig,name):
    for ext in ['png','pdf']:fig.savefig(ROOT/'figures'/f'{name}.{ext}',dpi=240,bbox_inches='tight',facecolor='white')
    plt.close(fig)
def figures():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axs=plt.subplots(1,2,figsize=(10,4.5),sharey=True)
    for ax,y,title in zip(axs,['M','S'],['Measured threshold','Reported diagnosis']):
        for j,(method,color,lab) in enumerate([('cc','#0072B2','Complete cases'),('ipw','#D55E00','Missingness reweighted')]):
            for k,model in enumerate(['baseline','both']):
                r=er(y,method,model);v,lo,hi=np.exp([r.estimate,r.lo,r.hi]);ax.errorbar(v,k+(j-.5)*.18,xerr=[[v-lo],[hi-v]],fmt='o',color=color,capsize=3,ms=6,label=lab if k==0 else None)
        ax.axvline(1,color='#777',ls='--',lw=1);ax.set_title(title,weight='bold');ax.set_xscale('log');ax.set_xticks([.4,.6,.8,1,1.2],['0.4','0.6','0.8','1.0','1.2']);ax.set_xlim(.38,1.22);ax.set_ylim(1.5,-.6);ax.set_xlabel('Current vs never: prevalence OR');ax.grid(axis='x',alpha=.15)
    axs[0].set_yticks([0,1],['Demographics','+ BMI and income']);handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.56,.89),ncol=2,frameon=False)
    fig.suptitle('Diabetes associations change little after BMI/income missingness reweighting',weight='bold',fontsize=12)
    fig.text(.025,.025,'NHANES 2011–2014, ages 50–79. Source n = 2,009; complete cases n = 1,816.\nSurvey design t 95% intervals. Reweighting requires the stated missingness-model assumptions.',fontsize=9)
    fig.tight_layout(rect=[0,.17,1,.80]);export(fig,'01_missingness_effects')
    fig,axs=plt.subplots(1,2,figsize=(10,4.5),sharey=True)
    for ax,de,title in zip(axs,['primary','hba1c_only'],['Fasting glucose or HbA1c','HbA1c only (different sample)']):
        for j,(cy,color) in enumerate(zip(CYCLES,['#0072B2','#D55E00'])):
            for k,y in enumerate(['M','S']):
                r=cr(y,cy,de);v,lo,hi=np.exp([r.estimate,r.lo,r.hi]);ax.errorbar(v,k+(j-.5)*.18,xerr=[[v-lo],[hi-v]],fmt='o',color=color,capsize=3,ms=6,label=cy if k==0 else None)
        ax.axvline(1,color='#777',ls='--',lw=1);ax.set_title(title,weight='bold');ax.set_xscale('log');ax.set_xticks([.4,.6,.8,1,1.5,2],['0.4','0.6','0.8','1.0','1.5','2.0']);ax.set_xlim(.32,2.15);ax.set_ylim(1.5,-.6);ax.set_xlabel('Current vs never: prevalence OR');ax.grid(axis='x',alpha=.15)
    axs[0].set_yticks([0,1],['Measured','Self-report']);handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.55,.89),ncol=2,frameon=False)
    fig.suptitle('Cycle comparisons standardized to a common population within each definition',weight='bold',fontsize=12)
    fig.text(.025,.025,'Demographics + BMI + income, with smoking-by-cycle interaction and missingness reweighting.\nTargets: pooled covariate distributions within each definition. Intervals do not establish equivalence.',fontsize=9)
    fig.tight_layout(rect=[0,.17,1,.80]);export(fig,'02_cycle_comparison')
def main():
    figures();models={'baseline':'人口学','both':'＋BMI和收入'};methods={'cc':'完整案例','ipw':'缺失重加权'}
    rows=[]
    for mo in models:
        for method in methods:rows.append([models[mo],methods[method],fx(er('M',method,mo),exp=True),fx(er('S',method,mo),exp=True)])
    paired=pd.read_csv(RES/'selection_paired_changes.csv');al=pd.read_csv(RES/'adjustment_allocations.csv');within=pd.read_csv(RES/'within_method_changes.csv')
    pairedrows=[];allocrows=[]
    for y,lab in [('M','实测'),('S','自报')]:
        z=one(paired,definition='primary',method='ipw',outcome=y,model='both',metric='change_RD');zz=one(paired,definition='primary',method='ipw',outcome=y,model='both',metric='change_logOR')
        pairedrows.append([lab,fx(z,scale=100),fx(zz,digits=3)])
        vals=[fx(one(al,definition='primary',method='ipw',outcome=y,component=x,metric='allocated_RD'),scale=100) for x in ['BMI','income']]
        net=one(within,definition='primary',method='ipw',outcome=y,comparison='both_minus_baseline',metric='change_RD');allocrows.append([lab,*vals,fx(net,scale=100)])
    cyrows=[];diffrows=[];sensrows=[]
    for y,lab in [('M','实测'),('S','自报')]:
        cyrows.append([lab,*[fx(cr(y,cy),exp=True) for cy in CYCLES]])
        rr=one(DI,definition='primary',method='ipw',specification='shared_nuisance',model='both',outcome=y,metric='cycle_difference_logOR');rd=one(DI,definition='primary',method='ipw',specification='shared_nuisance',model='both',outcome=y,metric='cycle_difference_RD')
        diffrows.append([lab,fx(rr,exp=True),fx(rd,scale=100)])
        for de,spec,l in [('primary','all_cycle_interactions','联合定义，全部系数按周期变化'),('hba1c_only','shared_nuisance','较大HbA1c样本，相同调整项')]:sensrows.append([l,lab,*[fx(cr(y,cy,de,spec),exp=True) for cy in CYCLES]])
    o=pd.read_csv(RES/'observation_model_audit.csv');bal=pd.read_csv(RES/'observed_variable_balance.csv');oa=one(o,definition='primary',method='ipw')
    audit=json.loads((RES/'final_audit.json').read_text());counts=audit['counts']
    text=f'''# 第七轮阶段性成果：完整案例选择与跨周期比较

2026年9月17日。现有数据足够完成本轮，正文未改。探索性二次分析，沿用统计分析及可复现核验流程。

**主要结论：在本轮观察模型及缺失假设下，BMI/收入额外缺失的重加权没有明显改变第六轮糖尿病结果。固定联合实测定义并标准化至同一目标人群后，两个周期实测OR点估计均低于1，但区间宽、周期差异不明确，尚不能认定等效或普遍稳定。**

## 1. 本轮具体检查了哪一层选择

主来源样本仍为NHANES 2011–2014、50–79岁、双指标完整且医疗/人口学变量完整的2,009人，使用空腹子样本权重。额外要求BMI及收入完整后为1,816人：仅BMI缺失20人、仅收入缺失171人、两者均缺失2人，共193人（未加权9.61%；按调查权重约6.94%）。

本轮只处理这193人的额外协变量缺失，未解决更早的调查非应答、医疗变量缺失、未进入有效空腹检测样本或生存选择。

以已知年龄、性别、教育、种族、吸烟、周期、疾病状态、生化指标及医疗信息预测BMI/收入完整概率。拟合与边际标准化都使用调查权重×逆完整概率。依赖的假设是：给定这些已测信息后，缺失与尚未观测的BMI/收入条件独立，且观察概率模型充分、具有正性。

{img('00_missingness.png','不同吸烟组与周期的BMI收入缺失比例')}

主分析完整概率预测范围约{oa.obs_min_probability:.3f}–{oa.obs_max_probability:.3f}；完整案例逆概率因子中位数{oa.inverse_p50:.3f}、95百分位{oa.inverse_p95:.3f}、最大{oa.inverse_max:.3f}，没有极端逆概率因子。上限5的敏感性未实际截尾，结果与未截尾一致，不能把两者相同当作独立稳健性证据。

观察模型变量的最大绝对标准化差异从约0.024降至0.001以内，说明**已测信息分布**恢复得较好；这不验证缺失随机假设，也不证明未观测的收入值被正确恢复。

## 2. 缺失重加权对主结果改变很小

当前相对从不吸烟；既往吸烟单列。下表是边际标准化患病OR（逐项设计95%CI）：

{tab(['调整模型','方法','实测OR','自报OR'],rows)}

第六轮四模型、两结局的全部主定义估计与区间已经复现，最大差{counts['max_reproduction_error']:.2e}。缺失加权后，BMI＋收入模型的实测OR约0.73，自报OR约0.75，与完整案例结果接近。二者区间仍跨1，不能宣称偏差已消除。

配对计算“重加权减完整案例”，同时纳入估计观察权重、结局拟合及标准化分布的不确定性：

{tab(['结局','RD变化（百分点，95%CI）','logOR变化（95%CI）'],pairedrows)}

实测RD变化仅约−0.07个百分点（−0.70，0.55），自报约−0.08（−0.59，0.44）。**在所设模型和条件缺失假设下，额外BMI/收入完整案例选择未显示为本轮负向关联的主要解释。**仍不能据此排除依赖未报告收入等未观测因素的非随机缺失。

{img('01_missingness_effects.png','缺失重加权前后糖尿病关联')}

一个可观测基准是无需BMI/收入的全来源人口学模型：实测OR约0.68，自报约0.66；完整案例分别0.65、0.67，重加权分别0.64、0.66。重加权实测估计并未更接近全来源点估计；其与全来源的配对差仍不明确（logOR差−0.048，95%CI −0.145～0.049）。因此不能把“加权”本身当作正确性保证。

## 3. BMI与收入的相反调整方向保留

继续对BMI和收入两种加入顺序取平均，得到指定模型变化的描述性分配。下面都是**百分点**，两项之和等于净变化：

{tab(['结局','BMI分配项（95%CI）','收入分配项（95%CI）','净配对变化（95%CI）'],allocrows)}

实测的BMI分配项约+3.84，收入项约−2.17，净变化约+1.68个百分点、区间跨0，与第六轮接近。保留“两个因素的调整方向相反”这一描述性发现；不把它写成BMI和收入各造成多少疾病或保护性的因果比例。

## 4. 固定目标人群后的两周期比较

主样本2011–2012来源982人、完整案例873人；2013–2014来源1,027人、完整案例943人。年龄范围、糖尿病阈值和吸烟分类均固定。

合并模型加入吸烟×周期交互，再把同一个合并目标样本分别设为两个周期、当前或从不吸烟，保留其余协变量分布。主模型的其他协变量系数在周期间共享；敏感性允许所有系数随周期变化。重加权后标准化的目标是来源样本的协变量分布在所设缺失假设下的估计，不能称为时期干预效应。

BMI＋收入调整、缺失重加权后的主比较：

{tab(['结局','2011–2012 OR（95%CI）','2013–2014 OR（95%CI）'],cyrows)}

两个周期实测点估计都低于1，自报点估计也低于1，但精度不足。2011–2012自报区间刚好不跨1，而2013–2014跨1，**这不是两个周期关联不同的证据**。直接比较2013–2014相对2011–2012：

{tab(['结局','两周期OR之比（95%CI）','RD之差（百分点，95%CI）'],diffrows)}

实测OR之比约0.90（0.48，1.69），自报约1.38（0.67，2.85）；均不精确。主要检验族预设为M/S的两项缺失加权变化及两项周期差异，共4项；Holm校正p值均为1.00。不据此宣称无差异或等效。

自报与实测口径差Δ=logOR(S)−logOR(M)，两周期分别约−0.199（−0.557，0.158）和+0.228（−0.172，0.629）。方向不同而区间均跨0，不能说NHANES两个周期存在一致方向的自报额外偏差，也不能将OR<1等同于Δ<0。

{img('02_cycle_comparison.png','相同目标人群下的周期比较与HbA1c敏感性')}

## 5. 模型与测量定义敏感性全部保留

{tab(['敏感性','结局','2011–2012 OR（95%CI）','2013–2014 OR（95%CI）'],sensrows)}

允许所有系数按周期变化后，联合实测OR约0.86和0.71，区间仍宽；主模型的周期差异不明确并非明显由共享其他协变量系数这一限制产生，但不能因此验证模型完全正确。

较大HbA1c样本来源4,388人、BMI/收入完整3,964人，用MEC权重。本轮只分析M/S，因此未额外要求治疗资料完整，较第六轮该样本多6人。该不同定义和不同样本下，实测OR约1.28和0.90，显示**“实测负向关联在各种定义中都稳定”仍不成立**；不能只保留联合定义的同方向点估计。第六轮已做固定空腹样本的单指标比较，本轮没有把两个不同样本的差异全归因于测量。

最细的周期×吸烟×性别×年龄段完整案例单元格，主定义最小8人、HbA1c定义最小17人。模型没有触发预设的不稳定阈值，但细分人群中的精度和支持仍有限；所有结果仅针对当前分析范围。

## 6. 现在能说到哪一步

本轮完成了两个具体质量检查：第一，按已测信息恢复额外协变量缺失的选择后，主估计及BMI/收入相反调整方向基本保留；第二，在同一目标人群下直接估计周期差异，避免用各自显著性判断差异。

目前可支持的表述是：**糖尿病负向关联在这两个周期的联合实测定义中均有同方向点估计；对额外完整案例重加权改变较小，但其大小仍不精确，且依赖测量定义和样本。现有证据不能把它完整解释为自报漏诊，也不能证明吸烟有保护作用。**

下一步优先核查进入有效空腹检测及早期完整样本的选择，在同一HbA1c定义下拆分样本变化与权重变化；之后将这条“实测关联”线与CHARLS高血压更清楚的“自报—实测差异”线汇总为证据表。当前不需要用户补数据，尚不进入正文改写或校正模型扩展。

## 7. 可复现性与产物

输入{counts['input_count']}项和第六轮{counts['round6_output_count']}个产物散列未变；本轮{counts['model_specs']}套记录的结局回归规格均通过预设收敛/数值检查，失败记录为空。新增影响函数通过独立重加权扰动核验，最大误差{counts['max_perturbation_error']:.2e}。所有区间采用完整调查设计32自由度，共同目标分布和观察模型估计的不确定性均纳入；未只使用普通回归默认标准误。

原始和个体派生数据留在本地，未上传。全部零结果、模型敏感性和条件假设均保留。

- {link(ROOT/'PROTOCOL.md','分析前方案')}
- {link(RES/'missing_patterns.csv','缺失模式与人数')}
- {link(RES/'selection_estimates.csv','缺失重加权全部效应（OR/RR以log值保存）')}
- {link(RES/'selection_paired_changes.csv','配对加权变化')}
- {link(RES/'observation_model_audit.csv','观察概率与权重诊断')}
- {link(RES/'observed_variable_balance.csv','已测变量分布平衡')}
- {link(RES/'cycle_estimates.csv','周期效应全部规格')}
- {link(RES/'cycle_differences.csv','直接估计的周期差异')}
- {link(RES/'primary_family_Holm.csv','预设四项比较与Holm校正')}
- {link(RES/'final_audit.json','最终审计与限制')}

按`01_build_describe.py → 02_selection.py / 03_cycles.py → 04_audit.py → 05_report.py`复现。02与03彼此独立，其余依赖顺序固定。
'''
    path=ROOT/'第七轮阶段性成果.md';path.write_text(text,encoding='utf-8')
    (ROOT/'README.md').write_text(f'''# 第七轮：完整案例选择与跨周期检验

{link(path,'阅读阶段性成果')}。

代码01至05依次运行，02/03可独立执行。设`OPENBLAS_NUM_THREADS=1`、`OMP_NUM_THREADS=1`、`PYTHONIOENCODING=utf-8`。软件版本在`results/environment.json`。

`common.py`新增同时考虑观察概率、回归拟合、重加权标准化分布的影响函数，已做独立数值扰动核验；不会为缺失BMI/收入填一个常数后冒充已知协变量。所有OR/logRR需指数化，RD乘100为百分点。结果为探索性关联，缺失加权依赖条件缺失假设，区间跨零不代表等效。

`data`为本地个体派生资料；公开补充材料只应取经审查的汇总结果与代码。
''',encoding='utf-8')
    manifest=[dict(path=str(f.relative_to(ROOT)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(ROOT.rglob('*')) if f.is_file() and '__pycache__' not in f.parts and f.name!='output_manifest.json']
    (RES/'output_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8');print(path)
if __name__=='__main__':main()
