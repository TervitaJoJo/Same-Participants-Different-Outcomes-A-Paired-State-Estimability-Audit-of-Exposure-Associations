from pathlib import Path
import importlib.util,json,hashlib,platform
import numpy as np
import pandas as pd
from patsy import dmatrix,build_design_matrices
from scipy.special import expit,logit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;RES=ROOT/'results'
for name in ['data','results','figures']:(ROOT/name).mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('round4_common',BASE/'nhanes_robustness/code/common.py');prev=importlib.util.module_from_spec(spec);spec.loader.exec_module(prev)
NAMES=prev.NAMES
BASEFORM='C(smoke_status)*male + bs(age,df=4) + C(edu3) + C(race) + C(cycle)'
EXTRA={'baseline':'','bmi':' + bs(bmi,df=3)','income':' + bs(income_ratio,df=3)','both':' + bs(bmi,df=3) + bs(income_ratio,df=3)'}
CYCLES=['2011-2012','2013-2014']
def save(rows,name):pd.DataFrame(rows).to_csv(RES/name,index=False,encoding='utf-8-sig')
def sha(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def obs_formula(definition):
    form='C(smoke_status)*C(cycle) + male + bs(age,df=3) + C(edu3) + C(race) + M + S + insurance + usual_care + C(cycle):care12m + hba1c_z'
    if definition=='primary':form+=' + glu_z'
    return form
def prepare(g,method='cc',multiplier=None):
    """Full-source IF for observation weights; missing covariates never filled."""
    n=len(g);r=g.R.to_numpy(bool);w=g.analysis_weight.to_numpy(float);w=w/w.mean()
    w=w*(np.ones(n) if multiplier is None else np.asarray(multiplier))
    obsp=np.ones(n);aif=None;Z=None;oa={};cap=5 if method=='ipw_cap5' else None
    if method!='cc':
        Z=np.asarray(dmatrix(obs_formula(g.definition.iloc[0]),g,NA_action='raise'))
        af,obsp,H=prev.solve(r.astype(float),Z,w)
        aif=((w*(r-obsp))[:,None]*Z)@np.linalg.inv(H)
        oa=dict(obs_parameters=Z.shape[1],obs_max_beta=float(abs(af.params).max()),obs_hessian_condition=float(np.linalg.cond(H)),obs_min_probability=float(obsp.min()),obs_max_probability=float(obsp.max()))
        assert oa['obs_max_beta']<20 and oa['obs_hessian_condition']<1e8,('unstable_observation_model',oa)
    inv=1/obsp
    active=np.ones(n) if cap is None else (inv<cap).astype(float)
    if cap is not None:inv=np.minimum(inv,cap)
    tw=w[r]*inv[r]
    return dict(n=n,r=r,gc=g.loc[r].copy(),w=w,tw=tw,obsp=obsp,inv=inv,active=active,alpha_if=aif,Z=Z,method=method,oa=oa)
def standardized(ctx,y,formula,settings):
    """Fit and standardize using identical complete-case/IPW target weights.

    Influence includes outcome score, empirical target distribution and the
    derivative of BOTH weighting uses w.r.t. the fitted observation model.
    settings is a list of replacement dicts for standardized contrasts.
    """
    g=ctx['gc'];r=ctx['r'];n=ctx['n'];tw=ctx['tw'];T=tw.sum()
    xd=dmatrix(formula,g,return_type='dataframe',NA_action='raise');X=np.asarray(xd)
    f,mu,H=prev.solve(g[y].to_numpy(float),X,tw)
    a=dict(n_source=n,n_observed=len(g),events=int(g[y].sum()),parameters=X.shape[1],max_beta=float(abs(f.params).max()),hessian_condition=float(np.linalg.cond(H)),converged=bool(f.converged),effective_n=float(T*T/(tw@tw)),weight_p50=float(np.median(tw)),weight_p95=float(np.quantile(tw,.95)),weight_max=float(tw.max()),inverse_max=float(ctx['inv'][r].max()),capped_n=int((ctx['active'][r]==0).sum()),min_fitted_probability=float(mu.min()),max_fitted_probability=float(mu.max()),**ctx['oa'])
    assert a['max_beta']<20 and a['hessian_condition']<1e8,('unstable_outcome_model',a)
    score=np.zeros((n,X.shape[1]));score[r]=(tw*(g[y].to_numpy()-mu))[:,None]*X
    if ctx['alpha_if'] is not None:
        J=-X.T@((tw*(1-ctx['obsp'][r])*(g[y].to_numpy()-mu)*ctx['active'][r])[:,None]*ctx['Z'][r])
        score+=ctx['alpha_if']@J.T
    bif=score@np.linalg.inv(H);values=[];influences=[]
    for replacements in settings:
        z=g.copy()
        for k,v in replacements.items():z[k]=v
        xx=np.asarray(build_design_matrices([xd.design_info],z)[0]);pred=expit(xx@f.params)
        v=float(tw@pred/T);grad=np.sum((tw*pred*(1-pred))[:,None]*xx,axis=0)/T
        influence=bif@grad;influence[r]+=tw*(pred-v)/T
        if ctx['alpha_if'] is not None:
            direct=-np.sum((tw*(1-ctx['obsp'][r])*ctx['active'][r]*(pred-v))[:,None]*ctx['Z'][r],axis=0)/T
            influence+=ctx['alpha_if']@direct
        values.append(v);influences.append(influence)
    return np.array(values),np.column_stack(influences),a
def contrast(v,i,ref=0,exp=1):
    a,b=v[ref],v[exp];aa,bb=i[:,ref],i[:,exp]
    return np.array([a,b,b-a,logit(b)-logit(a),np.log(b/a)]),np.column_stack([aa,bb,bb-aa,bb/(b*(1-b))-aa/(a*(1-a)),bb/b-aa/a])
def fit(ctx,y,formula):
    v,i,a=standardized(ctx,y,formula,[dict(smoke_status=0),dict(smoke_status=2)])
    vv,ii=contrast(v,i);return vv,ii,a
