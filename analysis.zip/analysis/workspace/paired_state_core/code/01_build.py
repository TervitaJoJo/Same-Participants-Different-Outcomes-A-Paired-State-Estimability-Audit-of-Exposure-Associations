from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
import pyreadstat
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;PREV=BASE/'charls_preparation'
for p in ['data','results','figures']:(ROOT/p).mkdir(exist_ok=True)
SOURCES=set();DICT=[]
def readcsv(p,**kw):SOURCES.add(p);return pd.read_csv(p,low_memory=False,**kw)
def readraw(p,cols):
    SOURCES.add(p)
    f=pyreadstat.read_xport if p.suffix.lower()=='.xpt' else pyreadstat.read_dta
    d,m=f(str(p),usecols=cols)
    for c in d.columns:DICT.append(dict(path=str(p.relative_to(BASE)),variable=c,label=m.column_names_to_labels.get(c),values=json.dumps(m.variable_value_labels.get(c),ensure_ascii=False)))
    return d
def numeric(s):return pd.to_numeric(s,errors='coerce')
def uid(s):return 'CHARLS:'+numeric(s).astype(float).astype(str)
def main():
    names={'r1doctor1m':'outpatient','r1hosp1y':'hospital','r1higov':'public_insurance','r1rural2':'rural_hukou'}
    hc=['ID','ID_w1',*names,'r2iwstat','r3iwstat','r1iwy','r1iwm','r3iwy','r3iwm']
    h=readraw(BASE/'CHARLS/Harmonized_CHARLS/H_CHARLS_D_Data.dta',hc)
    h.ID_w1=h.ID_w1.astype(str).str.strip();h.ID=h.ID.astype(str).str.strip()
    h=h[h.ID_w1.str.fullmatch(r'\d{11}')].copy();assert h.ID_w1.is_unique
    for c in hc[2:]:h[c]=numeric(h[c])
    h=h.rename(columns=names);h['uid']=uid(h.ID_w1)
    assert (h.ID_w1.str[:9]+h.ID_w1.str[9:].str.zfill(3)).eq(h.ID).all()
    for c in names.values():assert set(h[c].dropna())<={0.,1.}
    demo=readraw(BASE/'CHARLS/2011/demographic_background.dta',['ID','communityID','householdID','ba002_1'])
    demo['uid']=uid(demo.ID);demo=demo.rename(columns={'communityID':'community','householdID':'household','ba002_1':'birth_year'})
    w=readcsv(BASE/'CHARLS/analysis/charls_analysis_wide.csv',dtype={'ID':'string'});w['uid']=uid(w.ID)
    extra=h.drop(columns=['ID','ID_w1']).merge(demo[['uid','community','household','birth_year']],on='uid',how='left',validate='one_to_one')
    extra=extra.merge(w[['uid','sbp','dbp','glu','hba1c','cho','ldl']],on='uid',how='left',validate='one_to_one')
    p=readcsv(PREV/'data/two_country_mechanism_panel.csv.gz')
    cc=p[p.dataset=='CHARLS 2011'].merge(extra,on='uid',how='left',validate='many_to_one')
    cc['edu3']=np.select([cc.edu<=4,cc.edu<=7,cc.edu<=10],[0.,1.,2.],default=np.nan)
    cc['cluster']=cc.community.astype(str);cc['strata']='all'
    nh=[]
    for ds,g in p[p.dataset.str.startswith('NHANES')].groupby('dataset'):
        f=next((BASE/'NHANES'/ds.replace('NHANES ','')).glob('DEMO*.xpt'))
        dd=readraw(f,['SEQN','SDMVSTRA','SDMVPSU']);dd['uid']=ds+':'+dd.SEQN.astype(float).astype(str)
        gg=g.merge(dd[['uid','SDMVSTRA','SDMVPSU']],on='uid',how='left',validate='many_to_one')
        assert gg[['SDMVSTRA','SDMVPSU']].notna().all().all()
        gg['edu3']=np.select([gg.edu<=2,gg.edu==3,gg.edu<=5],[0.,1.,2.],default=np.nan)
        gg['strata']=ds+':'+gg.SDMVSTRA.astype(str);gg['cluster']=gg.strata+':'+gg.SDMVPSU.astype(str);nh.append(gg)
    both=pd.concat([cc,*nh],ignore_index=True);assert both[['cluster','strata','edu3']].notna().all().all()
    both.to_csv(ROOT/'data/cross_section.csv.gz',index=False)
    z=readcsv(PREV/'data/charls_longitudinal_rebuilt.csv.gz',dtype={'ID':'string','ID_followup':'string'})
    z['uid']=uid(z.ID)
    z=z.merge(extra,on='uid',how='left',validate='one_to_one')
    z['edu3']=np.select([z.edu<=4,z.edu<=7,z.edu<=10],[0.,1.,2.],default=np.nan)
    source=BASE/'CHARLS/2015/Sample_Infor.dta';si=readraw(source,['ID','died','iyear','imonth']);si=si.rename(columns={'ID':'ID_followup','died':'sample_died','iyear':'sample_year','imonth':'sample_month'})
    z=z.merge(si,on='ID_followup',how='left',validate='one_to_one')
    dead=z.sample_died.eq(1)|z.r3iwstat.isin([5,6])|z.r2iwstat.eq(5)
    alive=z.sample_died.eq(0)|z.r3iwstat.isin([1,4])|z.interview_2015.eq(1)
    z['vital_status']=np.select([dead&alive,dead,alive],['conflict','dead','alive'],default='unknown')
    hp=next((BASE/'CHARLS/2015').glob('*[Hh]ealth*[Ff]unctioning.dta'))
    quitraw=readraw(hp,['ID','da062','da062_1','da062_2']).rename(columns={'ID':'ID_followup'})
    z=z.merge(quitraw,on='ID_followup',how='left',validate='one_to_one')
    z['quit_year_explicit']=numeric(z.da062_2).where(z.da062.eq(2)&numeric(z.da062_2).between(1900,2016))
    z['quit_year_from_age']=(z.birth_year+numeric(z.da062_1)).where(z.da062.eq(1)&numeric(z.da062_1).between(0,110))
    z['time_class']=np.select([z.quit_explicit_2015.ne(1),z.quit_year_explicit.lt(z.r1iwy),z.quit_year_explicit.eq(z.r1iwy),z.quit_year_explicit.gt(z.r3iwy),z.quit_year_explicit.gt(z.r1iwy)&z.quit_year_explicit.le(z.r3iwy),z.quit_year_from_age.notna()],['not_explicit_quitter','before_baseline','same_year_uncertain','after_followup','strictly_after_baseline','age_based_only'],default='missing_time')
    rawh=readraw(BASE/'CHARLS/2011/health_status_and_functioning.dta',['ID','da007_1_','da007_3_','da007_4_','da007_7_','da007_8_','da012','da015_1_a'])
    rawh['uid']=uid(rawh.ID)
    for var,raw in [('cancer','da007_4_'),('heart','da007_7_'),('stroke','da007_8_')]:rawh[var]=rawh[raw].map({1:1.,2:0.})
    z=z.merge(rawh[['uid','cancer','heart','stroke']],on='uid',how='left',validate='one_to_one')
    z.to_csv(ROOT/'data/longitudinal.csv.gz',index=False)
    availability=[]
    for diagnosis,variable in [('da007_1_','da012'),('da007_3_','da015_1_a')]:
        for value,g in rawh.groupby(diagnosis,dropna=False):availability.append(dict(diagnosis_variable=diagnosis,check_variable=variable,diagnosis_code=value,n=len(g),observed_check_n=int(g[variable].notna().sum())))
    pd.DataFrame(availability).to_csv(ROOT/'results/disease_specific_check_availability.csv',index=False)
    flow=[]
    for dis,g in cc.groupby('disease'):
        for c in ['outpatient','hospital','public_insurance','rural_hukou','community']:
            flow.append(dict(disease=dis,variable=c,n=len(g),missing_n=int(g[c].isna().sum())))
    pd.DataFrame(flow).to_csv(ROOT/'results/access_missingness.csv',index=False)
    pd.DataFrame(DICT).to_csv(ROOT/'results/source_dictionary.csv',index=False,encoding='utf-8-sig')
    SOURCES.add(BASE/'CHARLS/Harmonized_CHARLS/H_CHARLS_D_do_file.do')
    manifest=[dict(path=str(p.relative_to(BASE)),sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()) for p in sorted(SOURCES)]
    (ROOT/'results/input_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(pd.DataFrame(flow).to_string(index=False));print('VITAL',z[z.current_2011.eq(1)].vital_status.value_counts().to_dict());print('TIME',z[z.current_2011.eq(1)&z.quit_explicit_2015.eq(1)].time_class.value_counts().to_dict())
if __name__=='__main__':main()
