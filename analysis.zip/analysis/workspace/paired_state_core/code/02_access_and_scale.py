from common import *

def main():
    p=pd.read_csv(ROOT/'data/cross_section.csv.gz',low_memory=False)
    rows=[];flows=[];audit=[];changes=[];uses=[]
    for dis,markers in [('hypertension',['sbp','dbp']),('diabetes',['glu','hba1c']),('dyslipidaemia',['cho','ldl'])]:
        g=p[(p.dataset=='CHARLS 2011')&(p.disease==dis)&p.M.eq(1)].copy()
        n=len(g);g=g.dropna(subset=[*markers,'outpatient','hospital','public_insurance','rural_hukou','cluster','edu3']).reset_index(drop=True)
        g['E']=g.smoke
        base='E + bs(age, df=4) + male + C(edu3) + '+' + '.join(f'bs({x}, df=3)' for x in markers)
        forms=[('severity',base),('plus_access',base+' + public_insurance + rural_hukou'),('plus_use',base+' + public_insurance + rural_hukou + outpatient + hospital')]
        fits=[]
        for label,formula in forms:
            vals,psi,a=binary_marginal(g,g.S,formula);fits.append((vals,psi))
            for rr in estimates(vals,psi,g,['risk_noncurrent','risk_current','RD','logOR']):rows.append(dict(disease=dis,model=label,n=len(g),**rr))
            audit.append(dict(scope='access',disease=dis,model=label,**a))
        for j,label in [(1,'adding_access'),(2,'adding_access_and_use')]:
            val=fits[j][0][2]-fits[0][0][2];ps=fits[j][1][:,2]-fits[0][1][:,2]
            rr=estimates([val],ps[:,None],g,['change_RD'])[0];changes.append(dict(disease=dis,change=label,n=len(g),**rr))
        for outcome in ['outpatient','hospital']:
            v,i,a=binary_marginal(g,g[outcome],base)
            for rr in estimates(v,i,g,['risk_noncurrent','risk_current','RD','logOR']):uses.append(dict(disease=dis,outcome=outcome,n=len(g),**rr))
        for e,z in g.groupby('E'):
            flows.append(dict(disease=dis,current=e,n_before_complete=n,n_complete=len(g),n=len(z),reported_fraction=z.S.mean(),outpatient_fraction=z.outpatient.mean(),hospital_fraction=z.hospital.mean(),insurance_fraction=z.public_insurance.mean(),rural_fraction=z.rural_hukou.mean()))
        print('ACCESS',dis,len(g),flush=True)
    save(rows,'access_standardized_models.csv');save(changes,'access_paired_RD_changes.csv');save(uses,'smoking_medical_use_models.csv');save(flows,'access_sample_flow.csv')
    unified=[]
    for label,sub in [('CHARLS',p[p.dataset=='CHARLS 2011']),('NHANES',p[p.dataset.str.startswith('NHANES')])]:
        for dis,gg in sub.groupby('disease'):
            for ages,g in [('age50_79',gg[gg.age.between(50,79)]),('all_ages',gg)]:
                g=g.copy().reset_index(drop=True)
                # Categorical smoking uses never as reference; include sex interaction.
                form='C(smoke_status) * male + bs(age, df=4) + C(edu3)'
                if label=='NHANES':form+=' + C(dataset)'
                v,i,a=multinomial_marginal(g,form)
                for rr in estimates(v,i,g,JOINT_NAMES):unified.append(dict(dataset=label,disease=dis,age_scope=ages,contrast='current_vs_never',n=len(g),**rr))
                audit.append(dict(scope='unified',dataset=label,disease=dis,ages=ages,contrast='current_vs_never',**a))
                # Same probability machinery and population, binary current comparator.
                gb=g.copy();gb['smoke_status']=np.where(gb.smoke==1,2.,0.)
                v,i,a=multinomial_marginal(gb,form)
                for rr in estimates(v,i,gb,JOINT_NAMES):unified.append(dict(dataset=label,disease=dis,age_scope=ages,contrast='current_vs_noncurrent',n=len(gb),**rr))
                audit.append(dict(scope='unified',dataset=label,disease=dis,ages=ages,contrast='current_vs_noncurrent',**a))
                print('UNIFIED',label,dis,ages,len(g),flush=True)
    save(unified,'unified_marginal_decomposition.csv');save(audit,'model_numeric_audit.csv')
    print('ACCESS AND UNIFIED COMPLETE',flush=True)
if __name__=='__main__':main()
