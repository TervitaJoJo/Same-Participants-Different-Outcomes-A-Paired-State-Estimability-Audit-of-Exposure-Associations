from common import *
import warnings,json
from scipy.special import expit,logit
from patsy import dmatrix
RNG=np.random.default_rng(2026091703);B=400

def selection_matrix(g):
    q=g.copy();terms=[]
    for c in ['bmi','cig_day','outpatient','hospital','public_insurance','rural_hukou','cancer','heart','stroke']:
        q[c]=pd.to_numeric(q[c],errors='coerce')
        if c=='bmi':q[c]=q[c].where(q[c].between(10,70))
        if q[c].isna().any():q[c+'_missing']=q[c].isna().astype(float);terms.append(c+'_missing')
        q[c]=q[c].fillna(q[c].median());terms.append(c)
    form='E + bs(age, df=4) + male + C(edu3) + '+' + '.join(terms)
    X=np.asarray(dmatrix(form,q),float)
    return X
def glm(y,X,family,fw):
    z=fw>0;f=sm.GLM(y[z],X[z],family=family,freq_weights=fw[z]).fit(maxiter=100,tol=1e-9)
    if not f.converged or not np.isfinite(f.params).all():raise ValueError('model convergence')
    return f
def percentile(x,fw,p=.99):
    order=np.argsort(x);x=x[order];w=fw[order];c=np.cumsum(w)/w.sum()
    return np.interp(p,c,x)
def pipeline(g,Xr,Xy,fw):
    R=g['observed'].to_numpy(float);yf=g['quit'].fillna(0).to_numpy(float);obs=R==1
    fr=glm(R,Xr,sm.families.Binomial(),fw);pred=expit(Xr@fr.params)
    if pred.min()<=0:raise ValueError('nonpositive observation probability')
    ipw=1/pred;cap=percentile(ipw[obs],fw[obs]);wt=np.minimum(ipw,cap)
    estimates=[]
    for weights in [np.ones(len(g)),ipw,wt]:
        ff=glm(yf,Xy,sm.families.Poisson(),fw*R*weights)
        estimates.append(float(np.exp(ff.params[1])))
    return np.array(estimates),pred,ipw,wt,cap

def main():
    p=pd.read_csv(ROOT/'data/longitudinal.csv.gz',low_memory=False)
    p['bmi']=p.bmi.where(p.bmi.between(10,70))
    rows=[];flows=[];weightdiag=[];balance=[];bootfail=[];timing=[];mnar=[];aud=[]
    for dis in ['hypertension','diabetes','dyslipidaemia']:
        d=p[p.current_2011.eq(1)].dropna(subset=[f'S2011_{dis}','age','male','edu','edu3','community']).copy()
        d['E']=d[f'S2011_{dis}'];d['quit']=d.quit_explicit_2015
        for (e,vital),q in d.groupby(['E','vital_status']):
            flows.append(dict(disease=dis,diagnosed=e,vital_status=vital,n=len(q),observed_n=q.quit.notna().sum(),quit_n=q.quit.sum()))
        g=d[d.vital_status=='alive'].copy().reset_index(drop=True);g['observed']=g.quit.notna().astype(float);g['age10']=(g.age-60)/10
        g['strata']='all';g['cluster']=g.community.astype(str)
        for (e,tc),q in g[g.quit==1].groupby(['E','time_class']):timing.append(dict(disease=dis,diagnosed=e,time_class=tc,n=len(q)))
        Xr=selection_matrix(g);Xy=np.column_stack([np.ones(len(g)),g.E,g.age10,g.male,g.edu])
        unit=np.ones(len(g));point,pred,ipw,wt,cap=pipeline(g,Xr,Xy,unit)
        code,groups=pd.factorize(g.cluster);G=len(groups)
        draws=[];failed=0
        for rep in range(B):
            fw=RNG.multinomial(G,np.repeat(1/G,G))[code].astype(float)
            try:rr,*_=pipeline(g,Xr,Xy,fw);draws.append(rr)
            except (np.linalg.LinAlgError,ValueError) as err:
                failed+=1;bootfail.append(dict(disease=dis,replicate=rep,error=str(err)))
            if (rep+1)%100==0:print('BOOT',dis,rep+1,'/',B,flush=True)
        assert len(draws)>=.95*B
        ci=np.quantile(np.asarray(draws),[.025,.975],axis=0);obs=g.observed.eq(1)
        for k,name in enumerate(['observed_survivors','IPOW_untrimmed','IPOW_p99']):
            rows.append(dict(disease=dis,analysis=name,target_n=len(g),observed_n=int(obs.sum()),estimate=point[k],lo=ci[0,k],hi=ci[1,k],bootstrap_valid=len(draws),bootstrap_total=B))
        for e,q in g.groupby('E'):
            ix=q.index.to_numpy();oo=q.observed.eq(1).to_numpy();ww=ipw[ix][oo]
            weightdiag.append(dict(disease=dis,diagnosed=e,alive_n=len(q),observed_n=int(oo.sum()),quit_n=q.quit.sum(),observation_rate=oo.mean(),pred_min=pred[ix].min(),pred_p01=np.quantile(pred[ix],.01),weight_median=np.median(ww),weight_p99=np.quantile(ww,.99),weight_max=ww.max(),ESS=ww.sum()**2/np.sum(ww**2),trim_cap=cap))
        # Balance against known survivors (description; not confounding balance).
        for c in ['age','male','edu','E','outpatient','hospital','public_insurance','rural_hukou']:
            v=g[c].to_numpy(float);known=np.isfinite(v);o=obs.to_numpy()&known
            sd=np.std(v[known],ddof=1);full=v[known].mean()
            raw=v[o].mean();weighted=np.average(v[o],weights=ipw[o])
            balance.append(dict(disease=dis,variable=c,target_mean=full,observed_mean=raw,weighted_mean=weighted,SMD_before=(raw-full)/sd,SMD_after=(weighted-full)/sd))
        # Strict temporal subset: keep current smokers and explicitly dated post-baseline quitters.
        strict=g[g.quit.eq(0)|(g.quit.eq(1)&g.time_class.eq('strictly_after_baseline'))].copy()
        XS=np.column_stack([np.ones(len(strict)),strict.E,(strict.age-60)/10,strict.male,strict.edu])
        fit=sm.GLM(strict.quit,XS,family=sm.families.Poisson()).fit()
        mu=np.asarray(fit.fittedvalues);bread=np.linalg.inv(XS.T@(mu[:,None]*XS));psi=(XS*(strict.quit.to_numpy()-mu)[:,None])@bread
        V,df=cov_cluster(psi,strict);se=np.sqrt(V[1,1]);b=fit.params.iloc[1] if hasattr(fit.params,'iloc') else fit.params[1]
        rows.append(dict(disease=dis,analysis='strict_explicit_quit_year',target_n=len(g),observed_n=len(strict),estimate=np.exp(b),lo=np.exp(b-1.96*se),hi=np.exp(b+1.96*se),cluster_df=df))
        # Pattern-mixture sensitivity for unknown smoking state among known survivors.
        f=glm(g['quit'].fillna(0).to_numpy(),Xy,sm.families.Binomial(),g.observed.to_numpy());basepred=expit(Xy@f.params)
        X0=Xy.copy();X0[:,1]=0;X1=Xy.copy();X1[:,1]=1
        for odds0 in [.25,.5,1.,2.,4.]:
            for odds1 in [.25,.5,1.,2.,4.]:
                shift=np.where(g.E==1,np.log(odds1),np.log(odds0))
                yi=np.where(obs,g.quit.fillna(0),expit(logit(basepred)+shift))
                fi=glm(yi,Xy,sm.families.Binomial(),unit)
                r0=expit(X0@fi.params).mean();r1=expit(X1@fi.params).mean()
                mnar.append(dict(disease=dis,missing_odds_multiplier_undiagnosed=odds0,missing_odds_multiplier_diagnosed=odds1,risk0=r0,risk1=r1,RR=r1/r0,RD=r1-r0))
        aud.append(dict(disease=dis,selection_parameters=Xr.shape[1],selection_rank=int(np.linalg.matrix_rank(Xr)),clusters=G,bootstrap_failed=failed,original_observed_rr=point[0]))
        print('SELECTION',dis,point,flush=True)
    save(rows,'selection_adjusted_quitting.csv');save(flows,'vital_status_flow.csv');save(weightdiag,'observation_weight_diagnostics.csv');save(balance,'selection_balance.csv');save(timing,'quit_time_audit.csv');save(mnar,'missing_not_at_random_scenarios.csv');save(aud,'selection_numeric_audit.csv')
    (RES/'bootstrap_failures.json').write_text(json.dumps(bootfail,indent=2),encoding='utf-8')
    print('SELECTION COMPLETE',flush=True)
if __name__=='__main__':main()
