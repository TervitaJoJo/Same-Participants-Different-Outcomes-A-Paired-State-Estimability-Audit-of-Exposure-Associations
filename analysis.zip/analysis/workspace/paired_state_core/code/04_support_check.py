from common import *
def main():
    p=pd.read_csv(ROOT/'data/cross_section.csv.gz',low_memory=False);p=p[p.age.between(50,79)].copy();p['decade']=(p.age//10).astype(int)
    counts=p[p.smoke_status.isin([0,2])].groupby(['dataset','disease','male','edu3','decade','smoke_status']).size().unstack('smoke_status',fill_value=0).reset_index()
    counts.to_csv(RES/'smoking_common_support_cells.csv',index=False)
    good=counts[(counts[0.]>=10)&(counts[2.]>=10)][['dataset','disease','male','edu3','decade']]
    kept=p.merge(good,on=['dataset','disease','male','edu3','decade'],validate='many_to_one')
    out=[];checks=[]
    for label,full,sub in [('CHARLS',p[p.dataset=='CHARLS 2011'],kept[kept.dataset=='CHARLS 2011']),('NHANES',p[p.dataset.str.startswith('NHANES')],kept[kept.dataset.str.startswith('NHANES')])]:
        for dis,g in sub.groupby('disease'):
            g=g.reset_index(drop=True);form='C(smoke_status) * male + bs(age, df=4) + C(edu3)'
            if label=='NHANES':form+=' + C(dataset)'
            # Some survey strata lose a PSU after support restriction. Retain zero
            # score contributions from excluded units when computing survey variance.
            target=full[full.disease==dis].reset_index(drop=True)
            v,psi,a=multinomial_marginal(g,form)
            if label=='NHANES':
                ix=pd.Index(target.uid).get_indexer(g.uid);assert (ix>=0).all()
                ip=np.zeros((len(target),psi.shape[1]));ip[ix]=psi
                rr=estimates(v,ip,target,JOINT_NAMES)
            else:rr=estimates(v,psi,g,JOINT_NAMES)
            for r in rr:out.append(dict(dataset=label,disease=dis,n_original=len(target),n=len(g),removed=len(target)-len(g),**r))
            checks.append(dict(dataset=label,disease=dis,**a))
    save(out,'common_support_restricted_models.csv');save(checks,'support_numeric_audit.csv')
    print(pd.DataFrame(out).query("metric=='delta'").to_string(index=False))
if __name__=='__main__':main()
