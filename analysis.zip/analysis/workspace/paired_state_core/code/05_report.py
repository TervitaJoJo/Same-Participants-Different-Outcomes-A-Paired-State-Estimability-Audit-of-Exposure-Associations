from common import *
import hashlib,json,platform
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator
import statsmodels
DIS=['hypertension','diabetes','dyslipidaemia'];ZH=dict(zip(DIS,['高血压','糖尿病','血脂异常']));EN=dict(zip(DIS,['Hypertension','Diabetes','Dyslipidaemia']))
def read(name):return pd.read_csv(RES/name)
def one(t,**kw):
    for k,v in kw.items():t=t[t[k]==v]
    assert len(t)==1,(kw,len(t));return t.iloc[0]
def table(head,rows):return '\n'.join(['| '+' | '.join(head)+' |','|'+'|'.join(['---']*len(head))+'|']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def ci(r,scale=1,expo=False):
    vals=np.array([r.estimate,r.lo,r.hi]);vals=np.exp(vals) if expo else vals*scale
    return f'{vals[0]:.3f}（{vals[1]:.3f}–{vals[2]:.3f}）'
def finish(fig,name):
    fig.savefig(ROOT/f'figures/{name}.png',dpi=220,bbox_inches='tight');fig.savefig(ROOT/f'figures/{name}.pdf',bbox_inches='tight');plt.close(fig)
def figures():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    a=read('access_standardized_models.csv');a=a[a.metric=='RD']
    fig,ax=plt.subplots(figsize=(9,4.5))
    for model,off,col,lab in [('severity',-.18,'#666666','Severity + demographic variables'),('plus_access',0,'#bc7930','Plus insurance / hukou'),('plus_use',.18,'#26749c','Plus outpatient / hospitalization')]:
        for y,dis in enumerate(DIS):
            r=one(a,disease=dis,model=model);ax.errorbar(r.estimate*100,y+off,xerr=[[(r.estimate-r.lo)*100],[(r.hi-r.estimate)*100]],fmt='o',ms=5,color=col,capsize=3,label=lab if y==0 else None)
    ax.axvline(0,ls='--',color='.5');ax.set_yticks(range(3),[EN[d] for d in DIS]);ax.invert_yaxis();ax.set_xlabel('Standardized diagnosis-report risk difference, percentage points (95% CI)')
    ax.legend(loc='upper left',bbox_to_anchor=(0,1.31),frameon=False,fontsize=9);ax.grid(axis='x',alpha=.15)
    fig.text(.02,-.06,'CHARLS participants with abnormal measured indicators: current minus non-current smokers.\nIdentical complete cases across models; community-clustered uncertainty. Adjustment changes are descriptive, not mediation effects.',fontsize=9)
    fig.tight_layout();finish(fig,'01_access_adjustment')
    u=read('unified_marginal_decomposition.csv');u=u[(u.age_scope=='age50_79')&(u.contrast=='current_vs_never')]
    fig,ax=plt.subplots(figsize=(9,5.2));labels=[]
    for y,(ds,dis) in enumerate([(ds,dis) for ds in ['CHARLS','NHANES'] for dis in DIS]):
        labels.append(ds+' / '+EN[dis])
        for metric,off,col,lab in [('logOR_M',-.12,'#26749c','Measured threshold'),('logOR_S',.12,'#bc7930','Reported diagnosis')]:
            r=one(u,dataset=ds,disease=dis,metric=metric);v,lo,hi=np.exp([r.estimate,r.lo,r.hi]);ax.errorbar(v,y+off,xerr=[[v-lo],[hi-v]],fmt='o',color=col,capsize=3,label=lab if y==0 else None)
    ax.axvline(1,ls='--',color='.5');ax.set_xscale('log');ax.set_xticks([.5,.7,1.,1.3],labels=['0.5','0.7','1.0','1.3']);ax.xaxis.set_minor_locator(NullLocator())
    ax.set_yticks(range(6),labels);ax.invert_yaxis();ax.set_xlabel('Standardized marginal OR: current vs never smoking (95% CI)');ax.legend(loc='upper left',bbox_to_anchor=(0,1.18),ncol=2,frameon=False);ax.grid(axis='x',alpha=.15)
    fig.text(.02,-.05,'Ages 50–79; common joint-state model for M, S and their decomposition. Standardization within each cohort.\nUnweighted sample associations; uncertainty accounts for communities (CHARLS) or strata / PSUs (NHANES).',fontsize=9)
    fig.tight_layout();finish(fig,'02_unified_marginal_OR')
    l=read('selection_adjusted_quitting.csv');fig,ax=plt.subplots(figsize=(9,4.3))
    for name,off,col,lab in [('observed_survivors',-.18,'#777777','Observed outcomes'),('IPOW_untrimmed',0,'#26749c','Observation probability weighted'),('strict_explicit_quit_year',.18,'#bc7930','Strict quit-year subset')]:
        for y,dis in enumerate(DIS):
            r=one(l,disease=dis,analysis=name);ax.errorbar(r.estimate,y+off,xerr=[[r.estimate-r.lo],[r.hi-r.estimate]],fmt='o',color=col,capsize=3,label=lab if y==0 else None)
    ax.axvline(1,ls='--',color='.5');ax.set_yticks(range(3),[EN[d] for d in DIS]);ax.invert_yaxis();ax.set_xlabel('Adjusted RR for later reported quitting (95% CI)');ax.legend(loc='upper left',bbox_to_anchor=(0,1.31),frameon=False,fontsize=9);ax.grid(axis='x',alpha=.15)
    fig.text(.02,-.06,'2011 current smokers known to be alive at the 2015 wave; diagnosis recorded at baseline.\n400 community bootstrap draws refit observation models; strict-year subset uses cluster-robust intervals. Targets differ.',fontsize=9)
    fig.tight_layout();finish(fig,'03_followup_robustness')

def report():
    a=read('access_standardized_models.csv');change=read('access_paired_RD_changes.csv');u=read('unified_marginal_decomposition.csv');l=read('selection_adjusted_quitting.csv');flow=read('vital_status_flow.csv')
    rows=[]
    for dis in DIS:
        b=one(a,disease=dis,model='severity',metric='RD');f=one(a,disease=dis,model='plus_use',metric='RD');d=one(change,disease=dis,change='adding_access_and_use')
        rows.append([ZH[dis],int(b.n),ci(b,100),ci(f,100),ci(d,100)])
    access=table(['疾病','相同样本 n','基础差距（百分点）','加医疗变量后差距','配对改变（95%CI）'],rows)
    main=u[(u.age_scope=='age50_79')&(u.contrast=='current_vs_never')];rows=[];decs=[]
    for ds in ['CHARLS','NHANES']:
        for dis in DIS:
            m=one(main,dataset=ds,disease=dis,metric='logOR_M');s=one(main,dataset=ds,disease=dis,metric='logOR_S');d=one(main,dataset=ds,disease=dis,metric='delta')
            rows.append([ds,ZH[dis],int(d.n),ci(m,expo=True),ci(s,expo=True),ci(d)])
            uu=one(main,dataset=ds,disease=dis,metric='unreported_component');vv=one(main,dataset=ds,disease=dis,metric='history_normal_component');decs.append([ds,ZH[dis],f'{d.estimate:.3f}',f'{uu.estimate:.3f}',f'{vv.estimate:.3f}'])
    unified=table(['数据','疾病','n','实测边际 OR（95%CI）','自报边际 OR（95%CI）','Δ（95%CI）'],rows)
    decomposition=table(['数据','疾病','总 Δ','异常但无诊断史项','有诊断史但未超阈值项'],decs)
    rows=[]
    for dis in DIS:
        vals=[one(l,disease=dis,analysis=name) for name in ['observed_survivors','IPOW_untrimmed','strict_explicit_quit_year']]
        rows.append([ZH[dis],int(vals[0].target_n),int(vals[0].observed_n),ci(vals[0]),ci(vals[1]),ci(vals[2])])
    longitudinal=table(['基线诊断','已知存活目标 n','明确吸烟结局 n','完整结局 RR','观察加权 RR','严格戒烟年份 RR'],rows)
    rows=[]
    for e in [0,1]:
        vals=[one(flow,disease='hypertension',diagnosed=e,vital_status=v) for v in ['alive','dead','unknown']]
        rows.append(['已诊断' if e else '未诊断',int(sum(v.n for v in vals)),*[int(v.n) for v in vals],int(vals[0].observed_n)])
    vital=table(['基线高血压','合计','已知存活','已知死亡','生存未知','有明确吸烟结局'],rows)
    mnar=read('missing_not_at_random_scenarios.csv').groupby('disease').RR.agg(['min','max']);mnartable=table(['疾病','25个假设情景的RR点估计范围'],[[ZH[d],f'{mnar.loc[d,"min"]:.3f}–{mnar.loc[d,"max"]:.3f}'] for d in DIS])
    s=read('common_support_restricted_models.csv');rows=[]
    for ds in ['CHARLS','NHANES']:
        for dis in DIS:
            q=one(s,dataset=ds,disease=dis,metric='delta');rows.append([ds,ZH[dis],int(q.removed),ci(q)])
    support=table(['数据','疾病','排除人数','限制共同支持后的 Δ（95%CI）'],rows)
    text=f'''# 机制研究第二轮：医疗利用、失访和统一估计尺度

日期：2026-09-17。阶段性成果，探索性二次分析；正文和校正模型未修改。前轮包保持完整，本轮单独存放于 paired_state_core。

## 本轮结论

**高血压的解释链条更完整了，但仍是有边界的机制证据。**已测医疗可及性和利用变量加入后，CHARLS 实测异常者中吸烟与诊断报告的差距有所减小；已知存活者的结局缺失加权、严格戒烟年份限制后，基线高血压与后续戒烟的关联保留。统一年龄范围、估计目标和聚类不确定性后，CHARLS高血压仍存在“实测 OR>1、自报 OR<1”的差异，另外两病不宜写成同样强的结论。

这些分析没有把病例诊断、治疗、医疗利用、戒烟串成已被识别的因果中介链；目前只能说存在相容的关联证据。一个指标变化多少，不能直接解读成该机制造成的百分比。

## 1. 医疗利用确实有关，但解释幅度有限

原始医疗服务模块本地未找到；官方协调库有基线近一月门诊、近一年住院、公共医保、农村户口四项字段，已核对官方生成代码。门诊定义排除仅去中医医院者，因此并非所有形式的医疗接触；农村户口也不等同现住地城乡。使用原始诊断史，未使用协调库被后期访谈追溯修订的基线诊断。

在每病当次实测异常者中，保持完全相同案例，先调整年龄样条、性别、三级教育、连续严重程度，再加医保/户口、门诊/住院。比较当前吸烟者减非当前吸烟者的标准化“报告诊断史”概率差；所有区间按社区聚类。

{access}

例如，高血压报告诊断史的差距从−8.23个百分点变为−7.10个百分点，缩小1.13个百分点（95%CI 0.43–1.82）。糖尿病缩小1.43个百分点（0.47–2.39）；血脂异常改变0.52个百分点，区间跨0。**所测医疗变量只能对应一小部分差距，残余差异依然存在。**

在同样的实测异常者与严重程度调整下，当前吸烟者的近月门诊概率在高血压组低3.87个百分点（95%CI −6.88至−0.86）；糖尿病组近年住院概率低3.96个百分点（−7.50至−0.42）。其他医疗利用差异区间跨0，全部结果保留。

门诊、住院发生于近月/近年，而诊断史可能更早；诊断本身可能增加就医。因此不能把这些变量当成严格先于诊断的中介。对当次异常条件化也可能产生选择偏倚。这里的“加入后改变”是配对描述性敏感性，不是医疗利用的因果贡献。

![医疗变量](figures/01_access_adjustment.png)

## 2. 主效应与状态分解现在来自同一套概率

前轮条件回归 OR 和粗年龄层标准化分解存在估计尺度不一致。本轮预先固定50–79岁为主范围，以当前 vs 从不吸烟为主参照；将 M/S 两个二值指标组合成四种联合状态，用同一多项模型得到标准化联合概率，然后同时计算患病率、风险差、边际 OR、Δ和分解。

模型纳入年龄样条、性别、三级教育、吸烟×性别交互；NHANES另纳入周期。每个库每病标准化至本库本病全部入选者的协变量分布，并不是把两国标准化到完全相同的人口分布。区间考虑 CHARLS社区或NHANES周期内分层/PSU；NHANES此处仍未用人口权重，不作国家总体推断。

{unified}

Δ=log OR(S)−log OR(M)。现在 CHARLS高血压的 Δ约−0.294（95%CI −0.450至−0.137），方向和区间均支持口径差异。CHARLS糖尿病与血脂异常的区间跨0。NHANES糖尿病自报与实测 OR均约0.796，但两种口径的 Δ接近0：**其保护性关联不能由“自报相对于实测的口径差异”单独解释。**NHANES高血压两种口径差异不确定，血脂异常仍有口径差异。

以下两项为标准化联合概率的对称代数分解，每行两项之和严格等于同一模型的 Δ：

{decomposition}

两个分量分别对应当次异常却未报告诊断史、报告诊断史但当次未超阈值的状态差异。不等同临床漏诊/误诊；后者可包含治疗控制。分量区间保存在CSV，可能正负抵消，不报告相加的因果解释比例。与前轮数值变化同时包含年龄范围、吸烟参照、协变量和边际估计目标的变化，不能只拿某一个数字的变化归因于某项机制。

![统一尺度](figures/02_unified_marginal_OR.png)

部分高教育女性层没有当前吸烟者，存在模型外推。额外限制每个性别×教育×十岁年龄层（NHANES另按周期）的当前、从不吸烟者各不少于10人，结论如下：

{support}

CHARLS高血压仅排除112人，Δ基本不变。NHANES排除人数较多，因此这是不同目标总体的敏感性，不应替代原主结果。全龄估计也保留：部分CHARLS全龄模型数值条件较差，相关诊断见model_numeric_audit.csv，不以全龄结果代替预先确定的主年龄范围。

## 3. 已将死亡、失访和未知状态分开

2015原始样本信息中的died、协调库访谈状态和原始随访问卷相互核查。符合高血压纵向基本条件的4,841名基线吸烟者分布为：

{vital}

已诊断组死亡91/995（9.1%），未诊断组189/3,846（4.9%）；这些只是粗比例，不是调整后的死亡效应。死亡不能按“未戒烟”填补。本轮加权目标限定于2015波次已知存活者，生存未知者也单列；**并未解决全体基线人群的生存选择问题。**

已知存活者中，用基线诊断、人口学、BMI/烟量、医疗利用/可及性、其他病史建模明确吸烟结局的观察概率。对观察者赋予逆概率权重；400次社区整群重抽样中每次重估选择模型和结局模型。

{longitudinal}

高血压 RR由1.347变为1.344，95%CI约1.14–1.55；权重最大约1.51，有效样本量接近实际观察人数，没有明显极端权重驱动。99百分位截尾结果1.344，也几乎不变。糖尿病、血脂异常的区间跨1，保留证据不足的判断。全部1,200次重抽样成功；所检查基线变量的最大绝对标准化差异从约0.01降到0.001以内，说明已测变量的观察选择很小；这不验证缺失随机假设。

## 4. 戒烟回忆时间有矛盾，但高血压结论在严格子样本中保留

高血压分析的657名报告戒烟者中，504人明确报告的戒烟年晚于基线实际访问年、不晚于随访访问年；60人报告早于基线，25人与基线同年、先后不明，55人只有年龄信息，13人缺乏可用时间。比前轮仅根据波次判断时间顺序更严格。

严格子样本保留这504名明确后续戒烟者和仍吸烟者，高血压调整RR为1.382（1.152–1.659）。糖尿病严格子样本RR降至1.067且区间宽；血脂异常仍不确定。该限制会选择能够提供一致日期的戒烟者，故作为敏感性而非无偏真值，也没有把矛盾时间直接重编码为未戒烟。

![随访稳健性](figures/03_followup_robustness.png)

对于已知存活但吸烟状态未知者，再令有/无诊断组的预测戒烟优势分别乘0.25、0.5、1、2、4，形成25个非随机缺失情景：

{mnartable}

这些是不同假设下的**点估计范围，不是置信区间**。所设情景中高血压方向未逆转，但不能声称对所有非随机失访都稳健，也不能将其外推到生存未知或死亡者。糖尿病和血脂异常即使情景点估计大于1，其抽样区间仍不确定。

## 5. 数据还缺什么

本轮主要分析已完成，现有协调字段够用。进一步解释具体筛查渠道、医疗障碍和时间顺序，需要优先补：

- **CHARLS 2011 的 `health_care_and_insurance.dta`**。官方生成脚本明确引用该文件，本地CHARLS目录中未找到。若有2013、2015同模块，也有助于核查新增诊断前后的医疗接触；先提供2011模块即可推进更细的字段审计。
- 原始模块里是否包含可用于未诊断者的筛查条目和检查日期，需要收到后核实，不能提前保证其中具备这些变量。若没有，就需要另有普遍询问筛查史的资料或独立队列。

现有健康问卷的血压检查次数在报告高血压者中有4,162条记录，但13,186名报告未诊断者中只有124条；糖尿病检查次数在16,415名报告未诊断者中只有3条。准确表述为高度选择性记录，不能把其他缺失直接当“没有筛查”，也不把它加入全样本诊断中介模型。第一轮进度说明中“只向已诊断者询问”的说法过于绝对，已按实际记录更正。

## 6. 下一阶段建议

优先推进**高血压机制主线，三病作为一致性与反例检验**。先补医疗模块和可用筛查时间，增加一个独立队列的纵向复现；然后才考虑是否有条件做因果中介或更细的诊断—戒烟事件顺序分析。当前“新增诊断触发戒烟”的事件数不足问题尚未解决，基线诊断预测后续戒烟不能替代这个证据。

统一尺度、按社区/调查设计计算区间、保留跨0结果和反例，提升的是可复核性及结论边界，不是把所有结果改成显著。尚未到最终投稿分析，也不据此承诺期刊影响因子。

## 文件与核查

`PROTOCOL.md`保存本轮分析前方案与后续扩展；`code/01_build.py`至`05_report.py`按编号可复现。`results/`保留医疗变量缺失、全部估计、共同支持、权重、时间矛盾、非随机缺失情景及来源字典。最终数值/输入散列审计见`results/final_audit.json`；个体级衍生数据仅在本地`data/`，未上传。
'''
    text=text.replace('(figures/',f'({ROOT.as_posix()}/figures/')
    (ROOT/'第二轮阶段性成果.md').write_text(text,encoding='utf-8')
    (ROOT/'README.md').write_text('''# 机制分析第二轮

主报告：第二轮阶段性成果.md。方案：PROTOCOL.md。

按code/01_build.py、02_access_and_scale.py、03_followup_selection.py、04_support_check.py、05_report.py顺序运行；Python为python，设置OPENBLAS_NUM_THREADS=1、OMP_NUM_THREADS=1。

全部结果为探索性。医疗利用调整不是因果中介；纵向主目标仅为已知存活者；NHANES联合状态主模型未使用人口权重。第一轮及原始数据未改写。data含本地个体数据，对外交流使用results汇总、figures和报告。

关键结果表：access_standardized_models.csv、access_paired_RD_changes.csv、unified_marginal_decomposition.csv、common_support_restricted_models.csv、selection_adjusted_quitting.csv、vital_status_flow.csv、quit_time_audit.csv、observation_weight_diagnostics.csv、missing_not_at_random_scenarios.csv。
''',encoding='utf-8')

def audit():
    manifest=json.loads((RES/'input_manifest.json').read_text());checks=[]
    for m in manifest:assert hashlib.file_digest((BASE/m['path']).open('rb'),'sha256').hexdigest()==m['sha256']
    u=read('unified_marginal_decomposition.csv').pivot(index=['dataset','disease','age_scope','contrast'],columns='metric',values='estimate')
    err=float(abs(u.delta-u.unreported_component-u.history_normal_component).max());assert err<1e-10
    assert np.allclose(u.RD_M,u.risk_M1-u.risk_M0) and np.allclose(u.RD_S,u.risk_S1-u.risk_S0)
    assert np.allclose(u.delta,u.logOR_S-u.logOR_M)
    old=pd.read_csv(BASE/'charls_preparation/results/longitudinal_quitting_models.csv')
    old=old[(old.analysis=='baseline2011_diagnosis_to_quit2015')&(old.adjustment=='age_sex_education')&(old.measure=='RR')]
    new=read('selection_adjusted_quitting.csv');v=new[new.analysis=='observed_survivors'].merge(old,on='disease',suffixes=('_new','_old'));diff=float(abs(v.estimate_new-v.estimate_old).max());assert diff<1e-8
    diag=read('selection_numeric_audit.csv');assert (diag.selection_parameters==diag.selection_rank).all();assert (diag.bootstrap_failed==0).all()
    f=read('vital_status_flow.csv');assert not (f.vital_status=='conflict').any();assert f.loc[f.vital_status!='alive','observed_n'].sum()==0
    results=dict(all_source_hashes_unchanged=True,input_files=len(manifest),unified_model_cells=len(u),decomposition_identity_max_error=err,replicated_previous_complete_case_RR_max_error=diff,all_bootstrap_replicates_successful=True,bootstrap_replicates_total=1200,vital_conflicts=0,
      versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,statsmodels=statsmodels.__version__),protocol_sha256=hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest())
    results['output_hashes']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.rglob('*') if p.is_file() and p.suffix in ['.py','.md','.csv','.png','.pdf']}
    (RES/'final_audit.json').write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf-8');print({k:v for k,v in results.items() if k!='output_hashes'})
if __name__=='__main__':figures();report();audit();print('ROUND TWO REPORT COMPLETE')
