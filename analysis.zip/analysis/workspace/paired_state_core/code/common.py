from pathlib import Path
import numpy as np
import pandas as pd
import statsmodels.api as sm
from patsy import dmatrix,build_design_matrices
from scipy.special import expit,logit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;RES=ROOT/'results'
def save(rows,name):pd.DataFrame(rows).to_csv(RES/name,index=False,encoding='utf-8-sig')
def matrices(formula,g,exposure='E',levels=(0,1)):
    x=dmatrix(formula,g,return_type='dataframe');arr=[]
    for e in levels:
        z=g.copy();z[exposure]=e
        arr.append(np.asarray(build_design_matrices([x.design_info],z)[0],float))
    return np.asarray(x,float),arr,list(x.columns)
def cov_cluster(psi,g):
    psi=np.atleast_2d(psi)
    if psi.shape[0]!=len(g):psi=psi.T
    df=pd.DataFrame(psi);df['strata']=g.strata.to_numpy();df['cluster']=g.cluster.to_numpy()
    sums=df.groupby(['strata','cluster']).sum();out=np.zeros((psi.shape[1],psi.shape[1]));dof=0
    for _,z in sums.groupby(level=0):
        x=z.to_numpy();m=len(x);assert m>=2
        x=x-x.mean(axis=0);out+=m/(m-1)*x.T@x;dof+=m-1
    return out,dof
def estimates(v,psi,g,names):
    V,df=cov_cluster(psi,g);se=np.sqrt(np.maximum(0,np.diag(V)))
    return [dict(metric=name,estimate=float(a),se=float(s),lo=float(a-1.96*s),hi=float(a+1.96*s),cluster_df=df) for name,a,s in zip(names,v,se)]
def binary_marginal(g,y,formula):
    X,(X0,X1),names=matrices(formula,g)
    f=sm.GLM(np.asarray(y,float),X,family=sm.families.Binomial()).fit(maxiter=100,tol=1e-10)
    assert f.converged
    mu=np.asarray(f.fittedvalues);bread=np.linalg.inv(X.T@((mu*(1-mu))[:,None]*X))
    ib=(X*(np.asarray(y)-mu)[:,None])@bread
    probs=[];ips=[]
    for xx in [X0,X1]:
        pr=expit(xx@f.params);r=pr.mean();grad=np.mean((pr*(1-pr))[:,None]*xx,axis=0)
        probs.append(r);ips.append(ib@grad+(pr-r)/len(g))
    p0,p1=probs;i0,i1=ips
    vals=np.array([p0,p1,p1-p0,logit(p1)-logit(p0)])
    psi=np.column_stack([i0,i1,i1-i0,i1/(p1*(1-p1))-i0/(p0*(1-p0))])
    return vals,psi,dict(n=len(g),parameters=X.shape[1],condition_number=float(np.linalg.cond(X)),converged=bool(f.converged))

def joint_metrics(flat):
    p=np.asarray(flat).reshape(2,4);m=p[:,2]+p[:,3];s=p[:,1]+p[:,3];u=p[:,2];v=p[:,1]
    L=lambda q:logit(q[1])-logit(q[0])
    lm=L(m);ls=L(s);lu=L(m-u);lv=L(m+v)
    vals=np.array([*m,*s,m[1]-m[0],s[1]-s[0],lm,ls,ls-lm,
         .5*((lu-lm)+(ls-lv)),.5*((lv-lm)+(ls-lu))])
    assert abs(vals[8]-vals[9]-vals[10])<1e-10
    return vals
JOINT_NAMES=['risk_M0','risk_M1','risk_S0','risk_S1','RD_M','RD_S','logOR_M','logOR_S','delta','unreported_component','history_normal_component']

def multinomial_marginal(g,formula,levels=(0,2)):
    X,(X0,X1),names=matrices(formula,g,exposure='smoke_status',levels=levels)
    y=(g.M*2+g.S).astype(int).to_numpy()
    model=sm.MNLogit(y,X);fit=model.fit(method='newton',disp=False,maxiter=150,tol=1e-8)
    assert fit.mle_retvals['converged'] and np.isfinite(fit.params).all()
    params=np.asarray(fit.params);flat=params.ravel(order='F');H=-model.hessian(flat)
    score=model.score_obs(flat);assert score.shape[1]==len(flat)
    assert abs(score.sum(axis=0)).max()<1e-4
    ib=score@np.linalg.inv(H)
    means=[];mean_ifs=[];jacobs=[]
    for xx in [X0,X1]:
        pp=np.asarray(model.predict(params,xx));mean=pp.mean(axis=0)
        J=np.zeros((4,len(flat)))
        for k in range(4):
            for l in range(1,4):
                J[k,(l-1)*X.shape[1]:l*X.shape[1]]=np.mean((pp[:,k]*((k==l)-pp[:,l]))[:,None]*xx,axis=0)
        means.append(mean);mean_ifs.append(ib@J.T+(pp-mean)/len(g));jacobs.append(J)
    probs=np.r_[means[0],means[1]];ip=np.column_stack(mean_ifs)
    Jm=np.zeros((len(JOINT_NAMES),8))
    for j in range(8):
        shift=np.zeros(8);shift[j]=1e-6
        Jm[:,j]=(joint_metrics(probs+shift)-joint_metrics(probs-shift))/(2e-6)
    vals=joint_metrics(probs);psi=ip@Jm.T
    assert abs(psi[:,8]-psi[:,9]-psi[:,10]).max()<1e-9
    # Independent directional numerical check of averaged-probability Jacobian.
    direction=np.arange(1,len(flat)+1,dtype=float);direction/=np.linalg.norm(direction)
    plus=np.asarray(model.predict((flat+1e-5*direction).reshape(params.shape,order='F'),X0)).mean(axis=0)
    minus=np.asarray(model.predict((flat-1e-5*direction).reshape(params.shape,order='F'),X0)).mean(axis=0)
    err=float(abs((plus-minus)/(2e-5)-jacobs[0]@direction).max());assert err<1e-6
    audit=dict(n=len(g),parameters=len(flat),hessian_condition=float(np.linalg.cond(H)),score_max=float(abs(score.sum(axis=0)).max()),jacobian_check_error=err,
       identity_error=float(abs(vals[8]-vals[9]-vals[10])),min_predicted_state_probability=float(min(np.min(model.predict(params,X0)),np.min(model.predict(params,X1)))))
    return vals,psi,audit
