from pathlib import Path
import json, re, sys, importlib.util, io, zipfile
import pandas as pd
import pyreadstat

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[1] / 'results'
OUT.mkdir(exist_ok=True)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

records=[]
paths={
 'ELSA':ROOT/'ELSA/Raw_data/UKDA-5050-stata/stata/stata13_se/h_elsa_g3.dta',
 'LASI':ROOT/'LASI/LASI_印度/Temp_data/lasi.dta',
 'HAALSI':ROOT/'HAALSI/HAALSI Baseline Survey/HAALSI_baseline_dataverse_14Apr2017.dta',
 'CHARLS':ROOT/'CHARLS/2011/health_status_and_functioning.dta'
}
for dataset,p in paths.items():
    _,meta=pyreadstat.read_dta(str(p),metadataonly=True)
    for c,l in zip(meta.column_names,meta.column_labels):
        if re.search(r'(blood pressure|hypertens|hibp|high bp|降压|高血压)',str(l)+' '+c,re.I) and re.search(r'(med|drug|treat|pill|用药|服药|治疗|hibp)',str(l)+' '+c,re.I):
            vals=meta.variable_value_labels.get(c,{})
            records.append(dict(dataset=dataset,variable=c,label=l,values=json.dumps(vals,ensure_ascii=False)))
    if dataset=='CHARLS':
        for c in ['da011s1','da011s2','da011s3','da011s4','da007_1_']:
            if c in meta.column_names:
                records.append(dict(dataset=dataset,variable=c,label=meta.column_names_to_labels[c],values=json.dumps(meta.variable_value_labels.get(c,{}),ensure_ascii=False)))
pd.DataFrame(records).to_csv(OUT/'medication_variable_audit.csv',index=False,encoding='utf-8-sig')
print(pd.DataFrame(records).to_string(index=False))

m=module('oldpanel',ROOT/'survey_panels/code/00_build_panel.py')
sex=[]
for year,(bp,ad) in m.WAVES.items():
    d=m.rd(ROOT/'ENSANUT'/year/ad,cats=False)
    s=next((c for c in ['sexo','SEXO'] if c in d),None)
    print('ENSANUT',year,'sex numeric',s,d[s].value_counts(dropna=False).to_dict() if s else None)
    for c in [s,'FOLIO_I','FOLIO_INT']:
        if c: sex.append(dict(year=year,variable=c,dtype=str(d[c].dtype),n=len(d),unique=d[c].nunique()))
d=m.rd(ROOT/'ENSANUT/2018_10+/CS_ADULTOS.stata.stata.zip',cats=False)
print('ENSANUT2018 SEXO',d['SEXO'].value_counts(dropna=False).to_dict())
pd.DataFrame(sex).to_csv(OUT/'ensanut_key_sex_audit.csv',index=False,encoding='utf-8-sig')

for cyc in ['1999-2000','2017-2018']:
    f=next((ROOT/'NHANES'/cyc).glob('BPQ*.xpt'))
    d,meta=pyreadstat.read_xport(str(f))
    print('NHANES',cyc,[(c,meta.column_names_to_labels[c],d[c].value_counts(dropna=False).to_dict()) for c in ['BPQ020','BPQ040A','BPQ050A'] if c in d])

p=pd.read_csv(ROOT/'legacy_panel_sources/data/panel_diseases_bmi.csv')
e=p[(p.country=='England')&(p.disease=='hypertension')]
print('ELSA observations',len(e),'unique IDs',e.pid.nunique(),'missingID',e.pid.isna().sum())
print('MODULE VERSIONS')
for name in ['numpy','pandas','scipy','statsmodels','sklearn','pyreadstat','matplotlib','docx']:
    mod=__import__(name);print(name,getattr(mod,'__version__','unknown'))
