from common import *
import pyreadstat,hashlib,sys

def medicated(raw,S,yes=1,no=(0,2)):
    z=binary(raw,yes,no)
    # Harmonised files distinguish .x (does not have condition) from .m/.d/.r.
    # Generic missing/refusal/don't-know must stay missing even when S is zero.
    z=z.mask(raw.astype(str).isin(['x','.x'])&(S==0),0.)
    return z

def main():
    old70=module('old70',OLD/'code/analysis/70_complete_evidence.py')
    old00=module('old00',BASE/'survey_panels/code/00_build_panel.py')
    p=pd.read_csv(OLD/'data/panel_individual.csv',low_memory=False)
    dz=pd.read_csv(OLD/'data/panel_diseases_bmi.csv',low_memory=False)
    hz=dz[dz.disease=='hypertension'].copy()
    sources=[];audit=[];frames=[]
    def rd(path,cols):
        sources.append(path)
        return pyreadstat.read_dta(str(path),usecols=cols,user_missing=True)[0]
    # Recover numeric sex codes before value-label rendering in ENSANUT.
    for ds,g in p.groupby('dataset',sort=True):
        if ds.startswith(('NHANES','CHARLS')):continue
        g=g.copy();g['bmi']=np.nan;g['med']=np.nan
        if ds.startswith('ENSANUT'):
            yr=ds.split()[-1]
            if g.smoke_src.notna().mean()>.5:g['smoke']=g.smoke_src
            if yr=='2018':
                path=BASE/'ENSANUT/2018_10+/CS_ADULTOS.stata.stata.zip'
                raw=old00.rd(path,cols=['UPM','VIV_SEL','HOGAR','NUMREN','SEXO'])
                raw['_k']=raw[['UPM','VIV_SEL','HOGAR','NUMREN']].apply(pd.to_numeric,errors='coerce').astype('Int64').astype(str).agg('|'.join,axis=1)
                sx='SEXO'
            elif yr in old00.WAVES:
                path=BASE/'ENSANUT'/yr/old00.WAVES[yr][1]
                raw=old00.rd(path,cats=False)
                raw['_k']=raw.FOLIO_I.astype(str)+'|'+raw.FOLIO_INT.astype(str)
                sx=next(c for c in ['sexo','SEXO'] if c in raw)
            else:raw=None
            if raw is not None:
                sources.append(path);raw['male_corrected']=binary(raw[sx],1,(2,))
                assert not raw._k.duplicated().any(),ds
                g=g.merge(raw[['_k','male_corrected']],on='_k',how='left',validate='many_to_one')
                assert g.male_corrected.notna().all(),f'{ds}: unmatched sex'
                audit.append(dict(dataset=ds,n=len(g),old_male_rate=g.male.mean(),new_male_rate=g.male_corrected.mean(),changed=int((g.male!=g.male_corrected).sum())))
                g['male']=g.male_corrected
            g['uid']=ds+':'+g.index.astype(str);g['country']='Mexico'
        else:
            # Single CHNS wave; source panel has no retained original ID.
            g['uid']=ds+':'+g.index.astype(str);g['country']='China'
        g['dataset']=ds
        frames.append(g)

    # Attach medications and survey design to the already paired disease panel.
    elsa_path=BASE/'ELSA/Raw_data/UKDA-5050-stata/stata/stata13_se/h_elsa_g3.dta'
    e=rd(elsa_path,['idauniq']+[f'r{w}rxhibp' for w in [2,4,6,8,9]])
    charls_path=BASE/'CHARLS/2011/health_status_and_functioning.dta'
    c=rd(charls_path,['ID','da007_1_','da011s1','da011s2','da011s3'])
    c['pid']=pd.to_numeric(c.ID,errors='coerce')
    c['S_corrected']=binary(c.da007_1_,1,(2,))
    c['med']=np.where(c.da011s2==2,1.,np.where((c.da007_1_==2)|(c.da011s3==3)|(c.da011s1==1),0.,np.nan))
    for ds,g in hz.groupby('dataset',sort=True):
        g=g.copy()
        if ds.startswith('NHANES'):
            cyc=ds.split()[-1];folder=BASE/'NHANES'/cyc
            bpq_path=next(folder.glob('BPQ*.xpt'));demo_path=next(folder.glob('DEMO*.xpt'))
            sources.extend([bpq_path,demo_path])
            q=pd.read_sas(bpq_path,format='xport')
            med=binary(q.BPQ050A,1,(2,))
            med=med.mask(med.isna()&((q.BPQ020==2)|(q.BPQ040A==2)),0.)
            q['med']=med
            g=g.merge(q[['SEQN','med']],left_on='pid',right_on='SEQN',validate='one_to_one',how='left')
            de=pd.read_sas(demo_path,format='xport')
            wc='WTMEC2YR'
            g=g.merge(de[['SEQN',wc,'SDMVSTRA','SDMVPSU']],on='SEQN',validate='one_to_one',how='left').rename(columns={wc:'wt','SDMVSTRA':'stratum','SDMVPSU':'psu'})
            g['uid']=ds+':'+g.pid.astype(str)
        elif ds.startswith('ELSA'):
            w=ds.split('w')[-1];col=f'r{w}rxhibp'
            g=g.merge(e[['idauniq',col]],left_on='pid',right_on='idauniq',validate='one_to_one',how='left')
            g['med']=medicated(g[col],g.S,1,(0,))
            g['uid']='ELSA:'+g.pid.astype(str)
        elif ds.startswith('CHARLS'):
            g=g.merge(c[['pid','S_corrected','med']],on='pid',validate='one_to_one',how='left')
            audit.append(dict(dataset=ds,n=len(g),old_male_rate=np.nan,new_male_rate=np.nan,changed=int((g.S!=g.S_corrected).sum())))
            g['S']=g.S_corrected;g['uid']='CHARLS:'+g.pid.astype(str)
        frames.append(g)

    lasi,n0,n1=old70.lasi_frame()
    path=BASE/'LASI/LASI_印度/Temp_data/lasi.dta'
    med=rd(path,['r1rxhibp','ragender'])
    lasi['med']=medicated(med.loc[lasi.index,'r1rxhibp'],lasi.S,1,(0,))
    lasi['male']=binary(med.loc[lasi.index,'ragender'],1,(2,))
    lasi['uid']='LASI:'+lasi.index.astype(str);lasi['dataset']='LASI w1';lasi['country']='India';frames.append(lasi)
    haa,n0,n1=old70.haalsi_frame()
    path=BASE/'HAALSI/HAALSI Baseline Survey/HAALSI_baseline_dataverse_14Apr2017.dta'
    hm=rd(path,['cm002','cm004','cm005'])
    haa['med']=medicated(hm.cm005,haa.S,1,(2,))
    haa.loc[haa.med.isna()&(haa.S==0),'med']=0.
    haa.loc[haa.med.isna()&(hm.cm004==2),'med']=0.
    haa['uid']='HAALSI:'+haa.index.astype(str);haa['dataset']='HAALSI baseline';haa['country']='South Africa';frames.append(haa)
    t=pd.concat(frames,ignore_index=True)
    t['M_treatment']=np.where((t.M==1)|(t.med==1),1.,np.where((t.M==0)&(t.med==0),0.,np.nan))
    t['obese']=np.where(t.bmi.notna(),(t.bmi>=30).astype(float),np.nan)
    # Binary validation precedes complete-case selection.
    for col in ['M','S','smoke','male','med']:
        assert set(t[col].dropna().unique())<=set([0.,1.]),(col,t[col].value_counts().to_dict())
    assert not t[['dataset','uid']].duplicated().any()
    keep=['dataset','country','uid','M','S','smoke','age','male','edu','bmi','obese','med','M_treatment','wt','stratum','psu']
    t[keep].to_csv(DATA/'hypertension_panel.csv.gz',index=False)
    save(pd.DataFrame(audit),'coding_corrections.csv')
    a=t.groupby('dataset').agg(source_n=('M','size'),paired_n=('M','count'),med_available=('med','count'),med_positive=('med','sum'),sex_unique=('male','nunique'),bmi_n=('bmi','count'))
    save(a.reset_index(),'panel_availability.csv')
    print(a.to_string());print(pd.DataFrame(audit).to_string(index=False))
    # Records are local, restricted derivatives; no raw source is redistributed.
    sources+=list((OLD/'data').glob('*.csv'))
    records=[]
    for pth in sorted(set(sources)):
        h=hashlib.sha256()
        with pth.open('rb') as f:
            for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
        records.append(dict(path=str(pth.relative_to(BASE)),bytes=pth.stat().st_size,sha256=h.hexdigest()))
    save(pd.DataFrame(records),'source_manifest.csv')
    print('Saved panel',len(t),'rows',t.dataset.nunique(),'waves',flush=True)

if __name__=='__main__':main()
