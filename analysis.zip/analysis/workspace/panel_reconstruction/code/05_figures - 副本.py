from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

FIG=REV/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'pdf.fonttype':42,'savefig.facecolor':'white'})
CN={'China':'中国','England':'英格兰','India':'印度','Mexico':'墨西哥','South Africa':'南非','United States':'美国'}
COL={'China':'#C85854','England':'#8667AD','India':'#D88B36','Mexico':'#159E91','South Africa':'#967638','United States':'#3F6B96'}
METHOD={'identity_no_shift':'不作口径调整','external_wave_average':'外部波次平均','external_pooled':'外部条件比例合并','conditional_standardized':'协变量条件化迁移','conditional_country_balanced':'国家等权条件化迁移','local_independent_half':'本地独立半样本'}

def finish(fig,name):
    fig.savefig(FIG/f'{name}.png',dpi=300,bbox_inches='tight')
    fig.savefig(FIG/f'{name}.pdf',bbox_inches='tight')
    fig.savefig(FIG/f'{name}.svg',bbox_inches='tight')
    plt.close(fig)

def label(ax,text):ax.text(-.08,1.035,text,transform=ax.transAxes,fontweight='bold',fontsize=12)

def main():
    p=pd.read_csv(RES/'primary_corrected.csv')
    fig,ax=plt.subplots(figsize=(9,8.2),layout='constrained')
    y=np.arange(len(p))[::-1]
    for i,r in enumerate(p.itertuples()):
        ax.errorbar(r.delta,y[i],xerr=[[r.delta-r.lo],[r.hi-r.delta]],fmt='o',color=COL[r.country],markersize=4,capsize=2)
    ax.set_yticks(y,p.dataset);ax.axvline(0,color='.55',ls='--',lw=1)
    allr=pd.read_csv(RES/'primary_meta_correlated.csv').iloc[0]
    ax.errorbar(allr.delta,-1.7,xerr=[[allr.delta-allr.lo],[allr.hi-allr.delta]],fmt='D',color='black',capsize=3)
    ax.text(ax.get_xlim()[0],-1.7,'',ha='left')
    ax.set_yticks(list(y)+[-1.7],p.dataset.tolist()+['总体（相关结构已计入）'])
    ax.set_xlabel('Δ = ln OR（自报）− ln OR（实测）；点和95%区间')
    ax.grid(axis='x',alpha=.15);finish(fig,'Fig2_paired')

    t=pd.read_csv(RES/'treatment_definition_comparison.csv');states=pd.read_csv(RES/'treatment_discordant_states.csv')
    fig,axs=plt.subplots(1,3,figsize=(12.8,5),layout='constrained',gridspec_kw={'width_ratios':[1.1,1.1,.9]})
    for ax,ex,title in zip(axs[:2],['smoke','obese'],['吸烟（16个波次）','肥胖（12个波次）']):
        g=t[t.exposure==ex]
        for r in g.itertuples():ax.plot([0,1],[r.delta_threshold,r.delta_treatment],'-o',color=COL[r.country],alpha=.7,lw=1,ms=3)
        ax.axhline(0,color='.55',ls='--',lw=1);ax.set_xticks([0,1],['血压阈值','血压阈值\n或当前治疗']);ax.set_xlim(-.18,1.18);ax.set_ylabel('自报相对参照定义的 Δ');ax.set_title(title)
    s=states.groupby('country')[['discordant_n','treated_discordant']].sum();f=s.treated_discordant/s.discordant_n
    axs[2].barh([CN[c] for c in f.index],100*f,color=[COL[c] for c in f.index]);axs[2].set_xlim(0,100);axs[2].set_xlabel('实测阴性、自报阳性者中\n报告当前治疗的比例（%）')
    for i,v in enumerate(f):axs[2].text(v*100+1,i,f'{v:.1%}',va='center',fontsize=8)
    for ax,l in zip(axs,'abc'):label(ax,l)
    finish(fig,'Fig3_treatment')

    m=pd.read_csv(RES/'multidisease_corrected.csv')
    fig,axs=plt.subplots(1,2,figsize=(10,4.8),layout='constrained')
    dise=['hypertension','diabetes','dyslipidaemia'];dic={'hypertension':'高血压','diabetes':'糖尿病','dyslipidaemia':'血脂异常'}
    rng=np.random.default_rng(1)
    for k,ex in enumerate(['smoke','obese']):
        g=m[m.exposure==ex]
        for j,dis in enumerate(dise):
            h=g[g.disease==dis]
            axs[k].scatter(np.full(len(h),j)+rng.uniform(-.18,.18,len(h)),h.delta,c=[COL[c] for c in h.country],s=24,alpha=.85)
            axs[k].plot([j-.23,j+.23],[h.delta.median()]*2,color='black',lw=2)
        axs[k].axhline(0,color='.55',ls='--');axs[k].set_xticks(range(3),[dic[d] for d in dise]);axs[k].set_ylabel('Δ');axs[k].set_title(f'{"吸烟" if ex=="smoke" else "肥胖"}：{len(g)}个分析单元')
        label(axs[k],'ab'[k])
    finish(fig,'Fig4_multidisease')

    a=pd.read_csv(RES/'transport_macro_metrics.csv').set_index('method');b=pd.read_csv(RES/'independent_half_macro_metrics.csv').set_index('method')
    fig,axs=plt.subplots(1,2,figsize=(12,4.3),layout='constrained')
    orders=[['identity_no_shift','external_wave_average','external_pooled','conditional_standardized','conditional_country_balanced'],['identity_no_shift','external_pooled','conditional_standardized','local_independent_half']]
    for ax,df,order,title in zip(axs,[a,b],orders,['整波次留一国家外推','固定独立评估半样本']):
        vals=df.loc[order,'mae_logor'];cols=['#A4ACB2' if k=='identity_no_shift' else '#238C78' if k=='local_independent_half' else '#4F7297' for k in order]
        yy=np.arange(len(order));ax.barh(yy,vals,color=cols)
        ax.set_yticks(yy,[METHOD[k] for k in order]);ax.invert_yaxis();ax.set_xlim(0,.45);ax.set_xlabel('国家宏平均绝对误差（logOR）');ax.set_title(title)
        for j,v in enumerate(vals):ax.text(v+.006,j,f'{v:.3f}',va='center')
    for ax,l in zip(axs,'ab'):label(ax,l)
    finish(fig,'Fig5_transport')

    d=pd.read_csv(RES/'validation_design_macro.csv')
    fig,axs=plt.subplots(1,2,figsize=(10.5,4.4),layout='constrained')
    for al,co in [('simple_random','#8B99A7'),('exposure_stratified','#D48028')]:
        for prior,ls in [(0,'-'),(20,'--')]:
            h=d[(d.allocation==al)&(d.prior_strength==prior)].sort_values('n')
            name=('简单随机' if al=='simple_random' else '按吸烟分层')+('；本地Jeffreys' if prior==0 else '；外部收缩20')
            axs[0].plot(h.n,h.mae_logor,ls,marker='o',color=co,label=name)
            axs[1].plot(h.n,h.success_fraction,ls,marker='o',color=co)
    axs[0].set_ylabel('前向预测 MAE（logOR）');axs[1].set_ylabel('|预测误差| ≤ 0.10的重复比例');axs[1].axhline(.8,color='.55',ls=':',label='规划阈值80%');axs[1].set_ylim(0,1)
    for ax,l in zip(axs,'ab'):ax.set_xticks([100,300,500,1000]);ax.set_xlabel('本地验证样本量');ax.grid(alpha=.12);label(ax,l)
    axs[0].legend(fontsize=7,loc='upper right');finish(fig,'Fig6_validation_design')

    inv=pd.read_csv(RES/'inverse_transport_predictions.csv');dd=pd.read_csv(RES/'inverse_validation_design_summary.csv')
    fig,axs=plt.subplots(1,2,figsize=(10,4.4),layout='constrained')
    counts=inv.groupby('method').valid.agg(['sum','count'])
    methods=['external_marginal_inversion','conditional_likelihood'];v=counts.loc[methods,'sum']
    axs[0].bar(['外部边际反演','外部条件似然'],v,color=['#7F8B98','#9A6C49']);axs[0].set_ylim(0,24);axs[0].set_yticks([0,6,12,18,24]);axs[0].set_ylabel('有效解波次数 / 24')
    for j,x in enumerate(v):axs[0].text(j,x+.5,f'{int(x)}/24',ha='center')
    for al,co in [('simple_random','#8B99A7'),('exposure_stratified','#D48028')]:
        h=dd[(dd.allocation==al)&(dd.prior_strength==0)].groupby('n').valid_fraction.mean()
        axs[1].plot(h.index,h.values,marker='o',color=co,label='简单随机' if al=='simple_random' else '按吸烟分层')
    axs[1].set_ylim(0,1.05);axs[1].set_xticks([100,300,500,1000]);axs[1].set_xlabel('本地验证样本量');axs[1].set_ylabel('边际反演得到合法概率的比例');axs[1].legend()
    for ax,l in zip(axs,'ab'):label(ax,l)
    finish(fig,'Fig7_inverse')

    w=pd.read_csv(RES/'nhanes_survey_design.csv')
    fig,ax=plt.subplots(figsize=(8,4.6),layout='constrained')
    yy=np.arange(len(w))
    for suffix,offset,color,labeltext in [('unweighted',-.12,'#8B99A7','未加权'),('weighted',.12,'#3F6B96','体检权重＋分层PSU方差')]:
        val=w[f'delta_{suffix}'];lo=w[f'lo_{suffix}'];hi=w[f'hi_{suffix}']
        ax.errorbar(val,yy+offset,xerr=[val-lo,hi-val],fmt='o',color=color,ms=4,capsize=2,label=labeltext)
    ax.set_yticks(yy,w.dataset);ax.axvline(0,color='.6',ls='--');ax.set_xlabel('吸烟—高血压 Δ（95%区间）');ax.legend(fontsize=8);finish(fig,'FigS1_survey_design')
    print('Generated 7 figures in PNG/PDF/SVG.',flush=True)

if __name__=='__main__':main()
