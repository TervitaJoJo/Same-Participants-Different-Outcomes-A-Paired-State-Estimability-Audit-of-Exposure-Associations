from common import REV
from pathlib import Path
import re
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT

def font(run,size=10.5,bold=None):
    run.font.name='Times New Roman';run.font.size=Pt(size)
    run._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'宋体')
    if bold is not None:run.bold=bold

def inline(p,text,size=10.5):
    for chunk in re.split(r'(\*\*.*?\*\*)',text):
        if not chunk:continue
        strong=chunk.startswith('**') and chunk.endswith('**')
        r=p.add_run(chunk[2:-2] if strong else chunk);font(r,size,strong)

def configure(doc,title):
    s=doc.sections[0];s.page_width=Cm(21);s.page_height=Cm(29.7)
    s.top_margin=Cm(2);s.bottom_margin=Cm(2);s.left_margin=Cm(2.15);s.right_margin=Cm(2.15)
    s.header_distance=Cm(.8);s.footer_distance=Cm(.9)
    for name in ['Normal','Title','Heading 1','Heading 2']:
        style=doc.styles[name];style.font.name='Times New Roman'
        style._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'宋体' if name=='Normal' else '黑体')
    st=doc.styles['Normal'];st.font.size=Pt(10.5);st.paragraph_format.line_spacing=1.25;st.paragraph_format.space_after=Pt(6)
    st.paragraph_format.widow_control=True
    for name,size in [('Title',17),('Heading 1',13),('Heading 2',11.5)]:
        st=doc.styles[name];st.font.size=Pt(size);st.font.bold=True;st.font.color.rgb=RGBColor.from_string('243746')
        st.paragraph_format.space_before=Pt(10);st.paragraph_format.space_after=Pt(6);st.paragraph_format.keep_with_next=True
    hp=s.header.paragraphs[0];hp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    font(hp.add_run('2026年9月16日 · 实证修订工作稿'),8)
    fp=s.footer.paragraphs[0];fp.alignment=WD_ALIGN_PARAGRAPH.CENTER
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');fp._p.append(field)
    doc.core_properties.title=title;doc.core_properties.author='';doc.core_properties.subject='同人双结局比较、治疗敏感性、参数迁移与验证设计'

def add_table(doc,rows):
    n=len(rows[0]);t=doc.add_table(rows=0,cols=n);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    t.style='Table Grid'
    width=16.7/n
    # Variable widths for long labels and paired CI strings.
    widths=[width]*n
    if n==2:widths=[2.4,14.3]
    if n==7:widths=[1.9,1.4,3.7,3.1,2.2,2.2,2.2] if rows[0][0]=='数据库' else [3.5,2.2,2.3,2.2,2.2,2.2,2.1]
    if n==6:widths=[3.2,1.0,1.6,2.1,2.2,6.6]
    if n==5:widths=[3.4,2.0,5.2,2.6,3.5] if '范围' in rows[0] else [2.3,3.0,1.5,3.5,6.4]
    if n==3:widths=[6.2,5.25,5.25]
    if n==4:widths=[2.2,4.8,4.8,4.9]
    scale=16.7/sum(widths);widths=[w*scale for w in widths]
    for c,w in zip(t.columns,widths):c.width=Cm(w)
    for i,row in enumerate(rows):
        cells=t.add_row().cells
        trpr=t.rows[-1]._tr.get_or_add_trPr();ns=OxmlElement('w:cantSplit');trpr.append(ns)
        if i==0:
            repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
        for j,value in enumerate(row):
            cell=cells[j];cell.width=Cm(widths[j]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p=cell.paragraphs[0];p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3);p.paragraph_format.line_spacing=1.05
            if (i==0 or n==7 or len(rows)<=10) and i<len(rows)-1:p.paragraph_format.keep_with_next=True
            inline(p,value,8 if n<=5 else 7.8)
            if i==0:
                for r in p.runs:r.bold=True
                shd=OxmlElement('w:shd');shd.set(qn('w:fill'),'E7EEF3');cell._tc.get_or_add_tcPr().append(shd)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

def build(source):
    doc=Document();lines=source.read_text(encoding='utf-8').splitlines();configure(doc,lines[0].removeprefix('# '))
    i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line.startswith('|') and i+1<len(lines) and re.match(r'^\|[\s|:-]+$',lines[i+1]):
            rows=[[x.strip() for x in line.strip('|').split('|')]];i+=2
            while i<len(lines) and lines[i].startswith('|'):
                rows.append([x.strip() for x in lines[i].strip().strip('|').split('|')]);i+=1
            add_table(doc,rows);continue
        image=re.match(r'^!\[(.*?)\]\((.*?)\)$',line)
        if image:
            file=source.parent/image.group(2);p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.keep_with_next=True;p.paragraph_format.space_after=Pt(3)
            # Tall forest has its own page; width still allows readable text.
            p.add_run().add_picture(str(file),width=Cm(16.4))
        elif line.startswith('# '):
            p=doc.add_paragraph(line[2:],style='Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        elif line.startswith('### '):doc.add_paragraph(line[4:],style='Heading 2')
        elif line.startswith('## '):doc.add_paragraph(line[3:],style='Heading 1')
        else:
            p=doc.add_paragraph()
            caption=bool(re.match(r'^(图\d+|表\d+|补充表S\d+)\s*\|',line))
            legend=bool(re.match(r'^(注：|图\d+注|补充图S\d+注)',line))
            if caption:
                p.paragraph_format.keep_with_next=True;p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                if line.startswith('图1 |'):p.paragraph_format.page_break_before=True
            if legend:p.paragraph_format.line_spacing=1.1
            inline(p,line,9 if legend else 10.5)
            if caption:
                for r in p.runs:r.bold=True
        i+=1
    out=source.with_suffix('.docx');doc.save(out)
    print(out,flush=True)

if __name__=='__main__':
    for name in ['正文_样本流程核查版.md','补充方法与结果_样本流程核查版.md','样本流程修改说明.md']:build(REV/name)
