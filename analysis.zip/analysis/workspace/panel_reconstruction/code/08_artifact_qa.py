from common import *
from zipfile import ZipFile
import xml.etree.ElementTree as E
import pymupdf as fitz
from PIL import Image,ImageOps,ImageDraw

QA=REV/'qa';QA.mkdir(exist_ok=True)
def main():
    reports=[];ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    for p in REV.glob('*.docx'):
        if p.name.startswith('~$'):continue
        with ZipFile(p) as z:
            root=E.fromstring(z.read('word/document.xml'))
            text=''.join(x.text or '' for x in root.findall('.//w:t',ns))
            images=[n for n in z.namelist() if n.startswith('word/media/')]
            assert len(text)>500 and '占位符' not in text
            reports.append(dict(file=p.name,characters=len(text),tables=len(root.findall('.//w:tbl',ns)),images=len(images)))
    pages=[]
    for p in REV.glob('*.pdf'):
        doc=fitz.open(p);thumbs=[]
        for i,page in enumerate(doc):
            txt=page.get_text()
            blocks=page.get_text('blocks')
            overflow=[b for b in blocks if b[0]<-1 or b[1]<-1 or b[2]>page.rect.width+1 or b[3]>page.rect.height+1]
            pages.append(dict(file=p.name,page=i+1,characters=len(txt),images=len(page.get_images()),outside_page=len(overflow)))
            pix=page.get_pixmap(matrix=fitz.Matrix(1,1))
            img=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
            out=QA/f'{p.stem}_{i+1:02d}.png';img.save(out)
            thumb=img.copy();thumb.thumbnail((270,390))
            canvas=Image.new('RGB',(280,410),'#D7DCE1');canvas.paste(thumb,((280-thumb.width)//2,20))
            ImageDraw.Draw(canvas).text((8,4),f'Page {i+1}',fill='black');thumbs.append(canvas)
        for start in range(0,len(thumbs),12):
            batch=thumbs[start:start+12];montage=Image.new('RGB',(4*280,((len(batch)+3)//4)*410),'white')
            for j,im in enumerate(batch):montage.paste(im,((j%4)*280,(j//4)*410))
            montage.save(QA/f'{p.stem}_montage_{start//12+1}.png')
        print(p.name,'pages',len(doc),'chars',[len(x.get_text()) for x in doc],flush=True)
    save(pd.DataFrame(reports),'document_structure_qa.csv');save(pd.DataFrame(pages),'pdf_page_qa.csv')
    p=pd.read_csv(RES/'validation_design_repetitions.csv');assert len(p)==96000
    t=pd.read_csv(RES/'treatment_definition_comparison.csv')
    assert np.allclose(t.delta_treatment-t.delta_threshold,t['shift'],atol=1e-7)
    assert np.allclose(t.shift_lo+t.shift_hi,2*t['shift'],atol=1e-7)
    print('Artifacts and numeric difference identities verified.',flush=True)

if __name__=='__main__':main()
