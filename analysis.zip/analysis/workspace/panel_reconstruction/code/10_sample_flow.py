"""Reconstruct reporting denominators without changing frozen analysis membership.

Starts are database-specific local analysis frames, not recruitment denominators.
All exclusions are sequential; missing outcome categories are mutually exclusive.
"""
from common import *
import json, hashlib, sys
import pyreadstat

sys.stdout.reconfigure(encoding='utf-8')
ORDER = ['CHARLS','CHNS','ELSA','LASI','ENSANUT','HAALSI','NHANES']
CN = {'China':'中国','England':'英格兰','India':'印度','Mexico':'墨西哥','South Africa':'南非','United States':'美国'}
RULES = {
 'CHARLS': ('2011', '未额外限龄', '2011协调宽表，与同波健康问卷匹配；当前稿继承历史字符串ID匹配集合，本步骤未额外限龄'),
 'CHNS': ('2009', '≥45岁', '2009协调体检资料，已限年龄≥45岁且收缩压可用'),
 'ELSA': ('w2、w4、w6、w8、w9', '50–110岁', '协调文件与护士访视按参与者匹配后，限50–110岁'),
 'LASI': ('w1', '45–110岁', '协调文件73,408条中，限45–110岁后66,617条；此前排除6,791条'),
 'ENSANUT': ('2012、2018、2021–2025', '成人问卷匹配样本', '体检/血压文件与成人问卷匹配后的协调记录；未再设置统一年龄阈值'),
 'HAALSI': ('基线', '未额外限龄', '基线协调文件全部5,059条；本步骤未额外限龄'),
 'NHANES': ('1999–2000、2005–2018（8周期）', '≥20岁', '各纳入周期DEMO人口学文件中年龄≥20岁者，左连接血压及诊断资料；不含2001–2004周期'),
}

def cov(ds):
    return ['age','male'] if ds.startswith('HAALSI') or (ds.startswith('ENSANUT') and ds != 'ENSANUT 2012') else ['age','male','edu']

def main():
    frozen = pd.read_csv(DATA/'hypertension_panel.csv.gz',low_memory=False)
    primary = pd.read_csv(RES/'primary_corrected.csv').set_index('dataset')
    panel = pd.read_csv(OLD/'data/panel_individual.csv',low_memory=False)
    china = module('flow_china',BASE/'survey_sources/code/10_prevalent_china.py')
    elsa = module('flow_elsa',BASE/'survey_panels/code/31_elsa_three_diseases.py')
    rows=[]; checks=[]; issues=[]

    def emit(ds,d):
        db=ds.split()[0];d=d.copy()
        paired=d[['M','S']].notna().all(axis=1)
        exposed=paired & d.smoke.notna()
        complete=exposed & d[cov(ds)].notna().all(axis=1)
        target=frozen[frozen.dataset==ds].dropna(subset=['M','S','smoke',*cov(ds)])
        cols=['M','S','smoke',*cov(ds)]
        # Compare all model input values and multiplicities, not just a target n.
        a=d.loc[complete,cols].astype(float).sort_values(cols).to_numpy()
        b=target[cols].astype(float).sort_values(cols).to_numpy()
        assert a.shape==b.shape and np.allclose(a,b), (ds,a.shape,b.shape)
        assert int(complete.sum())==int(primary.loc[ds,'n']), ds
        r=dict(database=db,dataset=ds,country=primary.loc[ds,'country'],
               start_n=len(d),missing_M_only=int((d.M.isna()&d.S.notna()).sum()),
               missing_S_only=int((d.M.notna()&d.S.isna()).sum()),
               missing_both=int((d.M.isna()&d.S.isna()).sum()),paired_n=int(paired.sum()),
               excluded_smoke=int((paired & ~exposed).sum()),
               excluded_covariates=int((exposed & ~complete).sum()),complete_n=int(complete.sum()),
               age_min_complete=float(d.loc[complete,'age'].min()),age_max_complete=float(d.loc[complete,'age'].max()),
               age_rule=RULES[db][1],start_definition=RULES[db][2])
        assert r['start_n']==sum(r[k] for k in ['missing_M_only','missing_S_only','missing_both','excluded_smoke','excluded_covariates','complete_n'])
        rows.append(r);checks.append(dict(dataset=ds,model_inputs_match=True,count_matches=True,sequential_identity=True))
        print(ds, {k:r[k] for k in ['start_n','paired_n','excluded_smoke','excluded_covariates','complete_n']},flush=True)

    d=china.charls_cross().rename(columns={'smoke_current':'smoke'})
    raw=pyreadstat.read_dta(str(BASE/'CHARLS/2011/health_status_and_functioning.dta'),usecols=['ID','da007_1_'])[0]
    raw['key']=pd.to_numeric(raw.ID);raw['S_new']=binary(raw.da007_1_,1,(2,))
    d['key']=pd.to_numeric(d.ID);d=d.merge(raw[['key','S_new']],on='key',how='left',validate='one_to_one')
    linked=d.S.notna()
    recovered=int((~linked & d[['M','S_new','smoke','age','male','edu']].notna().all(axis=1)).sum())
    issues.append(dict(dataset='CHARLS 2011',historical_unlinked=int((~linked).sum()),
                       additional_complete_after_numeric_id_match=recovered))
    # Reproduce the *actual* historical selection before the prior 57-row repair.
    # Numeric ID normalization would recover records; that is a separate reanalysis.
    d['S']=d.S_new.where(linked);emit('CHARLS 2011',d)
    for ds,g in frozen.groupby('dataset'):
        if ds.startswith(('CHNS','ENSANUT','LASI','HAALSI')):emit(ds,g)
    for w,(path,wfilter) in elsa.NURSE.items():
        d=elsa.wave_frame(w,path,wfilter).rename(columns={'M_htn':'M','S_htn':'S'})
        emit(f'ELSA w{w}',d)
    for ds in primary.index[primary.index.str.startswith('NHANES')]:
        cyc=ds.split()[-1];folder=BASE/'NHANES'/cyc
        def rd(prefix):return pd.read_sas(next(folder.glob(prefix+'*.xpt')),format='xport')
        demo=rd('DEMO');bp=rd('BPX');q=rd('BPQ');smq=rd('SMQ')
        sy=[c for c in bp if c.startswith('BPXSY')];di=[c for c in bp if c.startswith('BPXDI')]
        bp[sy+di]=bp[sy+di].where(bp[sy+di]>0)
        bp['M']=np.where(bp[sy+di].notna().any(axis=1),((bp[sy].mean(axis=1)>=140)|(bp[di].mean(axis=1)>=90)).astype(float),np.nan)
        q['S']=binary(q.BPQ020,1,(2,))
        d=demo[demo.RIDAGEYR>=20].copy()
        d['age']=d.RIDAGEYR;d['male']=binary(d.RIAGENDR,1,(2,));d['edu']=d.DMDEDUC2.where(d.DMDEDUC2<=5)
        d=d.merge(bp[['SEQN','M']],on='SEQN',how='left',validate='one_to_one').merge(q[['SEQN','S']],on='SEQN',how='left',validate='one_to_one')
        old=panel[panel.dataset==ds]
        d=d.merge(old[['SEQN','smoke']],on='SEQN',how='left',validate='one_to_one')
        # Smoking coding is inherited here so membership and model inputs stay frozen.
        emit(ds,d)
        a=d.dropna(subset=['M','S','smoke',*cov(ds)]).merge(smq[['SEQN','SMQ040']],on='SEQN',how='left',validate='one_to_one')
        issues.append(dict(dataset=ds,smq040_2_coded_zero=int(((a.SMQ040==2)&(a.smoke==0)).sum())))

    flow=pd.DataFrame(rows);flow['sort_db']=flow.database.map({x:i for i,x in enumerate(ORDER)})
    flow=flow.sort_values(['sort_db','dataset']).drop(columns='sort_db')
    save(flow,'sample_flow_reconstructed.csv');save(pd.DataFrame(checks),'sample_flow_checks.csv')
    summary=[]
    for db in ORDER:
        g=flow[flow.database==db]
        summary.append(dict(database=db,region=CN[g.country.iloc[0]],waves=RULES[db][0],wave_n=len(g),age_rule=RULES[db][1],start_n=int(g.start_n.sum()),paired_n=int(g.paired_n.sum()),complete_n=int(g.complete_n.sum()),start_definition=RULES[db][2]))
    save(pd.DataFrame(summary),'sample_flow_database_summary.csv')
    save(pd.DataFrame(issues),'sample_flow_additional_coding_audit.csv')
    multi=pd.read_csv(RES/'multidisease_corrected.csv');treat=pd.read_csv(RES/'treatment_definition_comparison.csv')
    halves=pd.read_csv(RES/'independent_half_predictions.csv').drop_duplicates('dataset')
    design=pd.read_csv(RES/'validation_design_samples.csv')
    counts={k:int(flow[k].sum()) for k in ['start_n','missing_M_only','missing_S_only','missing_both','paired_n','excluded_smoke','excluded_covariates','complete_n']}
    counts.update(evaluated_databases=11,included_databases=7,included_waves=24,regions=6,
        elsa_unique=int(frozen[frozen.dataset.str.startswith('ELSA')].uid.nunique()),
        calibration_records=int(halves.n_calibration.sum()),evaluation_records=int(halves.n_evaluation.sum()),
        design_pool=int(design.calibration_pool.sum()),design_evaluation=int(design.evaluation_n.sum()))
    for ex in ['smoke','obese']:
        counts[f'multidisease_{ex}_n']=int(multi[multi.exposure==ex].n.sum())
        counts[f'multidisease_{ex}_cells']=int((multi.exposure==ex).sum())
        counts[f'treatment_{ex}_n']=int(treat[treat.exposure==ex].n.sum())
        counts[f'treatment_{ex}_waves']=int((treat.exposure==ex).sum())
    assert counts['calibration_records']+counts['evaluation_records']==counts['complete_n']
    (RES/'sample_flow_counts.json').write_text(json.dumps(counts,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(counts,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
