"""Data-driven vector sample flow for the frozen manuscript version."""
from common import REV, RES
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

def main():
    c=json.loads((RES/'sample_flow_counts.json').read_text(encoding='utf-8'))
    plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,ax=plt.subplots(figsize=(7.2,8.1));fig.subplots_adjust(left=.01,right=.99,bottom=.01,top=.99)
    ax.set(xlim=(0,100),ylim=(0,112));ax.axis('off')
    textboxes=[]
    def box(x,y,w,h,text,kind='main',size=9):
        fill,edge={'main':('#F0F5F9','#718DA6'),'exclude':('#FFF6E9','#CAA572'),'final':('#DDEFEA','#4C8C7B'),'module':('#F6F7F8','#9AA6AF')}[kind]
        p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.2,rounding_size=.8',facecolor=fill,edgecolor=edge,lw=.85)
        ax.add_patch(p);t=ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,linespacing=1.45,color='#213547')
        textboxes.append((p,t))
    def arrow(a,b):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=9,lw=.9,color='#607582',shrinkA=1,shrinkB=1))
    def heading(y,t):ax.text(2,y,t,fontweight='bold',fontsize=10,color='#243C50',va='bottom')
    heading(108,'A  数据库筛选')
    box(2,98,52,8,'已获得并评估的数据库\nn = 11')
    box(59,87,39,19,'未纳入横断面主分析：4个\nKLoSA、SHARE：未形成实测配对\nMHAS：完整样本287条（<300）\nHRS：实测与自报并非同波次','exclude',8.1)
    arrow((54,102),(59,102));arrow((28,98),(28,94))
    box(2,85,52,9,'纳入7个数据库\n6个国家/地区 · 24个波次')
    heading(79,'B  当前稿的记录筛选（各库起点及前置条件见表1、补充表S1）')
    box(2,68,52,9,f'可核查起始记录\nn = {c["start_n"]:,}')
    box(59,58,39,19,f'未形成双结局配对：{c["start_n"]-c["paired_n"]:,}\n仅实测不可用：{c["missing_M_only"]:,}\n仅自报未获得：{c["missing_S_only"]:,}\n两者均未获得：{c["missing_both"]:,}\n含CHARLS历史匹配未链接记录','exclude',8.1)
    arrow((28,68),(28,64));arrow((28,66),(59,66))
    box(2,55,52,9,f'实测与自报均可用\nn = {c["paired_n"]:,}')
    box(59,47,39,8,f'排除吸烟信息缺失\nn = {c["excluded_smoke"]:,}','exclude')
    arrow((28,55),(28,51));arrow((28,53),(59,51))
    box(2,42,52,9,f'进一步具有吸烟信息\nn = {c["paired_n"]-c["excluded_smoke"]:,}')
    box(59,35,39,8,f'排除模型协变量缺失\nn = {c["excluded_covariates"]:,}','exclude')
    arrow((28,42),(28,38));arrow((28,40),(59,39))
    box(2,27,52,11,f'吸烟—高血压完整主分析\nn = {c["complete_n"]:,} 条记录\nELSA：29,703条记录 / 13,060人','final',9)
    heading(22,'C  各分析模块的分母（模块重叠，不相加；扩展按疾病另行筛选）')
    box(2,12,46,9,f'治疗定义敏感性\n吸烟：16波次 / {c["treatment_smoke_n"]:,}条\n肥胖：12波次 / {c["treatment_obese_n"]:,}条','module',8.4)
    box(52,12,46,9,f'主分析的独立半样本验证\n校准集：{c["calibration_records"]:,}条\n评估集：{c["evaluation_records"]:,}条','module',8.4)
    box(2,1,46,9,f'验证样本设计：6波次，年龄≥50岁\n校准池：{c["design_pool"]:,}人\n独立评估集：{c["design_evaluation"]:,}人','module',8.4)
    box(52,1,46,9,f'三疾病扩展：人—疾病记录\n吸烟：42单元 / {c["multidisease_smoke_n"]:,}条\n肥胖：36单元 / {c["multidisease_obese_n"]:,}条','module',8.4)
    fig.canvas.draw();renderer=fig.canvas.get_renderer()
    for p,t in textboxes:
        a=p.get_window_extent(renderer);b=t.get_window_extent(renderer)
        assert a.contains(b.x0,b.y0) and a.contains(b.x1,b.y1),t.get_text()
    for ext in ['png','pdf','svg']:fig.savefig(REV/'figures'/f'Fig1_sample_flow.{ext}',dpi=300,facecolor='white')
    plt.close(fig)
    print('Figure 1 exported; all text fits inside its box.')

if __name__=='__main__':main()
