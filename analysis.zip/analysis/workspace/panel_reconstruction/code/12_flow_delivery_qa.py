"""Verify reporting identities, figure references and source provenance."""
from common import *
import re, hashlib
from docx import Document

def main():
    f=pd.read_csv(RES/'sample_flow_reconstructed.csv')
    db=pd.read_csv(RES/'sample_flow_database_summary.csv')
    p=pd.read_csv(RES/'primary_corrected.csv').set_index('dataset')
    assert len(f)==24 and len(db)==7
    exclusions=['missing_M_only','missing_S_only','missing_both','excluded_smoke','excluded_covariates']
    assert (f.start_n==f[exclusions].sum(axis=1)+f.complete_n).all()
    assert (f.paired_n==f.complete_n+f.excluded_smoke+f.excluded_covariates).all()
    assert f.set_index('dataset').complete_n.sort_index().equals(p.n.sort_index())
    assert f.complete_n.sum()==db.complete_n.sum()==212921
    md=(REV/'正文_样本流程核查版.md').read_text(encoding='utf-8')
    assert re.findall(r'^图(\d+) \|',md,re.M)==list('1234567')
    assert set(re.findall(r'图(\d+)',md))==set('1234567')
    for rel in re.findall(r'!\[.*?\]\((.*?)\)',md):assert (REV/rel).is_file(),rel
    doc=Document(REV/'正文_样本流程核查版.docx')
    assert len(doc.inline_shapes)==7 and len(doc.tables)==4
    assert len(doc.tables[0].rows)==9 and len(doc.tables[0].columns)==7
    for t in doc.tables:
        for row in t.rows:assert len(row.cells)==len(t.columns)
    paths=[DATA/'hypertension_panel.csv.gz',OLD/'data/panel_individual.csv',
        BASE/'CHARLS/analysis/charls_analysis_wide.csv',BASE/'CHARLS/2011/health_status_and_functioning.dta',
        BASE/'survey_sources/code/10_prevalent_china.py',BASE/'survey_sources/code/13_differential_sensitivity.py',
        BASE/'survey_panels/code/31_elsa_three_diseases.py',
        BASE/'ELSA/Raw_data/UKDA-5050-stata/stata/stata13_se/h_elsa_g3.dta',
        BASE/'ELSA/Raw_data/wave2/wave_2_nurse_data_v2.dta',BASE/'ELSA/Raw_data/wave4/wave_4_nurse_data.dta',
        BASE/'ELSA/Raw_data/wave6/wave_6_elsa_nurse_data_v2.dta',BASE/'ELSA/Raw_data/elsa_nurse_w8w9_data_eul.dta']
    for ds in p.index[p.index.str.startswith('NHANES')]:
        folder=BASE/'NHANES'/ds.split()[-1]
        paths.extend(next(folder.glob(x+'*.xpt')) for x in ['DEMO','BPX','BPQ','SMQ'])
    paths.extend(RES/name for name in ['primary_corrected.csv','multidisease_corrected.csv','treatment_definition_comparison.csv','independent_half_predictions.csv','validation_design_samples.csv'])
    records=[]
    for path in sorted(set(paths)):
        with path.open('rb') as stream:h=hashlib.file_digest(stream,'sha256').hexdigest()
        records.append(dict(path=str(path.relative_to(BASE)),bytes=path.stat().st_size,sha256=h))
    save(pd.DataFrame(records),'sample_flow_source_manifest.csv')
    result=dict(waves=24,databases=7,arithmetic='passed',frozen_model_input_checks='24 passed',
        figures='1–7, references and files verified',main_docx_tables=4,
        caveat='Two historical construction issues remain unresolved; no model reanalysis in this delivery.')
    (RES/'sample_flow_delivery_qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(result)

if __name__=='__main__':main()
