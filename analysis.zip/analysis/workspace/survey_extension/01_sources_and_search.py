from pathlib import Path
import json,re,sys,urllib.request,urllib.parse,concurrent.futures
import pyreadstat,pandas as pd
import pymupdf as fitz
R=Path(__file__).resolve().parent;B=R.parent;sys.stdout.reconfigure(encoding='utf8')
# Focused raw questionnaires/codebooks; no exposure-effect calculations.
txt=(B/'HRS/public_survey_data/2018/h18cb/h2018cb.txt').read_text(encoding='utf8',errors='replace')
snips=[]
for term in ['QC005','QC006','QC116','QC117','QI859','QI860','QI854']:
 for m in list(re.finditer(r'\b'+term+r'\b',txt))[:4]:snips.append(txt[max(0,m.start()-100):m.start()+3300])
(R/'sources/hrs_raw_codebook.txt').write_text('\n\n'.join(snips),encoding='utf8')
book=fitz.open(B/'HRS/RAND HRS Data/Longitudinal and Cross-Wave Data Products/randhrs1992_2022v1.pdf')
out=[]
for term,pages in [('bp',range(798,807)),('diagnosis',range(400,419)),('smoking',range(584,614))]:
 for i in pages:
  text=book[i].get_text()
  if term!='smoking' or re.search('smok',text,re.I):out.append(f'\nPDF PAGE {i+1}\n{text}')
(R/'sources/hrs_derivation_details.txt').write_text('\n'.join(out),encoding='utf8')
m=json.loads((R/'audit/metadata.json').read_text(encoding='utf8'))
for key,cols in [('hrs_c',['QC005','QC006','QC116','QC117']),('mhas_core',['c4_12','c5_12','c51_12','c53_12','c54_12','yrschool_12']),('mhas_constructed',['educacion','edu_gru','tabaco_12'])]:
 d=pyreadstat.read_dta(m[key]['path'],usecols=cols)[0]
 (R/'audit'/f'{key}_values.json').write_text(json.dumps({c:{str(k):int(v) for k,v in d[c].value_counts(dropna=False).items()} for c in d},indent=2),encoding='utf8')
queries={
 'taiwan':'(TITLE_ABS:"smoking" OR TITLE_ABS:"smokers") AND (TITLE_ABS:"hypertension") AND (TITLE_ABS:"self-report" OR TITLE_ABS:"underreport") AND (TITLE_ABS:"Taiwan")',
 'selfreport_recent':'(TITLE:"self-reported" OR TITLE:"self-report") AND (TITLE:"hypertension" OR TITLE:"chronic diseases") AND FIRST_PDATE:[2021-01-01 TO 2026-09-18]',
 'hrs_profile':'TITLE:"Cohort Profile" AND TITLE_ABS:"Health and Retirement Study"',
 'mhas_profile':'(TITLE:"Mexican Health and Aging Study") AND (TITLE:"Profile" OR TITLE:"biomarkers" OR TITLE:"representative")',
 'mhas_weights':'TITLE_ABS:"Mexican Health and Aging" AND (TITLE_ABS:"four states" OR TITLE_ABS:"biomarker weights")',
}
def task(item):
 k,q=item;u='https://www.ebi.ac.uk/europepmc/webservices/rest/search?'+urllib.parse.urlencode({'query':q,'format':'json','resultType':'core','pageSize':25})
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'ManuscriptEvidenceAudit/1.0'}),timeout=40) as f:j=json.load(f)
  (R/'literature'/f'{k}.json').write_text(json.dumps(j,ensure_ascii=False,indent=2),encoding='utf8')
  return k,[(x.get('id'),x.get('pubYear'),x.get('doi'),x.get('title')) for x in j.get('resultList',{}).get('result',[])]
 except Exception as e:return k,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for k,j in pool.map(task,queries.items()):print(k,j,flush=True)
