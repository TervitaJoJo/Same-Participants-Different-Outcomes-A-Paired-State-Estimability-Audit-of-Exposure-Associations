from pathlib import Path
import json,sys,hashlib
import numpy as np,pandas as pd,pyreadstat
R=Path(__file__).resolve().parent;B=R.parent;sys.stdout.reconfigure(encoding='utf8')
meta=json.loads((R/'audit/metadata.json').read_text(encoding='utf8'));audit={};files={}
def read(k,cols):
 p=Path(meta[k]['path']);files[k]=dict(path=str(p),size=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
 return pyreadstat.read_dta(str(p),usecols=cols)[0]
def join(a,b,key,how='left'):
 assert not a.duplicated(key).any() and not b.duplicated(key).any()
 return a.merge(b,on=key,how=how,validate='one_to_one')
def binary(x,yes,no):return np.where(x.isin(yes),1.,np.where(x.isin(no),0.,np.nan))
def finish(d,name):
 d['programme']=name;d['dataset']=name+(' 2018' if name=='HRS' else ' 2012');d['country']='United States' if name=='HRS' else 'Mexico'
 d['M']=np.where(d[['sbp','dbp']].notna().all(axis=1),((d.sbp>=140)|(d.dbp>=90)).astype(float),np.nan)
 d['MT']=np.where(d[['M','med']].notna().all(axis=1),((d.M==1)|(d.med==1)).astype(float),np.nan)
 d['smoke']=np.where(d.smoke_status.notna(),(d.smoke_status==2).astype(float),np.nan)
 d.to_pickle(R/'data'/f'{name}_panel.pkl')
 g=d[d.age.between(50,79)];p=g.dropna(subset=['M','S']);s=p.dropna(subset=['smoke']);c=s.dropna(subset=['age','male','edu'])
 vals=[len(d),len(g),len(p),len(s),len(c)]
 row=dict(programme=name,dataset=d.dataset.iloc[0],**dict(zip(['start_n','age_n','paired_n','smoking_n','complete_n'],vals)),**dict(zip(['excluded_age','excluded_outcomes','excluded_smoking','excluded_covariates'],np.array(vals[:-1])-np.array(vals[1:]))))
 audit[name]['flow']=row;audit[name]['smoking_complete']=c.smoke_status.value_counts().to_dict();audit[name]['positive_component_weight_n']=int((c.wt>0).sum())
 audit[name]['reading_summary']=d[['sbp','dbp']].describe().to_dict();audit[name]['medication_missing_complete']=int(c.med.isna().sum())
 print(name,'FLOW',vals,'SMOKING',c.smoke_status.value_counts().to_dict(),'WEIGHT',(c.wt>0).sum(),flush=True)
 return row
# HRS: use contemporaneous history responses and documented RAND smoking carry-forward.
h=read('hrs_c',['hhid','pn','QC005','QC006','QC116','QC117'])
h['hhidpn']=pd.to_numeric(h.hhid)*1000+pd.to_numeric(h.pn)
rand=read('hrs_rand',['hhidpn','r14agey_b','ragender','raedyrs','raeduc','r14smoken','r14smokev','r14bpsys','r14bpdia','r14hibpe'])
h=join(h,rand,['hhidpn']);tr=read('hrs_tracker',['HHID','PN','QPMWGTR','STRATUM','SECU']).rename(columns={'HHID':'hhid','PN':'pn'})
h=join(h,tr,['hhid','pn']);ip=read('hrs_i',['hhid','pn','QI859','QI860','QI864','QI865','QI869','QI870'])
h=join(h,ip,['hhid','pn'])
pr=pyreadstat.read_dta(str(B/'HRS/public_survey_data/2018/h18sta/h18pr_r.dta'),usecols=['hhid','pn','QZ205'])[0];h=join(h,pr,['hhid','pn'])
ever=pd.Series(binary(h.QC116,[1],[5]),index=h.index)
ever.loc[h.QC116.isna()]=binary(h.loc[h.QC116.isna(),'QZ205'],[1],[5])
smoking=np.where(h.QC117.eq(1),2.,np.where(h.QC117.eq(5)&ever.eq(1),1.,np.where(ever.eq(0)&(h.QC117.isna()|h.QC117.eq(5)),0.,np.nan)))
rs=np.where(h.r14smoken.eq(1),2.,np.where(h.r14smoken.eq(0)&h.r14smokev.eq(1),1.,np.where(h.r14smoken.eq(0)&h.r14smokev.eq(0),0.,np.nan)))
check=np.isfinite(smoking)&np.isfinite(rs)
audit['HRS']={'raw_vs_rand_smoking_disagreements':int(np.sum(smoking[check]!=rs[check])),'raw_smoking_known':int(np.isfinite(smoking).sum()),'rand_smoking_known':int(np.isfinite(rs).sum()),'diagnosis_code6_n':int(h.QC005.eq(6).sum())}
if audit['HRS']['raw_vs_rand_smoking_disagreements']:
 print('HRS SMOKING DISAGREEMENTS',h.loc[check&(smoking!=rs),['QC116','QC117','QZ205','r14smoken','r14smokev']].value_counts(dropna=False).to_dict(),flush=True)
d=pd.DataFrame(dict(uid=h.hhid+':'+h.pn,household=h.hhid,age=h.r14agey_b,male=binary(h.ragender,[1],[2]),edu=h.raedyrs,edu3=h.raeduc,smoke_status=smoking,smoke_rand_status=rs,S=binary(h.QC005,[1,6],[4,5]),S_code6_no=binary(h.QC005,[1],[4,5,6]),sbp=h.r14bpsys,dbp=h.r14bpdia,med=binary(h.QC006,[1],[4,5,6]),wt=h.QPMWGTR,stratum=h.STRATUM,psu=h.SECU))
d.loc[h.QC006.isna()&h.QC005.isin([4,5,6]),'med']=0
audit['HRS']['bp_raw_ranges']={v:{'min':float(h[v].min()),'max':float(h[v].max())} for v in ['QI859','QI860','QI864','QI865','QI869','QI870']}
# Official RAND summaries encode the source's physical-test eligibility and valid-reading rules.
audit['HRS']['bp_source']='RAND R14BPSYS/R14BPDIA; same-wave 2018 readings; documented mean of last two when all three valid, otherwise mean of available valid readings.'
hf=finish(d,'HRS')
design=tr[(tr.QPMWGTR>0)&tr.STRATUM.ne(99)&tr.SECU.isin([1,2])][['hhid','pn','STRATUM','SECU']].copy();design['uid']=design.hhid+':'+design.pn
design.rename(columns={'STRATUM':'stratum','SECU':'psu'}).to_pickle(R/'data/HRS_design.pkl')
# MHAS: biomarker component is the assembled entry frame; all links are one-to-one.
m=read('mhas_bp',['cunicah','np','sist1_12','sist2_12','dias1_12','dias2_12','rpres1_12','rpres2_12','factora_12'])
core=read('mhas_core',['cunicah','np','age_12','sex_12','c4_12','c5_12','c51_12','c53_12','c54_12','yrschool_12'])
m=join(m,core,['cunicah','np']);co=read('mhas_constructed',['cunicah','np','educacion','edu_gru','tabaco_12']);m=join(m,co,['cunicah','np'])
st=np.where(m.c54_12.eq(1),2.,np.where(m.c51_12.eq(2),0.,np.where(m.c51_12.eq(1)&(m.c53_12.eq(2)|m.c54_12.eq(2)),1.,np.nan)))
audit['MHAS']={'biomarker_core_linked_n':int(m.age_12.notna().sum()),'never_current_contradiction_n':int((m.c51_12.eq(2)&m.c54_12.eq(1)).sum()),'current_reconstruction_disagreements':int(np.sum(np.where(np.isfinite(st),st==2,np.nan)[m.tabaco_12.notna()]!=m.tabaco_12[m.tabaco_12.notna()].to_numpy())),'bp_raw_ranges':{v:{'min':float(m[v].min()),'max':float(m[v].max()),'code999_n':int(m[v].eq(999).sum())} for v in ['sist1_12','sist2_12','dias1_12','dias2_12']}}
assert audit['MHAS']['current_reconstruction_disagreements']==0 and audit['MHAS']['never_current_contradiction_n']==0
bp=m[['sist1_12','sist2_12','dias1_12','dias2_12']].replace(999,np.nan)
assert (bp.dropna() >0).all().all() and (bp.max()<300).all()
d=pd.DataFrame(dict(uid=m.cunicah.astype(str)+':'+m.np.astype(str),household=m.cunicah.astype(str),age=m.age_12,male=binary(m.sex_12,[1],[2]),edu=m.educacion,edu3=m.edu_gru,smoke_status=st,S=binary(m.c4_12,[1],[2]),sbp=bp[['sist1_12','sist2_12']].mean(axis=1),dbp=bp[['dias1_12','dias2_12']].mean(axis=1),med=binary(m.c5_12,[1],[2]),wt=m.factora_12,stratum=1,psu=m.cunicah.astype(str)))
d.loc[m.c5_12.isna()&m.c4_12.eq(2),'med']=0
eligible=d.age.between(50,79)&d[['S','sbp','dbp']].notna().all(axis=1)
audit['MHAS']['paired_common_age_current_question_nonmissing']=int((eligible&m.c54_12.isin([1,2])).sum());audit['MHAS']['paired_common_age_education_recovered']=int((eligible&m.yrschool_12.isna()&d.edu.notna()).sum())
mf=finish(d,'MHAS');d[d.wt>0][['uid','stratum','psu']].to_pickle(R/'data/MHAS_design.pkl')
pd.DataFrame([hf,mf]).to_csv(R/'audit/new_flow.csv',index=False)
(R/'audit/panel_audit.json').write_text(json.dumps(audit,indent=2,default=lambda x:int(x)),encoding='utf8')
(R/'audit/source_hashes.json').write_text(json.dumps(files,indent=2),encoding='utf8')
