from pathlib import Path
import json,importlib.util,sys,warnings
import numpy as np,pandas as pd
from scipy.stats import t as tdist
R=Path(__file__).resolve().parent;B=R.parent;sys.stdout.reconfigure(encoding='utf8')
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load('paired_common',B/'corrected_panel/code/common.py');j=load('joint_common',B/'paired_state_core/code/common.py')
results=[];joint=[];audits=[];cells=[]
def cov(psi,g,design=None):
 arr=np.asarray(psi);arr=arr[:,None] if arr.ndim==1 else arr
 f=pd.DataFrame(arr,index=g.uid);f.index.name='uid'
 if design is None:
  design=g[['uid','stratum','psu']]
 z=design.merge(f.reset_index(),on='uid',how='left',validate='one_to_one').fillna({i:0. for i in range(arr.shape[1])})
 sums=z.groupby(['stratum','psu'])[list(range(arr.shape[1]))].sum();v=np.zeros((arr.shape[1],arr.shape[1]));df=0
 for _,ss in sums.groupby(level=0):
  x=ss.to_numpy();n=len(x);assert n>1
  x=x-x.mean(axis=0);v+=n/(n-1)*x.T@x;df+=n-1
 return v,df
def paired(g,label,weighted=False,survey=False):
 g=g.copy();X,names=c.design(g)
 for col in ['M','S']:
  tab=pd.crosstab(g.smoke,g[col]).reindex(index=[0,1],columns=[0,1],fill_value=0)
  if tab.min().min()<10:return dict(programme=g.programme.iloc[0],analysis=label,n=len(g),status='not fitted: fewer than 10 events/non-events in a contrast cell')
 bm,im,cm=c.fit_score(X,g.M,g.wt if weighted else None);bs,ii,cs=c.fit_score(X,g.S,g.wt if weighted else None)
 assert cm and cs and max(abs(bm).max(),abs(bs).max())<20
 psi=np.c_[im[:,1],ii[:,1],ii[:,1]-im[:,1]]
 if survey:
  design=pd.read_pickle(R/'data'/f'{g.programme.iloc[0]}_design.pkl');V,df=cov(psi,g,design);critical=tdist.ppf(.975,df)
 else:
  g['stratum']=1;g['psu']=g.household;V,df=cov(psi,g);critical=1.96
 vals=np.array([bm[1],bs[1],bs[1]-bm[1]]);se=np.sqrt(np.diag(V));lo=vals-critical*se;hi=vals+critical*se
 return dict(programme=g.programme.iloc[0],analysis=label,n=len(g),or_measured=np.exp(vals[0]),or_selfreport=np.exp(vals[1]),delta=vals[2],se=se[2],lo=lo[2],hi=hi[2],or_M_lo=np.exp(lo[0]),or_M_hi=np.exp(hi[0]),or_S_lo=np.exp(lo[1]),or_S_hi=np.exp(hi[1]),df=df,status='converged',weighted=weighted)
for name in ['HRS','MHAS']:
 d=pd.read_pickle(R/'data'/f'{name}_panel.pkl');g=d[d.age.between(50,79)].dropna(subset=['M','S','smoke','age','male','edu']).copy()
 for age,dd in [('common_age',g),('age50plus',d[d.age>=50].dropna(subset=['M','S','smoke','age','male','edu']))]:
  out=c.paired(dd);out.update(programme=name,dataset=dd.dataset.iloc[0],country=dd.country.iloc[0],analysis=age+'_map');results.append(out)
 results.append(paired(g,'threshold_noncurrent_household'))
 gw=g[(g.wt>0)&g.stratum.ne(99)&g.psu.notna()].copy()
 results.append(paired(gw,'weight_eligible_unweighted',survey=True));results.append(paired(gw,'component_weighted',weighted=True,survey=True))
 for ref in ['noncurrent','never']:
  gt=g.dropna(subset=['MT']).copy()
  if ref=='never':gt=gt[gt.smoke_status.ne(1)]
  results.append(paired(gt,'treatment_complete_threshold_'+ref))
  results.append(paired(gt.assign(M=gt.MT),'treatment_inclusive_'+ref))
 if name=='HRS':
  results.append(paired(g.assign(S=g.S_code6_no),'history_code6_as_no'))
  gr=g.dropna(subset=['smoke_rand_status']).copy();results.append(paired(gr.assign(smoke=(gr.smoke_rand_status==2).astype(float)),'RAND_smoking_sensitivity'))
 gj=g.dropna(subset=['smoke_status','edu3']).copy();gj['strata']=1;gj['cluster']=gj.household
 for (st,sex),dd in gj.groupby(['smoke_status','male']):
  for state,n in (2*dd.M+dd.S).value_counts().items():cells.append(dict(programme=name,smoke_status=st,male=sex,state=state,n=int(n)))
 for ref in ['never','noncurrent']:
  z=gj.copy();formula='C(smoke_status)*male + bs(age, df=4) + C(edu3)'
  if ref=='noncurrent':z['smoke_status']=np.where(z.smoke_status==2,2,0)
  try:
   vals,psi,aa=j.multinomial_marginal(z,formula)
  except Exception as e:
   audits.append(dict(programme=name,reference=ref,requested_formula=formula,status='failed',reason=str(e)));raise
  est=j.estimates(vals,psi,z,j.JOINT_NAMES)
  for x in est:x.update(programme=name,reference=ref,n=len(z));joint.append(x)
  aa.update(programme=name,reference=ref,formula=formula,status='converged');audits.append(aa)
 print(name,pd.DataFrame(results).query('programme==@name')[['analysis','n','or_measured','or_selfreport','delta','lo','hi']].to_string(index=False),flush=True)
 print('JOINT',pd.DataFrame(joint).query('programme==@name and metric in ["delta","unreported_component","history_normal_component"]')[['reference','metric','estimate','lo','hi']].to_string(index=False),flush=True)
pd.DataFrame(results).to_csv(R/'results/paired_models.csv',index=False)
pd.DataFrame(joint).to_csv(R/'results/joint_models.csv',index=False)
pd.DataFrame(cells).to_csv(R/'audit/joint_cells.csv',index=False)
(R/'audit/model_checks.json').write_text(json.dumps(audits,indent=2),encoding='utf8')
