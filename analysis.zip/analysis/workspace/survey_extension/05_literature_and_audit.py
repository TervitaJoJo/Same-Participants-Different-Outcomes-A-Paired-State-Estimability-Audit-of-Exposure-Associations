from pathlib import Path
import json,re,sys,urllib.request,urllib.parse,concurrent.futures
import pandas as pd,numpy as np
from lxml import html
R=Path(__file__).resolve().parent;sys.stdout.reconfigure(encoding='utf8')
selected={'24671021':'hrs2014','25626437':'mhas2017','39692026':'mhasBiomarkers2024','39161156':'LaMonte2024TreatedHypertension','39446864':'GUTS2024Hypertension'}
records={}
for fn in ['mhas_profile.json','hrs_profile.json','selfreport_recent.json']:
 for x in json.loads((R/'literature'/fn).read_text(encoding='utf8'))['resultList']['result']:
  if x.get('id') in selected:records[x['id']]=x
def verify(item):
 pmid,x=item;doi=x['doi'];u='https://api.crossref.org/works/'+urllib.parse.quote(doi,safe='')
 try:
  req=urllib.request.Request(u,headers={'User-Agent':'ManuscriptCitationVerification/1.0'})
  cache=R/'literature'/f'{pmid}_crossref.json'
  cr=json.loads(cache.read_text(encoding='utf8')) if cache.exists() else json.load(urllib.request.urlopen(req,timeout=40))['message']
  (R/'literature'/f'{pmid}_crossref.json').write_text(json.dumps(cr,ensure_ascii=False,indent=2),encoding='utf8')
  norm=lambda s:re.sub('[^a-z0-9]','',s.lower())
  assert norm(cr['title'][0])==norm(x['title']),(cr['title'],x['title'])
  au=x['authorList']['author'][0];a=au.get('lastName','')+', '+au.get('initials','')+'. et al.'
  issue=x.get('journalInfo',{});journal=issue.get('journal',{}).get('medlineAbbreviation','');year=issue.get('yearOfPublication',x.get('pubYear'))
  ref=dict(key=selected[pmid],authors=a,title=x['title'].rstrip('.'),journal=journal,volume=issue.get('volume',''),pages=x.get('pageInfo',''),year=int(year),doi=doi,url='')
  return ref,dict(pmid=pmid,doi=doi,title_match=True,epmc_year=x.get('pubYear'),issue_year=year,crossref_print=cr.get('published-print'),crossref_online=cr.get('published-online'),abstract_read=True)
 except Exception as e:return None,dict(pmid=pmid,error=str(e))
refs=[];checks=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
 for ref,check in pool.map(verify,records.items()):
  print(ref or check,flush=True);checks.append(check)
  if ref:refs.append(ref)
(R/'literature/new_references.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf8')
(R/'literature/citation_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf8')
assert len(refs)==5
# Additional source/weight audit, distinct from inference about a mechanism.
out=[]
for name in ['HRS','MHAS']:
 d=pd.read_pickle(R/'data'/f'{name}_panel.pkl');g=d[d.age.between(50,79)].dropna(subset=['M','S','smoke','age','male','edu']);w=g[g.wt>0]
 for label,z in [('All',w),('Never',w[w.smoke_status==0]),('Former',w[w.smoke_status==1]),('Current',w[w.smoke_status==2])]:
  out.append(dict(programme=name,group=label,n=len(z),sum_weights=z.wt.sum(),weight_ess=z.wt.sum()**2/(z.wt**2).sum(),min_weight=z.wt.min(),median_weight=z.wt.median(),max_weight=z.wt.max(),max_weight_share=z.wt.max()/z.wt.sum()))
 v=g[(g.M==0)&(g.S==1)].dropna(subset=['med']);print(name,'V treated',int(v.med.sum()),len(v),flush=True)
 pd.DataFrame({'M':g.M,'S':g.S,'smoking':g.smoke_status,'med':g.med}).groupby(['smoking','M','S']).agg(n=('M','size'),treated=('med','sum')).to_csv(R/'results'/f'{name}_joint_counts.csv')
pd.DataFrame(out).to_csv(R/'audit/weight_diagnostics.csv',index=False)
page=html.fromstring((R/'literature/natcomms_guidelines.html').read_text(encoding='utf8'))
print('JOURNAL LINKS',[(a.text_content(),a.get('href')) for a in page.xpath('//a[@href]') if re.search('type|format|prepar',a.text_content(),re.I)][:25])
