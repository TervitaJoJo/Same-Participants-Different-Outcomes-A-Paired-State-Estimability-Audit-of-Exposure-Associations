from pathlib import Path
import json
R=Path(__file__).resolve().parent
p=R/'manuscript.md';s=p.read_text(encoding='utf8')
s=s.replace('[[TABLE1]]\n\n','',1).replace('[[FIG1]]','[[TABLE1]]\n\n[[FIG1]]',1)
a=s.index('The pattern was heterogeneous.');b=s.index('\n\n',a)
s=s[:a]+'''The pattern was heterogeneous. CHARLS odds ratios were 1.105 for measured blood pressure and 0.737 for reported hypertension, with Δ = −0.405 (95% CI −0.538 to −0.273). LASI showed inverse associations under both definitions and a small gap. ELSA wave 9 showed the opposite point-estimate direction, Δ = 0.224 (−0.166 to 0.614).'''+s[b:]
a=s.index('The added HRS and MHAS applications') if 'The added HRS and MHAS applications' in s else s.index('HRS and MHAS exposed further boundaries');b=s.index('\n\n',a)
s=s[:a]+'''HRS and MHAS exposed further boundaries (Supplementary Fig. 7 and Supplementary Tables 25–29). HRS showed little conditional gap: Δ = 0.008 (95% CI −0.196 to 0.211). MHAS shifted downward without weights, Δ = −0.249 (−0.638 to 0.141), but its component-weighted estimate changed direction and was imprecise: 0.578 (−0.596 to 1.752). The same weight-eligible sample gave −0.259 without weights, locating the point-estimate change in weighting rather than exclusion. Current-versus-never joint-state gaps were uncertain in both programmes.'''+s[b:]
a=s.index('The multidisease analysis distinguished');b=s.index('\n\n',a)
s=s[:a]+'''The multidisease analysis distinguished definition gaps from inverse associations shared by both outcomes. Across 42 disease-wave cells in CHARLS, ELSA and NHANES, reported-diagnosis odds ratios were below one in 12 of 14 diabetes cells, compared with 11 for measured diabetes (Supplementary Fig. 1 and Supplementary Tables 3–5). Corresponding counts were five versus one for hypertension and six versus two for dyslipidaemia. These original-age comparisons motivated the NHANES diabetes boundary tests.'''+s[b:]
a=s.index('### HRS and MHAS framework applications');b=s.index('### Healthcare contacts and smoking transitions in CHARLS',a)
s=s[:a]+'''### HRS and MHAS framework applications

HRS 2018 combined same-wave RAND blood-pressure summaries with raw QC005 diagnosis history. Previously diagnosed, currently resolved hypertension counted as history; a sensitivity recoded it as no. Smoking used QC116/QC117 and contemporaneous QZ205 preloads. MHAS 2012 linked biomarker, core and constructed releases on household/person identifiers. Blood pressure averaged available readings; diagnosis used c4_12. Smoking distinguished never, former and current status through c51_12/c53_12/c54_12 skip patterns. Education used official constructed years/categories. The MHAS component covered four states.[@mhas2017;mhasBiomarkers2024] Detailed rules and counts appear in Supplementary Tables 23, 24 and 28.

Both programmes used the comparison-map specification. Joint-state models used smoking × sex, age splines and education categories, with household-clustered influence covariance. Treatment/reference sensitivities retained identical treatment-complete samples within each contrast. HRS weighted models used QPMWGTR, STRATUM and SECU, preserving the full positive-weight design with zero influence for excluded records. MHAS used factora_12 and household clustering; unavailable sampling strata/PSUs prevent reconstruction of full survey-design variance or national inference. Weighted and unweighted fits also used identical positive-weight samples. Weight-concentration diagnostics used (Σw)²/Σw². Original-age comparisons used ages ≥50. Full estimates and diagnostics appear in Supplementary Tables 25–29.

'''+s[b:]
p.write_text(s,encoding='utf8')
tables=json.loads((R/'tables.json').read_text(encoding='utf8'));tables[0]['headers'][1]='Original-age complete n'
tables[0]['notes']=tables[0]['notes'].replace('All-age complete is','Original-age complete is')
tables[22]['notes']=tables[22]['notes'].replace('The original 24-wave memberships and inputs remain unchanged; HRS and MHAS were reconstructed from their source files.','Final memberships and model inputs were checked against the source-linked analysis panels.')
tables[27]['notes']=tables[27]['notes'].replace(' Dataset access authorization is distinct from an analytical protocol or preregistration.','')
(R/'tables.json').write_text(json.dumps(tables,ensure_ascii=False,indent=2),encoding='utf8')
refs=json.loads((R/'references.json').read_text(encoding='utf8'))
for ref in refs:
 if ref['key'] in ['hrs2014','mhas2017']:ref['journal']='Int. J. Epidemiol.'
 if ref['key']=='LaMonte2024TreatedHypertension':ref['journal']='J. Clin. Hypertens.'
 if ref['key']=='mhasBiomarkers2024':ref['journal']='J. Gerontol. A Biol. Sci. Med. Sci.'
(R/'references.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf8')
figs=json.loads((R/'figures.json').read_text(encoding='utf8'))
figs[0]['legend']=figs[0]['legend'].replace(' HRS and MHAS were included after source reconciliation; all original 24-wave estimates remain unchanged.','')
(R/'figures.json').write_text(json.dumps(figs,ensure_ascii=False,indent=2),encoding='utf8')
print('Compressed overlapping Results detail, kept all estimates in supplements, combined sample text before display items.')
