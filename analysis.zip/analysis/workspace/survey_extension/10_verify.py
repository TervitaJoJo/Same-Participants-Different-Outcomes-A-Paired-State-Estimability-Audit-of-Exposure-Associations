from pathlib import Path
from zipfile import ZipFile
from collections import Counter
import json,re,hashlib
import numpy as np,pandas as pd,pymupdf as fitz
from lxml import etree
from docx import Document
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;B=R.parent
def js(p):return json.loads(p.read_text(encoding='utf8'))
def media(p):
 with ZipFile(p) as z:return Counter(hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/') and not n.endswith('/'))
audit={};old=pd.read_csv(B/'publication_helpers/sources/primary_age50_79.csv').set_index('dataset');new=pd.read_csv(R/'results/primary_age50_79.csv').set_index('dataset')
pd.testing.assert_frame_equal(old,new.loc[old.index,old.columns],check_dtype=False,rtol=1e-13)
audit['original_24_wave_estimates_preserved']=True
ts0=js(R/'before/tables.json');ts=js(R/'tables.json')
assert ts[2:20]==ts0[2:20]
for i in [0,1]:
 before={row[0]:row for row in ts0[i]['rows']};after={row[0]:row for row in ts[i]['rows']}
 for k,v in before.items():assert after[k]==v
audit['all_original_estimate_tables_preserved']=True
md=(R/'manuscript.md').read_text(encoding='utf8');refs=js(R/'references.json');figs=js(R/'figures.json')
keys=[]
for group in re.findall(r'\[@([^\]]+)\]',md):
 for k in group.split(';'):
  if k not in keys:keys.append(k)
assert keys==[r['key'] for r in refs];assert [r['number'] for r in refs]==list(range(1,30))
audit['reference_first_citation_order']=True
audit['counts']={'references':len(refs),'main_figures':sum(not f['supplement'] for f in figs),'main_tables':2,'supplementary_figures':sum(f['supplement'] for f in figs),'supplementary_tables':len(ts)}
words={k:len(text.split()) for k,text in [('title',md.splitlines()[0][2:]),('abstract',md.split('## Abstract')[1].split('## Introduction')[0]),('main_excluding_methods',md.split('## Introduction')[1].split('## Methods')[0]),('methods',md.split('## Methods')[1].split('## References')[0])]}
assert words['title']<=15 and words['abstract']<=200 and words['main_excluding_methods']<=5000 and words['methods']<3000
assert max(len(f['legend'].split()) for f in figs)<=350
audit['word_counts']=words;audit['current_journal_guidelines_cached']='literature/natcomms_article.html'
flow=pd.read_csv(R/'audit/flow_by_wave.csv');cols=['start_n','age_n','paired_n','smoking_n','complete_n']
assert len(flow)==26 and flow.complete_n.sum()==138813
assert ((flow.start_n-flow.complete_n)==flow[['excluded_age','excluded_outcomes','excluded_smoking','excluded_covariates']].sum(axis=1)).all()
audit['flow_totals']={c:int(flow[c].sum()) for c in cols}
assert int((new.delta<0).sum())==23 and int((new.hi<0).sum())==10
for check in js(R/'audit/model_checks.json'):
 assert check['status']=='converged' and check['identity_error']<1e-10 and check['jacobian_check_error']<1e-6
audit['four_joint_models_converged_and_passed_derivative_identity_checks']=True
assert pd.read_csv(R/'audit/joint_cells.csv').n.min()==15
audit['minimum_exposure_sex_state_cell']=15
names=['manuscript_V1.docx','supplementary_figures/supplementary_figures.docx','supplementary_tables/supplementary_tables.docx']
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
for name in names:
 p=R/'staged'/name
 with ZipFile(p) as z:
  fonts=set()
  for f in ['word/document.xml','word/styles.xml','word/footer1.xml']:
   x=etree.fromstring(z.read(f))
   for e in x.findall('.//w:rFonts',ns):fonts.update(e.attrib.values())
  assert fonts=={'Times New Roman'}
  assert 'Anonymous' in z.read('docProps/core.xml').decode()
 audit[Path(name).name]={'fonts':list(fonts),'anonymized_metadata':True}
assert sum((media(R/'staged/manuscript_V1.docx')&media(R/'before/manuscript_V1.docx')).values())==3
assert media(R/'staged/supplementary_figures/supplementary_figures.docx')&media(R/'before/supplementary_figures.docx')==media(R/'before/supplementary_figures.docx')
audit['unaffected_main_and_supplementary_images_preserved']=True
o=Document(R/'before/manuscript_V1.docx');n=Document(R/'staged/manuscript_V1.docx')
assert [[c.text for c in r.cells] for r in o.tables[1].rows]==[[c.text for c in r.cells] for r in n.tables[1].rows]
audit['focused_characteristics_table_preserved']=True
pages=[]
for stem,total in [('manuscript',28),('supplementary_figures',7),('supplementary_tables',29)]:
 p=R/'rendered'/f'{stem}_final.pdf';d=fitz.open(p);assert len(d)==total,(stem,len(d))
 texts=[p.get_text() for p in d]
 assert all(len(t.strip())>20 for t in texts)
 if stem!='manuscript':
  label='Supplementary Figure ' if stem.endswith('figures') else 'Supplementary Table '
  for i,t in enumerate(texts):assert label+str(i+1)+'.' in t,(stem,i+1)
 for start in range(0,len(d),8):
  ims=[]
  for i in range(start,min(start+8,len(d))):
   pix=d[i].get_pixmap(matrix=fitz.Matrix(.6,.6),alpha=False);im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
   ca=Image.new('RGB',(im.width,im.height+22),'#E5E5E5');ca.paste(im,(0,22));ImageDraw.Draw(ca).text((8,4),f'{stem} p{i+1}',fill='black');ims.append(ca)
  w,h=ims[0].size;sheet=Image.new('RGB',(w*4,h*((len(ims)+3)//4)),'#CCCCCC')
  for i,im in enumerate(ims):sheet.paste(im,((i%4)*w,(i//4)*h))
  sheet.save(R/'rendered'/f'{stem}_contact_{start+1}.png')
 selected=[]
 if stem=='manuscript':selected=[i for i,t in enumerate(texts) if any(k in t for k in ['Abstract','Figure 1.','Figure 2.','Self-report shifted'])]
 elif stem=='supplementary_tables':selected=[0,20,24,27,28]
 else:selected=[6]
 for i in selected:d[i].get_pixmap(matrix=fitz.Matrix(1.3,1.3),alpha=False).save(R/'rendered'/f'{stem}_p{i+1}.png')
 audit[stem+'_pages']=len(d);pages.extend([dict(document=stem,page=i+1,words=len(t.split()),first=t[:110].replace('\n',' ')) for i,t in enumerate(texts)])
pd.DataFrame(pages).to_csv(R/'audit/rendered_page_map.csv',index=False)
(R/'audit/delivery_checks.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print(json.dumps(audit,indent=2))
