"""Apply the agreed narrative revision to the source of the existing V1."""
from pathlib import Path
import csv
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
PUBLISHED = Path('D:/review_workspace/manuscript/research/Differentiaion')
BACKUP = ROOT / 'before' / 'narrative_20260918'
assert not BACKUP.exists(), 'A revision snapshot already exists; inspect it before rerunning.'
expected = json.loads((ROOT / 'audit/published_hashes.json').read_text(encoding='utf-8'))
for name, checksum in expected.items():
    assert hashlib.sha256((PUBLISHED / name).read_bytes()).hexdigest() == checksum, name
BACKUP.mkdir(parents=True)
for name in expected:
    target = BACKUP / 'published' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(PUBLISHED / name, target)
for name in ['manuscript.md', 'figures.json', 'tables.json', 'references.json',
             'main_table.json', 'main_table2.json', '07_build_docx.cjs']:
    shutil.copy2(ROOT / name, BACKUP / name)
(BACKUP / 'published_hashes.json').write_text(json.dumps(expected, indent=2), encoding='utf-8')

counts = list(csv.DictReader((ROOT / 'results/HRS_joint_counts.csv').open(encoding='utf-8')))
n = sum(int(x['n']) for x in counts)
u = sum(int(x['n']) for x in counts if float(x['M']) == 1 and float(x['S']) == 0)
v = sum(int(x['n']) for x in counts if float(x['M']) == 0 and float(x['S']) == 1)
assert (n, u, v) == (5798, 399, 2359)
discordance = 100 * (u + v) / n
assert round(discordance, 1) == 47.6

p = ROOT / 'manuscript.md'
s = p.read_text(encoding='utf-8')
old = s
changes = []
def replace_once(before, after, label):
    global s
    assert s.count(before) == 1, (label, s.count(before))
    s = s.replace(before, after, 1)
    changes.append({'label': label, 'before_words': len(before.split()), 'after_words': len(after.split())})

replace_once('# An outcome definition sensitivity framework for interpreting inverse smoking associations',
             '# When disease definitions disagree: a framework for interpreting exposure associations across diagnosis and measurement', 'title')

abstract = ('Self-reported diagnoses support large population studies, yet diagnosis history and current measurements can yield exposure associations in opposite directions. '
'We present an outcome definition sensitivity framework: compare paired associations, allocate their difference to discordant diagnosis–measurement states, and test sensitivity to treatment, exposure history and analytical eligibility. '
'Across nine survey programmes comprising 138,813 participant-wave records, reported hypertension generally shifted smoking associations downward, with population and weighting-dependent exceptions. '
'In CHARLS, the paired log-odds-ratio difference was −0.294 (95% confidence interval −0.450 to −0.137), with similar allocations to both discordant states. Treatment inclusion and smoking-reference choice narrowed the gap. '
'HRS showed a small estimated conditional gap; MHAS estimates were weight-sensitive and imprecise. '
'NHANES diabetes provided a boundary test: inverse associations persisted under measured definitions, while body mass index and income adjustments acted in opposite directions. '
'The framework makes outcome choice explicit and quantifies its consequences for exposure associations, supporting study design and evidence assessment. '
'These association differences do not establish a protective effect of smoking or identify causal mechanisms.')
replace_once(s.split('## Abstract\n\n')[1].split('\n\n## Introduction')[0], abstract, 'abstract')

replace_once('For association studies, the practical question is whether this choice changes the estimated relationship with an exposure.',
             'Association studies therefore need to specify whether an outcome represents diagnosis history, current physiological abnormality or treatment-inclusive disease, and quantify the consequences of that choice.',
             'introduction: explicit outcome construct')
replace_once('Smoking makes this question consequential. Prospective evidence links smoking to a wide range of adverse health outcomes,[@Chan2022SmokingDiseases] while cross-sectional surveys can show inverse associations with reported chronic disease.',
             'Smoking makes this question consequential: prospective evidence links smoking to adverse health outcomes,[@Chan2022SmokingDiseases] yet cross-sectional surveys can show inverse associations with reported chronic disease.',
             'introduction: smoking contrast')
replace_once('The framework makes outcome choice an explicit, quantitative part of association analysis before any error correction is attempted.',
             'The framework makes outcome choice an explicit, quantitative part of association analysis.',
             'introduction: practical endpoint')

replace_once('HRS and MHAS exposed further boundaries (Supplementary Fig. 7 and Supplementary Tables 25–29). HRS showed little conditional gap: Δ = 0.008 (95% CI −0.196 to 0.211). MHAS shifted downward without weights, Δ = −0.249 (−0.638 to 0.141), but its component-weighted estimate changed direction and was imprecise: 0.578 (−0.596 to 1.752). The same weight-eligible sample gave −0.259 without weights, locating the point-estimate change in weighting rather than exclusion. Current-versus-never joint-state gaps were uncertain in both programmes.',
             'HRS combined substantial classification discordance (47.6%) with a small estimated conditional gap: Δ = 0.008 (95% CI −0.196 to 0.211). MHAS shifted downward without weights, Δ = −0.249 (−0.638 to 0.141), but its component-weighted estimate changed direction and was imprecise: 0.578 (−0.596 to 1.752). The same weight-eligible sample gave −0.259 without weights, locating the point-estimate change in weighting rather than exclusion. Current-versus-never joint-state gaps were uncertain in both programmes (Supplementary Fig. 7 and Supplementary Tables 25–29).',
             'results: HRS discordance and MHAS boundary')

discussion = s.split('## Discussion\n\n')[1].split('\n\n## Methods')[0].strip()
paras = discussion.split('\n\n')
assert len(paras) == 8
new_paras = list(paras)
new_paras[0] = ('The choice of disease definition is an analytical decision with quantifiable consequences for exposure associations. '
'Across our applications, treatment and smoking history altered the definition gap, substantial classification discordance coexisted with a small estimated gap, and measured disease could retain an inverse association. '
'The framework separates three questions: what the endpoint represents, how much the association changes, and which data or analytical choices warrant closer examination. '
'This distinction makes outcome construction part of evidence interpretation, with smoking as an informative application.')
new_paras[1] = ('The framework extends agreement research by making the exposure association the quantity to be diagnosed. '
'Previous work has documented discordance between self-reported and objectively defined hypertension, including in CHARLS.[@Wu2024CHARLSAgreement;Lee2023VascularSelfReport] '
'HRS illustrates why agreement statistics cannot replace direct evaluation of association sensitivity: substantial classification discordance coexisted with a small estimated conditional gap. '
'The allocation distinguishes the roles of threshold positivity without reported diagnosis and reported diagnosis below threshold. '
'The high medication frequency in the latter state in CHARLS, HRS and MHAS (Supplementary Table 28) is particularly informative: many participants had treated blood pressure below the current threshold. '
'Retaining this state preserves the distinction between disease recognition and current physiological control, which is lost when every disagreement is labelled measurement error.')
new_paras[5] = ('Analytical eligibility and weighting require equally explicit decisions. '
'HbA1c and fasting glucose measure different aspects of glycaemia,[@Staimez2022GlycemicMismatch] and their availability can select different analytical populations. '
'Holding HbA1c and spline bases fixed distinguished the NHANES sample increment from the subsequent weight increment, although the paired tests remained inconclusive. '
'In MHAS, the point-estimate change on the same weight-eligible sample and its wide interval make the component-weighting strategy and weight concentration central to interpretation. '
'Investigators should specify the intended population and report the sampling component, weighting strategy and resulting uncertainty alongside the estimates. '
'These diagnostics complement official component weights, which account for component sampling and nonresponse.[@nhanes_weighting]')
new_paras[7:] = [
    ('For clinical and epidemiological researchers, the first decision is which disease construct answers the study question. '
     'Diagnosis history, a current measurement threshold and a treatment-inclusive definition can then be compared on the same participants, using the same exposure contrast and comparable model specifications. '
     'Each paired binary comparison yields an association gap and a discordant-state allocation. '
     'For example, pairing reported kidney disease with reduced estimated glomerular filtration rate could identify which discordant state accounts for an association gap and direct examination of diagnosis opportunities, chronicity and treatment. '
     'The practical gain is a quantitative account of how endpoint construction affects the evidence.'),
    ('For systematic reviewers, outcome definition, intended population and sampling or weighting strategy provide concrete items to extract and use when organizing comparisons or stratified syntheses. '
     'Direct assessment of definition sensitivity is possible where studies report paired estimates or provide the corresponding data. '
     'This information can also inform assessment of whether external validation parameters are applicable across populations.[@ross2024]'),
    ('For survey planners, the corresponding decision concerns which information must remain linkable. '
     'Where feasible, surveys supporting association research should retain diagnosis, examination, treatment and exposure-history data in the same individuals. '
     'This permits investigators to distinguish disease recognition from current physiology and to specify the paired comparisons before analysis.'),
    ('These association differences do not establish a protective effect of smoking or identify causal mechanisms. '
     'They identify which diagnosis–measurement states, treatment patterns and analytical choices warrant further investigation in longitudinal designs.')
]
replace_once(discussion, '\n\n'.join(new_paras), 'discussion: evidence to research decisions')

assert s.split('## Methods')[1] == old.split('## Methods')[1]
assert len(abstract.split()) <= 200
assert len(s.splitlines()[0][2:].split()) <= 15
p.write_text(s, encoding='utf-8')

tables = json.loads((ROOT / 'tables.json').read_text(encoding='utf-8'))
t28 = next(t for t in tables if t['id'] == 28)
t28['rows'].insert(3, [
    'HRS paired classification',
    'Complete paired sample, ages 50–79',
    'Of 5,798 participants, 399 were threshold-positive without reported diagnosis (U) and 2,359 reported diagnosis below threshold (V): 2,758/5,798 (47.6%) had discordant classifications. The treatment-complete V denominator below excludes five with unknown medication.'
])
(ROOT / 'tables.json').write_text(json.dumps(tables, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

audit = {
    'revision': 'Combined, user-approved narrative plans; original V1 filenames retained',
    'scope': 'Title, abstract, introduction, HRS results, discussion, Supplementary Table 28',
    'new_models': False,
    'changes': changes,
    'HRS_discordance': {'n': n, 'U': u, 'V': v, 'discordant': u + v, 'percent': discordance,
                        'treatment_complete_V_n': 2354, 'treated_V_n': 2056},
    'terminology': {
        'framework': 'outcome definition sensitivity framework',
        'record': 'participant-wave record, not unique participant',
        'U': 'threshold-positive without reported diagnosis',
        'V': 'reported diagnosis below the current threshold',
        'conditional_gap': 'paired difference between conditional log odds ratios',
        'allocation': 'symmetric descriptive allocation of the marginal paired association gap'
    },
    'paragraph_map': {
        'introduction': ['practical outcome choice and early framework', 'smoking contrast', 'agreement versus association gap', 'three-step study route'],
        'discussion': ['central synthesis', 'HRS insight and clinical meaning of V', 'treatment and healthcare', 'smoking transitions', 'NHANES adjustment', 'eligibility and weights', 'limitations', 'researcher decisions', 'evidence synthesis', 'survey design', 'longitudinal follow-up boundary']
    },
    'evidence_allocation': [
        {'result': 'HRS discordance with small estimated conditional gap', 'role': 'qualification', 'main': '47.6%, conditional gap and CI', 'SI': 'all counts in Table 28; models in Tables 25–29'},
        {'result': 'MHAS weighting sensitivity', 'role': 'boundary', 'main': 'unweighted/weighted gaps and CI retained', 'SI': 'weights, effective size, design limitations in Tables 25–29'},
        {'result': 'clinical / review / survey applications', 'role': 'bounded practical implications', 'main': 'discussion', 'SI': 'no hypothetical application results claimed'}
    ],
    'preservation': ['All fitted estimates and intervals', 'All Methods text', 'All references', 'All figure images and captions', 'All table cells except the added HRS classification row'],
    'avoided_claims': ['equivalence from null-crossing CI', 'discordance as an error rate', 'HRS as a control or access mechanism', 'global diagnosis inequity', 'weighted and unweighted regressions necessarily target different parameters', 'causal explanation of smoking protection'],
    'abstract_words': len(abstract.split()),
    'title_words': len(s.splitlines()[0][2:].split())
}
(ROOT / 'audit/narrative_revision.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'title_words': audit['title_words'], 'abstract_words': audit['abstract_words'], 'changes': changes, 'HRS_discordance': audit['HRS_discordance']}, indent=2))
