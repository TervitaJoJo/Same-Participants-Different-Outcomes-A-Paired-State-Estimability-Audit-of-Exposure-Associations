from pathlib import Path
from collections import Counter
from zipfile import ZipFile
import hashlib
import json
import re
import csv

import pymupdf as fitz
from docx import Document
from lxml import etree
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent
BEFORE = ROOT / 'before/narrative_20260918'
STAGED = ROOT / 'staged_narrative'
RENDERED = ROOT / 'rendered_narrative'

def js(path):
    return json.loads(path.read_text(encoding='utf-8'))

def media(path):
    with ZipFile(path) as z:
        return Counter(hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()
                       if n.startswith('word/media/') and not n.endswith('/'))

old = (BEFORE / 'manuscript.md').read_text(encoding='utf-8')
new = (ROOT / 'manuscript.md').read_text(encoding='utf-8')
audit = {}
assert new.split('## Methods')[1] == old.split('## Methods')[1]
audit['methods_preserved_verbatim'] = True

def results(s):
    return s.split('## Results')[1].split('## Discussion')[0]

old_results, new_results = results(old), results(new)
num_re = r'[−–+-]?\d[\d,.]*(?:%)?'
new_numbers = Counter(re.findall(num_re, new_results))
old_numbers = Counter(re.findall(num_re, old_results))
assert not old_numbers - new_numbers
assert new_numbers - old_numbers == Counter({'47.6%': 1})
audit['all_results_numbers_preserved'] = True
audit['only_new_results_number'] = '47.6% HRS classification discordance'

refs = js(ROOT / 'references.json')
assert refs == js(BEFORE / 'references.json')
keys = []
for group in re.findall(r'\[@([^\]]+)\]', new):
    for key in group.split(';'):
        if key not in keys:
            keys.append(key)
assert keys == [r['key'] for r in refs]
assert [r['number'] for r in refs] == list(range(1, 30))
audit['references_preserved_and_in_first_citation_order'] = True

figs = js(ROOT / 'figures.json')
assert figs == js(BEFORE / 'figures.json')
for name in ['main_table.json', 'main_table2.json']:
    assert js(ROOT / name) == js(BEFORE / name)
tables = js(ROOT / 'tables.json')
before_tables = js(BEFORE / 'tables.json')
for t, old_t in zip(tables, before_tables, strict=True):
    if t['id'] == 28:
        check = {**t, 'rows': t['rows'][:3] + t['rows'][4:]}
        assert check == old_t
    else:
        assert t == old_t
audit['all_existing_table_cells_preserved'] = True
audit['added_table_row'] = 'Supplementary Table 28, HRS paired classification'
audit['counts'] = {'main_figures': sum(not x['supplement'] for x in figs), 'main_tables': 2,
                   'supplementary_figures': sum(x['supplement'] for x in figs),
                   'supplementary_tables': len(tables), 'references': len(refs)}
assert list(audit['counts'].values()) == [5, 2, 7, 29, 29]

words = {k: len(v.split()) for k, v in {
    'title': new.splitlines()[0][2:],
    'abstract': new.split('## Abstract')[1].split('## Introduction')[0],
    'main_excluding_methods': new.split('## Introduction')[1].split('## Methods')[0],
    'methods': new.split('## Methods')[1].split('## References')[0],
}.items()}
assert words['title'] <= 15 and words['abstract'] <= 200
assert words['main_excluding_methods'] <= 5000 and words['methods'] < 3000
assert max(len(x['legend'].split()) for x in figs) <= 350
assert '[@' not in new.split('## Abstract')[1].split('## Introduction')[0]
audit['word_counts'] = words

for phrase in ['near-universal', 'negative control', 'investigators rarely', 'before any error correction']:
    assert phrase not in new
for phrase in ['No interval crossing a null value was interpreted as proof of equivalence',
               'BMI and income adjustments', '−0.596 to 1.752', 'CHNS, HAALSI and the MHAS',
               'These association differences do not establish a protective effect of smoking or identify causal mechanisms.']:
    assert phrase in new
assert new.count('These association differences do not establish a protective effect of smoking or identify causal mechanisms.') == 2
audit['bounded_interpretation_checks'] = True

names = ['manuscript_V1.docx', 'supplementary_figures/supplementary_figures.docx',
         'supplementary_tables/supplementary_tables.docx']
ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
for name in names:
    path = STAGED / name
    with ZipFile(path) as z:
        fonts = set()
        for part in ['word/document.xml', 'word/styles.xml', 'word/footer1.xml']:
            xml = etree.fromstring(z.read(part))
            for e in xml.findall('.//w:rFonts', ns):
                fonts.update(e.attrib.values())
        assert fonts == {'Times New Roman'}, (name, fonts)
        assert 'Anonymous' in z.read('docProps/core.xml').decode()
        assert not etree.fromstring(z.read('word/document.xml')).findall('.//w:ins', ns)
    assert media(path) == media(BEFORE / 'published' / name)
audit['all_images_preserved_byte_for_byte'] = True
audit['all_documents_times_new_roman_and_anonymous'] = True

old_doc = Document(BEFORE / 'published/manuscript_V1.docx')
new_doc = Document(STAGED / 'manuscript_V1.docx')
assert len(new_doc.inline_shapes) == 5 and len(new_doc.tables) == 2
for x, y in zip(old_doc.tables, new_doc.tables, strict=True):
    assert [[c.text for c in r.cells] for r in x.rows] == [[c.text for c in r.cells] for r in y.rows]
assert new_doc.paragraphs[0].text == new.splitlines()[0][2:]
assert new_doc.paragraphs[2].text == new.split('## Abstract\n\n')[1].split('\n\n## Introduction')[0]

pages = []
for stem in ['manuscript', 'supplementary_figures', 'supplementary_tables']:
    path = RENDERED / (f'{stem}_checked.pdf' if stem == 'manuscript' else f'{stem}_pass1.pdf')
    doc = fitz.open(path)
    texts = [p.get_text() for p in doc]
    assert all(len(t.strip()) > 20 for t in texts)
    if stem != 'manuscript':
        label = 'Supplementary Figure ' if stem.endswith('figures') else 'Supplementary Table '
        assert len(doc) == (7 if stem.endswith('figures') else 29)
        for i, text in enumerate(texts):
            assert label + str(i+1) + '.' in text, (stem, i+1)
    for i, text in enumerate(texts):
        pages.append({'document': stem, 'page': i+1, 'words': len(text.split()),
                      'first': text[:130].replace('\n', ' '), 'last': text[-120:].replace('\n', ' ')})
    for start in range(0, len(doc), 8):
        ims = []
        for i in range(start, min(start + 8, len(doc))):
            pix = doc[i].get_pixmap(matrix=fitz.Matrix(.6, .6), alpha=False)
            im = Image.frombytes('RGB', [pix.width, pix.height], pix.samples)
            canvas = Image.new('RGB', (im.width, im.height + 22), '#E5E5E5')
            canvas.paste(im, (0, 22))
            ImageDraw.Draw(canvas).text((8, 4), f'{stem} p{i+1}', fill='black')
            ims.append(canvas)
        w, h = ims[0].size
        sheet = Image.new('RGB', (w * 4, h * ((len(ims) + 3)//4)), '#CCCCCC')
        for i, im in enumerate(ims):
            sheet.paste(im, ((i % 4)*w, (i//4)*h))
        sheet.save(RENDERED / f'{stem}_contact_{start+1}.png')
    if stem == 'manuscript':
        selected = [i for i, t in enumerate(texts) if any(s in t for s in
                    ['Abstract', 'Introduction', 'HRS combined', 'Discussion', 'For clinical', 'For systematic', 'For survey planners', 'Let m, s, u and v denote'])]
    elif stem == 'supplementary_tables':
        selected = [27]
    else:
        selected = [6]
    for i in selected:
        doc[i].get_pixmap(matrix=fitz.Matrix(1.3, 1.3), alpha=False).save(RENDERED / f'{stem}_p{i+1}.png')
    audit[stem + '_pages'] = len(doc)

with (ROOT / 'audit/narrative_page_map.csv').open('w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=list(pages[0]))
    writer.writeheader()
    writer.writerows(pages)
(ROOT / 'audit/narrative_delivery_checks.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
print(json.dumps(audit, indent=2))
print('\nMain page map:')
for p in pages:
    if p['document'] == 'manuscript' or (p['document'] == 'supplementary_tables' and p['page'] == 28):
        print(p)
