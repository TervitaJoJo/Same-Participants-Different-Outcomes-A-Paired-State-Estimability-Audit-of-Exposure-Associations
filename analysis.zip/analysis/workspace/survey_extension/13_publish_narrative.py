from pathlib import Path
import difflib
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
OUT = Path('D:/review_workspace/manuscript/research/Differentiaion')
BEFORE = ROOT / 'before/narrative_20260918'
STAGED = ROOT / 'staged_narrative'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

baseline = json.loads((BEFORE / 'published_hashes.json').read_text(encoding='utf-8'))
checks = json.loads((ROOT / 'audit/narrative_delivery_checks.json').read_text(encoding='utf-8'))
assert checks['manuscript_pages'] == 28
assert checks['all_results_numbers_preserved']
assert checks['all_documents_times_new_roman_and_anonymous']
for name, checksum in baseline.items():
    assert sha(OUT / name) == checksum, f'Published document changed since snapshot: {name}'

# The supplementary figure document has no content changes; retain its bytes.
updated = ['manuscript_V1.docx', 'supplementary_tables/supplementary_tables.docx']
for name in updated:
    shutil.copy2(STAGED / name, OUT / name)
    assert sha(STAGED / name) == sha(OUT / name)
hashes = {name: sha(OUT / name) for name in baseline}
(ROOT / 'audit/published_hashes.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')

before = (BEFORE / 'manuscript.md').read_text(encoding='utf-8')
after = (ROOT / 'manuscript.md').read_text(encoding='utf-8')
diff = ''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                  fromfile='V1 before narrative revision', tofile='V1 revised in place'))
(ROOT / 'audit/narrative_revision.diff').write_text(diff, encoding='utf-8')
revision = json.loads((ROOT / 'audit/narrative_revision.json').read_text(encoding='utf-8'))
revision['final_word_counts'] = checks['word_counts']
revision['final_discussion_words'] = len(after.split('## Discussion')[1].split('## Methods')[0].split())
revision['layout_refinement'] = 'Compressed redundant Discussion text and kept the allocation-equation paragraph together; retained 28 main pages.'
revision['publication'] = {'updated': updated, 'unchanged': ['supplementary_figures/supplementary_figures.docx'],
                           'hashes': hashes, 'visual_inspection_completed': True}
(ROOT / 'audit/narrative_revision.json').write_text(json.dumps(revision, ensure_ascii=False, indent=2), encoding='utf-8')
checks['visual_inspection_completed'] = True
checks['published_hashes'] = hashes
checks['rendered_sources'] = ['rendered_narrative/manuscript_checked.pdf',
                              'rendered_narrative/supplementary_figures_pass1.pdf',
                              'rendered_narrative/supplementary_tables_pass1.pdf']
(ROOT / 'audit/narrative_delivery_checks.json').write_text(json.dumps(checks, indent=2), encoding='utf-8')

notes = '''

## Subsequent approved narrative revision, 18 September 2026

The original V1 and supplementary table document were updated in place after combining the user's two approved narrative plans. The prior published files and source inputs are preserved in `before/narrative_20260918/`.

- Title now states the general diagnosis-versus-measurement problem and the framework's association-level purpose (14 words).
- Abstract is 165 words: 138,813 participant-wave records, the CHARLS paired gap and interval, HRS/MHAS uncertainty, the NHANES boundary and a concrete study-design/evidence-assessment payoff.
- The four-paragraph Introduction introduces the framework early, names the three outcome constructs and sharpens the smoking contrast without unsupported claims about typical researcher behaviour.
- HRS now illustrates that substantial classification discordance (2,758/5,798; 47.6%) can coexist with a small estimated conditional association gap. Supplementary Table 28 gives U = 399 and V = 2,359 and distinguishes the medication-complete V denominator of 2,354.
- Discussion converts the applications into decisions for association-study investigators, systematic reviewers and survey planners. MHAS retains its imprecise weighted estimate and component-specific interpretation. No causal mechanism, equivalence, universal access or global diagnosis-inequity claim was introduced.
- Repetitive Discussion sentences were compressed. Final body is approximately 2,585 words excluding Methods; Methods remain verbatim at approximately 2,343 words. Full article still has 28 pages, five main figures and two tables.
- All original numerical estimates, confidence intervals, table cells and reference metadata are retained. All figure images and captions are unchanged and consistent with the revised text. No new fitted models were required.
- Microsoft Word rendering and visual inspection verified the revised main text, equation pagination, embedded displays and updated supplementary table. The supplementary figure document remains unchanged at seven pages. Supplementary tables remain 29 pages, one table per page. All documents use Times New Roman and anonymous metadata.
- Final verification: `audit/narrative_delivery_checks.json`; narrative decisions and counts: `audit/narrative_revision.json`; text diff: `audit/narrative_revision.diff`. The existing manuscript source and builder remain authoritative; do not rerun earlier integration scripts to regenerate an outdated narrative.
'''
with (ROOT / 'EDIT_NOTES.md').open('a', encoding='utf-8') as f:
    f.write(notes)
print(json.dumps({'updated_original_files': [str(OUT / n) for n in updated],
                  'word_counts': checks['word_counts'], 'published_hashes': hashes}, indent=2))
