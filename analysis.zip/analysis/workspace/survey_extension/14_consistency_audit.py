from pathlib import Path
from collections import Counter
from zipfile import ZipFile
import csv, hashlib, json, re, shutil
import pandas as pd
import numpy as np

R = Path(__file__).resolve().parent
B = R.parent
P = Path('D:/review_workspace/manuscript/research/Differentiaion')
A = R / 'audit/final_consistency_20260918'
K = R / 'before/final_consistency_20260918'
A.mkdir(exist_ok=True)
def js(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
expected = js(R / 'audit/published_hashes.json')
if not K.exists():
    for name, checksum in expected.items():
        assert sha(P/name) == checksum, name
    K.mkdir()
    for name in ['manuscript.md','figures.json','tables.json','references.json','main_table.json','main_table2.json','07_build_docx.cjs','08_figures.py']:
        shutil.copy2(R/name,K/name)
    for name in expected:
        p = K/'published'/name
        p.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(P/name,p)
    (K/'published_hashes.json').write_text(json.dumps(expected,indent=2),encoding='utf-8')

tables = js(K/'tables.json')
md = (K/'manuscript.md').read_text(encoding='utf-8')
# Reconstruct the original twenty numerical tables in memory only, using the
# saved corrected result files. Stop before every generator write operation.
source = B/'publication_helpers/05_tables.py'
code = source.read_text(encoding='utf-8').split("(R/'tables.json').write_text")[0]
scope = {'__file__': str(source)}
exec(compile(code,str(source),'exec'),scope)
reconstructed = scope['tables']
checks = []
for t in reconstructed:
    current = tables[t['id']-1]
    canonical = lambda row: [v.replace('MEC examination weight','MEC weight') if isinstance(v,str) else v for v in row]
    current_rows = [canonical(row) for row in current['rows']]
    missing = [row for row in t['rows'] if canonical(row) not in current_rows]
    checks.append({'old_id':t['id'],'source_rows':len(t['rows']),'missing_rows':missing})
assert all(not t['missing_rows'] for t in checks), checks

source_checks=[]
for rec in js(B/'publication_helpers/table_provenance.json'):
    source_checks.append({'file':rec['file'],'matches_saved_hash':sha(Path(rec['file']))==rec['sha256']})
assert all(x['matches_saved_hash'] for x in source_checks)

primary = pd.read_csv(R/'results/primary_age50_79.csv')
flow = pd.read_csv(R/'audit/flow_by_wave.csv')
assert len(primary)==26 and primary.n.sum()==138813
assert flow.complete_n.sum()==138813
assert (flow[['excluded_age','excluded_outcomes','excluded_smoking','excluded_covariates']].sum(axis=1)==flow.start_n-flow.complete_n).all()
for _,r in primary.iterrows():
    row=next(x for x in tables[0]['rows'] if x[0]==r.dataset)
    assert row[3:]==[f'{int(r.n):,}',f'{r.or_measured:.3f}',f'{r.or_selfreport:.3f}',f'{r.delta:.3f} ({r.lo:.3f}, {r.hi:.3f})']
for _,r in flow.iterrows():
    row=next(x for x in tables[22]['rows'] if x[0]==r.dataset)
    assert row[1:]==[f'{int(r[c]):,}' for c in ['start_n','age_n','paired_n','smoking_n','complete_n']]

duplicates=[]
for i,t in enumerate(tables):
    for other in tables[:i]:
        same=[row for row in t['rows'] if row in other['rows']]
        if same: duplicates.append({'table':t['id'],'also_in_table':other['id'],'count':len(same),'rows':same})

full_dup=[row for row in tables[2]['rows'] if row in tables[1]['rows']]
assert len(full_dup)==14
assert sum(row in tables[11]['rows'] for row in tables[18]['rows'])==2

# Inspect saved schema/selected estimates without any refitting.
specific={}
for folder,file in [('nhanes_robustness','charls_estimates.csv'),
                    ('nhanes_adjustment','same_sample_estimates.csv'),
                    ('survey_extension','paired_models.csv')]:
    df=pd.read_csv(B/folder/'results'/file)
    if file=='charls_estimates.csv': df=df[df.analysis.eq('smoking2013') & df.metric.eq('RD')]
    specific[folder+'/'+file]=df.to_dict('records')

# Exact duplicate sentences outside conventional section-level repetition.
sentences=re.split(r'(?<=[.!?])\s+',re.sub(r'\[@[^\]]+\]','',md))
counts=Counter(s.strip() for s in sentences if len(s.split())>=9)
sentence_duplicates={s:n for s,n in counts.items() if n>1}
report={'table_source_checks':checks,'original_source_hashes':source_checks,
        'counts':{'waves':len(primary),'records':int(primary.n.sum()),'downward':int((primary.delta<0).sum()),
                  'below_zero_intervals':int((primary.hi<0).sum()),'OR_S_below_one':int((primary.or_selfreport<1).sum()),
                  'OR_M_below_one':int((primary.or_measured<1).sum())},
        'table_duplicate_rows':duplicates,'exact_sentence_duplicates':sentence_duplicates,
        'selected_source_estimates':specific}
(A/'initial_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
pa=pd.read_csv(R/'results/paired_models.csv')
jm=pd.read_csv(R/'results/joint_models.csv')
def selected(name,analysis):
    d=pa[pa.programme.eq(name)&pa.analysis.eq(analysis)]
    assert len(d)==1
    return d.iloc[0]
def ci(r): return f'{r.delta:.3f} ({r.lo:.3f}, {r.hi:.3f})'
for row in tables[24]['rows']:
    z=jm[jm.programme.eq(row[0])&jm.reference.eq(row[1])].set_index('metric')
    fmt=lambda k:f'{z.loc[k,"estimate"]:.3f} ({z.loc[k,"lo"]:.3f}, {z.loc[k,"hi"]:.3f})'
    assert row[2:]==[f'{int(z.n.iloc[0]):,}',f'{np.exp(z.loc["logOR_M","estimate"]):.3f}',f'{np.exp(z.loc["logOR_S","estimate"]):.3f}',fmt('delta'),fmt('unreported_component'),fmt('history_normal_component')]
for row in tables[25]['rows']:
    name,definition,ref=row[:3]
    r=selected(name,('treatment_complete_threshold_' if definition=='Threshold' else 'treatment_inclusive_')+ref)
    assert row[3:]==[f'{int(r.n):,}',f'{r.or_measured:.3f}',f'{r.or_selfreport:.3f}',ci(r)]
specs={'All complete; unweighted':'threshold_noncurrent_household','Weight-eligible; unweighted':'weight_eligible_unweighted',
       'Weight-eligible; weighted':'component_weighted','Previous, resolved diagnosis as no':'history_code6_as_no','RAND smoking history':'RAND_smoking_sensitivity'}
for row in tables[26]['rows']:
    r=selected(row[0],specs[row[1]])
    assert row[2:]==[f'{int(r.n):,}',f'{r.or_measured:.3f}',f'{r.or_selfreport:.3f}',ci(r)]
weights=pd.read_csv(R/'audit/weight_diagnostics.csv')
assert tables[28]['rows']==[[r.programme,r['group'],f'{int(r.n):,}',f'{r.weight_ess:.1f}',f'{r.median_weight:,.0f}',f'{r.max_weight:,.0f}',f'{r.max_weight_share*100:.1f}%'] for _,r in weights.iterrows()]
for row in js(K/'main_table.json')['rows']:
    d=primary[primary.dataset.str.startswith(row[0])]
    assert [row[3],row[4]]==[str(len(d)),f'{int(d.n.sum()):,}']
code=source.read_text(encoding='utf-8').split('# Compact participant characteristics')[1].split('\n',1)[1].split("(R/'main_table2.json').write_text")[0]
exec(compile(code,str(source),'exec'),scope)
assert scope['mt2']['rows']==js(K/'main_table2.json')['rows']
report['added_programme_effect_tables_matched']=True
report['main_table_counts_and_characteristics_matched']=True
(A/'initial_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'source_tables_matched':len(checks),'saved_source_files_matched':len(source_checks),
                  'counts':report['counts'],'duplicates':[dict(table=d['table'],also_in=d['also_in_table'],rows=d['count']) for d in duplicates],
                  'sentence_duplicates':sentence_duplicates,
                  'examination_rows':specific['nhanes_robustness/charls_estimates.csv']},ensure_ascii=False,indent=2))
