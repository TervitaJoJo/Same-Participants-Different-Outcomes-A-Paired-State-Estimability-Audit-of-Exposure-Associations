"""Re-render saved data in an isolated audit directory and compare delivered images."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
B=R.parent
A=R/'audit/final_consistency_20260918'
O=A/'reconstructed_figures'
O.mkdir(exist_ok=True)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
original=B/'publication_helpers/04_figures.py'
code=original.read_text(encoding='utf-8').replace("F=R/'figures'",f'F=Path({str(O)!r})')
exec(compile(code,str(original),'exec'),{'__file__':str(original)})
figs=json.loads((R/'figures.json').read_text(encoding='utf-8'))
checks=[]
for f in figs:
    if f['name'] in ['Fig1','Fig2','SuppFig6','SuppFig7']: continue
    checks.append({'figure':f['name'],'exact_png_match':digest(Path(f['path']))==digest(O/(f['name']+'.png'))})
extension=R/'08_figures.py'
import matplotlib.pyplot as plt
plt.rcdefaults()
code=extension.read_text(encoding='utf-8').split("figs=json.loads((R/'before/figures.json')")[0]
code=code.replace("S='#BC6C25';V='#A68A64'",f"F=Path({str(O)!r})\nS='#BC6C25';V='#A68A64'")
exec(compile(code,str(extension),'exec'),{'__file__':str(extension)})
for f in figs:
    if f['name'] in ['Fig1','Fig2','SuppFig7']:
        checks.append({'figure':f['name'],'exact_png_match':digest(Path(f['path']))==digest(O/(f['name']+'.png'))})
plt.rcdefaults()
flow_source=B/'sample_flow/04_flow_figures.py'
flow_code=flow_source.read_text(encoding='utf-8')
code=flow_code.split("s=Scene('Fig1',605)")[0]+f'\nF=Path({str(O)!r})\n'+"s=Scene('SuppFig6',620)"+flow_code.split("s=Scene('SuppFig6',620)")[1].split("figs=json.loads")[0]
exec(compile(code,str(flow_source),'exec'),{'__file__':str(flow_source)})
f=next(f for f in figs if f['name']=='SuppFig6')
checks.append({'figure':'SuppFig6','exact_png_match':digest(Path(f['path']))==digest(O/'SuppFig6.png')})
(A/'figure_reconstruction.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
