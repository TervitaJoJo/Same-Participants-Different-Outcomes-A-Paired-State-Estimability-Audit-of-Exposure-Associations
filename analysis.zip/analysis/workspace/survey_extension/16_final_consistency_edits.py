"""Deduplicate supplementary displays, repair source pointers and unify numbering."""
from pathlib import Path
import copy,json,re
import pandas as pd
R=Path(__file__).resolve().parent
B=R.parent
K=R/'before/final_consistency_20260918'
A=R/'audit/final_consistency_20260918'
def js(p):return json.loads(p.read_text(encoding='utf-8'))
old=js(K/'tables.json')
by={t['id']:copy.deepcopy(t) for t in old}
mapping={1:1,2:2,3:2,4:3,5:3,6:4,7:5,8:6,9:7,10:8,11:9,12:10,13:11,14:12,15:13,16:14,17:15,18:16,19:10,20:17,21:18,22:19,23:20,24:21,25:22,26:23,27:24,28:25,29:26}

# Remove a complete duplicate; identify the subset once in the retained table.
assert all(row in by[2]['rows'] for row in by[3]['rows'])
by[2]['notes'] += ' The 14 CHARLS, ELSA and NHANES rows also supply the hypertension column of Supplementary Fig. 1.'

# Two diseases with exactly the same design and columns share one table.
merged=copy.deepcopy(by[4])
merged['title']='Complete disease-wave comparisons for diabetes and dyslipidaemia'
merged['headers']=['Survey / wave','Diabetes n','OR M','OR S','Δ (95% CI)','Dyslipidaemia n','OR M','OR S','Δ (95% CI)']
merged['rows']=[]
for left,right in zip(by[4]['rows'],by[5]['rows'],strict=True):
    assert left[0]==right[0]
    merged['rows'].append([left[0],*left[1:],*right[1:]])
merged['widths']=[1500,650,620,620,2085,700,620,620,2085]
merged['fontSize']=18
merged['notes']='Each disease contributes all 14 available CHARLS, ELSA and NHANES wave comparisons in Supplementary Fig. 1. Original age ranges; current versus noncurrent smoking. Models adjust for age, sex and education without survey weights. M denotes the measured threshold and S reported diagnosis. Intervals are paired 95% intervals for Δ = log OR(S) − log OR(M), not for either individual OR. The corresponding hypertension results are in Supplementary Table 2. Samples overlap across diseases and waves.'
by[4]=merged

# Put all fixed-person NHANES endpoint/adjustment comparisons together.
assert all(row in by[12]['rows'] for row in by[19]['rows'] if row[0]=='M')
additional=[row for row in by[19]['rows'] if row[0]!='M']
by[12]['rows'].extend([['HbA1c only' if row[0]=='A' else 'Fasting glucose only',*row[1:]] for row in additional])
by[12]['title']='NHANES diabetes associations across adjustment, treatment and biomarker definitions'
by[12]['widths']=[1900,2200,800,4600]
by[12]['notes']+=' HbA1c-only and fasting-glucose-only rows use the same 1,816 participants, fasting weights and model specifications; their thresholds are ≥6.5% and ≥126 mg/dl, respectively. These comparisons hold eligibility fixed; the nested-sample analysis separately fixes spline bases and analytical targets. Single-examination thresholds do not establish a confirmed clinical diagnosis.'

# The examination-use contrast was in the text but absent from its cited table.
df=pd.read_csv(B/'nhanes_robustness/results/charls_estimates.csv')
exam=df[df.analysis.eq('smoking2013')&df.metric.eq('RD')]
labels={'complete_cases':'Complete cases','common_target':'Common target','ipw':'IPW','ipw_cap20':'IPW, cap 20','men50_79':'Men aged 50–79'}
rows=[['Examination use (RD, pp)',labels[r.method],f'{int(r.n):,}',f'{int(r.n_observed):,}',f'{100*r.estimate:.2f} ({100*r.lo:.2f}, {100*r.hi:.2f})'] for _,r in exam.iterrows()]
rows.extend([[row[0]+' diagnosis (RR)',*row[1:]] for row in by[9]['rows']])
by[9]['rows']=rows
by[9]['headers']=['Analysis / outcome','Specification','Target n','Observed n','Estimate (95% CI)']
by[9]['widths']=[2050,1600,1000,1000,3850]
by[9]['title']='Routine examination use and subsequent reported diagnosis in CHARLS'
by[9]['notes']='The first five rows report current-minus-never differences in routine examination use in 2013 (RD, percentage points); former smokers remain separate. Complete cases and common-target standardization are distinct, and IPW addresses examination-outcome observation. The men aged 50–79 sensitivity has its own sample. Remaining rows report risk ratios for diagnosis by 2015, comparing prior examination histories among participants still reporting no diagnosis through 2013. This post-examination restriction precludes estimation of a total screening effect. Models adjust for age, sex where applicable, education, insurance and hukou; diagnosis models also adjust for baseline smoking. IPW uses measured predictors; the cap-20 versions are retained. Intervals use community-clustered t covariance; no national weights.'

# Clarify a legitimate variance difference, not a change in effect estimate.
by[27]['notes'] += ' All-complete point estimates match the comparison map in Supplementary Table 1; their intervals differ because this table clusters by household whereas the map uses participant-level covariance.'
by[1]['notes']=by[1]['notes'].replace('both outcomes, current smoking and model covariates','both outcomes, known current-smoking status and model covariates')
by[25]['notes']=by[25]['notes'].replace('C_U + C_V = Δ exactly.','C_U + C_V = Δ at full precision; rounding can produce a last-decimal discrepancy.')
by[14]['notes']=by[14]['notes'].replace(' MT_strict, if present, is outside that family.','')
for row in by[14]['rows']:
    if row[1]=='+ Income':row[1]='Income'

# Replace historical totals in the resource audit with current role information.
by[22]['rows'][0][2]='Included in the nine-programme comparison; current totals and wave-specific retention are reported below and in Supplementary Table 23.'
by[28]['notes']=by[28]['notes'].replace('two records in the complete source frame','two records with both smoking classifications available in the source frame')

def refs(text):
    pattern=r'Supplementary Tables? (\d+(?:(?:[–-]\d+)|(?:,\s*(?:and\s+)?\d+)|(?:\s+and\s+\d+))*)'
    def sub(m):
        ids=[]
        for token in re.findall(r'\d+(?:[–-]\d+)?',m[1]):
            nums=re.split('[–-]',token)
            ids.extend(range(int(nums[0]),int(nums[-1])+1))
        mapped=sorted({mapping[i] for i in ids})
        groups=[];start=prev=mapped[0]
        for value in mapped[1:]+[None]:
            if value is not None and value==prev+1:prev=value;continue
            if prev-start>=2:groups.append(f'{start}–{prev}')
            else:groups.extend(str(n) for n in range(start,prev+1))
            start=prev=value
        joined=groups[0] if len(groups)==1 else ' and '.join(groups) if len(groups)==2 else ', '.join(groups[:-1])+' and '+groups[-1]
        return 'Supplementary '+('Table ' if len(mapped)==1 else 'Tables ')+joined
    return re.sub(pattern,sub,text)
def transform(value):
    if isinstance(value,str):return refs(value)
    if isinstance(value,list):return [transform(x) for x in value]
    if isinstance(value,dict):return {k:transform(v) for k,v in value.items()}
    return value
tables=[]
for oldid in range(1,30):
    if oldid in [3,5,19]:continue
    table=transform(by[oldid]);table['id']=mapping[oldid];tables.append(table)
assert [t['id'] for t in tables]==list(range(1,27))
(R/'tables.json').write_text(json.dumps(tables,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

md=(K/'manuscript.md').read_text(encoding='utf-8')
edits=[
('Association studies therefore need to specify whether an outcome represents diagnosis history, current physiological abnormality or treatment-inclusive disease, and quantify the consequences of that choice.','Association studies therefore need to specify whether an outcome represents diagnosis history, current physiological abnormality or treatment-inclusive disease.'),
('The framework makes outcome choice an explicit, quantitative part of association analysis.',''),
('Both discordant states contributed similarly to the association reversal.',''),
('Reporting the separate increments makes this sensitivity visible.',''),
('Across our applications, treatment and smoking history altered the definition gap, substantial classification discordance coexisted with a small estimated gap, and measured disease could retain an inverse association.','Across our applications, treatment and smoking history altered the definition gap, while measured disease could retain an inverse association.'),
('In the complete NHANES fasting sample,','In the complete NHANES fasting sample of 1,816 participants,'),
('Adding BMI changed the measured-outcome odds ratio','Adding body mass index (BMI) changed the measured-outcome odds ratio'),
('HRS combined substantial classification discordance (47.6%) with a small estimated conditional gap:','In the comparison map, HRS combined substantial classification discordance (47.6%) with a small estimated conditional gap:'),
('after adjustment for observation. However, examination history','after adjustment for observation (Supplementary Table 9). However, examination history')
]
for before,after in edits:
    assert md.count(before)==1,(before,md.count(before))
    md=md.replace(before,after,1)
md=re.sub(r' +\n','\n',md)
md=refs(md)
(R/'manuscript.md').write_text(md,encoding='utf-8')

figures=transform(js(K/'figures.json'))
s7=next(x for x in figures if x['name']=='SuppFig7')
s7['legend'] += ' All-complete point estimates match main Fig. 2; household clustering here, versus participant-level covariance in Fig. 2, yields different intervals.'
for f in figures:
    if f['name']=='Fig1':f['path']=str(R/'figures/Fig1.png')
(R/'figures.json').write_text(json.dumps(figures,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['main_table.json','main_table2.json']:
    (R/name).write_text(json.dumps(transform(js(K/name)),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Allow an explicit table font size for the two-disease comparison layout.
p=R/'07_build_docx.cjs';builder=p.read_text(encoding='utf-8')
assert "font=dense?18:20;" in builder
builder=builder.replace('font=dense?18:20;','font=t.fontSize||(dense?18:20);')
p.write_text(builder,encoding='utf-8')

# Update the two table references drawn inside Fig. 1, keeping the same scene.
src=(K/'08_figures.py').read_text(encoding='utf-8').split('# Paired outcome map')[0]
src=refs(src)
exec(compile(src,str(R/'08_figures.py'),'exec'),{'__file__':str(R/'08_figures.py')})

records=[]
for oldid in range(1,30):
    action='Retain independent evidence'
    if oldid==3:action='Remove duplicate display; all 14 rows remain in Table 2'
    if oldid in [4,5]:action='Combine same-design disease comparisons side by side'
    if oldid in [12,19]:action='Combine fixed-person outcome comparisons; two repeated baseline rows shown once'
    if oldid==9:action='Retain diagnosis models and add source-verified examination-use rows cited by main text'
    records.append({'old_table':oldid,'new_table':mapping[oldid],'action':action,'old_title':old[oldid-1]['title']})
(A/'table_consolidation.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
(A/'edits.json').write_text(json.dumps({'text_edits':edits,'table_mapping':mapping,
    'variance_note':'Participant-level map intervals and household-clustered sensitivity intervals are explicitly distinguished.',
    'source_pointer_repair':'Added five saved examination-use RD estimates to old Table 9; no model refitted.'},ensure_ascii=False,indent=2),encoding='utf-8')
print('Supplementary tables consolidated 29 -> 26; all numerical source rows retained; Fig. 1 references updated.')
