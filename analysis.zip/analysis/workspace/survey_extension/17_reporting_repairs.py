from pathlib import Path
import json
R=Path(__file__).resolve().parent
tables=json.loads((R/'tables.json').read_text(encoding='utf-8'))
t=next(t for t in tables if t['id']==7)
assert 'IPW addresses examination-outcome observation' in t['notes']
t['notes']=t['notes'].replace('IPW addresses examination-outcome observation','IPW addresses missing contemporaneous smoking status among participants with known examination history')
t['notes']=t['notes'].replace('Complete cases and common-target standardization are distinct,','For these rows, observed n counts participants with known smoking status. Complete cases and common-target standardization are distinct,')
t=next(t for t in tables if t['id']==15)
old='The four main cycle-heterogeneity tests in the preceding analysis all had Holm-adjusted P = 1.000.'
assert old in t['notes']
t['notes']=t['notes'].replace(old,'The two cycle contrasts (M and S) and two IPW-versus-complete-case contrasts formed one four-test Holm family; all adjusted P values were 1.000.')
(R/'tables.json').write_text(json.dumps(tables,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=R/'manuscript.md';s=p.read_text(encoding='utf-8')
old='Observation models included measured demographic, smoking and healthcare predictors. We distinguished complete observations, standardization to a common target and inverse-observation weighting, including a weight cap of 20.'
new='Observation models addressed missing contemporaneous smoking status in the examination-use analysis and missing follow-up diagnosis in the diagnosis analysis, using measured demographic, smoking and healthcare predictors. We distinguished complete observations, standardization to a common target and inverse-observation weighting, including a weight cap of 20.'
assert old in s;s=s.replace(old,new)
p.write_text(s,encoding='utf-8')
print('Corrected observation-variable description and four-test Holm family label from saved model code and results.')
