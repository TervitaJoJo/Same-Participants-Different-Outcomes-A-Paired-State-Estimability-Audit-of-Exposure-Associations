from pathlib import Path
from collections import Counter
from zipfile import ZipFile
import csv,json,re,hashlib
import numpy as np
import pandas as pd
import pymupdf as fitz
from PIL import Image,ImageDraw
from docx import Document
from lxml import etree
R=Path(__file__).resolve().parent
B=R.parent
K=R/'before/final_consistency_20260918'
A=R/'audit/final_consistency_20260918'
S=R/'staged_consistency'
V=R/'rendered_consistency'
def js(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=js(K/'tables.json');new=js(R/'tables.json')
mapping={int(k):v for k,v in js(A/'edits.json')['table_mapping'].items()}
checks={}
for t in old:
    dest=new[mapping[t['id']]-1]
    for row in t['rows']:
        expected=list(row)
        if t['id'] in [4,5]:
            actual=next(x for x in dest['rows'] if x[0]==row[0])
            assert [actual[0]]+(actual[1:5] if t['id']==4 else actual[5:])==row
        elif t['id']==9:
            expected[0]+=' diagnosis (RR)';assert expected in dest['rows']
        elif t['id']==19:
            if row[0]=='A':expected[0]='HbA1c only'
            if row[0]=='F':expected[0]='Fasting glucose only'
            assert expected in dest['rows']
        elif t['id']==14:
            expected[1]=expected[1].replace('+ Income','Income');assert expected in dest['rows']
        elif t['id'] in [21,22,24,28]:
            # Audit/provenance prose and internal pointers may be clarified.
            assert any(x[0]==row[0] for x in dest['rows'])
        else:assert expected in dest['rows'],(t['id'],row)
checks['all_original_numerical_table_rows_retained']=True
checks['table_count']=len(new)
assert len(new)==26

md=(R/'manuscript.md').read_text(encoding='utf-8')
figs=js(R/'figures.json')
refs=js(R/'references.json')
keys=[]
for group in re.findall(r'\[@([^\]]+)\]',md):
    for key in group.split(';'):
        if key not in keys:keys.append(key)
assert keys==[r['key'] for r in refs]
assert refs==js(K/'references.json')
checks['references_unchanged_and_in_first_citation_order']=True

pat=r'Supplementary Tables? (\d+(?:(?:[–-]\d+)|(?:,\s*(?:and\s+)?\d+)|(?:\s+and\s+\d+))*)'
def getrefs(s):
    result=[]
    for match in re.finditer(pat,s):
        ids=[]
        for token in re.findall(r'\d+(?:[–-]\d+)?',match[1]):
            q=re.split('[–-]',token);ids.extend(range(int(q[0]),int(q[-1])+1))
        result.append((match[0],ids))
    return result
def strings(x):
    if isinstance(x,str):yield x
    elif isinstance(x,list):
        for value in x:yield from strings(value)
    elif isinstance(x,dict):
        for value in x.values():yield from strings(value)
all_strings=[md,*strings(figs),*strings(new),*strings(js(R/'main_table.json')),*strings(js(R/'main_table2.json'))]
citations=[]
for text in all_strings:
    for label,ids in getrefs(text):
        assert all(1<=i<=26 for i in ids),(label,ids)
        citations.append(label)
checks['all_supplementary_table_references_resolve']=True
checks['supplementary_reference_count']=len(citations)

# Every original quantitative result in prose survives the reference renumbering.
oldmd=(K/'manuscript.md').read_text(encoding='utf-8')
def result_numbers(s):
    s=s.split('## Results')[1].split('## Discussion')[0]
    s=re.sub(pat,'',s)
    return Counter(re.findall(r'[−–+-]?\d[\d,.]*(?:%)?',s))
assert not result_numbers(oldmd)-result_numbers(md)
checks['all_results_statistics_retained']=True
assert md.count('These association differences do not establish a protective effect of smoking or identify causal mechanisms.')==2
assert 'Both discordant states contributed similarly to the association reversal.' not in md
assert 'Reporting the separate increments makes this sensitivity visible.' not in md
checks['redundant_adjacent_conclusions_removed']=True

# Match key headline assertions against saved estimates, not previously printed numbers.
primary=pd.read_csv(R/'results/primary_age50_79.csv')
assert len(primary)==26 and primary.n.sum()==138813
assert (primary.delta<0).sum()==23 and (primary.hi<0).sum()==10
assert (primary.or_selfreport<1).sum()==20 and (primary.or_measured<1).sum()==12
cells=pd.read_csv(B/'charls_preparation/results/all_42_cells.csv')
assert len(cells)==42
for disease,counts in [('diabetes',(12,11)),('hypertension',(5,1)),('dyslipidaemia',(6,2))]:
    d=cells[cells.disease.eq(disease)]
    assert len(d)==14 and ((d.or_selfreport<1).sum(),(d.or_measured<1).sum())==counts
hrs=pd.read_csv(R/'results/HRS_joint_counts.csv')
assert hrs.n.sum()==5798 and hrs.loc[hrs.M.ne(hrs.S),'n'].sum()==2758
assert round(100*2758/5798,1)==47.6
holmp=pd.read_csv(B/'nhanes_fasting/results/primary_family_Holm.csv')
assert len(holmp)==6 and (holmp.p_holm>=.05).all()
cy=pd.read_csv(B/'nhanes_selection/results/primary_family_Holm.csv')
assert len(cy)==4 and cy.test.eq('cycle_difference').sum()==2 and cy.p_holm.eq(1).all()
checks['headline_counts_HRS_discordance_and_Holm_families_verified']=True

# All twelve images before renumbering were reproduced byte-for-byte from saved
# estimates; the only changed image is the table-reference text in Fig. 1.
reconstruction=js(A/'figure_reconstruction.json')
assert len(reconstruction)==12 and all(x['exact_png_match'] for x in reconstruction)
for f in figs:
    if f['name']=='Fig1':continue
    assert sha(Path(f['path']))==sha(A/'reconstructed_figures'/(f['name']+'.png'))
checks['all_twelve_figures_reproduced_from_saved_results']=True
checks['only_figure_image_change']='Fig. 1 supplementary-table references'

words={k:len(text.split()) for k,text in {
    'title':md.splitlines()[0][2:],
    'abstract':md.split('## Abstract')[1].split('## Introduction')[0],
    'body_excluding_methods':md.split('## Introduction')[1].split('## Methods')[0],
    'methods':md.split('## Methods')[1].split('## References')[0]}.items()}
assert words['title']<=15 and words['abstract']<=200 and words['body_excluding_methods']<=5000 and words['methods']<3000
assert max(len(f['legend'].split()) for f in figs)<=350
checks['word_counts']=words

ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
names=['manuscript_V1.docx','supplementary_figures/supplementary_figures.docx','supplementary_tables/supplementary_tables.docx']
for name in names:
    p=S/name
    with ZipFile(p) as z:
        fonts=set()
        for part in ['word/document.xml','word/styles.xml','word/footer1.xml']:
            x=etree.fromstring(z.read(part))
            for e in x.findall('.//w:rFonts',ns):fonts.update(e.attrib.values())
        assert fonts=={'Times New Roman'}
        assert 'Anonymous' in z.read('docProps/core.xml').decode()
doc=Document(S/'supplementary_tables/supplementary_tables.docx')
assert len(doc.tables)==26
for actual,t in zip(doc.tables,new,strict=True):
    normalize=lambda v:re.sub(r'(?<=\d)-(?=\d)','–',str(v))
    assert [[c.text for c in row.cells] for row in actual.rows]==[[normalize(c) for c in row] for row in [t['headers'],*t['rows']]]
doc=Document(S/'manuscript_V1.docx')
assert len(doc.inline_shapes)==5 and len(doc.tables)==2
for actual,t in zip(doc.tables,[js(R/'main_table.json'),js(R/'main_table2.json')],strict=True):
    assert [[c.text for c in row.cells] for row in actual.rows]==[[normalize(c) for c in row] for row in [t['headers'],*t['rows']]]
checks['Word_tables_match_sources_and_fonts_metadata_verified']=True

pages=[]
for stem in ['manuscript','supplementary_figures','supplementary_tables']:
    path=V/(f'{stem}_final.pdf' if stem=='manuscript' else f'{stem}_pass1.pdf')
    document=fitz.open(path)
    texts=[p.get_text() for p in document]
    if stem!='manuscript':
        label='Supplementary Figure ' if stem.endswith('figures') else 'Supplementary Table '
        assert len(document)==(7 if stem.endswith('figures') else 26)
        for i,text in enumerate(texts):assert label+str(i+1)+'.' in text,(stem,i+1)
    for i,text in enumerate(texts):
        assert len(text.strip())>20
        pages.append({'document':stem,'page':i+1,'words':len(text.split()),'first':text[:110].replace('\n',' '),'last':text[-100:].replace('\n',' ')})
    for start in range(0,len(document),8):
        ims=[]
        for i in range(start,min(start+8,len(document))):
            pix=document[i].get_pixmap(matrix=fitz.Matrix(.6,.6),alpha=False)
            im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
            ca=Image.new('RGB',(im.width,im.height+22),'#E5E5E5');ca.paste(im,(0,22));ImageDraw.Draw(ca).text((8,4),f'{stem} p{i+1}',fill='black');ims.append(ca)
        w,h=ims[0].size;sheet=Image.new('RGB',(w*4,h*((len(ims)+3)//4)),'#CCCCCC')
        for i,im in enumerate(ims):sheet.paste(im,((i%4)*w,(i//4)*h))
        sheet.save(V/f'{stem}_contact_{start+1}.png')
    selected=[2,6,9,14,23] if stem=='supplementary_tables' else [6] if stem=='supplementary_figures' else [i for i,t in enumerate(texts) if len(t.split())<100 or 'Figure 1.' in t or 'In the comparison map' in t]
    for i in selected:document[i].get_pixmap(matrix=fitz.Matrix(1.3,1.3),alpha=False).save(V/f'{stem}_p{i+1}.png')
    checks[stem+'_pages']=len(document)
with (A/'page_map.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(pages[0]));w.writeheader();w.writerows(pages)
(A/'delivery_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
print('Main page map:')
for p in pages:
    if p['document']=='manuscript':print(p)
