"""Publish the verified consistency revision to the original V1 filenames."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = Path('D:/review_workspace/manuscript/research/Differentiaion')
STAGED = ROOT / 'staged_consistency'
BEFORE = ROOT / 'before/final_consistency_20260918'
AUDIT = ROOT / 'audit/final_consistency_20260918'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


baseline = json.loads((BEFORE / 'published_hashes.json').read_text(encoding='utf-8'))
checks = json.loads((AUDIT / 'delivery_checks.json').read_text(encoding='utf-8'))
assert checks['all_original_numerical_table_rows_retained']
assert checks['all_results_statistics_retained']
assert checks['all_supplementary_table_references_resolve']
assert checks['all_twelve_figures_reproduced_from_saved_results']
assert (checks['manuscript_pages'], checks['supplementary_figures_pages'],
        checks['supplementary_tables_pages']) == (28, 7, 26)

# Verify every destination before any delivery file is overwritten.
for name, checksum in baseline.items():
    assert sha(OUT / name) == checksum, f'Delivery file changed since snapshot: {name}'
    with zipfile.ZipFile(STAGED / name) as archive:
        assert archive.testzip() is None, f'Invalid staged document: {name}'

figures = json.loads((ROOT / 'figures.json').read_text(encoding='utf-8'))
asset_sources = {}
for figure in figures:
    png = Path(figure['path'])
    for suffix in ('.png', '.pdf', '.drawio'):
        source = png.with_suffix(suffix)
        if source.exists():
            target = OUT / 'figure_assets' / source.name
            assert target.exists(), f'Missing delivery asset: {target}'
            if figure['name'] != 'Fig1':
                assert sha(source) == sha(target), f'Unexpected asset difference: {target}'
            asset_sources[source.name] = source

# Confirm that the staged Word images match all 12 authoritative figure PNGs.
for name, supplementary in [('manuscript_V1.docx', False),
                             ('supplementary_figures/supplementary_figures.docx', True)]:
    with zipfile.ZipFile(STAGED / name) as archive:
        embedded = {hashlib.sha256(archive.read(p)).hexdigest()
                    for p in archive.namelist() if p.startswith('word/media/')}
    expected = {sha(Path(f['path'])) for f in figures if f['supplement'] == supplementary}
    assert expected <= embedded, f'Embedded figure mismatch: {name}'

for suffix in ('.png', '.pdf', '.drawio'):
    target = OUT / 'figure_assets' / ('Fig1' + suffix)
    backup = BEFORE / 'published/figure_assets' / target.name
    backup.parent.mkdir(parents=True, exist_ok=True)
    if not backup.exists():
        shutil.copy2(target, backup)

for name in baseline:
    shutil.copy2(STAGED / name, OUT / name)
    assert sha(STAGED / name) == sha(OUT / name)
for suffix in ('.png', '.pdf', '.drawio'):
    source = ROOT / 'figures' / ('Fig1' + suffix)
    shutil.copy2(source, OUT / 'figure_assets' / source.name)

hashes = {name: sha(OUT / name) for name in baseline}
assets = {}
for name, source in asset_sources.items():
    target = OUT / 'figure_assets' / name
    assert sha(source) == sha(target)
    assets[name] = sha(target)

checks.update({
    'published_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'visual_inspection_completed': True,
    'published_hashes': hashes,
    'all_published_figure_assets_match_sources': True,
    'all_embedded_figures_match_authoritative_pngs': True,
    'published_figure_asset_hashes': assets,
    'rendered_sources': [
        'rendered_consistency/manuscript_final.pdf',
        'rendered_consistency/supplementary_figures_pass1.pdf',
        'rendered_consistency/supplementary_tables_pass1.pdf'],
    'new_models_fitted_in_this_audit': False,
})
(AUDIT / 'delivery_checks.json').write_text(json.dumps(checks, indent=2), encoding='utf-8')
(ROOT / 'audit/published_hashes.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')

report = '''# Final V1 consistency audit, 18 September 2026

Status: completed and published to the original V1 and supplementary filenames.

## Scope and verification

The final text, two main tables, five main figures, seven supplementary figures and all supplementary tables were checked against saved corrected analysis outputs. Eighteen source-file hashes were unchanged. The original 20 numerical tables were reconstructed from saved results; HRS/MHAS estimates, weight diagnostics, participant characteristics and counts were checked separately. All 12 figure PNGs were reproducible byte-for-byte before reference renumbering. No statistical models were refitted in this audit and no effect estimates were changed.

The headline map retains nine programmes in six countries, 26 survey-wave samples and 138,813 participant-wave records. The downward-gap and odds-ratio counts, HRS discordance counts and Holm families were checked. All 65 supplementary-table references resolve. Reference metadata and first-citation order are unchanged.

## Supplementary tables: 29 reduced to 26

- Original Table 3 duplicated all 14 hypertension rows already in original Table 2. Its standalone display was removed; the rows remain in final Table 2.
- Original Tables 4 and 5 used the same specification and wave rows for diabetes and dyslipidaemia. They are displayed side-by-side in final Table 3.
- Original Tables 12 and 19 overlapped in their NHANES adjustment and biomarker comparisons. Final Table 10 combines the displays, retaining the four unique single-marker rows and displaying the two repeated combined-marker rows once.

All independent numerical results, including uncertain and nonsignificant findings, were retained. The remaining 26 tables have separate analytical or documentation roles. The full numbering map is in table_consolidation.json.

## Reporting repairs

- Added the five saved CHARLS routine-examination-use risk-difference estimates to final Table 7, so the cited text has detailed numerical support.
- Corrected the corresponding observation-weight description: it addresses missing contemporaneous smoking status among participants with known examination history, rather than missing examination outcomes.
- Corrected the four-test Holm-family description to two cycle contrasts plus two inverse-observation-weighting versus complete-case contrasts; all four adjusted P values remain 1.000.
- Explained that the HRS/MHAS comparison map uses participant covariance, whereas the extension sensitivity displays use household clustering. Their identical point estimates can therefore have different confidence intervals.
- Clarified rounded allocation identities, HRS smoking-code audit wording and current programme roles. Removed obsolete conditional-label boilerplate.
- Updated supplementary numbering in all text, tables, captions and the Figure 1 artwork. Unified the final delivered PNG, PDF and editable Figure 1 assets with the embedded image.
- Compressed adjacent repeated interpretations and duplicated framework statements while retaining the specified causal limitations and essential analysis boundaries.

## Final delivery

The original manuscript_V1.docx and both supplementary Word documents were overwritten only after their previous hashes matched the saved snapshot. Published files match the verified staged files. Every delivered figure asset matches its authoritative source, and all 12 embedded Word figures match their PNG sources.

Microsoft Word rendering and visual inspection found no evident clipping or pagination problems. Main document: 28 pages, five figures and two tables. Supplementary figures: seven pages. Supplementary tables: 26 pages. Each supplementary item occupies its own page. Documents retain Times New Roman and anonymous metadata. Title: 14 words; Abstract: 165; body excluding Methods: approximately 2,555; Methods: approximately 2,325.

Audit records and the prior documents are retained locally. This was a source-to-delivery consistency check, not an independent re-estimation of every model from raw data.
'''
(AUDIT / 'FINAL_AUDIT.md').write_text(report, encoding='utf-8')

notes = '''

## Final consistency revision, 18 September 2026

The original V1 and both supplementary Word documents were updated in place after the final cross-document audit. This section supersedes the earlier table counts and numbering above; historical notes are retained.

- Supplementary tables reduced from 29 to 26 by removing a duplicate hypertension display, combining diabetes/dyslipidaemia displays and consolidating overlapping NHANES adjustment/biomarker displays. All independent numerical results remain.
- Supplementary references, figure captions and Figure 1 artwork now use the final numbering. Figure 1 PNG/PDF/drawio delivery assets match the Word image and current sources.
- Added missing CHARLS examination-use details and corrected the corresponding smoking-observation weighting description. Corrected the four-test Holm-family label and clarified participant versus household covariance for HRS/MHAS intervals.
- Removed adjacent repeated interpretations and redundant framing. No new statistical models were fitted; effect estimates are unchanged.
- Final Word renders: 28 main pages, seven supplementary figure pages and 26 supplementary table pages, one supplementary item per page. Title 14 words, Abstract 165, body approximately 2,555 excluding Methods, Methods approximately 2,325. Times New Roman and anonymous metadata retained.
- Detailed report: `audit/final_consistency_20260918/FINAL_AUDIT.md`; verification and published hashes: `audit/final_consistency_20260918/delivery_checks.json`; pre-edit snapshot: `before/final_consistency_20260918/`.
'''
with (ROOT / 'EDIT_NOTES.md').open('a', encoding='utf-8') as handle:
    handle.write(notes)
print(json.dumps({'updated_original_files': [str(OUT / name) for name in hashes],
                  'published_hashes': hashes, 'verified_figure_asset_files': len(assets),
                  'pages': [28, 7, 26], 'audit_report': str(AUDIT / 'FINAL_AUDIT.md')}, indent=2))
