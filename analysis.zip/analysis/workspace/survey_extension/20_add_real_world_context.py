"""Add verified real-world uses of self-reported diagnoses to the Introduction."""
from pathlib import Path
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
MANUSCRIPT = ROOT / 'manuscript.md'
REFS = ROOT / 'references.json'
BACKUP = ROOT / 'before/context_refs_20260918'

BACKUP.mkdir(parents=True, exist_ok=True)
for p in (MANUSCRIPT, REFS):
    target = BACKUP / p.name
    if not target.exists():
        shutil.copy2(p, target)

text = MANUSCRIPT.read_text(encoding='utf-8')
old = ('Self-reported clinician diagnoses make chronic disease ascertainment feasible in large population surveys and ageing cohorts, '
       'including HRS and MHAS.[@hrs2014;mhas2017;GUTS2024Hypertension] Yet a history of diagnosis and a measurement at examination can assign different disease states to the same person. Association studies therefore need to specify whether an outcome represents diagnosis history, current physiological abnormality or treatment-inclusive disease. We introduce an outcome definition sensitivity framework to quantify that change within a common analytical population and identify which diagnosis–measurement states account for it.')
new = old + (' This issue is not merely methodological: self-reported diagnoses underpin epidemiological studies with direct public-health and clinical relevance. '
              'For example, self-reported multimorbidity in CHARLS has been used to study depressive-symptom trajectories,[@Huang2024CHARLSDepression] '
              'self-reported versus biomedical hypertension and diabetes in ELSA has been used to assess educational inequalities,[@Leopold2023ELSAUnderreporting] '
              'and self-reported physician-diagnosed rheumatoid arthritis in HRS has served as a prospective outcome.[@Tao2025HRSRA] '
              'These applications make it consequential to state whether an outcome represents diagnosis history, current physiological abnormality or treatment-inclusive disease.')
assert text.count(old) == 1, 'Expected current opening paragraph was not found exactly once.'
text = text.replace(old, new, 1)
MANUSCRIPT.write_text(text, encoding='utf-8')

refs = json.loads(REFS.read_text(encoding='utf-8'))
new_refs = [
    {
        'key': 'Huang2024CHARLSDepression',
        'authors': 'Huang, J. et al.',
        'title': 'Age-related differences in the number of chronic diseases in association with trajectories of depressive symptoms: a population-based cohort study',
        'journal': 'BMC Public Health',
        'volume': '24',
        'pages': '2496',
        'year': 2024,
        'doi': '10.1186/s12889-024-19975-9',
        'url': ''
    },
    {
        'key': 'Leopold2023ELSAUnderreporting',
        'authors': 'Leopold, L., van Valkengoed, I. G. M. & Engelhardt, H.',
        'title': 'Education and age trajectories of chronic conditions: Are tests of the cumulative advantage and disadvantage hypothesis biased by underreporting?',
        'journal': 'Soc. Sci. Med.',
        'volume': '334',
        'pages': '116134',
        'year': 2023,
        'doi': '10.1016/j.socscimed.2023.116134',
        'url': ''
    },
    {
        'key': 'Tao2025HRSRA',
        'authors': 'Tao, M. et al.',
        'title': 'Trajectories of health status and their association with rheumatoid arthritis risk: insights from a national prospective cohort study',
        'journal': 'BMC Public Health',
        'volume': '25',
        'pages': '1132',
        'year': 2025,
        'doi': '10.1186/s12889-025-22303-4',
        'url': ''
    }
]
keys = {r['key'] for r in refs}
assert not keys.intersection(r['key'] for r in new_refs), 'New reference key already exists.'
refs.extend(new_refs)

# Keep the reference list in first-citation order, as in the previous V1.
order = []
for match in re.finditer(r'\[@([^\]]+)\]', text):
    for key in match.group(1).split(';'):
        if key not in order:
            order.append(key)
missing = set(r['key'] for r in refs) - set(order)
assert not missing, f'Uncited references would be left in the list: {missing}'
by_key = {r['key']: r for r in refs}
ordered = []
for i, key in enumerate(order, start=1):
    r = dict(by_key[key])
    r['number'] = i
    ordered.append(r)
REFS.write_text(json.dumps(ordered, ensure_ascii=False, indent=2), encoding='utf-8')

print(json.dumps({'added_keys': [r['key'] for r in new_refs],
                  'reference_count': len(ordered),
                  'first_citation_order': order[:8],
                  'manuscript_backup': str(BACKUP / 'manuscript.md'),
                  'references_backup': str(BACKUP / 'references.json')}, ensure_ascii=False, indent=2))
