"""Publish the verified Introduction context and its references to original V1."""
from pathlib import Path
from zipfile import ZipFile
import datetime
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
OUT = Path('D:/review_workspace/manuscript/research/Differentiaion')
STAGED = ROOT / 'staged_context_refs_20260918'
AUDIT = ROOT / 'audit/final_consistency_20260918'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


checks = json.loads((AUDIT / 'delivery_checks.json').read_text(encoding='utf-8'))
published = checks['published_hashes']
for name, checksum in published.items():
    assert sha(OUT / name) == checksum, f'Unexpected delivery edit: {name}'

md = (ROOT / 'manuscript.md').read_text(encoding='utf-8')
refs = json.loads((ROOT / 'references.json').read_text(encoding='utf-8'))
order = []
for match in re.finditer(r'\[@([^\]]+)\]', md):
    for key in match.group(1).split(';'):
        if key not in order:
            order.append(key)
assert len(refs) == 32 and order == [r['key'] for r in refs]
assert {'Huang2024CHARLSDepression', 'Leopold2023ELSAUnderreporting', 'Tao2025HRSRA'} <= set(order)
assert 'self-reported multimorbidity in CHARLS' in md
assert 'self-reported versus biomedical hypertension and diabetes in ELSA' in md
assert 'self-reported physician-diagnosed rheumatoid arthritis in HRS' in md

staged_main = STAGED / 'manuscript_V1.docx'
with ZipFile(staged_main) as archive:
    assert archive.testzip() is None
    core = archive.read('docProps/core.xml').decode('utf-8')
    assert 'Anonymous' in core
    document_xml = archive.read('word/document.xml').decode('utf-8')
    assert 'underreporting?' in document_xml

target = OUT / 'manuscript_V1.docx'
shutil.copy2(staged_main, target)
assert sha(target) == sha(staged_main)
published['manuscript_V1.docx'] = sha(target)

checks.update({
    'references_unchanged_and_in_first_citation_order': False,
    'references_currently_in_first_citation_order': True,
    'references_count_after_context_update': len(refs),
    'new_context_references_verified': [
        '10.1186/s12889-024-19975-9',
        '10.1016/j.socscimed.2023.116134',
        '10.1186/s12889-025-22303-4'],
    'context_update_published': True,
    'context_update_scope': 'Introduction paragraph and reference numbering only; no analyses, figures or supplementary tables changed.',
    'published_at_context_update': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'published_hashes': published,
    'main_render_context_update_pages': 28,
    'main_render_context_update_abstract_words': len(md.split('## Abstract')[1].split('## Introduction')[0].split()),
    'main_render_context_update_body_words_excluding_methods': len(md.split('## Introduction')[1].split('## Methods')[0].split()),
})
(AUDIT / 'delivery_checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
(ROOT / 'audit/published_hashes.json').write_text(json.dumps(published, ensure_ascii=False, indent=2), encoding='utf-8')

report = '''# Real-world self-report context update, 18 September 2026

The Introduction of the original `manuscript_V1.docx` now includes a concise, evidence-backed statement that self-reported diagnoses are used in epidemiological studies with public-health and clinical relevance. Three examples were added: CHARLS self-reported multimorbidity and depressive-symptom trajectories; ELSA comparisons of self-reported versus biomedical hypertension and diabetes in educational-inequality analyses; and HRS self-reported physician-diagnosed rheumatoid arthritis as a prospective outcome.

The three papers were checked against Europe PMC abstracts and Crossref bibliographic metadata:

- Huang et al., *BMC Public Health* 24, 2496 (2024), DOI 10.1186/s12889-024-19975-9.
- Leopold, van Valkengoed & Engelhardt, *Social Science & Medicine* 334, 116134 (2023), DOI 10.1016/j.socscimed.2023.116134.
- Tao et al., *BMC Public Health* 25, 1132 (2025), DOI 10.1186/s12889-025-22303-4.

References were renumbered in first-citation order from 29 to 32. The added wording is contextual and does not claim that those studies are invalid or that the present framework identifies their causal mechanisms. The abstract, results, methods, data, estimates, figures and supplementary documents were not changed. The rebuilt main document remains 28 pages; the visual check of the added paragraph and reference pages found no clipping or pagination defect. Only the original manuscript Word file was overwritten; supplementary Word files and figure assets were left untouched because their content did not change.
'''
(AUDIT / 'context_refs_20260918.md').write_text(report, encoding='utf-8')

notes = '''

## Real-world self-report context update, 18 September 2026

Added a concise evidence-backed Introduction paragraph explaining that self-reported diagnoses support epidemiological studies with public-health and clinical relevance. The paragraph gives verified CHARLS, ELSA and HRS examples and states the outcome-construct implication without claiming causal mechanisms or invalidating those studies. Three references were added and the reference list was renumbered in first-citation order (32 references total). The original manuscript V1 was updated in place; supplementary documents and figures were unchanged. The main render remains 28 pages, with 165-word Abstract and approximately 2,632-word body excluding Methods. Verification: `audit/final_consistency_20260918/context_refs_20260918.md`.
'''
with (ROOT / 'EDIT_NOTES.md').open('a', encoding='utf-8') as handle:
    handle.write(notes)

print(json.dumps({'published': str(target), 'sha256': published['manuscript_V1.docx'],
                  'reference_count': len(refs), 'pages': 28,
                  'supplementary_files_unchanged': True}, ensure_ascii=False, indent=2))
