"""Revise the current Word document, retaining edits made since the last build."""
from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile
from collections import Counter
from docx import Document
from docx.text.paragraph import Paragraph
from docx.shared import Pt, RGBColor
from lxml import etree
import hashlib, json, re, shutil

R = Path(__file__).resolve().parent
OUT = Path('D:/review_workspace/manuscript/research/Differentiaion')
TARGET = OUT / 'manuscript_V1.docx'
B = R / 'before/structure_20260918'
S = R / 'staged_structure_20260918'
A = R / 'audit/structure_20260918'
for p in (B, S, A): p.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
names = ['manuscript_V1.docx', 'supplementary_figures/supplementary_figures.docx',
         'supplementary_tables/supplementary_tables.docx']
hashes = {n: sha(OUT/n) for n in names}
assert hashes['manuscript_V1.docx'] == 'f09429e5fb2ef0bb9630a3d3c413969802697b77d783f44c5f3fad04576a3afe'
for p in [TARGET, R/'manuscript.md', R/'07_build_docx.cjs']:
    if not (B/p.name).exists(): shutil.copy2(p, B/p.name)
(B/'published_hashes.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')

d = Document(TARGET)
original = [p.text for p in d.paragraphs]
def find(start):
    matches = [p for p in d.paragraphs if p.text.startswith(start)]
    assert len(matches) == 1, (start, len(matches))
    return matches[0]
def replace_text(p, text):
    # These edited paragraphs have no citation superscripts or embedded objects.
    p.clear()
    r = p.add_run(text)
    r.font.name = 'Times New Roman'
    r.font.size = Pt(12)
def insert_before(p, text, template=None):
    q = deepcopy((template or find('The joint-state model separates'))._p)
    for child in list(q):
        if child.tag != '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}pPr':
            q.remove(child)
    p._p.addprevious(q)
    new = Paragraph(q, p._parent)
    replace_text(new, text)
    return new

h1 = find('Self-report shifted hypertension')
h2 = find('Two discordant states accounted')
heading1 = 'Step 1: Self-report shifted hypertension associations downward across most samples'
heading2 = 'Step 2: Two discordant states account for the CHARLS hypertension definition gap'
heading3 = 'Step 3: Treatment, exposure history and analytical eligibility alter the definition gap'
replace_text(h1, heading1)
replace_text(h2, heading2)

comparison = find('In the comparison map, HRS')
comparison_old = comparison.text
comparison_new = (comparison_old.split(', but its component-weighted')[0][:-1]
                  + '; Supplementary Fig. 7 and Supplementary Tables 22–26).')
replace_text(comparison, comparison_new)
weight_text = ('The MHAS component-weighted conditional gap changed direction and was imprecise: '
               '0.578 (−0.596 to 1.752). The same weight-eligible sample gave −0.259 without weights, '
               'locating the point-estimate change in weighting rather than exclusion '
               '(Supplementary Fig. 7 and Supplementary Tables 24 and 26).')
uncertain = ('Current-versus-never joint-state gaps were uncertain in both HRS and MHAS '
             '(Supplementary Fig. 7 and Supplementary Tables 22–26).')

treatment = find('Step 3 examined treatment')
allocation_support = find('Allocations varied across diseases')
allocation_old = allocation_support.text
allocation_sentence, support_sentence = allocation_old.split(' Restricting to smoking groups', 1)
support_sentence = 'Restricting to smoking groups' + support_sentence
replace_text(allocation_support, allocation_sentence + ' ' + uncertain)
treatment._p.addprevious(allocation_support._p)

new_h3 = insert_before(treatment, heading3, h2)
new_h3.paragraph_format.page_break_before = True
replace_text(treatment, treatment.text.replace('Step 3 examined treatment and smoking-reference sensitivity. ',
             'We first examined treatment and smoking-reference sensitivity. ', 1))
support = insert_before(find('Figure 3. Discordant states'), support_sentence)
insert_before(find('Figure 3. Discordant states'), weight_text)

# Keep the subordinate sections inside Step 3 in Word's outline.
for start, title in [
    ('Healthcare contacts and smoking transitions identified', 'Healthcare contacts and smoking transitions'),
    ('NHANES diabetes boundary tests separated', 'NHANES diabetes boundary tests')]:
    p = find(start)
    replace_text(p, title)
    p.style = d.styles['Heading 3']
    p.paragraph_format.keep_with_next = True
    for run in p.runs:
        run.bold = True
        run.italic = True
        run.font.color.rgb = RGBColor(0, 0, 0)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)

# Move the existing paragraph as a whole, preserving its wording and formatting.
allocation_discussion = find('The allocation serves a diagnostic purpose.')
allocation_discussion_text = allocation_discussion.text
find('Three limitations define')._p.addprevious(allocation_discussion._p)

new = [p.text for p in d.paragraphs]
start, stop = original.index('Discussion'), original.index('Methods')
assert Counter(original[start+1:stop]) == Counter(new[new.index('Discussion')+1:new.index('Methods')])
assert original[original.index('Methods'):] == new[new.index('Methods'):]
assert original[:original.index('Results')] == new[:new.index('Results')]
decimals = lambda s: Counter(re.findall(r'[−+]?\d+\.\d+', s))
assert decimals('\n'.join(original)) == decimals('\n'.join(new))
assert len(d.inline_shapes) == 5 and len(d.tables) == 2

staged = S/'manuscript_V1.docx'
with ZipFile(TARGET) as src, ZipFile(staged, 'w') as dst:
    for info in src.infolist():
        data = (etree.tostring(d._element, xml_declaration=True, encoding='UTF-8', standalone=True)
                if info.filename == 'word/document.xml' else src.read(info.filename))
        dst.writestr(info, data)

# Reconcile the user's intervening prose edits into the source before restructuring.
md = (B/'manuscript.md').read_text(encoding='utf-8')
md = md.replace('These applications make it consequential to state whether an outcome represents diagnosis history, current physiological abnormality or treatment-inclusive disease.',
                'These applications make the distinction between diagnosis history, current physiological abnormality and treatment-inclusive disease directly relevant to how their results are interpreted.')
md = re.sub(r'### Why this allocation is useful\n\n.*?\n\n(?=### HRS and MHAS)', '', md, flags=re.S)
assert 'The allocation serves a diagnostic purpose.' not in md
md = md.replace('Three limitations define the scope of the applications.',
                allocation_discussion_text + '\n\nThree limitations define the scope of the applications.', 1)
md = md.replace('### Self-report shifted hypertension associations downward across most samples', '### '+heading1)
md = md.replace('### Two discordant states accounted for the CHARLS hypertension definition gap', '### '+heading2)
assert comparison_old in md
md = md.replace(comparison_old, comparison_new)
assert allocation_old in md
md = md.replace('\n\n'+allocation_old, '')
md = md.replace('Step 3 examined treatment and smoking-reference sensitivity.',
                allocation_sentence+' '+uncertain+'\n\n### '+heading3+
                '\n\nWe first examined treatment and smoking-reference sensitivity.', 1)
md = md.replace('[[FIG3]]', support_sentence+'\n\n'+weight_text+'\n\n[[FIG3]]', 1)
md = md.replace('### Healthcare contacts and smoking transitions identified distinct sources of sensitivity',
                '#### Healthcare contacts and smoking transitions')
md = md.replace('### NHANES diabetes boundary tests separated definition, adjustment and sample sensitivity',
                '#### NHANES diabetes boundary tests')
(R/'manuscript.md').write_text(md, encoding='utf-8')

with ZipFile(TARGET) as oldz, ZipFile(staged) as newz:
    changed = [n for n in oldz.namelist() if oldz.read(n) != newz.read(n)]
assert changed == ['word/document.xml'], changed
report = {'baseline_hashes':hashes, 'changed_docx_parts':changed,
          'current_user_edits_preserved':True, 'discussion_reordered_verbatim':True,
          'intro_abstract_methods_references_unchanged_in_word':True,
          'all_decimal_results_preserved':True, 'figures_tables_and_captions_preserved':True,
          'step_2_wording_was_already_complete':True,
          'result_heading_hierarchy': [(p.style.name,p.text) for p in d.paragraphs
              if p.style.name.startswith('Heading') and (p.text.startswith('Step ') or p.text in
                  ['Healthcare contacts and smoking transitions','NHANES diabetes boundary tests'])],
          'staged_docx':str(staged)}
(A/'checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
