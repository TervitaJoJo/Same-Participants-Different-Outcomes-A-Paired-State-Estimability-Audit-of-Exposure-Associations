"""Restructure the current Word abstract without altering the remaining text."""
from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile
from docx import Document
from docx.text.paragraph import Paragraph
from docx.shared import Pt, RGBColor
from lxml import etree
import hashlib, json, re, shutil

R = Path(__file__).resolve().parent
O = Path('D:/review_workspace/manuscript/research/Differentiaion')
B = R/'before/structured_abstract_20260918'
S = R/'staged_structured_abstract_20260918'
A = R/'audit/structured_abstract_20260918'
for p in (B,S,A): p.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
target = O/'manuscript_V1.docx'
names = ['manuscript_V1.docx','supplementary_figures/supplementary_figures.docx',
         'supplementary_tables/supplementary_tables.docx']
hashes = {n:sha(O/n) for n in names}
assert hashes['manuscript_V1.docx'] == '0f1d1adca1a65e6d1f33a3febf72f4d0b4a43690490f223cbc7ec57554db8ffb'
for p in (target,R/'manuscript.md',R/'07_build_docx.cjs'):
    if not (B/p.name).exists(): shutil.copy2(p,B/p.name)
(B/'published_hashes.json').write_text(json.dumps(hashes,indent=2),encoding='utf8')

sections = [
('Objective', 'To quantify how outcome definition changes exposure associations in large population studies using self-reported diagnoses.'),
('Design', 'Secondary survey analysis combining cross-sectional comparisons and longitudinal sensitivity analyses.'),
('Setting and Participants', 'The primary comparison included 138,813 participant-wave records from adults aged 50–79 across 26 survey-wave samples from nine survey programmes in six countries.'),
('Methods', 'An outcome definition sensitivity framework compared paired associations under reported and measured definitions, allocated their difference to discordant diagnosis–measurement states, and tested sensitivity to treatment, exposure history and analytical eligibility.'),
('Results', 'Reported hypertension generally shifted smoking associations downward, sometimes reversing direction. In CHARLS, the paired log-odds-ratio difference was −0.294 (95% confidence interval −0.450 to −0.137), with similar allocations to both discordant states. Treatment inclusion and smoking-reference choice narrowed the gap. HRS showed a small estimated conditional gap; MHAS estimates were weight-sensitive and imprecise. NHANES diabetes boundary tests showed inverse associations under measured definitions, with body mass index and income adjustments acting in opposite directions.'),
('Conclusions', 'The framework makes outcome choice explicit and quantifies its consequences for exposure associations, supporting study design and evidence assessment. These association differences do not establish a protective effect of smoking or identify causal mechanisms.')
]
assert sum(len((label+' '+text).split()) for label,text in sections) <= 200
d = Document(target)
original = [p.text for p in d.paragraphs]
abstract_heading = next(p for p in d.paragraphs if p.text=='Abstract')
intro_heading = next(p for p in d.paragraphs if p.text=='Introduction')
abstract_p = d.paragraphs[original.index('Abstract')+1]
assert original.index('Introduction')==original.index('Abstract')+2
old_abstract = abstract_p.text
for label,text in sections:
    elem = deepcopy(abstract_p._p)
    abstract_p._p.addprevious(elem)
    p = Paragraph(elem, abstract_p._parent)
    p.clear()
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.keep_together = True
    p.paragraph_format.keep_with_next = label != 'Conclusions'
    for wording,bold in [(label+': ',True),(text,False)]:
        run=p.add_run(wording)
        run.bold=bold
        run.font.name='Times New Roman'
        run.font.size=Pt(12)
        run.font.color.rgb=RGBColor(0,0,0)
abstract_p._p.getparent().remove(abstract_p._p)
intro_heading.paragraph_format.page_break_before=True
next(p for p in d.paragraphs if p.text=='Results').paragraph_format.page_break_before=True
updated=[p.text for p in d.paragraphs]
assert original[original.index('Introduction'):]==updated[updated.index('Introduction'):]
assert len(d.inline_shapes)==5 and len(d.tables)==2
new_abstract='\n\n'.join(label+': '+text for label,text in sections)
for token in ['138,813','−0.294','−0.450','−0.137','CHARLS','HRS','MHAS','NHANES']:
    assert token in old_abstract and token in new_abstract

staged=S/'manuscript_V1.docx'
with ZipFile(target) as src,ZipFile(staged,'w') as dst:
    for info in src.infolist():
        data=(etree.tostring(d._element,encoding='UTF-8',xml_declaration=True,standalone=True)
              if info.filename=='word/document.xml' else src.read(info.filename))
        dst.writestr(info,data)

# Retain the user's intervening Introduction edits in the maintained source.
md=(B/'manuscript.md').read_text(encoding='utf8')
assert old_abstract in md
md=md.replace(old_abstract,'\n\n'.join('**'+label+':** '+text for label,text in sections),1)
md=md.replace('Agreement statistics establish how often definitions coincide, but cannot establish',
              'Although agreement statistics establish how often definitions coincide, it cannot establish')
md=md.replace('Our framework proceeds in three steps:', 'Consequently, Our framework proceeds in three steps:',1)
(R/'manuscript.md').write_text(md,encoding='utf8')
checks={
    'baseline_hashes':hashes,'staged_path':str(staged),'labels':[x[0] for x in sections],
    'old_abstract_words':len(old_abstract.split()),
    'abstract_words_excluding_labels':sum(len(t.split()) for _,t in sections),
    'abstract_words_including_labels':sum(len((l+' '+t).split()) for l,t in sections),
    'text_after_abstract_unchanged':True,'new_analyses':False,
    'all_original_numerical_abstract_results_retained':True,
    'additional_setting_information_verified_against_results':'Primary map: 26 samples, ages 50–79, six countries.',
    'all_original_result_themes_retained':[
        'Definition-related reversal of exposure associations',
        'Three-step outcome definition sensitivity framework',
        'Nine programmes and 138,813 participant-wave records',
        'CHARLS paired gap and confidence interval, similar discordant-state allocations',
        'Treatment inclusion and smoking-reference sensitivity',
        'Small estimated HRS conditional gap',
        'Weight-sensitive, imprecise MHAS estimates',
        'NHANES inverse measured-disease associations and opposing BMI/income adjustments',
        'Study-design and evidence-assessment use',
        'No smoking protection or causal mechanisms established'],
    'format_choice':'Structured abstract explicitly requested by the user; not represented as Nature Communications submission format.'
}
(A/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
(A/'abstract.txt').write_text(new_abstract,encoding='utf8')
print(json.dumps({k:v for k,v in checks.items() if k not in ['all_original_result_themes_retained','baseline_hashes']},ensure_ascii=False,indent=2))
