"""Renumber supplementary figures/tables by first citation in the manuscript."""
from pathlib import Path
import copy
import hashlib
import json
import re
import shutil

from docx import Document

R = Path(__file__).resolve().parent
O = Path('D:/review_workspace/manuscript/research/Differentiaion')
B = R / 'before/renumber_supplementary_20260918'
S = R / 'staged_renumber_supplementary_20260918'
A = R / 'audit/renumber_supplementary_20260918'
for p in (B, S, A):
    p.mkdir(parents=True, exist_ok=True)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

names = ['manuscript_V1.docx', 'supplementary_figures/supplementary_figures.docx',
         'supplementary_tables/supplementary_tables.docx']
baseline = {n: sha(O/n) for n in names}
published = json.loads((R/'audit/published_hashes.json').read_text(encoding='utf8'))

def docx_visible_content(path):
    """Return the visible paragraph/table/image structure for a normalization-safe check."""
    doc = Document(path)
    paragraphs = [p.text for p in doc.paragraphs]
    tables = [[[cell.text for cell in row.cells] for row in table.rows]
              for table in doc.tables]
    return paragraphs, tables, len(doc.inline_shapes)

for n in names:
    if baseline[n] != published[n]:
        # Word can rewrite package XML on open/save without changing visible content.
        # Accept that known normalization for the manuscript only after comparing it
        # with the latest structured-abstract build; supplementary files remain strict.
        staged_reference = R / 'staged_structured_abstract_20260918' / n
        if n == 'manuscript_V1.docx' and staged_reference.exists():
            assert docx_visible_content(O / n) == docx_visible_content(staged_reference), (
                f'Unexpected visible edit in current delivery: {n}'
            )
        else:
            raise AssertionError(f'Unexpected current delivery edit: {n}')
for n in names:
    (B / n).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(O/n, B/n)
for n in ['manuscript.md', 'figures.json', 'tables.json', 'main_table.json',
          'main_table2.json', '07_build_docx.cjs']:
    shutil.copy2(R/n, B/n)
(B/'published_hashes.json').write_text(json.dumps(baseline, indent=2), encoding='utf8')

md_path = R/'manuscript.md'
md_before = md_path.read_text(encoding='utf8')

def first_order(text, kind):
    # Capture each reference in manuscript order and expand ranges.
    if kind == 'table':
        pattern = r'Supplementary Tables?\s+([^.;)]+)'
    else:
        pattern = r'Supplementary (?:Fig\.?|Figures?)\s+([^.;)]+)'
    out = []
    for m in re.finditer(pattern, text):
        # A sentence can cite a figure and a table together (for example,
        # "Supplementary Fig. 7 and Supplementary Tables 22–26").  Restrict
        # each match to the number expression belonging to its own label.
        part = re.split(r'\s+and\s+Supplementary\s+', m.group(1), maxsplit=1,
                        flags=re.IGNORECASE)[0]
        for token in re.findall(r'\d+(?:[–-]\d+)?', part):
            if '–' in token or '-' in token:
                a, b = [int(x) for x in re.split('[–-]', token)]
                ids = range(a, b + 1)
            else:
                ids = [int(token)]
            for x in ids:
                if x not in out:
                    out.append(x)
    return out

table_order = first_order(md_before, 'table')
fig_order = first_order(md_before, 'figure')
assert table_order == [19,20,21,1,2,22,23,24,25,26,3,4,5,18,17,6,7,8,9,10,12,13,14,11,15,16], table_order
assert fig_order == [6,7,1,2,3,4,5], fig_order
table_map = {old: new for new, old in enumerate(table_order, 1)}
fig_map = {old: new for new, old in enumerate(fig_order, 1)}

def replace_refs(text, label, mapping):
    # Replace only the number expression immediately following a supplementary
    # label.  Capturing through the next full stop would also remap unrelated
    # numbers in the sentence (sample sizes, ages, years, and so on).
    number_expr = r'(\d+\s*(?:[\u2013-]\s*\d+)?(?:\s*(?:,|and)\s*\d+\s*(?:[\u2013-]\s*\d+)?)*)'
    if label == 'table':
        pattern = r'(Supplementary Tables?\s+)' + number_expr
    else:
        pattern = r'(Supplementary (?:Fig\.?|Figures?)\s+)' + number_expr
    def repl(m):
        def one(match):
            n = int(match.group(0))
            return str(mapping.get(n, n))
        nums = re.sub(r'\d+', one, m.group(2))
        return m.group(1) + nums
    return re.sub(pattern, repl, text)

md_after = replace_refs(replace_refs(md_before, 'table', table_map), 'figure', fig_map)
assert md_after != md_before
md_path.write_text(md_after, encoding='utf8')

figs_before = json.loads((R/'figures.json').read_text(encoding='utf8'))
tables_before = json.loads((R/'tables.json').read_text(encoding='utf8'))
supp_figs = [copy.deepcopy(x) for x in figs_before if x['supplement']]
main_figs = [copy.deepcopy(x) for x in figs_before if not x['supplement']]
assert [x['id'] for x in supp_figs] == list(range(1,8))
supp_figs_by_old = {x['id']: x for x in supp_figs}
supp_figs_after = []
for old in fig_order:
    x = supp_figs_by_old[old]
    x['id'] = fig_map[old]
    supp_figs_after.append(x)
figs_after = main_figs + supp_figs_after
# Captions for main figures can also cite supplementary material.  Apply the
# same reference map to every legend before rebuilding the Word files.
for x in figs_after:
    x['legend'] = replace_refs(x['legend'], 'table', table_map)
    x['legend'] = replace_refs(x['legend'], 'figure', fig_map)
(R/'figures.json').write_text(json.dumps(figs_after, ensure_ascii=False, indent=2), encoding='utf8')

tables_by_old = {x['id']: copy.deepcopy(x) for x in tables_before}
tables_after = []
for old in table_order:
    x = tables_by_old[old]
    x['id'] = table_map[old]
    x['title'] = replace_refs(x['title'], 'table', table_map)
    x['title'] = replace_refs(x['title'], 'figure', fig_map)
    x['notes'] = replace_refs(x['notes'], 'table', table_map)
    x['notes'] = replace_refs(x['notes'], 'figure', fig_map)
    x['headers'] = [replace_refs(replace_refs(str(v), 'table', table_map), 'figure', fig_map) for v in x['headers']]
    x['rows'] = [[replace_refs(replace_refs(str(v), 'table', table_map), 'figure', fig_map) for v in row] for row in x['rows']]
    tables_after.append(x)
(R/'tables.json').write_text(json.dumps(tables_after, ensure_ascii=False, indent=2), encoding='utf8')

# Main-table notes are part of the manuscript and may cite supplementary
# material (for example, the participant-flow table).  Keep their structure
# and numbers unchanged while synchronizing those labels.
for main_name in ('main_table.json', 'main_table2.json'):
    main_path = R / main_name
    main_obj = json.loads(main_path.read_text(encoding='utf8'))
    def remap_main(v):
        if isinstance(v, str):
            return replace_refs(replace_refs(v, 'table', table_map), 'figure', fig_map)
        if isinstance(v, list):
            return [remap_main(y) for y in v]
        if isinstance(v, dict):
            return {k: remap_main(y) for k, y in v.items()}
        return v
    main_path.write_text(json.dumps(remap_main(main_obj), ensure_ascii=False, indent=2), encoding='utf8')

# Ensure every reference in all manuscript/figure/table source strings resolves.
all_source = [md_after]
def strings(x):
    if isinstance(x, str): yield x
    elif isinstance(x, list):
        for y in x: yield from strings(y)
    elif isinstance(x, dict):
        for y in x.values(): yield from strings(y)
all_source += list(strings(figs_after)) + list(strings(tables_after))
main_tables = json.loads((R/'main_table.json').read_text(encoding='utf8'))
main_tables2 = json.loads((R/'main_table2.json').read_text(encoding='utf8'))
all_source += list(strings(main_tables)) + list(strings(main_tables2))
for text in all_source:
    for n in re.findall(r'Supplementary Tables?\s+(\d+)', text): assert 1 <= int(n) <= 26
    for n in re.findall(r'Supplementary (?:Fig\.?|Figures?)\s+(\d+)', text): assert 1 <= int(n) <= 7

audit = {
    'baseline_hashes': baseline,
    'table_first_citation_order_old': table_order,
    'figure_first_citation_order_old': fig_order,
    'table_old_to_new': table_map,
    'figure_old_to_new': fig_map,
    'table_new_order': [x['id'] for x in tables_after],
    'figure_new_order': [(x['name'], x['id']) for x in supp_figs_after],
    'source_changed_only_supplementary_references': True,
    'main_figures_unchanged': [x['name'] for x in main_figs],
    'table_count': len(tables_after),
    'figure_count': len(supp_figs_after),
    'staged_directory': str(S),
}
(A/'mapping.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps(audit, ensure_ascii=False, indent=2))
