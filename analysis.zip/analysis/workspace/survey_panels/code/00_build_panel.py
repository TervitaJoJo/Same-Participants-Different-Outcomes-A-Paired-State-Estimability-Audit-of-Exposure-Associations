# Build one individual-level panel covering the 17 datasets that
# 14_correction.build_all() already validates (M, S, exposure), with the
# covariates each source script adjusted for, plus a drinking variable.
#
# The outcome definitions are NOT re-derived here: they are taken from the
# frozen frames, so the panel inherits exactly the definitions that produced
# the published estimates.  Only covariates are attached, by the same keys the
# source scripts used.  Every dataset is then checked against the published
# sensitivity / specificity so a silent merge failure cannot slip through.

from __future__ import annotations

import io
import sys
import warnings
import zipfile
from importlib import import_module
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
SCI = ROOT / "survey_sources"
OUT = Path(__file__).resolve().parents[1] / "results"
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(SCI / "code"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

ENS = ROOT / "ENSANUT"
NHA = ROOT / "NHANES"


def rd(path: Path, cols=None, cats=False):
    with zipfile.ZipFile(path) as z:
        inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
        with z.open(inner) as f:
            raw = f.read()
    if cols:
        have = set(pd.read_stata(io.BytesIO(raw), iterator=True).variable_labels())
        cols = [c for c in cols if c in have]
    kw = {"convert_categoricals": False}
    if cols:
        kw["columns"] = cols
    d = pd.read_stata(io.BytesIO(raw), **kw)
    if cats and cols:
        vl = pd.read_stata(io.BytesIO(raw), iterator=True).value_labels()
        for c in d.columns:
            if c in vl:
                d[c] = d[c].map(vl[c])
    return d


def labels(path: Path) -> list[str]:
    with zipfile.ZipFile(path) as z:
        inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
        with z.open(inner) as f:
            return list(pd.read_stata(io.BytesIO(f.read()),
                                      iterator=True).variable_labels())


def pick(df, *names):
    for n in names:
        if n in df.columns:
            return n
    return None


def num(s):
    return pd.to_numeric(s, errors="coerce")


def drink_from_freq(s, weekly_plus=8):
    """Binary frequent drinking from an ordinal frequency column."""
    v = num(s.astype(str).str.strip())
    out = np.where(v.notna() & (v <= 30), (v >= weekly_plus).astype(float), np.nan)
    out = np.where(v == 98, 0.0, out)
    t = s.astype(str).str.strip().str.lower()
    out = np.where(np.isnan(out) & t.str.startswith("s"), 1.0, out)
    out = np.where(np.isnan(out) & t.str.startswith("no"), 0.0, out)
    return pd.Series(out, index=s.index)


def cov_ensanut_2012():
    bp = rd(ENS / "2012" / "sangre_tension_arterial.stata.stata.zip",
            cols=["folio", "intp", "sexo", "edad"])
    # cats=True: a1311 is a labelled frequency question, not a count.  Reading
    # codes and treating them as days produced a different (and wrong) binary.
    ad = rd(ENS / "2012" / "Adultos.stata.stata.zip",
            cols=["folio", "intp", "a1311"], cats=True)
    an = rd(ENS / "2012" / "adultos_antropometria_2012.stata.stata.zip",
            cols=["folio", "intp", "escolari"])
    c = bp.merge(ad, on=["folio", "intp"], how="left") \
          .merge(an, on=["folio", "intp"], how="left")
    c["age"] = num(c["edad"])
    c["male"] = np.where(num(c["sexo"]) == 1, 1.0, 0.0)
    c["edu"] = num(c["escolari"])
    # 06_ensanut_2012.py's own rule
    weekly = ["Una o dos veces a la semana", "Tres o cuatro veces a la semana",
              "Casi todos los días (5-6 veces por semana)", "Una vez al día",
              "Dos veces al día", "Tres o más veces al día"]
    dr = c["a1311"].astype(str)
    c["drink"] = np.where(dr == "Actualmente no toma", 0.0,
                          np.where(dr.isin(weekly), 1.0,
                                   np.where(dr == "NS/NR", np.nan, 0.0)))
    c["smoke_src"] = np.nan
    return c[["folio", "intp", "age", "male", "edu", "drink", "smoke_src"]]


def cov_ensanut_2018():
    base = ENS / "2018_10+"
    bp = rd(base / "ponderadores_hipertension.stata.stata.zip",
            cols=["UPM", "VIV_SEL", "HOGAR", "NUMREN"])
    # 07_ensanut_2018.py took age and sex from the ADULT file, not from the
    # blood-pressure file; the two do not carry identical values, and using the
    # wrong source shifts the adjusted odds ratio.
    adcols = ["UPM", "VIV_SEL", "HOGAR", "NUMREN", "P13_14", "P13_1", "P13_2",
              "EDAD", "SEXO"]
    ad = rd(base / "CS_ADULTOS.stata.stata.zip", cols=adcols, cats=True)
    KEY = ["UPM", "VIV_SEL", "HOGAR", "NUMREN"]
    for df in (bp, ad):
        parts = df[KEY].apply(pd.to_numeric, errors="coerce").astype("Int64")
        df["_k"] = parts.astype(str).agg("|".join, axis=1)
    c = bp.merge(ad, on="_k", how="left", suffixes=("", "_ad"))
    c["age"] = num(c["EDAD"])
    c["male"] = np.where(num(c["SEXO"]) == 1, 1.0, 0.0)
    # CS_ADULTOS carries 561 variables and none of them is education, so this
    # wave genuinely cannot be adjusted for it.  Recorded, not faked.
    c["edu"] = np.nan
    c["drink"] = drink_from_freq(c["P13_14"])
    # 07_ensanut_2018.py's own smoking rule, reapplied here: the frozen
    # differential-sensitivity frame used a narrower rule, which changes the
    # odds ratio even though sensitivity and specificity are unaffected.
    ever = c["P13_1"].astype(str).str.strip().str.lower()
    cur = c["P13_2"].astype(str).str.strip().str.lower()
    smk = pd.Series(np.nan, index=c.index)
    smk[cur.str.contains("d[ií]as", na=False)] = 1.0
    smk[cur.str.contains("no fuma", na=False)] = 0.0
    smk[ever.isin(["no", "nunca he fumado", "nunca"])] = 0.0
    smk[cur.str.contains("no responde", na=False) & ~ever.isin(["no"])] = np.nan
    c["smoke_src"] = smk
    return c[["_k", "age", "male", "edu", "drink", "smoke_src"]]


WAVES = {
    "2021": ("ensaantro21_entrega_w_17_12_2021.stata.stata.zip",
             "ensadul2021_entrega_w_15_12_2021.stata.stata.zip"),
    "2022": ("ensaantro2022_entrega_w.stata.stata.zip",
             "ensadul2022_entrega_w.stata.stata.zip"),
    "2023": ("antropometria_hta_4mar24.stata.stata.zip",
             "adultos_ensanut2023_w_n.stata.stata.zip"),
    "2024": ("antropometria_ensanut2024_w.stata.stata.zip",
             "adultos_ensanut2024_w.stata.stata.zip"),
    "2025": ("antro_2025_w.stata.stata.zip",
             "adultos_2025_w.stata.stata.zip"),
}


def cov_ensanut_wave(wave: str):
    bp_name, ad_name = WAVES[wave]
    # In 2021-2025 the anthropometry file carries ONLY the household keys;
    # age and sex live in the adult questionnaire.  The published models in
    # 08_ensanut_2021_2025.py already took them from the merged frame.
    ad_lab = labels(ENS / wave / ad_name)
    ad_cols = [c for c in ["FOLIO_I", "FOLIO_INT", "edad", "EDAD", "sexo",
                           "SEXO", "ESCOLARI", "escolari", "a1311", "a1303",
                           "a1302", "P13_14", "a1301"]
               if c in ad_lab]
    # cats=True: 08_ensanut_2021_2025.py read the adult file with value labels,
    # and the smoking wording ("no fuma actualmente?" / "todos los días") only
    # exists in the labelled form.  Reading codes instead silently produced an
    # all-missing smoke_src.
    ad = rd(ENS / wave / ad_name, cols=ad_cols, cats=True)
    ad["_k"] = ad["FOLIO_I"].astype(str) + "|" + ad["FOLIO_INT"].astype(str)
    agecol = pick(ad, "edad", "EDAD")
    sexcol = pick(ad, "sexo", "SEXO")
    educol = pick(ad, "escolari", "ESCOLARI")
    ad["age"] = num(ad[agecol]) if agecol else np.nan
    ad["male"] = np.where(num(ad[sexcol]) == 1, 1.0, 0.0) if sexcol else np.nan
    # Recorded as unavailable rather than faked: no wave in 2018-2025 ships an
    # education variable, so those analyses are adjusted for age and sex only.
    ad["edu"] = num(ad[educol]) if educol else np.nan
    dr = pick(ad, "a1311", "P13_14", "a1303", "a1302")
    ad["drink"] = drink_from_freq(ad[dr]) if dr else np.nan
    # 08_ensanut_2021_2025.py's own smoking rule.  It is wider than the one in
    # the differential-sensitivity frame: it also accepts "diario / ocasional /
    # semanal" and codes "nunca" to 0.  Using the narrower rule changes the
    # odds ratio while leaving sensitivity and specificity untouched, which is
    # exactly the failure this column exists to prevent.
    cand = [c for c in ["a1301", "a1303", "a1302"] if c in ad.columns]
    cur = None
    for c in cand:
        txt = ad[c].astype(str).str.strip().str.lower()
        if txt.str.contains("no fuma|d[ií]as", na=False).any():
            cur = txt
            break
    if cur is None and cand:
        cur = ad[cand[0]].astype(str).str.strip().str.lower()
    if cur is not None:
        smk = pd.Series(np.nan, index=ad.index)
        smk[cur.str.contains("d[ií]as|diario|ocasional|semanal", na=False)] = 1.0
        smk[cur.str.contains("no fuma", na=False)] = 0.0
        smk[cur.str.contains("nunca", na=False)] = 0.0
        ad["smoke_src"] = smk
    else:
        ad["smoke_src"] = np.nan
    return ad[["_k", "age", "male", "edu", "drink",
               "smoke_src"]].drop_duplicates("_k")


def cov_nhanes(cyc: str):
    d = Path(NHA) / cyc
    cands = [p for p in d.glob("*.xpt") if p.name.upper().startswith("DEMO")]
    demo = pd.read_sas(cands[0], format="xport")
    cols = [c for c in ["SEQN", "RIAGENDR", "RIDAGEYR", "DMDEDUC2"]
            if c in demo.columns]
    c = demo[cols].copy()
    c["age"] = num(c["RIDAGEYR"])
    c["male"] = (num(c["RIAGENDR"]) == 1).astype(float)
    edu = num(c["DMDEDUC2"]) if "DMDEDUC2" in c.columns else pd.Series(
        np.nan, index=c.index)
    c["edu"] = edu.where(edu <= 5)
    c["drink"] = np.nan
    alq = [p for p in d.glob("*.xpt") if p.name.upper().startswith("ALQ")]
    if alq:
        a = pd.read_sas(alq[0], format="xport")
        fc = pick(a, "ALQ121", "ALQ120Q")
        ec = pick(a, "ALQ111", "ALQ101", "ALQ100")
        keep = [c2 for c2 in ["SEQN", fc, ec] if c2]
        c = c.merge(a[keep], on="SEQN", how="left")
        if fc:
            f = num(c[fc])
            c["drink"] = np.where(f.isna(), np.nan, (f >= 3).astype(float))
            if ec:
                e = num(c[ec])
                c.loc[f.isna() & (e == 2), "drink"] = 0.0
    # 09_nhanes_all_cycles.py restricts to adults; keep the same frame
    c = c[c["age"] >= 20]
    # Physical inactivity, from the 2007+ PAQ module only.  Cycles 1999-2006 use
    # an older instrument (PAD020 / PAQ050Q / PAQ180 ...) whose questions are not
    # comparable, so inactivity is left missing there rather than approximated.
    paq = [p for p in d.glob("*.xpt") if p.name.upper().startswith("PAQ")]
    c["pa_inactive"] = np.nan
    if paq:
        q = pd.read_sas(paq[0], format="xport")
        dom = [x for x in ["PAQ605", "PAQ620", "PAQ650", "PAQ665"]
               if x in q.columns]
        if len(dom) == 4:
            q = q[["SEQN"] + dom].copy()
            for x in dom:
                q[x] = pd.to_numeric(q[x], errors="coerce")
            complete = q[dom].notna().all(axis=1)
            inactive = (q[dom] == 2).all(axis=1)
            q["_pa"] = np.where(complete, inactive.astype(float), np.nan)
            c = c.merge(q[["SEQN", "_pa"]], on="SEQN", how="left")
            c["pa_inactive"] = c["_pa"]
            c = c.drop(columns=["_pa"])
    return c[["SEQN", "age", "male", "edu", "drink", "pa_inactive"]]


def main() -> None:
    m14 = import_module("14_correction")
    m10 = import_module("10_prevalent_china")
    frames = m14.build_all()
    published = pd.read_csv(SCI / "results" / "11_consolidated_results.csv")

    def norm(n: str) -> str:
        return (n.replace("HRS (RAND)", "HRS (6 pairs)")
                .replace("1999-2000", "1999-00").replace("2005-2006", "2005-06")
                .replace("2007-2008", "2007-08").replace("2009-2010", "2009-10")
                .replace("2011-2012", "2011-12").replace("2013-2014", "2013-14")
                .replace("2015-2016", "2015-16").replace("2017-2018", "2017-18"))

    published["_k"] = published["dataset"].map(norm)
    pub_by_key = published.set_index("_k")
    rows, audit = [], []
    for name, country, d, ex in frames:
        d = d.copy()
        if name.startswith("ENSANUT"):
            wave = name.split()[-1]
            cov = cov_ensanut_2012() if wave == "2012" else (
                cov_ensanut_2018() if wave == "2018" else cov_ensanut_wave(wave))
            on = ["folio", "intp"] if wave == "2012" else ["_k"]
            d = d.merge(cov, on=on, how="left")
        elif name.startswith("NHANES"):
            cyc = name.replace("NHANES ", "")
            d = d.merge(cov_nhanes(cyc), on="SEQN", how="left")
        # China prevalent frames already carry age / male / edu
        rows.append(d.assign(dataset=name, country=country))
        # ---- audit against the published ascertainment parameters
        v = d.dropna(subset=["M", "S"]).copy()
        if len(v):
            tp = int(((v["M"] == 1) & (v["S"] == 1)).sum())
            fn = int(((v["M"] == 1) & (v["S"] == 0)).sum())
            fp = int(((v["M"] == 0) & (v["S"] == 1)).sum())
            tn = int(((v["M"] == 0) & (v["S"] == 0)).sum())
            sens = tp / (tp + fn) if tp + fn else np.nan
            spec = tn / (tn + fp) if tn + fp else np.nan
            key = norm(name)
            pub = pub_by_key.loc[[key]] if key in pub_by_key.index else None
            audit.append({
                "dataset": name, "n": len(v), "sens_rebuilt": round(sens, 4),
                "sens_published": float(pub["sens"].iloc[0]) if pub is not None else np.nan,
                "spec_rebuilt": round(spec, 4),
                "spec_published": float(pub["spec"].iloc[0]) if pub is not None else np.nan,
                "age_ok": float(d["age"].notna().mean()) if "age" in d else np.nan,
                "edu_ok": float(d["edu"].notna().mean()) if "edu" in d else np.nan,
                "drink_ok": float(d["drink"].notna().mean()) if "drink" in d else np.nan,
                "n_model": int(d.dropna(subset=["M", "S", "age", "male"]).shape[0]),
            })
    panel = pd.concat([r for r in rows], ignore_index=True)
    audit = pd.DataFrame(audit)
    audit["sens_diff"] = (audit["sens_rebuilt"] - audit["sens_published"]).abs()
    audit["spec_diff"] = (audit["spec_rebuilt"] - audit["spec_published"]).abs()
    keep = [c for c in ["dataset", "country", "design", "id", "_k", "SEQN",
                        "M", "S", "smoke", "smoke_src", "drink",
                        "drink_frequent", "pa_inactive", "age", "male", "edu",
                        "urban", "edu_3cat", "sbp"]
            if c in panel.columns]
    out = panel[keep].copy()
    # China's frames call the same construct drink_frequent; give it one name.
    if "drink_frequent" in out.columns:
        out["drink"] = out["drink"].where(
            out["drink"].notna(), out["drink_frequent"])
        out = out.drop(columns=["drink_frequent"])
    out.to_csv(OUT / "panel_individual.csv", index=False, encoding="utf-8-sig")
    audit.to_csv(OUT / "panel_audit.csv", index=False, encoding="utf-8-sig")
    print("=" * 96)
    print("PANEL AUDIT  (rebuilt vs published ascertainment)")
    print("=" * 96)
    print(audit.round(3).to_string(index=False))
    print()
    print(f"rows={len(panel):,}  datasets={panel['dataset'].nunique()}  "
          f"max sens diff={audit['sens_diff'].max():.4f}  "
          f"max spec diff={audit['spec_diff'].max():.4f}")
    print("wrote", OUT / "panel_individual.csv")


if __name__ == "__main__":
    main()
