# Feasibility probe for the five new cohorts.
#
# The design needs four things in every cohort: measured blood pressure, a
# self-reported doctor diagnosis, a smoking item, and age/sex/education.
# Reading variable names only, so a 300 MB file costs nothing to inspect.

from __future__ import annotations

import re
import sys
import warnings
from pathlib import Path

import pyreadstat

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PATTERNS = {
    "BP_measured": r"bpsys|bpdia|systol|diastol|blood.?pressure|bp_?sys|sbp|dbp|"
                   r"bp[\d_]*$|hypten|tension|presion|presión",
    "HTN_selfreport": r"hibp|hypert|hbp|diagnos|doctor|ever.?told|"
                      r"high.?blood|hta",
    "smoking": r"smok|fuma|tobacc|tobaco|cigare|fumo|흡연",
    "demography": r"^age|agey|rage|ragender|gender|sex|male|female|edu|"
                  r"escolar|education|school",
}


def probe(path: Path, label: str) -> None:
    try:
        _, meta = pyreadstat.read_dta(str(path), metadataonly=True)
    except Exception as e:  # noqa: BLE001
        try:
            _, meta = pyreadstat.read_sav(str(path), metadataonly=True)
        except Exception:  # noqa: BLE001
            print(f"  {label:<34} UNREADABLE ({type(e).__name__})")
            return
    cols = list(meta.column_names)
    labels = dict(zip(meta.column_names, meta.column_labels))
    hits = {}
    for key, pat in PATTERNS.items():
        found = [c for c in cols
                 if re.search(pat, c, re.I)
                 or re.search(pat, str(labels.get(c, "")), re.I)]
        hits[key] = found
    print(f"  {label:<34} vars={len(cols):>4}  "
          f"BP={len(hits['BP_measured']):>3} HTN={len(hits['HTN_selfreport']):>3} "
          f"smoke={len(hits['smoking']):>3} demo={len(hits['demography']):>3}")
    for key in ("BP_measured", "HTN_selfreport", "smoking"):
        if hits[key]:
            print(f"      {key:<14} {hits[key][:8]}")


def main() -> None:
    targets = [
        (ROOT / "ELSA" / "Raw_data" / "h_elsa_g3.dta",
         "ELSA harmonized (h_elsa_g3)"),
        (ROOT / "ELSA" / "Raw_data" / "UKDA-5050-stata" / "stata"
         / "stata13_se" / "wave0" / "wave_0_1998_data.dta", "ELSA wave 0 raw"),
        (ROOT / "KLoSA" / "KLoSA_韩国" / "Raw_data" / "wave1" / "w01_e.dta",
         "KLoSA wave1 (w01_e)"),
        (ROOT / "LASI" / "LASI_印度" / "Temp_data" / "lasi.dta",
         "LASI merged (Temp_data/lasi)"),
        (ROOT / "LASI" / "LASI_印度" / "Raw_data"
         / "LASI Wave 1 (Version B) Data" / "lasi_w1b_ind_bm.dta",
         "LASI w1 ind_bm"),
        (ROOT / "MHAS" / "MHAS_墨西哥" / "Raw_data"
         / "SimpleMHAS （ENASEMsimple）" / "simpleMHAS.dta", "MHAS simple"),
        (ROOT / "SHARE" / "SHARE_欧洲" / "Raw_data" / "easySHARE Release 9.0.0"
         / "easySHARE_rel9-0-0.dta", "SHARE easySHARE 9.0.0"),
    ]
    print("=" * 96)
    print("FEASIBILITY PROBE: measured BP / self-report / smoking / demography")
    print("=" * 96)
    for path, label in targets:
        if not path.exists():
            print(f"  {label:<34} FILE NOT FOUND")
            continue
        print(f"\n  --- {label}")
        probe(path, label)


if __name__ == "__main__":
    main()
