# Second probe: confirm what the promising candidates actually contain.

from __future__ import annotations

import re
import sys
import warnings
from pathlib import Path

import pyreadstat

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parents[2]
sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def show(path: Path, label: str, pattern: str, limit: int = 18) -> None:
    if not path.exists():
        print(f"\n--- {label}: FILE NOT FOUND\n    {path}")
        return
    try:
        _, meta = pyreadstat.read_dta(str(path), metadataonly=True)
    except Exception as e:  # noqa: BLE001
        print(f"\n--- {label}: unreadable ({type(e).__name__})")
        return
    lab = dict(zip(meta.column_names, meta.column_labels))
    hits = [c for c in meta.column_names
            if re.search(pattern, c, re.I)
            or re.search(pattern, str(lab.get(c, "")), re.I)]
    print(f"\n--- {label}  ({len(meta.column_names)} vars, {len(hits)} matched)")
    for c in hits[:limit]:
        print(f"      {c:<14} {str(lab.get(c,''))[:78]}")


def main() -> None:
    show(ROOT / "ELSA" / "Raw_data" / "UKDA-5050-stata" / "stata"
         / "stata13_se" / "h_elsa_g3.dta", "ELSA harmonized h_elsa_g3",
         r"^r\d|^ra|hibp|bpsys|bpdia|smoke")
    show(ROOT / "LASI" / "LASI_印度" / "Temp_data" / "lasi.dta",
         "LASI Temp_data/lasi", r"hibp|systo|diasto|smoke|rxhibp|agey|gender")
    show(ROOT / "KLoSA" / "KLoSA_韩国" / "Raw_data" / "wave1" / "w01_e.dta",
         "KLoSA w01_e", r"^w01C00[1-9]|^w01C01[0-2]|^w01C1[12]\d|^w01age|"
                        r"^w01gender|^w01edu")
    show(ROOT / "MHAS" / "MHAS_墨西哥" / "Raw_data"
         / "SimpleMHAS （ENASEMsimple）" / "simpleMHAS.dta", "MHAS simple",
         r"presion|presión|hiperten|sistol|diastol|tabaco|fuma|edad|sexo")
    show(ROOT / "SHARE" / "SHARE_欧洲" / "Raw_data"
         / "All Waves Coverscreen Release 9.0.0"
         / "sharewX_rel9-0-0_gv_allwaves_cv_r.dta", "SHARE coverscreen",
         r"hibp|bpsys|bpdia|smoke|age|gender")


if __name__ == "__main__":
    main()
