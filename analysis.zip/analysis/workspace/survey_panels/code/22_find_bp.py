# Third probe: locate the measured blood pressure and the self-report item in
# each new cohort, and find the hypertension question in KLoSA.

from __future__ import annotations

import re
import sys
import warnings
from pathlib import Path

import pyreadstat

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parents[2]
sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def scan_file(path: Path, pattern: str, limit: int = 10) -> list[str]:
    try:
        _, meta = pyreadstat.read_dta(str(path), metadataonly=True)
    except Exception:  # noqa: BLE001
        return []
    lab = dict(zip(meta.column_names, meta.column_labels))
    hits = [f"{c} :: {str(lab.get(c,''))[:60]}"
            for c in meta.column_names
            if re.search(pattern, c, re.I)
            or re.search(pattern, str(lab.get(c, "")), re.I)]
    return hits[:limit]


def scan_tree(base: Path, pattern: str, label: str, max_files: int = 260) -> None:
    if not base.exists():
        print(f"\n### {label}: path missing")
        return
    files = sorted(base.rglob("*.dta"))[:max_files]
    print(f"\n### {label}  (scanning {len(files)} .dta files)")
    found = 0
    for f in files:
        hits = scan_file(f, pattern)
        if hits:
            found += 1
            print(f"  {f.relative_to(base)}")
            for h in hits[:5]:
                print(f"      {h}")
    if not found:
        print("      (no match in any scanned file)")


def main() -> None:
    show = lambda p, lab, pat, n=14: print(
        f"\n--- {lab}\n" + "\n".join(
            "      " + h for h in scan_file(p, pat, n)) if scan_file(p, pat, n)
        else f"\n--- {lab}\n      (no match)")
    show(ROOT / "ELSA" / "Raw_data" / "UKDA-5050-stata" / "stata"
         / "stata13_se" / "h_elsa_g3.dta", "ELSA harmonized: core variables",
         r"^r[1-9](bpsys|bpdia|hibp|smoken|smokev)$|^raedyrs$|^r[1-9]agey")
    scan_tree(ROOT / "KLoSA", r"hypertens|high blood|blood pressure|고혈압|"
                             r"systol|diastol", "KLoSA: hypertension & BP")
    scan_tree(ROOT / "MHAS" / "MHAS_墨西哥" / "Raw_data",
              r"presi[oó]n|sist[oó]l|diast[oó]l|hiperten|blood pressure",
              "MHAS: measured BP")
    scan_tree(ROOT / "SHARE" / "SHARE_欧洲" / "Raw_data",
              r"bpsys|bpdia|systol|diastol|blood pressure|hipertensi",
              "SHARE: measured BP")


if __name__ == "__main__":
    main()
