# Run the main design on the new cohorts that HAVE measured blood pressure.
#
# Design is identical to the published one: within one cohort and one wave,
# M = measured BP >= 140/90, S = doctor-diagnosed hypertension, exposure =
# current smoking, covariates = age and sex (education where the file carries
# it), and Delta = lnOR(S) - lnOR(M) plus the exposure-stratified sensitivity
# gap that is supposed to carry it.

from __future__ import annotations

import re
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
RES = Path(__file__).resolve().parents[1] / "results"
RES.mkdir(exist_ok=True)
sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def labels_of(path: Path) -> dict:
    _, meta = pyreadstat.read_dta(str(path), metadataonly=True)
    return dict(zip(meta.column_names, meta.column_labels))


def find(lab: dict, *pats: str) -> str | None:
    for p in pats:
        for c in lab:
            if re.fullmatch(p, c, re.I):
                return c
    for p in pats:
        for c in lab:
            if re.search(p, c, re.I):
                return c
    return None


def fit_logor(d: pd.DataFrame, outcome: str, ex: str, cov: list[str]) -> float:
    m = d[[outcome, ex] + cov].dropna()
    if len(m) < 300 or m[outcome].nunique() < 2 or m[ex].nunique() < 2:
        return np.nan
    X = sm.add_constant(m[[ex] + cov].astype(float))
    f = sm.GLM(m[outcome].astype(float), X,
               family=sm.families.Binomial()).fit()
    return float(f.params[ex])


def analyse(d: pd.DataFrame, label: str, cov: list[str]) -> dict | None:
    v = d.dropna(subset=["M", "S", "smoke"]).copy()
    if len(v) < 500:
        print(f"  {label:<22} paired rows only {len(v)} - skipped")
        return None
    tp = int(((v["M"] == 1) & (v["S"] == 1)).sum())
    fn = int(((v["M"] == 1) & (v["S"] == 0)).sum())
    fp = int(((v["M"] == 0) & (v["S"] == 1)).sum())
    tn = int(((v["M"] == 0) & (v["S"] == 0)).sum())
    sens = tp / (tp + fn) if tp + fn else np.nan
    spec = tn / (tn + fp) if tn + fp else np.nan
    lm = fit_logor(v, "M", "smoke", cov)
    ls = fit_logor(v, "S", "smoke", cov)
    delta = ls - lm
    pos = v[v["M"] == 1]
    g1, g0 = pos[pos["smoke"] == 1], pos[pos["smoke"] == 0]
    gap = (g1["S"].mean() - g0["S"].mean()) if min(len(g1), len(g0)) >= 30 \
        else np.nan
    print(f"  {label:<22} n={len(v):>6}  M+={tp+fn:>5}  sens={sens:.3f}  "
          f"spec={spec:.3f}  OR_M={np.exp(lm):.3f}  OR_S={np.exp(ls):.3f}  "
          f"Δ={delta:+.4f}  gap={gap:+.4f}  cov={cov}")
    return {"cohort": label, "n": len(v), "n_measured_positive": tp + fn,
            "sens": round(sens, 4), "spec": round(spec, 4),
            "or_m": round(float(np.exp(lm)), 3),
            "or_s": round(float(np.exp(ls)), 3),
            "delta": round(float(delta), 4),
            "sens_gap": round(float(gap), 4) if gap == gap else np.nan,
            "covariates": "+".join(cov)}


def lasi() -> list[dict]:
    p = ROOT / "LASI" / "LASI_印度" / "Temp_data" / "lasi.dta"
    lab = labels_of(p)
    cols = [c for c in lab if re.match(r"^(r1|ra)", c, re.I) and
            re.search(r"hibpe|systo|diasto|smoken|smokev|agey|gender|edu|"
                      r"rxhibp", c, re.I)]
    d, _ = pyreadstat.read_dta(str(p), usecols=cols)
    print("  LASI columns used:", cols[:14])
    out = []
    sy = find({"x": 1} | {c: "" for c in d.columns}, r"r1systo\d")
    di = find({"x": 1} | {c: "" for c in d.columns}, r"r1diasto\d")
    sy2 = [c for c in d.columns if re.match(r"r1systo\d", c, re.I)]
    di2 = [c for c in d.columns if re.match(r"r1diasto\d", c, re.I)]
    if not sy2:
        return out
    sbp = d[sy2].apply(pd.to_numeric, errors="coerce").mean(axis=1, skipna=True)
    dbp = d[di2].apply(pd.to_numeric, errors="coerce").mean(axis=1, skipna=True) \
        if di2 else pd.Series(np.nan, index=d.index)
    m = pd.concat([sbp, dbp], axis=1)
    d["M"] = np.where(m.notna().any(axis=1),
                      ((sbp >= 140) | (dbp >= 90)).astype(float), np.nan)
    d["S"] = pd.to_numeric(d.get("r1hibpe"), errors="coerce")
    d["smoke"] = pd.to_numeric(d.get("r1smoken"), errors="coerce")
    d["age"] = pd.to_numeric(d.get("r1agey"), errors="coerce")
    d["male"] = (pd.to_numeric(d.get("ragender"), errors="coerce") == 1
                 ).astype(float)
    # education is present as a harmonised ladder; include it so the covariate
    # set matches the main analysis
    ed = pd.to_numeric(d.get("raeduc_l"), errors="coerce")
    if ed.notna().mean() > 0.5:
        d["edu"] = ed
        cov = ["age", "male", "edu"]
    else:
        cov = ["age", "male"]
    d = d[(d["age"] >= 45) & (d["age"] <= 110)]
    r = analyse(d, "LASI 印度 w1", cov)
    return [r] if r else []


def elsa() -> list[dict]:
    p = ROOT / "ELSA" / "Raw_data" / "UKDA-5050-stata" / "stata" \
        / "stata13_se" / "h_elsa_g3.dta"
    lab = labels_of(p)
    out = []
    for w in ("2", "4"):
        need = [c for c in lab if re.match(
            rf"^(r{w}(systo|diasto|hibpe|rxhibp|smoken|agey|iwstat)\w*|ragender)$",
            c, re.I)]
        if not any(re.match(rf"r{w}systo", c, re.I) for c in need):
            continue
        d, _ = pyreadstat.read_dta(str(p), usecols=need)
        sy = [c for c in d.columns if re.match(rf"r{w}systo\d", c, re.I)]
        di = [c for c in d.columns if re.match(rf"r{w}diasto\d", c, re.I)]
        sbp = d[sy].apply(pd.to_numeric, errors="coerce").mean(axis=1, skipna=True)
        dbp = d[di].apply(pd.to_numeric, errors="coerce").mean(axis=1, skipna=True) \
            if di else pd.Series(np.nan, index=d.index)
        d["M"] = np.where(pd.concat([sbp, dbp], axis=1).notna().any(axis=1),
                          ((sbp >= 140) | (dbp >= 90)).astype(float), np.nan)
        d["S"] = pd.to_numeric(d.get(f"r{w}hibpe"), errors="coerce")
        d["smoke"] = pd.to_numeric(d.get(f"r{w}smoken"), errors="coerce")
        d["age"] = pd.to_numeric(d.get(f"r{w}agey"), errors="coerce")
        d["male"] = (pd.to_numeric(d.get("ragender"), errors="coerce") == 1
                     ).astype(float)
        d = d[(d["age"] >= 50) & (d["age"] <= 110)]
        r = analyse(d, f"ELSA 英国 w{w}", ["age", "male"])
        if r:
            out.append(r)
    return out


def main() -> None:
    print("=" * 108)
    print("NEW COHORTS - same design as the published analysis")
    print("=" * 108)
    rows = []
    for fn in (lasi, elsa):
        try:
            rows += fn()
        except Exception as e:  # noqa: BLE001
            print(f"  {fn.__name__} FAILED: {type(e).__name__}: {e}")
        print()
    if rows:
        t = pd.DataFrame(rows)
        t.to_csv(RES / "new_cohorts.csv", index=False, encoding="utf-8-sig")
        print(t.to_string(index=False))
        print("\n  Δ 为负:", int((t["delta"] < 0).sum()), "/", len(t))
        print("  敏感度差距为负:", int((t["sens_gap"] < 0).sum()), "/", len(t))
        print("wrote", RES / "new_cohorts.csv")


if __name__ == "__main__":
    main()
