# Locate the diabetes-side variables and the MHAS wave-3 blood pressure.

from __future__ import annotations

import re
import sys
import warnings
from pathlib import Path

import pyreadstat

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parents[2]
sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def show(path: Path, label: str, pat: str, limit: int = 22) -> None:
    if not path.exists():
        print(f"\n--- {label}: FILE NOT FOUND")
        return
    _, meta = pyreadstat.read_dta(str(path), metadataonly=True)
    lab = dict(zip(meta.column_names, meta.column_labels))
    hits = [c for c in meta.column_names
            if re.search(pat, c, re.I)
            or re.search(pat, str(lab.get(c, "")), re.I)]
    print(f"\n--- {label}  ({len(meta.column_names)} vars, {len(hits)} hits)")
    for c in hits[:limit]:
        print(f"      {c:<16} {str(lab.get(c,''))[:72]}")


def main() -> None:
    B = ROOT / "LASI" / "LASI_印度" / "Raw_data" / "LASI Wave 1 (Version B) Data"
    show(ROOT / "LASI" / "LASI_印度" / "Temp_data" / "lasi.dta",
         "LASI harmonized (Temp_data)", r"diab|a1c|glucose|glu\b|hba|fasting")
    show(B / "lasi_w1b_ind_bm.dta", "LASI w1 ind_bm",
         r"diab|hba1c|glucose|fasting|blood sugar")
    M = ROOT / "MHAS" / "MHAS_墨西哥" / "Raw_data"
    show(M / "wave3" / "Biomarkers and Anthropometric Measures"
         / "sect_l_biomarkers_2012.dta", "MHAS w3 biomarkers",
         r"sist|dias|presion|presión|gluc|hba|a1c|chol|trig")
    show(M / "wave4" / "Cognitive Aging Ancillary Study (Mex-Cog)"
         / "Anthropometrics_and_Biomarkers_Mex_Cog_2016.dta",
         "MHAS Mex-Cog 2016 anthropometrics", r"sist|dias|presion|gluc|hba")
    show(M / "wave3" / "Core survey Data"
         / "sect_a_c_d_e_pc_f_h_i_em_2012.dta", "MHAS w3 core",
         r"^c4_12$|^c5_12$|diab|presion|fuma|tabaco")


if __name__ == "__main__":
    main()
