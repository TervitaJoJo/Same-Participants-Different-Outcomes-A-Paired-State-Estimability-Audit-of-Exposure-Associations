# Task 4: MHAS wave 3 (2012) as a sixth country-wave.
#
# Measured blood pressure sits in the biomarkers module and the diagnostic
# questions in the core module, so the two have to be joined first.  The join
# key is detected rather than assumed.

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
RES = Path(__file__).resolve().parents[1] / "results"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

M = ROOT / "MHAS" / "MHAS_墨西哥" / "Raw_data"
BM = M / "wave3" / "Biomarkers and Anthropometric Measures" / "sect_l_biomarkers_2012.dta"
CORE = M / "wave3" / "Core survey Data" / "sect_a_c_d_e_pc_f_h_i_em_2012.dta"


def cols_of(p: Path) -> list[str]:
    _, meta = pyreadstat.read_dta(str(p), metadataonly=True)
    return list(meta.column_names)


def main() -> None:
    cb, cc = cols_of(BM), cols_of(CORE)
    # MHAS identifies a person by household (cunicah) plus person number (np);
    # joining on the household alone fans out into a many-to-many merge.
    keys = [c for c in ["cunicah", "np"] if c in cb and c in cc]
    print("MHAS wave 3: join key =", keys)
    if len(keys) < 2:
        print("person-level join key not found")
        return
    b = pyreadstat.read_dta(str(BM), usecols=[
        c for c in ["sist1_12", "sist2_12", "dias1_12", "dias2_12",
                    "hdlc_12", "chol_12"] + keys if c in cb])[0]
    want = [c for c in ["c4_12", "c5_12", "c6_12", "c10_12", "c54_12",
                        "age_12", "sex_12"] + keys if c in cc]
    c = pyreadstat.read_dta(str(CORE), usecols=want)[0]
    print("MHAS core columns used:", [w for w in want if w not in keys][:8])
    d = b.merge(c, on=keys, how="inner")
    print(f"merged rows: {len(d):,}")
    for col in ("sist1_12", "sist2_12", "dias1_12", "dias2_12"):
        s = pd.to_numeric(d[col], errors="coerce")
        d[col] = s.where((s > 40) & (s < 300))
    sbp = d[["sist1_12", "sist2_12"]].mean(axis=1, skipna=True)
    dbp = d[["dias1_12", "dias2_12"]].mean(axis=1, skipna=True)
    d["M"] = np.where(pd.concat([sbp, dbp], axis=1).notna().any(axis=1),
                      ((sbp >= 140) | (dbp >= 90)).astype(float), np.nan)
    c4 = pd.to_numeric(d["c4_12"], errors="coerce")
    d["S"] = np.where(c4 == 1, 1.0, np.where(c4 == 2, 0.0, np.nan))
    d["S2"] = d["S"]
    med = pd.to_numeric(d.get("c5_12"), errors="coerce") if "c5_12" in d else None
    if med is not None:
        d["S2"] = np.where((c4 == 1) | (med == 1), 1.0,
                           np.where(c4 == 2, 0.0, np.nan))
    smoke_col = next((x for x in ["c54_12"] if x in d.columns), None)
    if smoke_col:
        v = pd.to_numeric(d[smoke_col], errors="coerce")
        d["smoke"] = np.where(v == 1, 1.0, np.where(v.isin([0, 2]), 0.0, np.nan))
    else:
        d["smoke"] = np.nan
    d["age"] = pd.to_numeric(d.get("age_12"), errors="coerce") \
        if "age_12" in d else np.nan
    d["male"] = (pd.to_numeric(d.get("sex_12"), errors="coerce") == 1
                 ).astype(float) if "sex_12" in d else np.nan
    d = d.dropna(subset=["M", "S", "smoke", "age", "male"])
    d = d[(d["age"] >= 50) & (d["age"] <= 110)]
    print(f"analysis rows: {len(d):,}   measured+ = {int(d['M'].sum()):,}   "
          f"self-report+ = {int(d['S'].sum()):,}")
    if len(d) < 300:
        print("too few rows - stopping")
        return
    tp = int(((d.M == 1) & (d.S == 1)).sum())
    fn = int(((d.M == 1) & (d.S == 0)).sum())
    fp = int(((d.M == 0) & (d.S == 1)).sum())
    tn = int(((d.M == 0) & (d.S == 0)).sum())
    sens = tp / (tp + fn) if tp + fn else np.nan
    spec = tn / (tn + fp) if tn + fp else np.nan
    cov = ["age", "male"]
    est = {}
    for oc in ("M", "S"):
        m = d[[oc, "smoke"] + cov].dropna()
        X = sm.add_constant(m[["smoke"] + cov].astype(float))
        f = sm.GLM(m[oc].astype(float), X, family=sm.families.Binomial()).fit()
        est[oc] = float(f.params["smoke"])
    delta = est["S"] - est["M"]
    pos = d[d.M == 1]
    g1, g0 = pos[pos.smoke == 1], pos[pos.smoke == 0]
    gap = g1.S.mean() - g0.S.mean()
    print(f"\n  MHAS 墨西哥 w3(2012)  n={len(d):,}  sens={sens:.3f}  "
          f"spec={spec:.3f}  OR_M={np.exp(est['M']):.3f}  "
          f"OR_S={np.exp(est['S']):.3f}  Δ={delta:+.4f}  粗差距={gap:+.4f}")
    pd.DataFrame([{"cohort": "MHAS 墨西哥 w3", "n": len(d),
                   "sens": round(sens, 4), "spec": round(spec, 4),
                   "or_m": round(float(np.exp(est["M"])), 3),
                   "or_s": round(float(np.exp(est["S"])), 3),
                   "delta": round(delta, 4),
                   "crude_gap": round(float(gap), 4)}]).to_csv(
        RES / "mhas_w3.csv", index=False, encoding="utf-8-sig")
    print("wrote", RES / "mhas_w3.csv")


if __name__ == "__main__":
    main()
