# HAALSI (South Africa, Agincourt) as a sixth system.
#
# The baseline release ships the mean of three blood-pressure readings
# (c_bs_mean_sys / c_bs_mean_dia), so the measured outcome needs no averaging
# here; the self-report item is cm002 and current smoking is cm061.

from __future__ import annotations

import re
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
RES = Path(__file__).resolve().parents[1] / "results"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE = ROOT / "HAALSI" / "HAALSI Baseline Survey" / "HAALSI_baseline_dataverse_14Apr2017.dta"
LONG = ROOT / "HAALSI" / "Wave3" / "HAALSI W1-3 Longitudinal Dataset.dta"
LAB = ROOT / "HAALSI" / "HAALSI Baseline Laboratory Data" / "HAALSI_Laboratory_Baseline_V3.dta"


def meta_of(p: Path):
    _, m = pyreadstat.read_dta(str(p), metadataonly=True)
    return m


def find_age_sex() -> None:
    m = meta_of(BASE)
    lab = dict(zip(m.column_names, m.column_labels))
    print("baseline: age-like variables")
    for c in m.column_names:
        l = str(lab.get(c, ""))
        if re.search(r"\bage\b|age in|years", l, re.I) and not re.search(
                r"contact|spouse|spouse|mother|father|child", l, re.I):
            print(f"   {c:<16} {l[:70]}")
    print("baseline: sex-like variables")
    for c in m.column_names:
        l = str(lab.get(c, ""))
        if re.search(r"\bsex\b|gender", l, re.I) and not re.search(
                r"contact", l, re.I):
            print(f"   {c:<16} {l[:70]}")
    ml = meta_of(LAB)
    print("lab file: key / age / sex")
    for c in ml.column_names[:6]:
        print(f"   {c:<16} {str(dict(zip(ml.column_names, ml.column_labels)).get(c,''))[:60]}")


def main() -> None:
    find_age_sex()
    need = ["prim_key", "c_bs_mean_sys", "c_bs_mean_dia", "cm002", "cm005",
            "cm061", "cm059", "bd002", "rsex", "bd036", "c_bd_educ4"]
    m = meta_of(BASE)
    have = [c for c in need if c in m.column_names]
    d = pyreadstat.read_dta(str(BASE), usecols=have)[0]
    print("\nloaded baseline columns:", have)
    # Age and sex live in the baseline itself (bd002, rsex).  The laboratory
    # file also carries them, but only for the ~half of the sample that gave
    # blood, so merging from there silently halves the analysis set.
    sbp = pd.to_numeric(d.get("c_bs_mean_sys"), errors="coerce")
    dbp = pd.to_numeric(d.get("c_bs_mean_dia"), errors="coerce")
    d["M"] = np.where(pd.concat([sbp, dbp], axis=1).notna().any(axis=1),
                      ((sbp >= 140) | (dbp >= 90)).astype(float), np.nan)
    c2 = pd.to_numeric(d.get("cm002"), errors="coerce")
    # HAALSI codes these items 1 = yes / 2 = no, not 1/0
    d["S"] = np.where(c2 == 1, 1.0, np.where(c2 == 2, 0.0, np.nan))
    c61 = pd.to_numeric(d.get("cm061"), errors="coerce")
    # cm061 is asked only of ever-smokers, so never-smokers must be set to 0
    # from cm059 rather than left missing.
    c59 = pd.to_numeric(d.get("cm059"), errors="coerce")
    smk = pd.Series(np.nan, index=d.index)
    smk[c61 == 1] = 1.0
    smk[(c61 == 2) | (c59 == 2)] = 0.0
    d["smoke"] = smk
    d["age"] = pd.to_numeric(d.get("bd002"), errors="coerce")
    g = pd.to_numeric(d.get("rsex"), errors="coerce")
    d["male"] = np.where(g.notna(), (g == 1).astype(float), np.nan)
    d["edu"] = pd.to_numeric(d.get("c_bd_educ4"), errors="coerce")
    print("non-missing: M", int(d["M"].notna().sum()), "S", int(d["S"].notna().sum()),
          "smoke", int(d["smoke"].notna().sum()), "age", int(d["age"].notna().sum()),
          "male", int(d["male"].notna().sum()))
    for cov in (["age", "male"], ["age", "male", "edu"]):
        v = d.dropna(subset=["M", "S", "smoke"] + cov)
        if len(v) < 300 or v["M"].sum() < 80:
            print(f"  cov={cov}: too few ({len(v)})")
            continue
        logs = {}
        for oc in ("M", "S"):
            mm = v[[oc, "smoke"] + cov].dropna()
            X = sm.add_constant(mm[["smoke"] + cov].astype(float))
            f = sm.GLM(mm[oc].astype(float), X,
                       family=sm.families.Binomial()).fit()
            logs[oc] = float(f.params["smoke"])
        tp = int(((v.M == 1) & (v.S == 1)).sum())
        fn = int(((v.M == 1) & (v.S == 0)).sum())
        fp = int(((v.M == 0) & (v.S == 1)).sum())
        tn = int(((v.M == 0) & (v.S == 0)).sum())
        print(f"\n  HAALSI 南非 baseline  n={len(v):,}  M+={tp+fn:,}  "
              f"sens={tp/(tp+fn):.3f}  spec={tn/(tn+fp):.3f}  "
              f"OR_M={np.exp(logs['M']):.3f}  OR_S={np.exp(logs['S']):.3f}  "
              f"Δ={logs['S']-logs['M']:+.4f}   cov={cov}")
        if cov == ["age", "male"]:
            pd.DataFrame([{"cohort": "HAALSI 南非", "n": len(v),
                           "sens": round(tp / (tp + fn), 4),
                           "spec": round(tn / (tn + fp), 4),
                           "or_m": round(float(np.exp(logs["M"])), 3),
                           "or_s": round(float(np.exp(logs["S"])), 3),
                           "delta": round(logs["S"] - logs["M"], 4),
                           "covariates": "+".join(cov)}]).to_csv(
                RES / "haalsi.csv", index=False, encoding="utf-8-sig")
            print("  wrote", RES / "haalsi.csv")


if __name__ == "__main__":
    main()
