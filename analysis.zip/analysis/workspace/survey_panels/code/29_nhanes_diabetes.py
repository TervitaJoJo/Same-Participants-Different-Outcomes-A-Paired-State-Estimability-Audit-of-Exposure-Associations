# The multi-disease matrix, extended to the United States.
#
# CHARLS was the only cohort carrying a glucose-side biomarker.  NHANES does
# too, and its files are free: DIQ010 gives the self-report item, LBXGH the
# glycohaemoglobin, LBXGLU the fasting glucose with fasting duration alongside.
#
# The design is identical to the CHARLS three-disease analysis: same exposure,
# same covariates, only the outcome changes.

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
RES = Path(__file__).resolve().parents[1] / "results"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

CYCLES = ["1999-2000", "2005-2006", "2007-2008", "2009-2010", "2011-2012",
          "2013-2014", "2015-2016", "2017-2018"]


def load(cyc: str, pfx: str):
    d = ROOT / "NHANES" / cyc
    c = [p for p in d.glob("*.xpt") if p.name.upper().startswith(pfx)]
    return pd.read_sas(c[0], format="xport") if c else None


def logor(d: pd.DataFrame, y: str, x: str, cov: list[str]) -> float:
    m = d[[y, x] + cov].dropna()
    if len(m) < 200 or m[y].nunique() < 2 or m[x].nunique() < 2:
        return np.nan
    X = sm.add_constant(m[[x] + cov].astype(float))
    f = sm.GLM(m[y].astype(float), X, family=sm.families.Binomial()).fit()
    return float(f.params[x])


def main() -> None:
    panel = pd.read_csv(RES / "panel_individual.csv", low_memory=False)
    nh = panel[panel["dataset"].str.startswith("NHANES")].copy()
    cov = ["age", "male", "edu"]
    rows = []
    print("=" * 104)
    print("NHANES: measured vs self-reported DIABETES, same exposure and covariates")
    print("=" * 104)
    for cyc in CYCLES:
        ds = f"NHANES {cyc}"
        g = nh[nh["dataset"] == ds]
        if g.empty:
            continue
        diq = load(cyc, "DIQ")
        ghb = load(cyc, "GHB")
        if ghb is None:
            ghb = load(cyc, "LAB10")          # 1999-2000 legacy naming
        glu = load(cyc, "GLU")
        if glu is None:
            glu = load(cyc, "LAB10AM")
        if diq is None or ghb is None:
            print(f"  {cyc:<11} missing DIQ or GHB")
            continue
        d = g[["SEQN", "M", "S", "smoke"] + cov].copy()
        diq = diq[[c for c in ["SEQN", "DIQ010"] if c in diq.columns]]
        d = d.merge(diq, on="SEQN", how="left")
        gh = ghb[[c for c in ["SEQN", "LBXGH"] if c in ghb.columns]]
        d = d.merge(gh, on="SEQN", how="left")
        lgu = None
        if glu is not None and "LBXGLU" in glu.columns:
            keep = [c for c in ["SEQN", "LBXGLU", "PHAFSTHR"] if c in glu.columns]
            lgu = glu[keep]
        if lgu is not None:
            d = d.merge(lgu, on="SEQN", how="left")
        for col in ("LBXGLU", "PHAFSTHR"):
            if col not in d.columns:
                d[col] = np.nan
        # self-reported diabetes: 1 = yes, 2 = no, 3 = borderline (counted as no),
        # 7/9 = refused / don't know (missing)
        c10 = pd.to_numeric(d["DIQ010"], errors="coerce")
        d["S_dm"] = np.where(c10 == 1, 1.0,
                             np.where(c10.isin([2, 3]), 0.0, np.nan))
        hba = pd.to_numeric(d["LBXGH"], errors="coerce")
        gl = pd.to_numeric(d["LBXGLU"], errors="coerce")
        fast = pd.to_numeric(d["PHAFSTHR"], errors="coerce")
        gl_ok = gl.where(fast >= 8)          # fasting glucose only if >= 8 h fasted
        d["M_dm"] = np.where(hba.notna() | gl_ok.notna(),
                             ((hba >= 6.5) | (gl_ok >= 126)).astype(float), np.nan)
        for out, lab in (("M", "高血压（实测）"), ("M_dm", "糖尿病（实测）")):
            v = d.dropna(subset=[out, "S_dm" if out == "M_dm" else "S", "smoke"] + cov)
            y = out
            sc = "S_dm" if out == "M_dm" else "S"
            v = d.dropna(subset=[y, sc, "smoke"] + cov)
            if len(v) < 300 or v[y].sum() < 80:
                continue
            delta = logor(v, sc, "smoke", cov) - logor(v, y, "smoke", cov)
            tp = int(((v[y] == 1) & (v[sc] == 1)).sum())
            fn = int(((v[y] == 1) & (v[sc] == 0)).sum())
            fp = int(((v[y] == 0) & (v[sc] == 1)).sum())
            tn = int(((v[y] == 0) & (v[sc] == 0)).sum())
            pos = v[v[y] == 1]
            g1, g0 = pos[pos.smoke == 1], pos[pos.smoke == 0]
            rows.append({
                "cycle": cyc, "disease": lab, "n": len(v),
                "n_measured_positive": tp + fn,
                "sens": round(tp / (tp + fn), 4) if tp + fn else np.nan,
                "spec": round(tn / (tn + fp), 4) if tn + fp else np.nan,
                "prev_measured": round(float(v[y].mean()), 4),
                "prev_selfreport": round(float(v[sc].mean()), 4),
                "or_m": round(float(np.exp(logor(v, y, "smoke", cov))), 3),
                "or_s": round(float(np.exp(logor(v, sc, "smoke", cov))), 3),
                "delta": round(delta, 4),
                "sens_gap": round(float(g1[sc].mean() - g0[sc].mean()), 4)
                if min(len(g1), len(g0)) >= 30 else np.nan})
    t = pd.DataFrame(rows)
    t.to_csv(RES / "nhanes_diabetes.csv", index=False, encoding="utf-8-sig")
    print(t.to_string(index=False))
    if len(t):
        g = t.groupby("disease").agg(
            k=("cycle", "size"), sens=("sens", "mean"), spec=("spec", "mean"),
            delta=("delta", "mean"), sens_gap=("sens_gap", "mean"))
        print()
        print(g.round(4).to_string())
        dm = t[t["disease"].str.contains("糖尿病")]
        if len(dm):
            print(f"\n  糖尿病：Δ 为负 {int((dm['delta'] < 0).sum())}/{len(dm)}，"
                  f"敏感度差距为负 {int((dm['sens_gap'] < 0).sum())}/{len(dm)}")
    print("\nwrote", RES / "nhanes_diabetes.csv")


if __name__ == "__main__":
    main()
