# Third disease for NHANES: dyslipidaemia.
#
# Measured: total cholesterol >= 240 mg/dL or LDL >= 160 mg/dL (the same
# thresholds used for CHARLS, converted to the units NHANES reports).
# Self-reported: the blood-pressure-and-cholesterol module.

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
RES = Path(__file__).resolve().parents[1] / "results"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

CYCLES = ["1999-2000", "2005-2006", "2007-2008", "2009-2010", "2011-2012",
          "2013-2014", "2015-2016", "2017-2018"]


def load(cyc: str, pfx: str):
    d = ROOT / "NHANES" / cyc
    c = [p for p in d.glob("*.xpt") if p.name.upper().startswith(pfx)]
    return pd.read_sas(c[0], format="xport") if c else None


def logor(d, y, x, cov):
    m = d[[y, x] + cov].dropna()
    if len(m) < 200 or m[y].nunique() < 2 or m[x].nunique() < 2:
        return np.nan
    X = sm.add_constant(m[[x] + cov].astype(float))
    return float(sm.GLM(m[y].astype(float), X,
                        family=sm.families.Binomial()).fit().params[x])


def main() -> None:
    panel = pd.read_csv(RES / "panel_individual.csv", low_memory=False)
    nh = panel[panel["dataset"].str.startswith("NHANES")].copy()
    cov = ["age", "male", "edu"]
    rows = []
    print("=" * 104)
    print("NHANES: measured vs self-reported DYSLIPIDAEMIA")
    print("=" * 104)
    for cyc in CYCLES:
        g = nh[nh["dataset"] == f"NHANES {cyc}"]
        if g.empty:
            continue
        tc, hdl, tr = load(cyc, "TCHOL"), load(cyc, "HDL"), load(cyc, "TRIGLY")
        bpq = load(cyc, "BPQ")
        if tc is None or tr is None or bpq is None:
            print(f"  {cyc:<11} missing TCHOL / TRIGLY / BPQ")
            continue
        d = g[["SEQN", "M", "S", "smoke"] + cov].copy()
        d = d.merge(tc[[c for c in ["SEQN", "LBXTC"] if c in tc.columns]],
                    on="SEQN", how="left")
        if hdl is not None and "LBDHDD" in hdl.columns:
            d = d.merge(hdl[["SEQN", "LBDHDD"]], on="SEQN", how="left")
        else:
            d["LBDHDD"] = np.nan
        keep = [c for c in ["SEQN", "LBXTR", "LBDLDL"] if c in tr.columns]
        d = d.merge(tr[keep], on="SEQN", how="left")
        # BPQ080 is "doctor told you your blood cholesterol was high"; BPQ090D and
        # BPQ100D are the *medication* questions, asked only of those already
        # diagnosed, so taking them first shrinks the sample to the treated.
        src = next((c for c in ["BPQ080", "BPQ090D", "BPQ100D"]
                    if c in bpq.columns), None)
        if src is None:
            print(f"  {cyc:<11} no cholesterol self-report variable")
            continue
        d = d.merge(bpq[["SEQN", src]], on="SEQN", how="left")
        c = pd.to_numeric(d[src], errors="coerce")
        d["S_lip"] = np.where(c == 1, 1.0, np.where(c.isin([2, 3]), 0.0, np.nan))
        tcv = pd.to_numeric(d["LBXTC"], errors="coerce")
        ldlv = pd.to_numeric(d.get("LBDLDL"), errors="coerce")
        d["M_lip"] = np.where(tcv.notna() | ldlv.notna(),
                              ((tcv >= 240) | (ldlv >= 160)).astype(float), np.nan)
        v = d.dropna(subset=["M_lip", "S_lip", "smoke"] + cov)
        if len(v) < 300 or v["M_lip"].sum() < 80:
            print(f"  {cyc:<11} too few ({len(v)}, positives {int(v['M_lip'].sum())})")
            continue
        delta = logor(v, "S_lip", "smoke", cov) - logor(v, "M_lip", "smoke", cov)
        tp = int(((v.M_lip == 1) & (v.S_lip == 1)).sum())
        fn = int(((v.M_lip == 1) & (v.S_lip == 0)).sum())
        fp = int(((v.M_lip == 0) & (v.S_lip == 1)).sum())
        tn = int(((v.M_lip == 0) & (v.S_lip == 0)).sum())
        pos = v[v.M_lip == 1]
        g1, g0 = pos[pos.smoke == 1], pos[pos.smoke == 0]
        rows.append({"cycle": cyc, "sr_var": src, "n": len(v),
                     "n_pos": tp + fn,
                     "sens": round(tp / (tp + fn), 4) if tp + fn else np.nan,
                     "spec": round(tn / (tn + fp), 4) if tn + fp else np.nan,
                     "prev_measured": round(float(v.M_lip.mean()), 4),
                     "prev_selfreport": round(float(v.S_lip.mean()), 4),
                     "or_m": round(float(np.exp(logor(v, "M_lip", "smoke", cov))), 3),
                     "or_s": round(float(np.exp(logor(v, "S_lip", "smoke", cov))), 3),
                     "delta": round(delta, 4),
                     "sens_gap": round(float(g1.S_lip.mean() - g0.S_lip.mean()), 4)
                     if min(len(g1), len(g0)) >= 30 else np.nan})
    t = pd.DataFrame(rows)
    t.to_csv(RES / "nhanes_dyslipidemia.csv", index=False, encoding="utf-8-sig")
    print(t.to_string(index=False))
    if len(t):
        print(f"\n  均值：敏感度 {t['sens'].mean():.3f}  特异度 {t['spec'].mean():.3f}  "
              f"Δ {t['delta'].mean():+.4f}  敏感度差距 {t['sens_gap'].mean():+.4f}")
        print(f"  Δ 为负 {int((t['delta']<0).sum())}/{len(t)}；"
              f"敏感度差距为负 {int((t['sens_gap']<0).sum())}/{len(t)}")
    print("\nwrote", RES / "nhanes_dyslipidemia.csv")


if __name__ == "__main__":
    main()
