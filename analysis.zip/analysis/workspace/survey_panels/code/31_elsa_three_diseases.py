# ELSA: three diseases (hypertension, diabetes, dyslipidaemia) across five
# nurse-visit waves (2, 4, 6, 8, 9), mirroring the CHARLS and NHANES designs.
#
# Self-report comes from the harmonised file (r{w}hibpe / r{w}diabe / r{w}hchole).
# Measured values come from the raw nurse-visit files, joined on idauniq.
#
# Three data traps had to be repaired; the first run of this script was wrong
# because of #1 and #2:
#
#   1. HbA1c is reported in DCCT % in waves 2 and 4 but in IFCC mmol/mol in
#      waves 6, 8 and 9.  The wave-8 variable label still reads "(%)", which is
#      a labelling error in the release; its values (median 38, max 131) are
#      plainly mmol/mol.  The unit is therefore detected from the data rather
#      than trusted to the label.
#   2. Every laboratory variable uses negative sentinel codes for missing
#      samples (-1 not received, -2 insufficient blood, -6 more than five days
#      to reach the lab, -11 sample not taken, ...).  Without a "> 0" filter
#      those codes are read as extremely low concentrations and silently turn
#      into "normal" negatives, which corrupts sensitivity and specificity.
#   3. Wave 9 has no harmonised measured BP, so the nurse-file derived means
#      (sysval / diaval) are used for that one wave.
#
# Definitions match CHARLS and NHANES so the three countries stay comparable:
#   diabetes      HbA1c >= 6.5 % or fasting glucose >= 7.0 mmol/L
#   dyslipidaemia total cholesterol >= 6.2 mmol/L or LDL >= 4.1 mmol/L
#   hypertension  systolic >= 140 mmHg or diastolic >= 90 mmHg

from __future__ import annotations

import re
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
RES = Path(__file__).resolve().parents[1] / "results"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ELSA = ROOT / "ELSA" / "Raw_data"
HARM = ELSA / "UKDA-5050-stata" / "stata" / "stata13_se" / "h_elsa_g3.dta"

# wave -> (nurse file, optional wave filter inside that file)
W8W9 = ELSA / "elsa_nurse_w8w9_data_eul.dta"
NURSE = {
    "2": (ELSA / "wave2" / "wave_2_nurse_data_v2.dta", None),
    "4": (ELSA / "wave4" / "wave_4_nurse_data.dta", None),
    "6": (ELSA / "wave6" / "wave_6_elsa_nurse_data_v2.dta", None),
    "8": (W8W9, 8),
    "9": (W8W9, 9),
}
# Covariates match CHARLS and NHANES (age, sex, education).  ELSA's harmonised
# education variable is raedyrs_e: despite the name it is an ordered 0-6
# education category, not a count of years.
COV = ["age", "male", "edu"]

# upper plausibility bounds (mmol/L, or the raw HbA1c scale before conversion)
LAB_HI = {"chol": 30.0, "hdl": 10.0, "ldl": 25.0, "trig": 60.0,
          "fglu": 40.0, "hba1c": 200.0, "bp": 400.0}


def binary(s, yes=(1,), no=(0, 2)):
    v = pd.to_numeric(s, errors="coerce")
    return np.where(v.isin(yes), 1.0, np.where(v.isin(no), 0.0, np.nan))


def lab(s, name: str) -> pd.Series:
    """Numeric lab value with the release's negative sentinel codes and
    implausible values set to NaN."""
    v = pd.to_numeric(s, errors="coerce")
    return v.where((v > 0) & (v < LAB_HI[name]))


def hba1c_pct(raw) -> tuple[pd.Series, str]:
    """Return HbA1c on the DCCT % scale plus the unit that was detected."""
    v = lab(raw, "hba1c")
    med = float(v.median()) if v.notna().any() else np.nan
    if np.isfinite(med) and med > 20:          # IFCC mmol/mol
        return v / 10.929 + 2.15, "mmol/mol"
    return v, "%"


def logor(d: pd.DataFrame, y: str, x: str, cov) -> float:
    m = d[[y, x] + cov].dropna()
    if len(m) < 150 or m[y].nunique() < 2 or m[x].nunique() < 2:
        return np.nan
    X = sm.add_constant(m[[x] + cov].astype(float))
    return float(sm.GLM(m[y].astype(float), X,
                        family=sm.families.Binomial()).fit().params[x])


def run(d: pd.DataFrame, label: str, measured: str, selfrep: str,
        disease: str) -> dict | None:
    v = d.dropna(subset=[measured, selfrep, "smoke"] + COV).copy()
    if len(v) < 300 or v[measured].sum() < 60:
        return None
    delta = logor(v, selfrep, "smoke", COV) - logor(v, measured, "smoke", COV)
    tp = int(((v[measured] == 1) & (v[selfrep] == 1)).sum())
    fn = int(((v[measured] == 1) & (v[selfrep] == 0)).sum())
    fp = int(((v[measured] == 0) & (v[selfrep] == 1)).sum())
    tn = int(((v[measured] == 0) & (v[selfrep] == 0)).sum())
    pos = v[v[measured] == 1]
    g1, g0 = pos[pos.smoke == 1], pos[pos.smoke == 0]
    return {"cohort": label, "disease": disease, "n": len(v),
            "n_pos": tp + fn,
            "sens": round(tp / (tp + fn), 4) if tp + fn else np.nan,
            "spec": round(tn / (tn + fp), 4) if tn + fp else np.nan,
            "prev_m": round(float(v[measured].mean()), 4),
            "prev_s": round(float(v[selfrep].mean()), 4),
            "or_m": round(float(np.exp(logor(v, measured, "smoke", COV))), 3),
            "or_s": round(float(np.exp(logor(v, selfrep, "smoke", COV))), 3),
            "delta": round(delta, 4),
            "sens_gap": round(float(g1[selfrep].mean() - g0[selfrep].mean()), 4)
            if min(len(g1), len(g0)) >= 25 else np.nan}


DISEASES = {"高血压": ("M_htn", "S_htn"),
            "糖尿病": ("M_dm", "S_dm"),
            "血脂异常": ("M_lip", "S_lip")}


def wave_frame(w: str, np_path: Path, wfilter) -> pd.DataFrame:
    """Individual-level frame for one nurse-visit wave, with measured and
    self-reported outcomes for all three diseases plus the shared covariates."""
    _, mh = pyreadstat.read_dta(str(HARM), metadataonly=True)
    want = [c for c in mh.column_names if c in
            ["idauniq", "ragender", "raedyrs_e"]
            or c in [f"r{w}{s}" for s in
                     ("hibpe", "diabe", "hchole", "smoken", "agey")]
            or re.match(rf"^r{w}(systo|diasto)\d$", c)]
    h = pyreadstat.read_dta(str(HARM), usecols=want)[0]
    _, mn = pyreadstat.read_dta(str(np_path), metadataonly=True)
    keep = [c for c in ["idauniq", "chol", "hdl", "ldl", "trig", "hba1c",
                        "fglu", "sysval", "diaval", "wave"]
            if c in mn.column_names]
    n = pyreadstat.read_dta(str(np_path), usecols=keep)[0]
    if wfilter is not None and "wave" in n.columns:
        n = n[pd.to_numeric(n["wave"], errors="coerce") == wfilter]
    d = h.merge(n, on="idauniq", how="inner")
    print(f"\n=== ELSA wave {w}: {np_path.name} -> merged {len(d):,} rows "
          f"(nurse vars: {[c for c in keep if c != 'idauniq']})")
    d["pid"] = d["idauniq"]
    d["age"] = pd.to_numeric(d.get(f"r{w}agey"), errors="coerce")
    d["male"] = (pd.to_numeric(d.get("ragender"),
                               errors="coerce") == 1).astype(float)
    d["edu"] = pd.to_numeric(d.get("raedyrs_e"), errors="coerce")
    d["smoke"] = binary(d.get(f"r{w}smoken"))
    d = d[(d["age"] >= 50) & (d["age"] <= 110)]

    # ---- hypertension
    d["S_htn"] = binary(d.get(f"r{w}hibpe"))
    sy = [c for c in d.columns if re.match(rf"r{w}systo\d", c)]
    di = [c for c in d.columns if re.match(rf"r{w}diasto\d", c)]
    if sy and di:
        sbp = d[sy].apply(pd.to_numeric, errors="coerce").mean(axis=1, skipna=True)
        dbp = d[di].apply(pd.to_numeric, errors="coerce").mean(axis=1, skipna=True)
        src = "harmonised readings"
    elif "sysval" in d.columns and "diaval" in d.columns:
        sbp = lab(d["sysval"], "bp")
        dbp = lab(d["diaval"], "bp")
        src = "nurse-derived sysval/diaval"
    else:
        sbp = dbp = None
        src = "none"
    if sbp is not None:
        d["M_htn"] = np.where(pd.concat([sbp, dbp], axis=1).notna().any(axis=1),
                              ((sbp >= 140) | (dbp >= 90)).astype(float), np.nan)
        print(f"    BP source: {src}; measured N = "
              f"{int(d['M_htn'].notna().sum()):,}")
    else:
        d["M_htn"] = np.nan
        print(f"    wave {w}: no measured BP available - hypertension skipped")

    # ---- diabetes
    hb, unit = hba1c_pct(d.get("hba1c"))
    fg = lab(d.get("fglu"), "fglu")
    print(f"    HbA1c unit detected: {unit}; usable HbA1c = "
          f"{int(hb.notna().sum()):,}, fasting glucose = {int(fg.notna().sum()):,}, "
          f"median HbA1c% = {hb.median():.2f}")
    d["M_dm"] = np.where(hb.notna() | fg.notna(),
                         ((hb >= 6.5) | (fg >= 7.0)).astype(float), np.nan)
    d["S_dm"] = binary(d.get(f"r{w}diabe"))

    # ---- dyslipidaemia
    tc = lab(d.get("chol"), "chol")
    ld = lab(d.get("ldl"), "ldl")
    d["M_lip"] = np.where(tc.notna() | ld.notna(),
                          ((tc >= 6.2) | (ld >= 4.1)).astype(float), np.nan)
    d["S_lip"] = binary(d.get(f"r{w}hchole"))
    return d


def main() -> None:
    rows = []
    for w, (np_path, wfilter) in NURSE.items():
        if not np_path.exists():
            print(f"  wave {w}: nurse file missing ({np_path.name})")
            continue
        d = wave_frame(w, np_path, wfilter)
        for disease, (measured, selfrep) in DISEASES.items():
            r = run(d, f"ELSA w{w}", measured, selfrep, disease)
            if r:
                rows.append(r)

    t = pd.DataFrame([r for r in rows if r])
    t.to_csv(RES / "elsa_three_diseases.csv", index=False, encoding="utf-8-sig")
    print()
    print(t.to_string(index=False))
    if len(t):
        print()
        print(t.groupby("disease").agg(k=("cohort", "size"), sens=("sens", "mean"),
                                       spec=("spec", "mean"),
                                       delta=("delta", "mean")).round(4).to_string())
    print("\nwrote", RES / "elsa_three_diseases.csv")


if __name__ == "__main__":
    main()
