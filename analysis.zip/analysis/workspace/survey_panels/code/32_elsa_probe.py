# Diagnostic probe for ELSA nurse files: units, missing codes, sample sizes.

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[2]
ELSA = ROOT / "ELSA" / "Raw_data"

FILES = {
    "w2": ELSA / "wave2" / "wave_2_nurse_data_v2.dta",
    "w4": ELSA / "wave4" / "wave_4_nurse_data.dta",
    "w6": ELSA / "wave6" / "wave_6_elsa_nurse_data_v2.dta",
    "w8old": ELSA / "wave8" / "wave_8_elsa_nurse_data_eul_v1.dta",
    "w8w9": ELSA / "elsa_nurse_w8w9_data_eul.dta",
}
LABS = ["chol", "hdl", "ldl", "trig", "hba1c", "fglu", "sysval", "diaval"]


def summarise(tag: str, p: Path) -> None:
    df, meta = pyreadstat.read_dta(str(p))
    print(f"\n=== {tag}  {p.name}  rows={len(df):,} cols={len(df.columns)}")
    if "wave" in df.columns:
        print("  wave values:", df["wave"].value_counts(dropna=False).to_dict())
        print("  wave labels:", meta.variable_value_labels.get("wave"))
        groups = list(df.groupby("wave"))
    else:
        groups = [("all", df)]
    for wv, g in groups:
        print(f"  --- wave={wv} n={len(g):,}")
        for c in LABS:
            if c not in g.columns:
                continue
            s = pd.to_numeric(g[c], errors="coerce")
            pos = s[s > 0]
            med = round(float(pos.median()), 2) if len(pos) else float("nan")
            p99 = round(float(pos.quantile(0.99)), 2) if len(pos) else float("nan")
            print(f"     {c:7s} nonmiss={s.notna().sum():6d} pos={len(pos):6d}"
                  f" min={s.min():8.1f} med_pos={med:8.2f} p99_pos={p99:8.2f}"
                  f" max={s.max():8.1f}")
        if "hba1c" in g.columns:
            print(f"     hba1c labels: {meta.variable_value_labels.get('hba1c')}")


def main() -> None:
    for tag, p in FILES.items():
        if p.exists():
            summarise(tag, p)
        else:
            print(f"\n=== {tag}: missing {p}")

    harm = ELSA / "UKDA-5050-stata" / "stata" / "stata13_se" / "h_elsa_g3.dta"
    _, mh = pyreadstat.read_dta(str(harm), metadataonly=True)
    names = set(mh.column_names)
    print("\n=== harmonised self-report by wave")
    for w in range(1, 10):
        cols = [f"r{w}{s}" for s in ("hibpe", "diabe", "hchole", "smoken")]
        cols = [c for c in cols if c in names]
        if not cols:
            continue
        df = pyreadstat.read_dta(str(harm), usecols=[c for c in cols + [f"r{w}agey"]
                                                    if c in names])[0]
        age = pd.to_numeric(df[f"r{w}agey"], errors="coerce")
        df = df[(age >= 50) & (age <= 110)]
        print(f"  wave {w}: n={len(df):,}")
        for c in cols:
            vc = df[c].value_counts(dropna=False).to_dict()
            yes = (pd.to_numeric(df[c], errors="coerce") == 1).mean()
            print(f"     {c:10s} yes={yes:6.3%}  values={vc}")


if __name__ == "__main__":
    main()
