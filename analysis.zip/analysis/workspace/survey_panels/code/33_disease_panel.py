# Build one individual-level, long-format panel for the multi-disease matrix.
#
# Until now the three diseases lived in three separate result tables, each with
# its own sample.  Anything that needs the diseases side by side - pooled
# models, bootstrap intervals, the paired forest plot - needs them in one frame
# with a common set of columns, so this script rebuilds all three countries with
# identical outcome definitions and identical covariates (age, sex, education).
#
#   hypertension   measured SBP >= 140 or DBP >= 90
#   diabetes       measured HbA1c >= 6.5 % or fasting glucose >= 7.0 mmol/L
#                  (>= 126 mg/dL in NHANES, where glucose is mg/dL)
#   dyslipidaemia  measured total cholesterol >= 6.2 mmol/L or LDL >= 4.1 mmol/L
#                  (>= 240 / >= 160 mg/dL in NHANES)
#
# Output: results/panel_diseases.csv
#   dataset, country, wave, pid, disease, M, S, smoke, age, male, edu

from __future__ import annotations

import sys
import warnings
from importlib import import_module
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
RES = Path(__file__).resolve().parents[1] / "results"
SCI = ROOT / "survey_sources"
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(SCI / "code"))
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

NHANES_CYCLES = ["1999-2000", "2005-2006", "2007-2008", "2009-2010",
                 "2011-2012", "2013-2014", "2015-2016", "2017-2018"]

DISEASES = {"hypertension": ("M", "S"),
            "diabetes": ("M_dm", "S_dm"),
            "dyslipidaemia": ("M_lip", "S_lip")}


def nhanes_load(cyc: str, prefixes: tuple[str, ...]):
    """First matching NHANES file for this cycle.  The 1999-2000 release uses
    legacy names (LAB10 = glycated haemoglobin, LAB10AM = fasting glucose,
    LAB13 / LAB13AM = the lipid files)."""
    d = ROOT / "NHANES" / cyc
    for pfx in prefixes:
        c = [p for p in d.glob("*.xpt") if p.name.upper().startswith(pfx)]
        if c:
            return pd.read_sas(c[0], format="xport")
    return None


def nhanes_frame(cyc: str, base: pd.DataFrame) -> pd.DataFrame:
    """Individual frame for one NHANES cycle with all three outcome pairs."""
    d = base[["SEQN", "M", "S", "smoke", "age", "male", "edu"]].copy()
    for col in ("M_dm", "S_dm", "M_lip", "S_lip"):
        d[col] = np.nan

    # ---- diabetes -------------------------------------------------------
    diq = nhanes_load(cyc, ("DIQ",))
    ghb = nhanes_load(cyc, ("GHB", "LAB10"))
    glu = nhanes_load(cyc, ("GLU", "LAB10AM"))
    if diq is not None:
        c = pd.to_numeric(diq.get("DIQ010"), errors="coerce")
        # 1 = yes, 2 = no, 3 = borderline (counted as no), 7/9 = missing
        dm_s = pd.DataFrame({"SEQN": diq["SEQN"],
                             "S_dm": np.where(c == 1, 1.0,
                                              np.where(c.isin([2, 3]), 0.0, np.nan))})
        d = d.merge(dm_s, on="SEQN", how="left", suffixes=("", "_new"))
        d["S_dm"] = np.where(d["S_dm_new"].notna(), d["S_dm_new"], d["S_dm"])
        d = d.drop(columns=["S_dm_new"])
    if ghb is not None:
        hba = pd.DataFrame({"SEQN": ghb["SEQN"],
                            "LBXGH": pd.to_numeric(ghb["LBXGH"], errors="coerce")})
        d = d.merge(hba, on="SEQN", how="left")
    else:
        d["LBXGH"] = np.nan
    if glu is not None and "LBXGLU" in glu.columns:
        keep = [c for c in ["SEQN", "LBXGLU", "PHAFSTHR"] if c in glu.columns]
        gl = glu[keep].copy()
        if "PHAFSTHR" not in gl.columns:
            gl["PHAFSTHR"] = np.nan
        d = d.merge(gl, on="SEQN", how="left")
    else:
        d["LBXGLU"] = np.nan
        d["PHAFSTHR"] = np.nan
    gl_ok = d["LBXGLU"].where(d["PHAFSTHR"] >= 8)      # fasting glucose only
    d["M_dm"] = np.where(d["LBXGH"].notna() | gl_ok.notna(),
                         ((d["LBXGH"] >= 6.5) | (gl_ok >= 126)).astype(float), np.nan)

    # ---- dyslipidaemia --------------------------------------------------
    tc = nhanes_load(cyc, ("TCHOL", "LAB13"))
    tr = nhanes_load(cyc, ("TRIGLY", "LAB13AM"))
    tc_var = next((c for c in ("LBXTC", "LBDTCSI") if tc is not None and c in tc.columns),
                  None)
    if tc_var is not None:
        d = d.merge(pd.DataFrame({"SEQN": tc["SEQN"],
                                  "LBXTC": pd.to_numeric(tc[tc_var], errors="coerce")}),
                    on="SEQN", how="left")
    else:
        d["LBXTC"] = np.nan
    ldl_var = next((c for c in ("LBDLDL",) if tr is not None and c in tr.columns), None)
    if ldl_var is not None:
        d = d.merge(pd.DataFrame({"SEQN": tr["SEQN"],
                                  "LBDLDL": pd.to_numeric(tr[ldl_var], errors="coerce")}),
                    on="SEQN", how="left")
    else:
        d["LBDLDL"] = np.nan
    bpq = nhanes_load(cyc, ("BPQ",))
    src = None
    if bpq is not None:
        # BPQ080 is the diagnostic question asked of everyone; BPQ090D and
        # BPQ100D are medication questions asked only of those already
        # diagnosed, so taking them first shrinks the sample to the treated.
        src = next((c for c in ("BPQ080", "BPQ090D", "BPQ100D")
                    if c in bpq.columns), None)
    if src is not None:
        c = pd.to_numeric(bpq[src], errors="coerce")
        lip_s = pd.DataFrame({"SEQN": bpq["SEQN"],
                              "S_lip": np.where(c == 1, 1.0,
                                                np.where(c.isin([2, 3]), 0.0, np.nan))})
        d = d.merge(lip_s, on="SEQN", how="left", suffixes=("", "_new"))
        d["S_lip"] = np.where(d["S_lip_new"].notna(), d["S_lip_new"], d["S_lip"])
        d = d.drop(columns=["S_lip_new"])
    d["M_lip"] = np.where(d["LBXTC"].notna() | d["LBDLDL"].notna(),
                          ((d["LBXTC"] >= 240) | (d["LBDLDL"] >= 160)).astype(float),
                          np.nan)
    d["_lipid_src"] = src
    return d


def charls_frame() -> pd.DataFrame:
    m10 = import_module("10_prevalent_china")
    d = m10.charls_cross()
    h = pd.read_stata(ROOT / "CHARLS" / "2011" / "health_status_and_functioning.dta",
                      columns=["ID", "da007_2_", "da007_3_"],
                      convert_categoricals=False)
    h["ID"] = pd.to_numeric(h["ID"], errors="coerce").astype("Int64")
    d["ID"] = pd.to_numeric(d["ID"], errors="coerce").astype("Int64")
    d = d.merge(h.rename(columns={"da007_2_": "S_lip", "da007_3_": "S_dm"}),
                on="ID", how="left")
    for c in ("S_lip", "S_dm"):
        v = pd.to_numeric(d[c], errors="coerce")
        d[c] = np.where(v == 1, 1.0, np.where(v == 2, 0.0, np.nan))
    glu = pd.to_numeric(d["glu"], errors="coerce")
    hba = pd.to_numeric(d["hba1c"], errors="coerce")
    cho = pd.to_numeric(d["cho"], errors="coerce")
    ldl = pd.to_numeric(d["ldl"], errors="coerce")
    d["M_dm"] = np.where(glu.notna() | hba.notna(),
                         ((glu >= 126) | (hba >= 6.5)).astype(float), np.nan)
    d["M_lip"] = np.where(cho.notna() | ldl.notna(),
                          ((cho >= 240) | (ldl >= 160)).astype(float), np.nan)
    d["pid"] = d["ID"]
    d["wave"] = "2011"
    d["smoke"] = pd.to_numeric(d["smoke_current"], errors="coerce")
    return d


def elsa_frames() -> list[pd.DataFrame]:
    m31 = import_module("31_elsa_three_diseases")
    out = []
    for w, (p, wf) in m31.NURSE.items():
        if p.exists():
            d = m31.wave_frame(w, p, wf)
            d["wave"] = w
            # wave_frame names the hypertension pair M_htn / S_htn because it
            # carries all three diseases at once; the shared emitter expects the
            # hypertension pair to be called M / S.
            d = d.rename(columns={"M_htn": "M", "S_htn": "S"})
            out.append(d)
    return out


def emit(rows: list, dataset: str, country: str, wave: str, d: pd.DataFrame
         ) -> None:
    for disease, (mcol, scol) in DISEASES.items():
        if mcol not in d.columns or scol not in d.columns:
            continue
        v = d.dropna(subset=[mcol, scol, "smoke", "age", "male", "edu"])
        if len(v) < 300:
            print(f"  {dataset:<16} {disease:<15} skipped (n={len(v)})")
            continue
        for r in v.itertuples():
            rows.append({"dataset": dataset, "country": country, "wave": wave,
                         "pid": getattr(r, "pid", np.nan), "disease": disease,
                         "M": float(getattr(r, mcol)),
                         "S": float(getattr(r, scol)),
                         "smoke": float(r.smoke), "age": float(r.age),
                         "male": float(r.male), "edu": float(r.edu)})
        print(f"  {dataset:<16} {disease:<15} n={len(v):>6}  "
              f"prev_measured={v[mcol].mean():.3f}  prev_self={v[scol].mean():.3f}")


def main() -> None:
    rows: list = []
    panel = pd.read_csv(RES / "panel_individual.csv", low_memory=False)
    nh = panel[panel["dataset"].str.startswith("NHANES")].copy()
    print("NHANES")
    for cyc in NHANES_CYCLES:
        g = nh[nh["dataset"] == f"NHANES {cyc}"]
        if g.empty:
            continue
        d = nhanes_frame(cyc, g)
        d["pid"] = d["SEQN"]
        emit(rows, f"NHANES {cyc}", "United States", cyc, d)

    print("\nCHARLS")
    d = charls_frame()
    emit(rows, "CHARLS 2011", "China", "2011", d)

    print("\nELSA")
    for d in elsa_frames():
        emit(rows, f"ELSA w{d['wave'].iloc[0]}", "England", str(d["wave"].iloc[0]), d)

    t = pd.DataFrame(rows)
    t.to_csv(RES / "panel_diseases.csv", index=False, encoding="utf-8-sig")
    print()
    print(t.groupby(["dataset", "disease"]).size().to_string())
    print(f"\nrows {len(t):,}  datasets {t['dataset'].nunique()}  "
          f"cells {t.groupby(['dataset', 'disease']).ngroups}")
    print("wrote", RES / "panel_diseases.csv")


if __name__ == "__main__":
    main()
