# Risk probe: is the behavioural-burden "reversal" real, and is it about
# outcome ascertainment?
#
# The existing evidence compared CFPS (self-report) with CHARLS/CHNS (measured),
# which confounds ascertainment with cohort. This probe does the comparison
# WITHIN one cohort, where the same people contribute both outcome definitions:
#
#   M = measured only   (follow-up BP >= 140/90)
#   S = self-report only(follow-up physician diagnosis or antihypertensive use)
#   C = composite       (M or S)
#
# Exposures: current smoking, frequent drinking, physical inactivity, and the
# 0-3 behavioural count. Adjusted for age, sex, urban, education, baseline SBP.
#
# Output: 01_charls_incident_report.txt, 07_reversal_probe_estimates.csv

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parents[1] / "results"
ROOT = HERE.parents[1]          # workspace root (data live there)
POOL = ROOT / "code_for_submit" / "HARMONIZED" / "processed" / "harmonized_pool_measured.csv"

LINES: list[str] = []
ROWS: list[dict] = []


def say(msg: str = "") -> None:
    print(msg)
    LINES.append(str(msg))


def head(t: str) -> None:
    say()
    say("=" * 78)
    say(t)
    say("=" * 78)


# --------------------------------------------------------------------------
def charls_selfreport() -> pd.DataFrame:
    """Self-reported hypertension at the CHARLS 2015 follow-up.

    IMPORTANT  the 2015 wave restructured the disease list.  da007_1_ is asked
    only of the ~528 refresh respondents.  Continuing respondents answer
    da007_w2_1_1_ (verify the previous record) and da007_w2_2_1_ (doctor told
    you since the last interview).  Incident self-report is therefore
    da007_w2_2_1_ == 1, not da007_1_.
    """
    f = ROOT / "CHARLS" / "2015" / "Health_Status_and_Functioning.dta"
    r = pd.read_stata(f, iterator=True)
    avail = set(r.variable_labels())
    want = [c for c in ["ID", "da007_1_", "da007_w2_1_1_", "da007_w2_2_1_",
                        "da011s1", "da011s2"] if c in avail]
    d = pd.read_stata(f, columns=want, convert_categoricals=False)
    d["id"] = pd.to_numeric(d["ID"], errors="coerce").astype("Int64")
    d["ht_dx_new"] = d["da007_w2_2_1_"].eq(1).astype(float)
    d["ht_dx_old"] = d["da007_w2_1_1_"].eq(1).astype(float)
    d["ht_dx_any"] = d["da007_1_"].eq(1).astype(float)
    if "da011s1" in d and "da011s2" in d:
        d["ht_med"] = (d["da011s1"].eq(1) | d["da011s2"].eq(2)).astype(float)
    else:
        d["ht_med"] = np.nan
    # primary self-report: newly doctor-diagnosed since the previous interview
    d["sr"] = (d["ht_dx_new"] == 1).astype(int)
    # secondary: diagnosis or antihypertensive medication
    d["sr_med"] = ((d["ht_dx_new"] == 1) | (d["ht_med"] == 1)).astype(int)
    return d[["id", "ht_dx_new", "ht_dx_old", "ht_dx_any", "ht_med", "sr", "sr_med"]]


def build() -> pd.DataFrame:
    head("DATA  CHARLS locked analysis set")
    pool = pd.read_csv(POOL)
    c = pool[pool["study"] == "CHARLS"].copy()
    say(f"  locked CHARLS rows: {len(c):,}")
    sr = charls_selfreport()
    say(f"  CHARLS 2015 self-report records: {len(sr):,}")
    say(f"    new doctor diagnosis (da007_w2_2_1_) : {int(sr['ht_dx_new'].sum()):,}")
    say(f"    previous-record agree (da007_w2_1_1_): {int(sr['ht_dx_old'].sum()):,}")
    say(f"    legacy da007_1_ (refresh only)       : {int(sr['ht_dx_any'].sum()):,}")
    say(f"    antihypertensive medication          : {int(sr['ht_med'].sum()):,}")
    d = c.merge(sr, left_on="id", right_on="id", how="left")
    d["M"] = pd.to_numeric(d["event_meas_only"], errors="coerce")
    d["C"] = pd.to_numeric(d["event"], errors="coerce")
    d["S"] = d["sr"]
    d["S2"] = d["sr_med"]
    say(f"  merged: {len(d):,}   with self-report available: {int(d['S'].notna().sum()):,}")
    return d


def cross_tab(d: pd.DataFrame) -> None:
    head("ASCERTAINMENT  how do the two definitions disagree?")
    m = d[["M", "S"]].dropna()
    say(f"  n with both definitions: {len(m):,}")
    tab = pd.crosstab(m["M"], m["S"], rownames=["measured M"], colnames=["self-report S"])
    say(tab.to_string())
    tp = int(((m["M"] == 1) & (m["S"] == 1)).sum())
    fn = int(((m["M"] == 1) & (m["S"] == 0)).sum())
    fp = int(((m["M"] == 0) & (m["S"] == 1)).sum())
    tn = int(((m["M"] == 0) & (m["S"] == 0)).sum())
    sens = tp / (tp + fn) if tp + fn else float("nan")
    spec = tn / (tn + fp) if tn + fp else float("nan")
    say()
    say(f"  self-report sensitivity vs measured : {sens:.3f}")
    say(f"  self-report specificity vs measured : {spec:.3f}")
    say(f"  measured-positive but not reported   : {fn:,}  ({100*fn/(tp+fn):.1f}% of measured cases)")
    say(f"  reported but measured-negative       : {fp:,}  ({100*fp/(tn+fp):.1f}% of measured non-cases)")
    ROWS.append({"block": "ascertainment", "metric": "sensitivity",
                 "value": round(float(sens), 4)})
    ROWS.append({"block": "ascertainment", "metric": "specificity",
                 "value": round(float(spec), 4)})


def models(d: pd.DataFrame) -> None:
    head("PROBE  same people, same exposure, different outcome definition")
    cov = ["age", "male", "urban", "edu_3cat", "sbp"]
    d = d.copy()
    d["behavioral3"] = d[["smoke_current", "drink_frequent", "pa_inactive"]].sum(
        axis=1, min_count=3)
    exposures = [("smoke_current", "current smoking"),
                 ("drink_frequent", "frequent drinking"),
                 ("pa_inactive", "physical inactivity"),
                 ("behavioral3", "behavioural count 0-3")]
    outcomes = [("M", "M  measured only"), ("S", "S  new diagnosis"),
                ("S2", "S2 diagnosis or med"), ("C", "C  composite")]

    say(f"  {'exposure':<26s}{'outcome':<22s}{'n':>7s}{'events':>8s}{'OR':>8s}   95% CI")
    for ex, exlab in exposures:
        for oc, oclab in outcomes:
            need = [oc, ex] + cov
            m = d[need].dropna()
            if len(m) < 200:
                continue
            y = m[oc].astype(float).values
            X = sm.add_constant(m[[ex] + cov].astype(float))
            try:
                fit = sm.GLM(y, X, family=sm.families.Binomial()).fit()
            except Exception as e:  # noqa: BLE001
                say(f"  {exlab:<26s}{oclab:<22s} FAILED {e}")
                continue
            b, se = fit.params[ex], fit.bse[ex]
            lo, hi = np.exp(b - 1.96 * se), np.exp(b + 1.96 * se)
            say(f"  {exlab:<26s}{oclab:<22s}{len(m):>7,}{int(y.sum()):>8,}"
                f"{np.exp(b):>8.3f}   {lo:.3f}-{hi:.3f}")
            ROWS.append({"block": "model", "exposure": ex, "outcome": oc,
                         "n": len(m), "events": int(y.sum()),
                         "OR": round(float(np.exp(b)), 4),
                         "lo": round(float(lo), 4), "hi": round(float(hi), 4)})
        say()


def main() -> None:
    d = build()
    cross_tab(d)
    models(d)
    head("READING")
    say("  M vs S within the same people isolates ascertainment from cohort.")
    say("  A reversal is a sign flip between the M row and the S row for the")
    say("  same exposure, not a difference between countries.")
    pd.DataFrame(ROWS).to_csv(HERE / "07_reversal_probe_estimates.csv",
                              index=False, encoding="utf-8-sig")
    (HERE / "01_charls_incident_report.txt").write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nwrote {HERE / '01_charls_incident_report.txt'}")


if __name__ == "__main__":
    sys.exit(main())
