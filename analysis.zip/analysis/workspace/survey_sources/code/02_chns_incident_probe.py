# CHNS replication of the ascertainment probe.
#
# Same design as the CHARLS probe: within one cohort, the same people, the same
# exposures, four outcome definitions:
#   M  measured only   (follow-up mean BP >= 140/90)
#   S  self-report only(new physician diagnosis; CHNS U22 == 1 at 2011)
#   S2 diagnosis or antihypertensive medication (U22 or U24)
#   C  composite (M or S2)
#
# The question is whether the smoking-specific shift seen in CHARLS reappears.

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parents[1] / "results"
ROOT = HERE.parents[1]          # workspace root (data live there)
POOL = ROOT / "code_for_submit" / "HARMONIZED" / "processed" / "harmonized_pool_measured.csv"
PEXAM = ROOT / "CHNS" / "Individual-Level_Data" / "pexam_00.sas7bdat"

LINES: list[str] = []
ROWS: list[dict] = []


def say(msg: str = "") -> None:
    print(msg)
    LINES.append(str(msg))


def head(t: str) -> None:
    say()
    say("=" * 78)
    say(t)
    say("=" * 78)


def chns_selfreport() -> pd.DataFrame:
    import pyreadstat

    d, _ = pyreadstat.read_sas7bdat(
        str(PEXAM), usecols=["IDind", "WAVE", "U22", "U24"])
    d["IDind"] = d["IDind"].astype("int64")
    for c in ["U22", "U24"]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    f = d[d["WAVE"] == 2011].copy()
    f["sr"] = (f["U22"] == 1).astype(int)
    f["sr_med"] = ((f["U22"] == 1) | (f["U24"] == 1)).astype(int)
    f["id"] = f["IDind"].astype(str)
    return f[["id", "U22", "U24", "sr", "sr_med"]]


def main() -> None:
    head("DATA  CHNS locked analysis set (2009 -> 2011)")
    pool = pd.read_csv(POOL)
    c = pool[pool["study"] == "CHNS"].copy()
    say(f"  locked CHNS rows: {len(c):,}")
    sr = chns_selfreport()
    say(f"  CHNS 2011 exam records: {len(sr):,}"
        f"   diagnosis U22==1: {int(sr['sr'].sum()):,}"
        f"   medication U24==1: {int((sr['U24'] == 1).sum()):,}")
    c["id"] = c["id"].astype(str)
    sr["id"] = sr["id"].astype(str)
    d = c.merge(sr, on="id", how="left")
    d["M"] = pd.to_numeric(d["event_meas_only"], errors="coerce")
    d["C"] = pd.to_numeric(d["event"], errors="coerce")
    d["S"] = d["sr"]
    d["S2"] = d["sr_med"]
    say(f"  merged: {len(d):,}   self-report available: {int(d['S'].notna().sum()):,}")

    head("ASCERTAINMENT  measured vs self-report, same people")
    m = d[["M", "S"]].dropna()
    say(f"  n with both definitions: {len(m):,}")
    say(pd.crosstab(m["M"], m["S"], rownames=["measured M"],
                    colnames=["self-report S"]).to_string())
    tp = int(((m["M"] == 1) & (m["S"] == 1)).sum())
    fn = int(((m["M"] == 1) & (m["S"] == 0)).sum())
    fp = int(((m["M"] == 0) & (m["S"] == 1)).sum())
    tn = int(((m["M"] == 0) & (m["S"] == 0)).sum())
    sens = tp / (tp + fn) if tp + fn else float("nan")
    spec = tn / (tn + fp) if tn + fp else float("nan")
    say()
    say(f"  self-report sensitivity vs measured : {sens:.3f}")
    say(f"  self-report specificity vs measured : {spec:.3f}")
    ROWS.append({"block": "ascertainment", "cohort": "CHNS",
                 "metric": "sensitivity", "value": round(float(sens), 4)})
    ROWS.append({"block": "ascertainment", "cohort": "CHNS",
                 "metric": "specificity", "value": round(float(spec), 4)})

    head("PROBE  CHNS, same people, four outcome definitions")
    cov = ["age", "male", "urban", "edu_3cat", "sbp"]
    d = d.copy()
    d["behavioral3"] = d[["smoke_current", "drink_frequent", "pa_inactive"]].sum(
        axis=1, min_count=3)
    exposures = [("smoke_current", "current smoking"),
                 ("drink_frequent", "frequent drinking"),
                 ("pa_inactive", "physical inactivity"),
                 ("behavioral3", "behavioural count 0-3")]
    outcomes = [("M", "M  measured only"), ("S", "S  self-report only"),
                ("S2", "S2 diagnosis or med"), ("C", "C  composite")]
    say(f"  {'exposure':<24s}{'outcome':<22s}{'n':>7s}{'events':>8s}{'OR':>8s}   95% CI")
    for ex, exlab in exposures:
        for oc, oclab in outcomes:
            need = [oc, ex] + cov
            mm = d[need].dropna()
            if len(mm) < 150:
                say(f"  {exlab:<24s}{oclab:<22s}{len(mm):>7,}   too few / no data")
                continue
            y = mm[oc].astype(float).values
            X = sm.add_constant(mm[[ex] + cov].astype(float))
            try:
                fit = sm.GLM(y, X, family=sm.families.Binomial()).fit()
            except Exception as e:  # noqa: BLE001
                say(f"  {exlab:<24s}{oclab:<22s} FAILED {e}")
                continue
            b, se = fit.params[ex], fit.bse[ex]
            lo, hi = np.exp(b - 1.96 * se), np.exp(b + 1.96 * se)
            say(f"  {exlab:<24s}{oclab:<22s}{len(mm):>7,}{int(y.sum()):>8,}"
                f"{np.exp(b):>8.3f}   {lo:.3f}-{hi:.3f}")
            ROWS.append({"block": "model", "cohort": "CHNS", "exposure": ex,
                         "outcome": oc, "n": len(mm), "events": int(y.sum()),
                         "OR": round(float(np.exp(b)), 4),
                         "lo": round(float(lo), 4), "hi": round(float(hi), 4)})
        say()

    pd.DataFrame(ROWS).to_csv(HERE / "09_chns_probe_estimates.csv",
                              index=False, encoding="utf-8-sig")
    (HERE / "02_chns_incident_report.txt").write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nwrote {HERE / '02_chns_incident_report.txt'}")


if __name__ == "__main__":
    sys.exit(main())
