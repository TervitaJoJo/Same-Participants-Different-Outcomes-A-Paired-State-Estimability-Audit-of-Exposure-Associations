# Is the measured-vs-self-report difference in the smoking OR statistically
# real? Bootstrap the difference in log-OR, resampling individuals so the
# correlation between the two outcome definitions is preserved.
#
# Run for the smoking exposure in both Chinese cohorts, plus the two control
# exposures (drinking, inactivity) that should NOT move if the effect is
# specific to healthcare-contact-correlated exposures.

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat
import statsmodels.api as sm

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parents[1] / "results"
ROOT = HERE.parents[1]          # workspace root (data live there)
POOL = ROOT / "code_for_submit" / "HARMONIZED" / "processed" / "harmonized_pool_measured.csv"
RNG = np.random.default_rng(20260913)

LINES: list[str] = []
ROWS: list[dict] = []


def say(msg: str = "") -> None:
    print(msg)
    LINES.append(str(msg))


def head(t: str) -> None:
    say()
    say("=" * 78)
    say(t)
    say("=" * 78)


def charls_frame() -> pd.DataFrame:
    f = ROOT / "CHARLS" / "2015" / "Health_Status_and_Functioning.dta"
    d = pd.read_stata(f, columns=["ID", "da007_w2_2_1_", "da011s1", "da011s2"],
                      convert_categoricals=False)
    d["id"] = pd.to_numeric(d["ID"], errors="coerce").astype("Int64")
    d["S"] = (d["da007_w2_2_1_"] == 1).astype(float)
    d["S2"] = ((d["da007_w2_2_1_"] == 1) | (d["da011s1"] == 1)
               | (d["da011s2"] == 2)).astype(float)
    pool = pd.read_csv(POOL)
    c = pool[pool["study"] == "CHARLS"].copy()
    c["id"] = pd.to_numeric(c["id"], errors="coerce").astype("Int64")
    d = c.merge(d[["id", "S", "S2"]], on="id", how="left")
    d["M"] = pd.to_numeric(d["event_meas_only"], errors="coerce")
    d["C"] = pd.to_numeric(d["event"], errors="coerce")
    return d


def chns_frame() -> pd.DataFrame:
    d, _ = pyreadstat.read_sas7bdat(str(ROOT / "CHNS" / "Individual-Level_Data"
                                        / "pexam_00.sas7bdat"),
                                    usecols=["IDind", "WAVE", "U22", "U24"])
    d["IDind"] = d["IDind"].astype("int64")
    for c in ["U22", "U24"]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    f = d[d["WAVE"] == 2011].copy()
    f["id"] = f["IDind"].astype(str)
    f["S"] = (f["U22"] == 1).astype(float)
    f["S2"] = ((f["U22"] == 1) | (f["U24"] == 1)).astype(float)
    pool = pd.read_csv(POOL)
    c = pool[pool["study"] == "CHNS"].copy()
    c["id"] = c["id"].astype(str)
    d = c.merge(f[["id", "S", "S2"]], on="id", how="left")
    d["M"] = pd.to_numeric(d["event_meas_only"], errors="coerce")
    d["C"] = pd.to_numeric(d["event"], errors="coerce")
    return d


COV = ["age", "male", "urban", "edu_3cat", "sbp"]


def logor(df: pd.DataFrame, ycol: str, ex: str) -> float:
    m = df[[ycol, ex] + COV].dropna()
    if len(m) < 100 or m[ycol].nunique() < 2:
        return np.nan
    X = sm.add_constant(m[[ex] + COV].astype(float))
    try:
        fit = sm.GLM(m[ycol].astype(float), X, family=sm.families.Binomial()).fit()
        return float(fit.params[ex])
    except Exception:  # noqa: BLE001
        return np.nan


def boot_delta(df: pd.DataFrame, ex: str, n_boot: int = 600) -> tuple:
    d = df.copy()
    d["behavioral3"] = d[["smoke_current", "drink_frequent", "pa_inactive"]].sum(
        axis=1, min_count=3)
    d["b3"] = (d["smoke_current"].fillna(0) > 0).astype(float)
    d.loc[d["smoke_current"].isna(), "b3"] = np.nan
    obs = logor(d, "S2", ex) - logor(d, "M", ex)
    n = len(d)
    deltas = []
    for _ in range(n_boot):
        idx = RNG.integers(0, n, n)
        s = d.iloc[idx]
        v = logor(s, "S2", ex) - logor(s, "M", ex)
        if np.isfinite(v):
            deltas.append(v)
    deltas = np.array(deltas)
    if len(deltas) < 50:
        return obs, np.nan, np.nan, len(deltas)
    lo, hi = np.percentile(deltas, [2.5, 97.5])
    return obs, lo, hi, len(deltas)


def main() -> None:
    head("FORMAL TEST  is the ascertainment shift statistically real?")
    say("  estimand: delta = log OR(self-report) - log OR(measured)")
    say("  a negative delta means self-report pushes the exposure toward protection")
    say("  bootstrap resamples individuals, preserving the paired design")

    for name, fn in [("CHARLS", charls_frame), ("CHNS", chns_frame)]:
        d = fn()
        say()
        say(f"  --- {name}")
        for ex, lab in [("smoke_current", "current smoking"),
                        ("drink_frequent", "frequent drinking"),
                        ("pa_inactive", "physical inactivity")]:
            obs, lo, hi, nb = boot_delta(d, ex)
            or_m = np.exp(logor(d, "M", ex))
            or_s = np.exp(logor(d, "S2", ex))
            sig = "yes" if (lo > 0 or hi < 0) else "no"
            say(f"    {lab:<22s} OR_meas={or_m:5.2f}  OR_self={or_s:5.2f}"
                f"  delta={obs:+.3f} (95% CI {lo:+.3f}, {hi:+.3f})  differs={sig}")
            ROWS.append({"cohort": name, "exposure": ex,
                         "OR_measured": round(float(or_m), 3),
                         "OR_selfreport": round(float(or_s), 3),
                         "delta_logOR": round(float(obs), 3),
                         "lo": round(float(lo), 3), "hi": round(float(hi), 3),
                         "differs": sig})

    pd.DataFrame(ROWS).to_csv(HERE / "03_china_delta_test.csv",
                              index=False, encoding="utf-8-sig")
    (HERE / "03_china_delta_report.txt").write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nwrote {HERE / '03_china_delta_report.txt'}")


if __name__ == "__main__":
    sys.exit(main())
