# HRS re-analysis using the RAND HRS Longitudinal File (1992-2022).
#
# Seven adjacent wave pairs that both have measured blood pressure:
#   (8,9) (9,10) (10,11) (11,12) (12,13) (13,14) (14,16)
# RAND wave -> year: 8=2006 9=2008 10=2010 11=2012 12=2014 13=2016 14=2018 16=2022
#
# Baseline: free of hypertension by BOTH measured BP and self-report.
# Follow-up definitions:
#   M   measured only         r{w}bpsys/bpdia >= 140/90
#   S   incident self-report  r{w}hibps == 1 ("since last interview")
#   S2  S or reports high BP this wave (r{w}hibp)

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
F = (ROOT / "HRS" / "RAND HRS Data" /
     "Longitudinal and Cross-Wave Data Products" / "randhrs1992_2022v1.dta")
OUT = Path(__file__).resolve().parents[1] / "results"

BP_WAVES = [8, 9, 10, 11, 12, 13, 14, 16]
# HRS administers the physical measures to an alternating half-sample, so the
# usable pairs are TWO waves apart (4-year intervals), not adjacent.
PAIRS = [(8, 10), (9, 11), (10, 12), (11, 13), (12, 14), (14, 16)]


def columns() -> list[str]:
    c = ["hhidpn", "ragender", "raedyrs"]
    for w in BP_WAVES:
        c += [f"r{w}agey_m", f"r{w}bpsys", f"r{w}bpdia",
              f"r{w}hibp", f"r{w}hibps"]
    for w in [8, 9, 10, 11, 12, 14]:
        c += [f"r{w}smoken", f"r{w}drinkd", f"r{w}vgactx", f"r{w}mdactx"]
    return c


def main() -> None:
    print("=" * 78)
    print("HRS via RAND HRS Longitudinal File   seven wave pairs")
    print("=" * 78)
    want = columns()
    print(f"  requesting {len(want)} of 19,880 columns ...")
    d = pd.read_stata(F, columns=want, convert_categoricals=False)
    print(f"  loaded rows {len(d):,}")
    print()
    for c in ["r8hibp", "r9hibps", "r8bpsys", "r8smoken", "r8drinkd", "r8vgactx"]:
        s = pd.to_numeric(d[c], errors="coerce")
        print(f"    {c:<10s} n={int(s.notna().sum()):6,} "
              f"vals={dict(list(s.value_counts().head(5).items()))}")

    rows = []
    frames = []
    for w0, w1 in PAIRS:
        need = ["hhidpn", "ragender", "raedyrs"]
        for w in (w0, w1):
            need += [f"r{w}agey_m", f"r{w}bpsys", f"r{w}bpdia", f"r{w}hibp"]
        need += [f"r{w1}hibps"]
        for extra in [f"r{w0}smoken", f"r{w0}drinkd",
                      f"r{w0}vgactx", f"r{w0}mdactx"]:
            if extra in d.columns:
                need.append(extra)
        s = d[need].copy()
        for w in (w0, w1):
            for v in ["bpsys", "bpdia"]:
                col = f"r{w}{v}"
                x = pd.to_numeric(s[col], errors="coerce")
                s[col] = x.where(x > 0)
        # baseline must be VERIFIED disease-free: measured BP present and below
        # threshold, and self-report not positive
        base_ok = s[f"r{w0}bpsys"].notna() & s[f"r{w0}bpdia"].notna()
        m0 = (s[f"r{w0}bpsys"] >= 140) | (s[f"r{w0}bpdia"] >= 90)
        s0 = pd.to_numeric(s[f"r{w0}hibp"], errors="coerce") == 1
        free = base_ok & (~m0.fillna(False)) & (~s0.fillna(False))
        s = s[free].copy()
        if s.empty:
            print(f"  {w0}->{w1}: no eligible rows")
            continue
        m1 = (s[f"r{w1}bpsys"] >= 140) | (s[f"r{w1}bpdia"] >= 90)
        s["M"] = np.where(s[f"r{w1}bpsys"].notna() & s[f"r{w1}bpdia"].notna(),
                          m1.astype(float), np.nan)
        hps = pd.to_numeric(s[f"r{w1}hibps"], errors="coerce")
        hbp = pd.to_numeric(s[f"r{w1}hibp"], errors="coerce")
        s["S"] = (hps == 1).astype(float).where(hps.notna(), np.nan)
        s["S2"] = ((hps == 1) | (hbp == 1)).astype(float).where(
            hps.notna() | hbp.notna(), np.nan)
        s["age"] = pd.to_numeric(s[f"r{w0}agey_m"], errors="coerce")
        s["male"] = (pd.to_numeric(s["ragender"], errors="coerce") == 1).astype(float)
        s["edu"] = pd.to_numeric(s["raedyrs"], errors="coerce")
        v = pd.to_numeric(s[f"r{w0}smoken"], errors="coerce")
        s["smoke_current"] = np.where(v == 1, 1.0, np.where(v == 0, 0.0, np.nan))
        dd = pd.to_numeric(s[f"r{w0}drinkd"], errors="coerce")
        s["drink_frequent"] = np.where(dd >= 3, 1.0,
                                       np.where(dd.notna(), 0.0, np.nan))
        # RAND vgactx / mdactx are a 1-5 frequency scale verified against the
        # core questionnaire: 2 = >1/wk, 3 = 1/wk, 4 = 1-3/month,
        # 5 = hardly ever or never.
        vg = pd.to_numeric(s[f"r{w0}vgactx"], errors="coerce")
        md = pd.to_numeric(s[f"r{w0}mdactx"], errors="coerce")
        both = vg.notna() & md.notna()
        s["pa_inactive"] = np.where((vg == 5) & (md == 5), 1.0,
                                    np.where(both, 0.0, np.nan))
        s = s.dropna(subset=["M", "S2"])
        s["pair"] = f"{w0}_{w1}"
        frames.append(s[["M", "S", "S2", "age", "male", "edu",
                         "smoke_current", "drink_frequent", "pa_inactive", "pair"]])
        print(f"  {w0}->{w1}: disease-free {len(s):6,}")

    if not frames:
        print("nothing built")
        return
    allp = pd.concat(frames, ignore_index=True)
    print(f"\n  POOLED paired sample: {len(allp):,}")
    tab = allp[["M", "S"]].dropna()
    tp = int(((tab["M"] == 1) & (tab["S"] == 1)).sum())
    fn = int(((tab["M"] == 1) & (tab["S"] == 0)).sum())
    fp = int(((tab["M"] == 0) & (tab["S"] == 1)).sum())
    tn = int(((tab["M"] == 0) & (tab["S"] == 0)).sum())
    print(f"  ascertainment: sens={tp/(tp+fn):.3f}  spec={tn/(tn+fp):.3f}"
          f"   (M+ n={tp+fn:,}, M- n={tn+fp:,})")

    print()
    print("=" * 78)
    print("PROBE  pooled, wave-pair fixed effect")
    print("=" * 78)
    cov = ["age", "male", "edu"]
    dum = pd.get_dummies(allp["pair"], prefix="p", drop_first=True).astype(float)
    exposures = [("smoke_current", "current smoking"),
                 ("drink_frequent", "frequent drinking"),
                 ("pa_inactive", "physical inactivity")]
    print(f"  {'exposure':<22s}{'outcome':<20s}{'n':>7s}{'events':>8s}{'OR':>8s}"
          f"   95% CI")
    for ex, exlab in exposures:
        for oc, oclab in [("M", "M measured"), ("S", "S self-report"),
                          ("S2", "S2 self or hbp")]:
            mm = allp[[oc, ex] + cov].dropna()
            idx = mm.index
            X = sm.add_constant(pd.concat([mm[[ex] + cov].astype(float),
                                           dum.loc[idx]], axis=1))
            y = mm[oc].astype(float).values
            if len(mm) < 300 or mm[oc].nunique() < 2 or mm[ex].nunique() < 2:
                continue
            fit = sm.GLM(y, X, family=sm.families.Binomial()).fit()
            b, se = fit.params[ex], fit.bse[ex]
            lo, hi = np.exp(b - 1.96 * se), np.exp(b + 1.96 * se)
            print(f"  {exlab:<22s}{oclab:<20s}{len(mm):>7,}{int(y.sum()):>8,}"
                  f"{np.exp(b):>8.3f}   {lo:.3f}-{hi:.3f}")
            rows.append({"exposure": ex, "outcome": oc, "n": len(mm),
                         "events": int(y.sum()),
                         "OR": round(float(np.exp(b)), 4),
                         "lo": round(float(lo), 4), "hi": round(float(hi), 4)})
        print()
    pd.DataFrame(rows).to_csv(OUT / "04_hrs_wave_pairs_estimates.csv",
                              index=False, encoding="utf-8-sig")
    print(f"wrote {OUT / '04_hrs_wave_pairs_estimates.csv'}")


if __name__ == "__main__":
    sys.exit(main())
