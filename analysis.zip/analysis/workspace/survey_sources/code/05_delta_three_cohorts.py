# Formal three-cohort comparison of the ascertainment shift.
#   delta = log OR(self-report) - log OR(measured), within cohort
#   bootstrap resamples people (HRS: wave-pair stays attached to the person row)

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parents[1] / "results"
RNG = np.random.default_rng(20260913)
COV = ["age", "male", "edu"]

sys.path.insert(0, str(Path(__file__).resolve().parent))
from importlib import import_module  # noqa: E402

rand = import_module("04_hrs_rand_wave_pairs")


def build_hrs() -> pd.DataFrame:
    d = pd.read_stata(rand.F, columns=rand.columns(), convert_categoricals=False)
    frames = []
    for w0, w1 in rand.PAIRS:
        need = ["hhidpn", "ragender", "raedyrs"]
        for w in (w0, w1):
            need += [f"r{w}agey_m", f"r{w}bpsys", f"r{w}bpdia", f"r{w}hibp"]
        need += [f"r{w1}hibps", f"r{w0}smoken", f"r{w0}drinkd",
                 f"r{w0}vgactx", f"r{w0}mdactx"]
        s = d[[c for c in need if c in d.columns]].copy()
        for w in (w0, w1):
            for v in ["bpsys", "bpdia"]:
                x = pd.to_numeric(s[f"r{w}{v}"], errors="coerce")
                s[f"r{w}{v}"] = x.where(x > 0)
        base_ok = s[f"r{w0}bpsys"].notna() & s[f"r{w0}bpdia"].notna()
        m0 = (s[f"r{w0}bpsys"] >= 140) | (s[f"r{w0}bpdia"] >= 90)
        s0 = pd.to_numeric(s[f"r{w0}hibp"], errors="coerce") == 1
        s = s[base_ok & (~m0.fillna(False)) & (~s0.fillna(False))].copy()
        if s.empty:
            continue
        m1 = (s[f"r{w1}bpsys"] >= 140) | (s[f"r{w1}bpdia"] >= 90)
        s["M"] = np.where(s[f"r{w1}bpsys"].notna() & s[f"r{w1}bpdia"].notna(),
                          m1.astype(float), np.nan)
        hps = pd.to_numeric(s[f"r{w1}hibps"], errors="coerce")
        hbp = pd.to_numeric(s[f"r{w1}hibp"], errors="coerce")
        s["S"] = (hps == 1).astype(float).where(hps.notna(), np.nan)
        s["S2"] = ((hps == 1) | (hbp == 1)).astype(float).where(
            hps.notna() | hbp.notna(), np.nan)
        s["age"] = pd.to_numeric(s[f"r{w0}agey_m"], errors="coerce")
        s["male"] = (pd.to_numeric(s["ragender"], errors="coerce") == 1).astype(float)
        s["edu"] = pd.to_numeric(s["raedyrs"], errors="coerce")
        v = pd.to_numeric(s[f"r{w0}smoken"], errors="coerce")
        s["smoke_current"] = np.where(v == 1, 1.0, np.where(v == 0, 0.0, np.nan))
        dd = pd.to_numeric(s[f"r{w0}drinkd"], errors="coerce")
        s["drink_frequent"] = np.where(dd >= 3, 1.0,
                                       np.where(dd.notna(), 0.0, np.nan))
        vg = pd.to_numeric(s[f"r{w0}vgactx"], errors="coerce")
        md = pd.to_numeric(s[f"r{w0}mdactx"], errors="coerce")
        both = vg.notna() & md.notna()
        s["pa_inactive"] = np.where((vg == 5) & (md == 5), 1.0,
                                    np.where(both, 0.0, np.nan))
        frames.append(s[["M", "S2", "age", "male", "edu", "smoke_current",
                         "drink_frequent", "pa_inactive"]])
    return pd.concat(frames, ignore_index=True)


def logor(df, ycol, ex):
    m = df[[ycol, ex] + COV].dropna()
    if len(m) < 200 or m[ycol].nunique() < 2 or m[ex].nunique() < 2:
        return np.nan
    X = sm.add_constant(m[[ex] + COV].astype(float))
    return float(sm.GLM(m[ycol].astype(float), X,
                        family=sm.families.Binomial()).fit().params[ex])


def boot(df, ex, n_boot=400):
    d = df.dropna(subset=["M", "S2", ex] + COV).reset_index(drop=True)
    obs = logor(d, "S2", ex) - logor(d, "M", ex)
    vals = []
    for _ in range(n_boot):
        s = d.iloc[RNG.integers(0, len(d), len(d))]
        v = logor(s, "S2", ex) - logor(s, "M", ex)
        if np.isfinite(v):
            vals.append(v)
    lo, hi = (np.percentile(vals, [2.5, 97.5]) if len(vals) > 50 else (np.nan,) * 2)
    return obs, lo, hi, len(d)


def main() -> None:
    print("=" * 78)
    print("delta = log OR(self-report) - log OR(measured)   three cohorts")
    print("=" * 78)
    hrs = build_hrs()
    print(f"  HRS paired sample: {len(hrs):,}")
    rows = []
    print()
    print(f"  {'cohort':<9}{'exposure':<20}{'n':>7}{'OR_meas':>9}{'OR_self':>9}"
          f"{'delta':>9}   95% CI")
    for ex, lab in [("smoke_current", "current smoking"),
                    ("drink_frequent", "frequent drinking"),
                    ("pa_inactive", "physical inactivity")]:
        obs, lo, hi, n = boot(hrs, ex)
        om, os_ = np.exp(logor(hrs, "M", ex)), np.exp(logor(hrs, "S2", ex))
        print(f"  {'HRS':<9}{lab:<20}{n:>7,}{om:>9.2f}{os_:>9.2f}{obs:>+9.3f}"
              f"   {lo:+.3f} to {hi:+.3f}")
        rows.append({"cohort": "HRS(RAND)", "exposure": ex, "n": n,
                     "OR_measured": round(float(om), 3),
                     "OR_selfreport": round(float(os_), 3),
                     "delta": round(float(obs), 3),
                     "lo": round(float(lo), 3), "hi": round(float(hi), 3)})
    pd.DataFrame(rows).to_csv(HERE / "44_hrs_delta.csv",
                              index=False, encoding="utf-8-sig")
    print()
    print("  previous Chinese estimates (from H_novelty/03_china_delta_test.csv):")
    p = HERE / "03_china_delta_test.csv"
    if p.exists():
        old = pd.read_csv(p)
        for _, r in old.iterrows():
            print(f"  {r['cohort']:<9}{r['exposure']:<20}{'':>7}"
                  f"{r['OR_measured']:>9.2f}{r['OR_selfreport']:>9.2f}"
                  f"{r['delta_logOR']:>+9.3f}   {r['lo']:+.3f} to {r['hi']:+.3f}")


if __name__ == "__main__":
    sys.exit(main())
