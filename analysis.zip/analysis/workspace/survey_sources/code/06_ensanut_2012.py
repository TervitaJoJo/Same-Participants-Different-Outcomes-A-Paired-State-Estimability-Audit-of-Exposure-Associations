# ENSANUT 2012 probe: the same ascertainment comparison, Mexico.
#
# ENSANUT 2012 is cross-sectional, so this is a PREVALENT design and is
# therefore comparable to NHANES, not to the incident cohort analyses.
#
#   M   measured      mean of systolic/diastolic readings >= 140/90
#   S   self-report   a401 doctor ever said high blood pressure
#   S2  S or medication a405
#
# Exposures: current smoking (a1303a/b), frequent drinking (a1311)
# Covariates: age (edad), sex (sexo), education (escolari)

from __future__ import annotations

import io
import sys
import warnings
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2] / "ENSANUT"
OUT = Path(__file__).resolve().parents[1] / "results"


def read(wave: str, name: str) -> pd.DataFrame:
    p = ROOT / wave / name
    with zipfile.ZipFile(p) as z:
        inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
        with z.open(inner) as f:
            return pd.read_stata(io.BytesIO(f.read()), convert_categoricals=False)


def read_cat(wave: str, name: str) -> pd.DataFrame:
    p = ROOT / wave / name
    with zipfile.ZipFile(p) as z:
        inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
        with z.open(inner) as f:
            return pd.read_stata(io.BytesIO(f.read()), convert_categoricals=True)


def say(m: str = "") -> None:
    print(m)


def probe(d: pd.DataFrame, label: str) -> None:
    # PAIRED sample only: both definitions observed, so the comparison is fair
    d = d.dropna(subset=["M", "S"]).copy()
    say()
    say("=" * 78)
    say(f"{label}   n = {len(d):,}")
    say("=" * 78)
    tab = d[["M", "S"]].dropna()
    say(f"  paired sample: {len(tab):,}")
    say(pd.crosstab(tab["M"], tab["S"], rownames=["measured M"],
                    colnames=["self-report S"]).to_string())
    tp = int(((tab["M"] == 1) & (tab["S"] == 1)).sum())
    fn = int(((tab["M"] == 1) & (tab["S"] == 0)).sum())
    fp = int(((tab["M"] == 0) & (tab["S"] == 1)).sum())
    tn = int(((tab["M"] == 0) & (tab["S"] == 0)).sum())
    if tp + fn and tn + fp:
        say(f"  sens={tp/(tp+fn):.3f}  spec={tn/(tn+fp):.3f}")

    cov = ["age", "male", "edu"]
    exposures = [("smoke_current", "current smoking"),
                 ("drink_frequent", "frequent drinking")]
    outcomes = [("M", "M measured"), ("S", "S self-report"), ("S2", "S2 or med")]
    say()
    say(f"  {'exposure':<22s}{'outcome':<16s}{'n':>7s}{'events':>8s}{'OR':>8s}   95% CI")
    rows = []
    for ex, exlab in exposures:
        for oc, oclab in outcomes:
            mm = d[[oc, ex] + cov].dropna()
            if len(mm) < 200 or mm[oc].nunique() < 2 or mm[ex].nunique() < 2:
                say(f"  {exlab:<22s}{oclab:<16s}{len(mm):>7,}   insufficient")
                continue
            X = sm.add_constant(mm[[ex] + cov].astype(float))
            fit = sm.GLM(mm[oc].astype(float), X, family=sm.families.Binomial()).fit()
            b, se = fit.params[ex], fit.bse[ex]
            lo, hi = np.exp(b - 1.96 * se), np.exp(b + 1.96 * se)
            say(f"  {exlab:<22s}{oclab:<16s}{len(mm):>7,}{int(mm[oc].sum()):>8,}"
                f"{np.exp(b):>8.3f}   {lo:.3f}-{hi:.3f}")
            rows.append({"exposure": ex, "outcome": oc, "n": len(mm),
                         "events": int(mm[oc].sum()),
                         "OR": round(float(np.exp(b)), 4),
                         "lo": round(float(lo), 4), "hi": round(float(hi), 4)})
        say()
    pd.DataFrame(rows).to_csv(OUT / "06_ensanut_2012.csv",
                              index=False, encoding="utf-8-sig")


def main() -> None:
    say("=" * 78)
    say("ENSANUT 2012  variable check")
    say("=" * 78)
    bp = read("2012", "sangre_tension_arterial.stata.stata.zip")
    ad = read_cat("2012", "Adultos.stata.stata.zip")
    an = read("2012", "adultos_antropometria_2012.stata.stata.zip")
    for c in ["a401", "a405", "a1301", "a1303a", "a1311"]:
        s = ad[c]
        say(f"  {c:<9s} n={int(s.notna().sum()):6,} "
            f"{dict(list(s.value_counts(dropna=True).head(6).items()))}")
    for c in ["sistol1", "diastol1", "sistol2", "diastol2"]:
        s = pd.to_numeric(bp[c], errors="coerce")
        say(f"  {c:<9s} n={int(s[s < 900].notna().sum()):6,} median={s[s<900].median():.0f}")

    # ---- build -----------------------------------------------------------
    b = bp[["folio", "intp", "sexo", "edad", "sistol1", "diastol1",
            "sistol2", "diastol2"]].copy()
    for c in ["sistol1", "diastol1", "sistol2", "diastol2"]:
        s = pd.to_numeric(b[c], errors="coerce")
        b[c] = s.where(s < 900)
    b["sbp"] = b[["sistol1", "sistol2"]].mean(axis=1, skipna=True)
    b["dbp"] = b[["diastol1", "diastol2"]].mean(axis=1, skipna=True)
    b["M"] = np.where(b[["sbp", "dbp"]].notna().any(axis=1),
                      ((b["sbp"] >= 140) | (b["dbp"] >= 90)).astype(float), np.nan)
    a = ad[["folio", "intp", "a401", "a405", "a1301", "a1303a", "a1311"]].copy()
    d = b.merge(a, on=["folio", "intp"], how="inner")
    d = d.merge(an[["folio", "intp", "escolari"]], on=["folio", "intp"], how="left")

    d["S"] = np.where(d["a401"].astype(str) == "Sí", 1.0,
                      np.where(d["a401"].astype(str) == "No", 0.0, np.nan))
    # S2 = doctor-diagnosed OR currently on blood-pressure medication.
    # a405 is only asked of those who reported a diagnosis, so a401 == "No"
    # implies S2 = 0 rather than missing.
    s2 = np.where((d["a401"].astype(str) == "Sí") | (d["a405"].astype(str) == "Sí"),
                  1.0, np.where(d["a401"].astype(str) == "No", 0.0, np.nan))
    d["S2"] = s2

    ever = d["a1301"].astype(str)
    cur = d["a1303a"].astype(str)
    smoke = pd.Series(np.nan, index=d.index)
    smoke[cur == "Actualmente no fuma"] = 0.0
    smoke[cur.isin(["Diario", "Ocasional", "Semanal", "Mensual",
                    "Al menos una vez al año"])] = 1.0
    smoke[(cur == "NS/NR") | (cur == "nan")] = np.nan
    smoke[ever == "Nunca he fumado"] = 0.0
    smoke[(cur == "nan") & (ever == "No")] = 0.0
    d["smoke_current"] = smoke

    freq_weekly_plus = ["Una o dos veces a la semana", "Tres o cuatro veces a la semana",
                        "Casi todos los días (5-6 veces por semana)", "Una vez al día",
                        "Dos veces al día", "Tres o más veces al día"]
    dr = d["a1311"].astype(str)
    d["drink_frequent"] = np.where(dr == "Actualmente no toma", 0.0,
                                   np.where(dr.isin(freq_weekly_plus), 1.0,
                                            np.where(dr == "NS/NR", np.nan, 0.0)))
    d["age"] = pd.to_numeric(d["edad"], errors="coerce")
    d["male"] = np.where(pd.to_numeric(d["sexo"], errors="coerce") == 1, 1.0, 0.0)
    d["edu"] = pd.to_numeric(d["escolari"], errors="coerce")
    d = d[(d["age"] >= 20) & (d["age"] <= 100)].copy()
    probe(d, "ENSANUT 2012")


if __name__ == "__main__":
    sys.exit(main())
