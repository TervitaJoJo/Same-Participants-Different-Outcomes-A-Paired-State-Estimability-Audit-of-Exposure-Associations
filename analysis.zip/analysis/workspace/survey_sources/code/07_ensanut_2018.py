# ENSANUT 2018 probe: within-country replication of the Mexican result.
#
#   measured BP  ponderadores_hipertension: a_P27_1_1/2, a_P27_2_1/2
#   self-report  CS_ADULTOS: P4_1 (ever told), P4_4 (medication)
#   exposures    CS_ADULTOS: P13_1 (ever 100 cigs), P13_2 (smoke now), P13_14 (alcohol)

from __future__ import annotations

import io
import sys
import warnings
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2] / "ENSANUT" / "2018_10+"
OUT = Path(__file__).resolve().parents[1] / "results"


def read(name: str, cats: bool = False) -> pd.DataFrame:
    with zipfile.ZipFile(ROOT / name) as z:
        inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
        with z.open(inner) as f:
            return pd.read_stata(io.BytesIO(f.read()), convert_categoricals=cats)


def meta(name: str) -> dict:
    with zipfile.ZipFile(ROOT / name) as z:
        inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
        with z.open(inner) as f:
            return pd.read_stata(io.BytesIO(f.read()), iterator=True).variable_labels()


def main() -> None:
    print("=" * 78)
    print("ENSANUT 2018   keys and codings")
    print("=" * 78)
    lab_bp = meta("ponderadores_hipertension.stata.stata.zip")
    lab_ad = meta("CS_ADULTOS.stata.stata.zip")
    print("  BP file vars:", ", ".join(list(lab_bp)[:14]))
    print("  adult file key-ish:", ", ".join(
        [k for k in list(lab_ad)[:14]]))

    bp = read("ponderadores_hipertension.stata.stata.zip")
    ad = read("CS_ADULTOS.stata.stata.zip", cats=True)
    print()
    for c in ["P4_1", "P4_4", "P13_1", "P13_2", "P13_14"]:
        if c in ad.columns:
            print(f"  {c:<8s} {dict(list(ad[c].value_counts(dropna=True).head(6).items()))}")
    for c in ["a_P27_1_1", "a_P27_1_2", "a_P27_2_1", "a_P27_2_2"]:
        if c in bp.columns:
            s = pd.to_numeric(bp[c], errors="coerce")
            print(f"  {c:<12s} n={int(s[s<900].notna().sum()):6,} median={s[s<900].median():.0f}")

    # merge on the four-part household/respondent key; the two files store the
    # components as different types (float vs zero-padded string), so normalise
    # both to numeric before combining.
    KEY = [c for c in ["UPM", "VIV_SEL", "HOGAR", "NUMREN"]
           if c in bp.columns and c in ad.columns]
    print("  merge key:", KEY)
    for df in (bp, ad):
        parts = df[KEY].apply(pd.to_numeric, errors="coerce").astype("Int64")
        df["_k"] = parts.astype(str).agg("|".join, axis=1)
    key = "_k"

    # ---- build -----------------------------------------------------------
    b = bp[[key] + [c for c in ["a_P27_1_1", "a_P27_1_2", "a_P27_2_1", "a_P27_2_2",
                                "sexo", "edad", "ponde_tension"] if c in bp.columns]].copy()
    for c in ["a_P27_1_1", "a_P27_1_2", "a_P27_2_1", "a_P27_2_2"]:
        s = pd.to_numeric(b[c], errors="coerce")
        b[c] = s.where(s < 900)
    b["sbp"] = b[["a_P27_1_1", "a_P27_2_1"]].mean(axis=1, skipna=True)
    b["dbp"] = b[["a_P27_1_2", "a_P27_2_2"]].mean(axis=1, skipna=True)
    b["M"] = np.where(b[["sbp", "dbp"]].notna().any(axis=1),
                      ((b["sbp"] >= 140) | (b["dbp"] >= 90)).astype(float), np.nan)

    a = ad[[key, "P4_1", "P4_4", "P13_1", "P13_2", "P13_14"] +
           [c for c in ["EDAD", "edad", "SEXO", "sexo"] if c in ad.columns]].copy()
    d = b.merge(a, on=key, how="inner")
    print(f"\n  merged rows: {len(d):,}")

    yes = lambda s: s.astype(str).str.strip().str.lower().isin(["sí", "si", "1"])
    no = lambda s: s.astype(str).str.strip().str.lower().isin(["no", "2"])
    d["S"] = np.where(yes(d["P4_1"]), 1.0, np.where(no(d["P4_1"]), 0.0, np.nan))
    d["S2"] = np.where(yes(d["P4_1"]) | yes(d["P4_4"]), 1.0,
                       np.where(no(d["P4_1"]), 0.0, np.nan))
    # P13_2 options: "no fuma actualmente?" / "algunos días?" / "todos los días?"
    ever = d["P13_1"].astype(str).str.strip().str.lower()
    cur = d["P13_2"].astype(str).str.strip().str.lower()
    smoke = pd.Series(np.nan, index=d.index)
    smoke[cur.str.contains("d[ií]as", na=False)] = 1.0
    smoke[cur.str.contains("no fuma", na=False)] = 0.0
    smoke[ever.isin(["no", "nunca he fumado", "nunca"])] = 0.0
    smoke[cur.str.contains("no responde", na=False) & ~ever.isin(["no"])] = np.nan
    d["smoke_current"] = smoke

    # P13_14 is a two-digit count of drinking occasions in the last 30 days;
    # 98 marks non-drinkers, blank is missing.
    dr = pd.to_numeric(d["P13_14"].astype(str).str.strip(), errors="coerce")
    dr = dr.where(dr <= 30)
    d["drink_frequent"] = np.where(dr.notna(), (dr >= 8).astype(float), np.nan)
    d.loc[pd.to_numeric(d["P13_14"].astype(str).str.strip(),
                        errors="coerce") == 98, "drink_frequent"] = 0.0
    agecol = "edad" if "edad" in d.columns else ("EDAD" if "EDAD" in d.columns else None)
    sexcol = "sexo" if "sexo" in d.columns else ("SEXO" if "SEXO" in d.columns else None)
    d["age"] = pd.to_numeric(d[agecol], errors="coerce") if agecol else np.nan
    d["male"] = (pd.to_numeric(d[sexcol], errors="coerce") == 1).astype(float) if sexcol else np.nan
    d["edu"] = 0.0          # education not merged yet; placeholder keeps the model running

    d = d.dropna(subset=["M", "S"]).copy()
    print("=" * 78)
    print(f"ENSANUT 2018   paired n = {len(d):,}")
    print("=" * 78)
    tab = d[["M", "S"]]
    tp = int(((tab["M"] == 1) & (tab["S"] == 1)).sum())
    fn = int(((tab["M"] == 1) & (tab["S"] == 0)).sum())
    fp = int(((tab["M"] == 0) & (tab["S"] == 1)).sum())
    tn = int(((tab["M"] == 0) & (tab["S"] == 0)).sum())
    print(pd.crosstab(tab["M"], tab["S"], rownames=["M"], colnames=["S"]).to_string())
    print(f"  sens={tp/(tp+fn):.3f}  spec={tn/(tn+fp):.3f}")

    cov = ["age", "male", "edu"]
    rows = []
    print()
    print(f"  {'exposure':<22s}{'outcome':<16s}{'n':>7s}{'events':>8s}{'OR':>8s}   95% CI")
    for ex in ["smoke_current", "drink_frequent"]:
        for oc in ["M", "S", "S2"]:
            mm = d[[oc, ex] + cov].dropna()
            if len(mm) < 200 or mm[oc].nunique() < 2 or mm[ex].nunique() < 2:
                print(f"  {ex:<22s}{oc:<16s}{len(mm):>7,}   insufficient")
                continue
            X = sm.add_constant(mm[[ex] + cov].astype(float))
            fit = sm.GLM(mm[oc].astype(float), X, family=sm.families.Binomial()).fit()
            bb, se = fit.params[ex], fit.bse[ex]
            lo, hi = np.exp(bb - 1.96 * se), np.exp(bb + 1.96 * se)
            print(f"  {ex:<22s}{oc:<16s}{len(mm):>7,}{int(mm[oc].sum()):>8,}"
                  f"{np.exp(bb):>8.3f}   {lo:.3f}-{hi:.3f}")
            rows.append({"exposure": ex, "outcome": oc, "n": len(mm),
                         "events": int(mm[oc].sum()),
                         "OR": round(float(np.exp(bb)), 4),
                         "lo": round(float(lo), 4), "hi": round(float(hi), 4)})
        print()
    pd.DataFrame(rows).to_csv(OUT / "07_ensanut_2018.csv",
                              index=False, encoding="utf-8-sig")


if __name__ == "__main__":
    sys.exit(main())
