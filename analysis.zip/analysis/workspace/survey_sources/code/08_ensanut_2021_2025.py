# ENSANUT 2021-2025, one generalised probe.
#
# Structure per wave:
#   anthropometry file : an27_01s/01d, an27_02s/02d, an27_03s/03d (3 readings)
#   adult questionnaire: a0401 (ever told high BP), a0404 (medication),
#                        a1301/a1303 (smoking), a1311 (alcohol)

from __future__ import annotations

import io
import re
import sys
import warnings
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2] / "ENSANUT"
OUT = Path(__file__).resolve().parents[1] / "results"

WAVES = {
    "2021": ("ensaantro21_entrega_w_17_12_2021.stata.stata.zip",
             "ensadul2021_entrega_w_15_12_2021.stata.stata.zip"),
    "2022": ("ensaantro2022_entrega_w.stata.stata.zip",
             "ensadul2022_entrega_w.stata.stata.zip"),
    "2023": ("antropometria_hta_4mar24.stata.stata.zip",
             "adultos_ensanut2023_w_n.stata.stata.zip"),
    "2024": ("antropometria_ensanut2024_w.stata.stata.zip",
             "adultos_ensanut2024_w.stata.stata.zip"),
    "2025": ("antro_2025_w.stata.stata.zip",
             "adultos_2025_w.stata.stata.zip"),
}

KEYS = ["FOLIO_I", "FOLIO_INT", "UPM", "VIV_SEL", "HOGAR", "NUMREN"]


def read(wave: str, name: str, cats: bool = False, cols: list | None = None):
    p = ROOT / wave / name
    if not p.exists():
        return None
    try:
        with zipfile.ZipFile(p) as z:
            inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
            with z.open(inner) as f:
                raw = f.read()
        if cats and cols:
            # pandas is very slow when convert_categoricals is combined with a
            # column subset, so read the codes fast and map the labels by hand.
            d = pd.read_stata(io.BytesIO(raw), convert_categoricals=False,
                              columns=[c for c in cols])
            vl = pd.read_stata(io.BytesIO(raw), iterator=True).value_labels()
            for c in d.columns:
                if c in vl:
                    d[c] = d[c].map(vl[c])
            return d
        kw = {"convert_categoricals": cats}
        if cols:
            kw["columns"] = cols
        return pd.read_stata(io.BytesIO(raw), **kw)
    except Exception:  # noqa: BLE001
        return None


def labels(wave: str, name: str) -> dict:
    p = ROOT / wave / name
    try:
        with zipfile.ZipFile(p) as z:
            inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
            with z.open(inner) as f:
                return pd.read_stata(io.BytesIO(f.read()), iterator=True).variable_labels()
    except Exception:  # noqa: BLE001
        return {}


def add_key(df, wave: str):
    ks = [k for k in KEYS if k in df.columns]
    if len(ks) < 2:
        ks = [c for c in df.columns
              if re.search(r"upm|viv|hogar|numren|folio|llave|id", c, re.I)][:4]
    if not ks:
        return None
    df = df.copy()
    # newer ENSANUT waves use string keys such as "2021_01001004_01", so no
    # numeric coercion here -- converting them would silently null the key.
    parts = df[ks].astype(str)
    key = parts.iloc[:, 0]
    for c in parts.columns[1:]:
        key = key + "|" + parts[c]
    df["_k"] = key
    return df


def run_wave(wave: str, bp_name: str, ad_name: str, verbose: bool) -> list:
    lab_bp = labels(wave, bp_name)
    lab_ad = labels(wave, ad_name)
    bpv0 = [c for c in lab_bp if re.match(r"^an27_0[123][sd]$", c, re.I)]
    ad_dx0 = [c for c in lab_ad if c.lower() in ("a0401", "p4_1")]
    ad_med0 = [c for c in lab_ad if c.lower() in ("a0404", "p4_4")]
    sm_ever0 = [c for c in lab_ad if c.lower() == "a1301"]
    sm_now0 = [c for c in lab_ad if c.lower() in ("a1303", "a1302", "p13_2")]
    alco0 = [c for c in lab_ad if c.lower() in ("a1311", "p13_14")]
    want_b = sorted(set(["FOLIO_I", "FOLIO_INT", "UPM", "VIV_SEL", "HOGAR",
                         "NUMREN", "EDAD", "edad", "SEXO", "sexo"] + bpv0))
    want_a = sorted(set(["FOLIO_I", "FOLIO_INT", "UPM", "VIV_SEL", "HOGAR",
                         "NUMREN", "EDAD", "edad", "SEXO", "sexo"]
                        + ad_dx0 + ad_med0 + sm_ever0 + sm_now0 + alco0))
    want_b = [c for c in want_b if c in lab_bp]
    want_a = [c for c in want_a if c in lab_ad]
    bp = read(wave, bp_name, cats=False, cols=want_b)
    ad = read(wave, ad_name, cats=True, cols=want_a)
    if bp is None or ad is None:
        print(f"  {wave}: could not read files")
        return []
    bpv = bpv0
    if not bpv:
        bpv = [c for c in lab_bp if re.search(r"sistol|diastol|an27", c, re.I)][:6]
    ad_dx, ad_med = ad_dx0, ad_med0
    smoke_ever, smoke_now = sm_ever0, sm_now0
    alco = alco0
    if verbose:
        print(f"\n  {wave}: BP={bpv} dx={ad_dx} med={ad_med} "
              f"smoke={smoke_ever}+{smoke_now} alcohol={alco}")

    bp = add_key(bp, wave)
    ad = add_key(ad, wave)
    if bp is None or ad is None:
        print(f"  {wave}: no usable key")
        return []

    keep_b = ["_k"] + bpv + [c for c in ["EDAD", "edad", "SEXO", "sexo"] if c in bp.columns]
    keep_a = ["_k"] + ad_dx + ad_med + smoke_ever + smoke_now + alco + \
        [c for c in ["EDAD", "edad", "SEXO", "sexo", "ESCOLARI", "escolari"]
         if c in ad.columns]
    b = bp[keep_b].copy()
    for c in bpv:
        s = pd.to_numeric(b[c], errors="coerce")
        b[c] = s.where(s < 900)
    sysc = [c for c in bpv if c.lower().endswith("s")]
    diac = [c for c in bpv if c.lower().endswith("d")]
    b["sbp"] = b[sysc].mean(axis=1, skipna=True)
    b["dbp"] = b[diac].mean(axis=1, skipna=True)
    b["M"] = np.where(b[["sbp", "dbp"]].notna().any(axis=1),
                      ((b["sbp"] >= 140) | (b["dbp"] >= 90)).astype(float), np.nan)
    d = b.merge(ad[keep_a], on="_k", how="inner")
    if d.empty:
        print(f"  {wave}: merge produced 0 rows")
        return []

    def _norm(s):
        return (s.astype(str).str.strip().str.lower()
                .str.replace(".", "", regex=False))

    def isyes(s):
        t = _norm(s)
        return t.str.startswith("s") | t.isin(["1"])

    def isno(s):
        t = _norm(s)
        return t.str.startswith("no") | t.isin(["2", "0"])

    if ad_dx:
        dx = d[ad_dx[0]]
        d["S"] = np.where(isyes(dx), 1.0, np.where(isno(dx), 0.0, np.nan))
        med = d[ad_med[0]] if ad_med else pd.Series(np.nan, index=d.index)
        d["S2"] = np.where(isyes(dx) | isyes(med), 1.0,
                           np.where(isno(dx), 0.0, np.nan))
    if smoke_ever or smoke_now:
        # In these waves a1301 itself asks about CURRENT smoking ("no fuma
        # actualmente?" / "algunos dias?" / "todos los dias?"), while a1302 and
        # a1303 are follow-ups. Detect which column carries that wording.
        cand = (smoke_ever + smoke_now)
        cur = None
        for c in cand:
            txt = d[c].astype(str).str.strip().str.lower()
            if txt.str.contains("no fuma|d[ií]as", na=False).any():
                cur = txt
                break
        if cur is None and cand:
            cur = d[cand[0]].astype(str).str.strip().str.lower()
        ever = cur if cur is not None else pd.Series("", index=d.index)
        smk = pd.Series(np.nan, index=d.index)
        smk[cur.str.contains("d[ií]as|diario|ocasional|semanal", na=False)] = 1.0
        smk[cur.str.contains("no fuma", na=False)] = 0.0
        smk[ever.str.contains("nunca", na=False)] = 0.0
        d["smoke_current"] = smk
    if alco:
        a = pd.to_numeric(d[alco[0]].astype(str).str.strip(), errors="coerce")
        d["drink_frequent"] = np.where(a.notna() & (a <= 30), (a >= 8).astype(float),
                                       np.where(a == 98, 0.0, np.nan))
        if d["drink_frequent"].notna().sum() < 100:
            raw = _norm(d[alco[0]])
            d["drink_frequent"] = np.where(raw.str.startswith("s"), 1.0,
                                           np.where(raw.str.startswith("no"), 0.0,
                                                    np.nan))
    agecol = next((c for c in ["edad", "EDAD"] if c in d.columns), None)
    sexcol = next((c for c in ["sexo", "SEXO"] if c in d.columns), None)
    educol = next((c for c in ["escolari", "ESCOLARI"] if c in d.columns), None)
    d["age"] = pd.to_numeric(d[agecol], errors="coerce") if agecol else np.nan
    d["male"] = (pd.to_numeric(d[sexcol], errors="coerce") == 1).astype(float) \
        if sexcol else np.nan
    d["edu"] = pd.to_numeric(d[educol], errors="coerce") if educol else 0.0

    d = d.dropna(subset=["M", "S"]).copy()
    if d.empty:
        print(f"  {wave}: paired sample empty")
        return []
    tab = d[["M", "S"]]
    tp = int(((tab["M"] == 1) & (tab["S"] == 1)).sum())
    fn = int(((tab["M"] == 1) & (tab["S"] == 0)).sum())
    fp = int(((tab["M"] == 0) & (tab["S"] == 1)).sum())
    tn = int(((tab["M"] == 0) & (tab["S"] == 0)).sum())
    sens = tp / (tp + fn) if (tp + fn) else float("nan")
    spec = tn / (tn + fp) if (tn + fp) else float("nan")
    print(f"\n  --- ENSANUT {wave}   paired n={len(d):,}   "
          f"sens={sens:.3f} spec={spec:.3f}")

    rows = []
    cov = ["age", "male", "edu"]
    for ex in ["smoke_current", "drink_frequent"]:
        if ex not in d.columns:
            continue
        line = f"     {ex:<16s}"
        for oc in ["M", "S", "S2"]:
            mm = d[[oc, ex] + cov].dropna()
            if len(mm) < 200 or mm[oc].nunique() < 2 or mm[ex].nunique() < 2:
                line += f"  {oc}: n/a"
                continue
            X = sm.add_constant(mm[[ex] + cov].astype(float))
            fit = sm.GLM(mm[oc].astype(float), X,
                         family=sm.families.Binomial()).fit()
            bb, se = fit.params[ex], fit.bse[ex]
            lo, hi = np.exp(bb - 1.96 * se), np.exp(bb + 1.96 * se)
            line += f"  {oc}: {np.exp(bb):.2f} ({lo:.2f}-{hi:.2f})"
            rows.append({"wave": wave, "exposure": ex, "outcome": oc,
                         "n": len(mm), "events": int(mm[oc].sum()),
                         "OR": round(float(np.exp(bb)), 3),
                         "lo": round(float(lo), 3), "hi": round(float(hi), 3)})
        print(line)
    return rows


def main() -> None:
    print("=" * 78)
    print("ENSANUT 2021-2025")
    print("=" * 78)
    allrows = []
    for wave, (bpn, adn) in WAVES.items():
        try:
            allrows += run_wave(wave, bpn, adn, verbose=True)
        except Exception as e:  # noqa: BLE001
            print(f"  {wave}: FAILED {type(e).__name__}: {e}")
    pd.DataFrame(allrows).to_csv(OUT / "08_ensanut_2021_2025.csv",
                                 index=False, encoding="utf-8-sig")
    print(f"\nwrote {OUT / '08_ensanut_2021_2025.csv'}  ({len(allrows)} estimates)")


if __name__ == "__main__":
    sys.exit(main())
