# NHANES probe across all ten downloaded cycles (1999-2000 .. 2017-2018).
#
# Design (prevalent, cross-sectional):
#   M   measured   mean of available BPXSY / BPXDI >= 140/90
#   S   self-report BPQ020 (doctor ever said high blood pressure)
#   S2  S or BPQ050A / BPQ040A (medication)
#
# Exposures: current smoking (SMQ020 ever 100 / SMQ040 smoke now),
#            frequent drinking (ALQ120Q or ALQ121), inactivity where PAQ605 exists.
#
# NOTE NHANES changed the blood-pressure measurement protocol in 2017-2018;
# the cycle is flagged so it can be excluded from pooled comparisons.

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2] / "NHANES"
OUT = Path(__file__).resolve().parents[1] / "results"

CYCLES = ["1999-2000", "2001-2002", "2003-2004", "2005-2006", "2007-2008",
          "2009-2010", "2011-2012", "2013-2014", "2015-2016", "2017-2018"]


def load(cyc: str, prefix: str) -> pd.DataFrame | None:
    d = ROOT / cyc
    cands = [p for p in d.glob("*.xpt") if p.name.upper().startswith(prefix)]
    if not cands:
        return None
    try:
        return pd.read_sas(cands[0], format="xport")
    except Exception:  # noqa: BLE001
        return None


def pick(cols, *names):
    for n in names:
        if n in cols:
            return n
    return None


def main() -> None:
    rows = []
    print("=" * 90)
    print(f"  {'cycle':<11}{'paired n':>9}{'sens':>7}{'spec':>7}"
          f"{'smoke M':>10}{'smoke S':>10}{'drink M':>10}{'drink S':>10}")
    print("=" * 90)
    for cyc in CYCLES:
        demo = load(cyc, "DEMO")
        bpx = load(cyc, "BPX")
        bpq = load(cyc, "BPQ")
        smq = load(cyc, "SMQ")
        alq = load(cyc, "ALQ")
        if demo is None or bpx is None or bpq is None:
            print(f"  {cyc:<11}  missing core files")
            continue
        d = demo[[c for c in ["SEQN", "RIAGENDR", "RIDAGEYR", "DMDEDUC2"]
                  if c in demo.columns]].copy()
        sysc = [c for c in bpx.columns if c.startswith("BPXSY")]
        diac = [c for c in bpx.columns if c.startswith("BPXDI")]
        b = bpx[["SEQN"] + sysc + diac].copy()
        for c in sysc + diac:
            s = pd.to_numeric(b[c], errors="coerce")
            b[c] = s.where(s > 0)
        b["sbp"] = b[sysc].mean(axis=1, skipna=True)
        b["dbp"] = b[diac].mean(axis=1, skipna=True)
        b["M"] = np.where(b[["sbp", "dbp"]].notna().any(axis=1),
                          ((b["sbp"] >= 140) | (b["dbp"] >= 90)).astype(float), np.nan)
        d = d.merge(b[["SEQN", "M"]], on="SEQN", how="left")

        qcols = [c for c in ["SEQN", "BPQ020", "BPQ040A", "BPQ050A"]
                 if c in bpq.columns]
        d = d.merge(bpq[qcols], on="SEQN", how="left")
        c020 = pd.to_numeric(d["BPQ020"], errors="coerce")
        d["S"] = np.where(c020 == 1, 1.0, np.where(c020 == 2, 0.0, np.nan))
        med = pd.Series(np.nan, index=d.index)
        for mc in ["BPQ050A", "BPQ040A"]:
            if mc in d.columns:
                v = pd.to_numeric(d[mc], errors="coerce")
                med = med.where(med.notna(), np.where(v == 1, 1.0,
                                                      np.where(v == 2, 0.0, np.nan)))
        d["S2"] = np.where((c020 == 1) | (med == 1), 1.0,
                           np.where(c020 == 2, 0.0, np.nan))

        if smq is not None:
            sc = [c for c in ["SEQN", "SMQ020", "SMQ040"] if c in smq.columns]
            d = d.merge(smq[sc], on="SEQN", how="left")
            ever = pd.to_numeric(d.get("SMQ020"), errors="coerce") \
                if "SMQ020" in d.columns else pd.Series(np.nan, index=d.index)
            now = pd.to_numeric(d.get("SMQ040"), errors="coerce") \
                if "SMQ040" in d.columns else pd.Series(np.nan, index=d.index)
            cur = pd.Series(np.nan, index=d.index)
            cur[now == 1] = 1.0
            cur[now == 2] = 0.0
            cur[now == 3] = 0.0
            cur[now.isna() & (ever == 2)] = 0.0
            d["smoke_current"] = cur

        if alq is not None:
            freqcol = pick(alq.columns, "ALQ121", "ALQ120Q")
            evercol = pick(alq.columns, "ALQ111", "ALQ101", "ALQ100")
            ac = [c for c in ["SEQN", freqcol, evercol] if c]
            d = d.merge(alq[ac], on="SEQN", how="left")
            if freqcol:
                f = pd.to_numeric(d[freqcol], errors="coerce")
                d["drink_frequent"] = np.where(f.isna(), np.nan, (f >= 3).astype(float))
                if evercol:
                    e = pd.to_numeric(d[evercol], errors="coerce")
                    d.loc[f.isna() & (e == 2), "drink_frequent"] = 0.0

        d["age"] = pd.to_numeric(d["RIDAGEYR"], errors="coerce")
        d["male"] = (pd.to_numeric(d["RIAGENDR"], errors="coerce") == 1).astype(float)
        edu = pd.to_numeric(d.get("DMDEDUC2", pd.Series(np.nan, index=d.index)),
                            errors="coerce")
        d["edu"] = edu.where(edu <= 5)
        d = d[d["age"] >= 20]
        d = d.dropna(subset=["M", "S"]).copy()
        if d.empty:
            print(f"  {cyc:<11}  no paired rows")
            continue

        tab = d[["M", "S"]]
        tp = int(((tab["M"] == 1) & (tab["S"] == 1)).sum())
        fn = int(((tab["M"] == 1) & (tab["S"] == 0)).sum())
        fp = int(((tab["M"] == 0) & (tab["S"] == 1)).sum())
        tn = int(((tab["M"] == 0) & (tab["S"] == 0)).sum())
        sens = tp / (tp + fn) if (tp + fn) else float("nan")
        spec = tn / (tn + fp) if (tn + fp) else float("nan")

        def orci(ex, oc):
            if ex not in d.columns:
                return None
            mm = d[[oc, ex, "age", "male", "edu"]].dropna()
            if len(mm) < 200 or mm[oc].nunique() < 2 or mm[ex].nunique() < 2:
                return None
            X = sm.add_constant(mm[[ex, "age", "male", "edu"]].astype(float))
            fit = sm.GLM(mm[oc].astype(float), X,
                         family=sm.families.Binomial()).fit()
            bb, se = fit.params[ex], fit.bse[ex]
            lo, hi = np.exp(bb - 1.96 * se), np.exp(bb + 1.96 * se)
            rows.append({"cycle": cyc, "exposure": ex, "outcome": oc,
                         "n": len(mm), "OR": round(float(np.exp(bb)), 3),
                         "lo": round(float(lo), 3), "hi": round(float(hi), 3)})
            return f"{np.exp(bb):.2f}"

        sm_m, sm_s = orci("smoke_current", "M"), orci("smoke_current", "S")
        dr_m, dr_s = orci("drink_frequent", "M"), orci("drink_frequent", "S")
        flag = "  <- protocol change" if cyc == "2017-2018" else ""
        print(f"  {cyc:<11}{len(d):>9,}{sens:>7.3f}{spec:>7.3f}"
              f"{str(sm_m or 'n/a'):>10}{str(sm_s or 'n/a'):>10}"
              f"{str(dr_m or 'n/a'):>10}{str(dr_s or 'n/a'):>10}{flag}")

    pd.DataFrame(rows).to_csv(OUT / "09_nhanes_all_cycles.csv",
                              index=False, encoding="utf-8-sig")
    print(f"\nwrote {OUT / '09_nhanes_all_cycles.csv'}")


if __name__ == "__main__":
    sys.exit(main())
