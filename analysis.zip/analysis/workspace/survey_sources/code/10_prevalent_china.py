# Decisive test: is the ascertainment pattern driven by the OUTCOME DESIGN
# (prevalent vs incident) rather than by the country?
#
# Run the SAME cross-sectional (prevalent) analysis in CHARLS 2011 and CHNS 2009
# that was run in NHANES 2017-2018, and compare all four datasets.
#
#   M   measured only    mean BP >= 140/90
#   S   self-report only physician diagnosis
#   S2  diagnosis or antihypertensive medication

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat
import statsmodels.api as sm

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parents[1] / "results"
COV = ["age", "male", "edu"]
EXPOSURES = [("smoke_current", "current smoking"),
             ("drink_frequent", "frequent drinking"),
             ("pa_inactive", "physical inactivity")]
OUTCOMES = [("M", "M measured"), ("S", "S self-report"), ("S2", "S2 dx or med")]


def charls_cross() -> pd.DataFrame:
    w = pd.read_csv(ROOT / "CHARLS" / "analysis" / "charls_analysis_wide.csv")
    w = w.rename(columns={"smoke_current_11": "smoke_current",
                          "drink_any_11": "drink_frequent",
                          "pa_any_11": "pa_any"})
    w["pa_inactive"] = 1.0 - pd.to_numeric(w["pa_any"], errors="coerce")
    h = pd.read_stata(ROOT / "CHARLS" / "2011" / "health_status_and_functioning.dta",
                      columns=["ID", "da007_1_", "da011s1", "da011s2"],
                      convert_categoricals=False)
    h["ht_dx"] = (pd.to_numeric(h["da007_1_"], errors="coerce") == 1).astype(float)
    h["ht_med"] = ((pd.to_numeric(h["da011s1"], errors="coerce") == 1)
                   | (pd.to_numeric(h["da011s2"], errors="coerce") == 2)).astype(float)
    w["ID"] = w["ID"].astype(str)
    h["ID"] = h["ID"].astype(str)
    d = w.merge(h[["ID", "ht_dx", "ht_med"]], on="ID", how="left")
    sbp = pd.to_numeric(d["sbp"], errors="coerce")
    dbp = pd.to_numeric(d["dbp"], errors="coerce")
    d["M"] = np.where(sbp.notna() | dbp.notna(),
                      ((sbp >= 140) | (dbp >= 90)).astype(float), np.nan)
    d["S"] = d["ht_dx"]
    d["S2"] = ((d["ht_dx"] == 1) | (d["ht_med"] == 1)).astype(float)
    d["age"] = pd.to_numeric(d["age"], errors="coerce")
    d["male"] = pd.to_numeric(d["male"], errors="coerce")
    d["edu"] = pd.to_numeric(d["edu"], errors="coerce")
    d["cohort"] = "CHARLS 2011"
    return d


def chns_cross() -> pd.DataFrame:
    """Rebuild the FULL CHNS 2009 cross-section.

    The locked pool contains only baseline disease-free people, so it cannot be
    used for a prevalent (cross-sectional) analysis. Rebuild from source.
    """
    B = ROOT / "CHNS" / "Individual-Level_Data"
    pe, _ = pyreadstat.read_sas7bdat(
        str(B / "pexam_00.sas7bdat"),
        usecols=["IDind", "WAVE", "SYSTOL1", "SYSTOL2", "SYSTOL3",
                 "DIASTOL1", "DIASTOL2", "DIASTOL3",
                 "U22", "U24", "U25", "U27", "U40", "U41"])
    sv, _ = pyreadstat.read_sas7bdat(str(B / "surveys_pub_12.sas7bdat"),
                                     usecols=["Idind", "wave", "age", "urban"])
    ms, _ = pyreadstat.read_sas7bdat(str(B / "mast_pub_12.sas7bdat"),
                                     usecols=["Idind", "GENDER"])
    ed, _ = pyreadstat.read_sas7bdat(str(B / "educ_12.sas7bdat"),
                                     usecols=["IDind", "WAVE", "A11"])
    sv = sv.rename(columns={"Idind": "IDind", "wave": "WAVE"})
    ms = ms.rename(columns={"Idind": "IDind"})
    for x in (pe, sv, ms, ed):
        x["IDind"] = x["IDind"].astype("int64")
    d = (pe.merge(sv, on=["IDind", "WAVE"], how="left")
           .merge(ms, on="IDind", how="left")
           .merge(ed, on=["IDind", "WAVE"], how="left"))
    d = d[d["WAVE"] == 2009].copy()
    for c in ["SYSTOL1", "SYSTOL2", "SYSTOL3", "DIASTOL1", "DIASTOL2", "DIASTOL3",
              "U22", "U24", "U25", "U27", "U40", "U41", "age", "urban"]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    d["sbp"] = d[["SYSTOL1", "SYSTOL2", "SYSTOL3"]].mean(axis=1, skipna=True)
    d["dbp"] = d[["DIASTOL1", "DIASTOL2", "DIASTOL3"]].mean(axis=1, skipna=True)
    d["M"] = np.where(d[["sbp", "dbp"]].notna().any(axis=1),
                      ((d["sbp"] >= 140) | (d["dbp"] >= 90)).astype(float), np.nan)
    d["S"] = (d["U22"] == 1).astype(float).where(d["U22"].notna(), np.nan)
    d["S2"] = ((d["U22"] == 1) | (d["U24"] == 1)).astype(float)
    d.loc[d["U22"].isna() & d["U24"].isna(), "S2"] = np.nan

    d["smoke_current"] = (d["U27"] == 1).astype(float)
    d.loc[d["U25"].isna() & d["U27"].isna(), "smoke_current"] = np.nan
    d["drink_frequent"] = np.where(
        d["U40"] == 0, 0.0,
        np.where((d["U40"] == 1) & d["U41"].isin([1, 2]), 1.0,
                 np.where((d["U40"] == 1) & d["U41"].isin([3, 4, 5]), 0.0, np.nan)))
    # pa not available in this compact rebuild -> excluded from this comparison
    d["pa_inactive"] = np.nan
    g = pd.to_numeric(d["GENDER"], errors="coerce")
    d["male"] = np.where(g == 1, 1.0, np.where(g == 2, 0.0, np.nan))
    a11 = pd.to_numeric(d["A11"], errors="coerce")
    d["edu"] = np.where(a11 == 0, 0, np.where(a11.between(11, 16), 0,
                     np.where(a11.between(21, 29), 1,
                     np.where(a11.between(31, 36), 2, np.nan))))
    d = d[(d["age"] >= 45) & d["sbp"].notna()].copy()
    d["cohort"] = "CHNS 2009"
    return d


def run(d: pd.DataFrame, label: str, rows: list) -> None:
    d = d.dropna(subset=["M", "S", "S2"]).copy()
    tab = d[["M", "S"]]
    tp = int(((tab["M"] == 1) & (tab["S"] == 1)).sum())
    fn = int(((tab["M"] == 1) & (tab["S"] == 0)).sum())
    fp = int(((tab["M"] == 0) & (tab["S"] == 1)).sum())
    tn = int(((tab["M"] == 0) & (tab["S"] == 0)).sum())
    sens = tp / (tp + fn) if (tp + fn) else float("nan")
    spec = tn / (tn + fp) if (tn + fp) else float("nan")
    print(f"\n  --- {label}   n={len(d):,}   sens={sens:.3f}  spec={spec:.3f}")
    for ex, exlab in EXPOSURES:
        line = f"    {exlab:<22s}"
        for oc, _ in OUTCOMES:
            mm = d[[oc, ex] + COV].dropna()
            if len(mm) < 200 or mm[oc].nunique() < 2 or mm[ex].nunique() < 2:
                line += f"  {oc}:  n/a"
                continue
            X = sm.add_constant(mm[[ex] + COV].astype(float))
            fit = sm.GLM(mm[oc].astype(float), X,
                         family=sm.families.Binomial()).fit()
            b, se = fit.params[ex], fit.bse[ex]
            line += f"  {oc}: {np.exp(b):.2f} ({np.exp(b-1.96*se):.2f}-{np.exp(b+1.96*se):.2f})"
            rows.append({"dataset": label, "design": "prevalent",
                         "exposure": ex, "outcome": oc, "n": len(mm),
                         "OR": round(float(np.exp(b)), 3)})
        print(line)


def main() -> None:
    print("=" * 78)
    print("DESIGN vs COUNTRY  prevalent (cross-sectional) analysis")
    print("=" * 78)
    rows: list = []
    for fn, lab in [(charls_cross, "CHARLS 2011"), (chns_cross, "CHNS 2009")]:
        try:
            run(fn(), lab, rows)
        except Exception as e:  # noqa: BLE001
            print(f"  {lab}: FAILED {type(e).__name__}: {e}")

    # bring in the NHANES run for the side-by-side view
    nha = HERE / "09b_nhanes2018_probe.csv"
    if nha.exists():
        n = pd.read_csv(nha)
        print("\n  --- NHANES 2017-2018 (from the previous run)")
        for ex, exlab in EXPOSURES:
            s = n[n["exposure"] == ex]
            if s.empty:
                continue
            parts = "  ".join(
                f"{r['outcome']}: {r['OR']:.2f} (n={int(r['n'])})"
                for _, r in s.iterrows())
            print(f"    {exlab:<22s}{parts}")
            for _, r in s.iterrows():
                rows.append({"dataset": "NHANES 2017-18", "design": "prevalent",
                             "exposure": ex, "outcome": r["outcome"],
                             "n": int(r["n"]), "OR": r["OR"]})
    pd.DataFrame(rows).to_csv(HERE / "10_prevalent_china.csv",
                              index=False, encoding="utf-8-sig")
    print(f"\nwrote {HERE / '10_prevalent_china.csv'}")


if __name__ == "__main__":
    sys.exit(main())
