# The direct mechanism test: is self-report WORSE at catching hypertension
# among the exposed than among the unexposed?
#
#   sens_exposed   = P(S=1 | M=1, exposed=1)
#   sens_unexposed = P(S=1 | M=1, exposed=0)
#   differential   = sens_exposed - sens_unexposed
#
# If smoking is associated with less diagnostic contact, differential should be
# NEGATIVE where the ascertainment shift is negative (China, Mexico) and ~0
# where it is absent (USA).

from __future__ import annotations

import io
import sys
import warnings
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[1] / "results"


def diff_sens(d: pd.DataFrame, ex: str) -> tuple[float, float, float, int]:
    """Sensitivity among M=1, split by exposure."""
    m = d[(d["M"] == 1) & d[ex].notna() & d["S"].notna()]
    if len(m) < 100:
        return np.nan, np.nan, np.nan, len(m)
    se = m[m[ex] == 1]["S"].mean()
    su = m[m[ex] == 0]["S"].mean()
    return se, su, se - su, len(m)


# ---------------------------------------------------------------- ENSANUT
def ensanut() -> pd.DataFrame:
    import zipfile as zf
    base = ROOT / "ENSANUT"
    out = []

    def rd(wave, name, cats=False, cols=None):
        with zf.ZipFile(base / wave / name) as z:
            inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
            with z.open(inner) as f:
                raw = f.read()
        kw = {"convert_categoricals": False}
        if cols:
            kw["columns"] = cols
        d = pd.read_stata(io.BytesIO(raw), **kw)
        if cats and cols:
            vl = pd.read_stata(io.BytesIO(raw), iterator=True).value_labels()
            for c in d.columns:
                if c in vl:
                    d[c] = d[c].map(vl[c])
        return d

    # --- 2012
    b12 = rd("2012", "sangre_tension_arterial.stata.stata.zip",
             cols=["folio", "intp", "sistol1", "diastol1", "sistol2", "diastol2"])
    a12 = rd("2012", "Adultos.stata.stata.zip", cats=True,
             cols=["folio", "intp", "a401", "a1301", "a1303a"])
    for c in ["sistol1", "diastol1", "sistol2", "diastol2"]:
        s = pd.to_numeric(b12[c], errors="coerce")
        b12[c] = s.where(s < 900)
    b12["sbp"] = b12[["sistol1", "sistol2"]].mean(axis=1, skipna=True)
    b12["dbp"] = b12[["diastol1", "diastol2"]].mean(axis=1, skipna=True)
    b12["M"] = np.where(b12[["sbp", "dbp"]].notna().any(axis=1),
                        ((b12["sbp"] >= 140) | (b12["dbp"] >= 90)).astype(float), np.nan)
    d12 = b12.merge(a12, on=["folio", "intp"], how="inner")
    d12["S"] = np.where(d12["a401"].astype(str) == "Sí", 1.0,
                        np.where(d12["a401"].astype(str) == "No", 0.0, np.nan))
    cur = d12["a1303a"].astype(str)
    d12["smoke"] = np.where(cur.str.contains("Diario|Ocasional|Semanal|Mensual|año"),
                            1.0, np.where(cur.str.contains("no fuma"), 0.0, np.nan))
    d12.loc[d12["a1301"].astype(str) == "Nunca he fumado", "smoke"] = 0.0
    out.append(("ENSANUT 2012", d12, "smoke"))

    # --- 2018
    bp18 = rd("2018_10+", "ponderadores_hipertension.stata.stata.zip")
    ad18 = rd("2018_10+", "CS_ADULTOS.stata.stata.zip", cats=True,
              cols=["UPM", "VIV_SEL", "HOGAR", "NUMREN", "P4_1", "P13_1", "P13_2"])
    # the BP file stores the key components as floats and the adult file as
    # zero-padded strings; normalise both to numeric before combining
    for df in (bp18, ad18):
        parts = df[["UPM", "VIV_SEL", "HOGAR", "NUMREN"]].apply(
            pd.to_numeric, errors="coerce").fillna(-1).astype("int64").astype(str)
        key = parts["UPM"]
        for c in ["VIV_SEL", "HOGAR", "NUMREN"]:
            key = key + "|" + parts[c]
        df["_k"] = key
    for c in ["a_P27_1_1", "a_P27_1_2", "a_P27_2_1", "a_P27_2_2"]:
        s = pd.to_numeric(bp18[c], errors="coerce")
        bp18[c] = s.where(s < 900)
    bp18["sbp"] = bp18[["a_P27_1_1", "a_P27_2_1"]].mean(axis=1, skipna=True)
    bp18["dbp"] = bp18[["a_P27_1_2", "a_P27_2_2"]].mean(axis=1, skipna=True)
    bp18["M"] = np.where(bp18[["sbp", "dbp"]].notna().any(axis=1),
                         ((bp18["sbp"] >= 140) | (bp18["dbp"] >= 90)).astype(float), np.nan)
    d18 = bp18[["_k", "M"]].merge(ad18[["_k", "P4_1", "P13_1", "P13_2"]],
                                  on="_k", how="inner")
    d18["S"] = np.where(d18["P4_1"].astype(str).str.lower().str.startswith("s"), 1.0,
                        np.where(d18["P4_1"].astype(str).str.lower().str.startswith("no"),
                                 0.0, np.nan))
    c2 = d18["P13_2"].astype(str).str.lower()
    d18["smoke"] = np.where(c2.str.contains("días", na=False), 1.0,
                            np.where(c2.str.contains("no fuma", na=False), 0.0, np.nan))
    d18.loc[d18["P13_1"].astype(str).str.lower().str.startswith("no"), "smoke"] = 0.0
    out.append(("ENSANUT 2018", d18, "smoke"))

    # --- 2021-2025
    W = {"2021": ("ensaantro21_entrega_w_17_12_2021.stata.stata.zip",
                  "ensadul2021_entrega_w_15_12_2021.stata.stata.zip"),
         "2022": ("ensaantro2022_entrega_w.stata.stata.zip",
                  "ensadul2022_entrega_w.stata.stata.zip"),
         "2023": ("antropometria_hta_4mar24.stata.stata.zip",
                  "adultos_ensanut2023_w_n.stata.stata.zip"),
         "2024": ("antropometria_ensanut2024_w.stata.stata.zip",
                  "adultos_ensanut2024_w.stata.stata.zip"),
         "2025": ("antro_2025_w.stata.stata.zip",
                  "adultos_2025_w.stata.stata.zip")}
    for w, (bn, an) in W.items():
        try:
            bp = rd(w, bn)
            # only request columns that actually exist in this wave
            with zf.ZipFile(base / w / an) as z:
                inner = [n for n in z.namelist() if n.lower().endswith(".dta")][0]
                with z.open(inner) as f:
                    avail = set(pd.read_stata(io.BytesIO(f.read()),
                                              iterator=True).variable_labels())
            want = [c for c in ["FOLIO_I", "FOLIO_INT", "a0401", "a1301",
                                "a1302", "a1303"] if c in avail]
            ad = rd(w, an, cats=True, cols=want)
            for df in (bp, ad):
                df["_k"] = df["FOLIO_I"].astype(str) + "|" + df["FOLIO_INT"].astype(str)
            vs = [c for c in bp.columns if c.lower().startswith("an27_0") and
                  c.lower().endswith("s")]
            vd = [c for c in bp.columns if c.lower().startswith("an27_0") and
                  c.lower().endswith("d")]
            for c in vs + vd:
                s = pd.to_numeric(bp[c], errors="coerce")
                bp[c] = s.where(s < 900)
            bp["M"] = np.where(bp[vs + vd].notna().any(axis=1),
                               ((bp[vs].mean(axis=1, skipna=True) >= 140)
                                | (bp[vd].mean(axis=1, skipna=True) >= 90)
                                ).astype(float), np.nan)
            ac = ["_k"] + [c for c in ["a0401", "a1301", "a1302", "a1303"]
                           if c in ad.columns]
            d = bp[["_k", "M"]].merge(ad[ac], on="_k", how="inner")
            dx = d["a0401"].astype(str).str.lower().str.replace(".", "", regex=False)
            d["S"] = np.where(dx.str.startswith("s"), 1.0,
                              np.where(dx.str.startswith("no"), 0.0, np.nan))
            cands = [c for c in ["a1301", "a1302"] if c in d.columns]
            cur = None
            for c in cands:
                t = d[c].astype(str).str.lower()
                if t.str.contains("no fuma|días", na=False).any():
                    cur = t
                    break
            if cur is not None:
                d["smoke"] = np.where(cur.str.contains("días"), 1.0,
                                      np.where(cur.str.contains("no fuma"), 0.0, np.nan))
                out.append((f"ENSANUT {w}", d, "smoke"))
        except Exception as e:  # noqa: BLE001
            print(f"  ENSANUT {w} failed: {type(e).__name__}: {e}")
    return out


# ---------------------------------------------------------------- NHANES
def nhanes() -> pd.DataFrame:
    base = ROOT / "NHANES"
    out = []
    for cyc in ["1999-2000", "2005-2006", "2007-2008", "2009-2010",
                "2011-2012", "2013-2014", "2015-2016", "2017-2018"]:
        d0 = base / cyc
        def g(pfx):
            c = [p for p in d0.glob("*.xpt") if p.name.upper().startswith(pfx)]
            return pd.read_sas(c[0], format="xport") if c else None
        demo, bpx, bpq, smq = g("DEMO"), g("BPX"), g("BPQ"), g("SMQ")
        if demo is None or bpx is None or bpq is None or smq is None:
            continue
        sysc = [c for c in bpx.columns if c.startswith("BPXSY")]
        diac = [c for c in bpx.columns if c.startswith("BPXDI")]
        b = bpx[["SEQN"] + sysc + diac].copy()
        for c in sysc + diac:
            s = pd.to_numeric(b[c], errors="coerce")
            b[c] = s.where(s > 0)
        b["M"] = np.where(b[sysc + diac].notna().any(axis=1),
                          ((b[sysc].mean(axis=1, skipna=True) >= 140)
                           | (b[diac].mean(axis=1, skipna=True) >= 90)).astype(float),
                          np.nan)
        d = b[["SEQN", "M"]].merge(bpq[["SEQN", "BPQ020"]], on="SEQN", how="inner")
        d = d.merge(smq[["SEQN", "SMQ020", "SMQ040"]], on="SEQN", how="left")
        c020 = pd.to_numeric(d["BPQ020"], errors="coerce")
        d["S"] = np.where(c020 == 1, 1.0, np.where(c020 == 2, 0.0, np.nan))
        ever = pd.to_numeric(d["SMQ020"], errors="coerce")
        now = pd.to_numeric(d["SMQ040"], errors="coerce")
        cur = pd.Series(np.nan, index=d.index)
        cur[now == 1] = 1.0
        cur[now.isin([2, 3])] = 0.0
        cur[now.isna() & (ever == 2)] = 0.0
        d["smoke"] = cur
        d = d.dropna(subset=["M", "S"])
        out.append((f"NHANES {cyc}", d, "smoke"))
    return out


def main() -> None:
    print("=" * 88)
    print("DIFFERENTIAL SENSITIVITY  P(S=1 | M=1, exposed) - P(S=1 | M=1, unexposed)")
    print("=" * 88)
    print(f"  {'dataset':<16}{'M+ n':>7}{'sens exposed':>14}"
          f"{'sens unexp':>12}{'difference':>12}")
    rows = []
    frames = []
    try:
        frames += ensanut()
    except Exception as e:  # noqa: BLE001
        print("  ENSANUT block failed:", e)
    try:
        frames += nhanes()
    except Exception as e:  # noqa: BLE001
        print("  NHANES block failed:", e)

    for name, d, ex in frames:
        se, su, dif, n = diff_sens(d, ex)
        if not np.isfinite(dif):
            continue
        print(f"  {name:<16}{n:>7,}{se:>14.3f}{su:>12.3f}{dif:>+12.3f}")
        rows.append({"dataset": name, "Mplus_n": n, "sens_exposed": round(se, 3),
                     "sens_unexposed": round(su, 3),
                     "differential": round(dif, 3)})
    pd.DataFrame(rows).to_csv(OUT / "13_differential_sensitivity.csv",
                              index=False, encoding="utf-8-sig")
    print(f"\nwrote {OUT / '13_differential_sensitivity.csv'}")


if __name__ == "__main__":
    sys.exit(main())
