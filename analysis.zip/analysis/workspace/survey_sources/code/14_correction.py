# Correct the exposure-outcome association for outcome misclassification and
# see whether the country differences survive.
#
# Method (Rogan-Gladen applied within exposure strata):
#   observed positives among stratum e : obs_e = n_e * P(S=1 | E=e)
#   corrected true positives           : a_e = (obs_e - n_e*(1 - Sp_e)) / (Se_e + Sp_e - 1)
#   corrected OR                       : (a_1/(n_1-a_1)) / (a_0/(n_0-a_0))
#
# Two versions:
#   non-differential : one Se/Sp pair applied to both strata
#   differential     : stratum-specific Se/Sp
#
# If the country contrast disappears under the differential correction, the
# difference was a measurement artefact; if it survives, real heterogeneity
# remains.

from __future__ import annotations

import io
import sys
import warnings
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parents[1] / "results"


# ---------------------------------------------------------------- helpers
def se_sp(d: pd.DataFrame, ex: str, stratum=None):
    """Sensitivity and specificity of S against M, overall or within a stratum."""
    m = d
    if stratum is not None:
        m = d[d[ex] == stratum]
    pos = m[m["M"] == 1]
    neg = m[m["M"] == 0]
    if len(pos) < 30 or len(neg) < 30:
        return np.nan, np.nan
    return pos["S"].mean(), 1.0 - neg["S"].mean()


def corrected(d: pd.DataFrame, ex: str, use_differential: bool):
    """Return observed OR and corrected OR."""
    rows = {}
    se_all, sp_all = se_sp(d, ex)
    for e in (0, 1):
        s = d[d[ex] == e]
        n = len(s)
        if n < 30:
            return np.nan, np.nan, np.nan, np.nan
        p = s["S"].mean()
        rows[e] = {"n": n, "p": p}
    obs_or = ((rows[1]["p"] / (1 - rows[1]["p"])) /
              (rows[0]["p"] / (1 - rows[0]["p"]))) if \
        (0 < rows[1]["p"] < 1 and 0 < rows[0]["p"] < 1) else np.nan

    # observed (uncorrected) OR under the measured definition
    mm = d[d[ex].notna()]
    a1 = ((mm[ex] == 1) & (mm["M"] == 1)).sum()
    b1 = ((mm[ex] == 1) & (mm["M"] == 0)).sum()
    a0 = ((mm[ex] == 0) & (mm["M"] == 1)).sum()
    b0 = ((mm[ex] == 0) & (mm["M"] == 0)).sum()
    meas_or = (a1 * b0) / (b1 * a0) if b1 and a0 else np.nan

    corr = {}
    for e in (0, 1):
        if use_differential:
            se, sp = se_sp(d, ex, e)
        else:
            se, sp = se_all, sp_all
        if not np.isfinite(se) or not np.isfinite(sp):
            return obs_or, meas_or, np.nan, np.nan
        denom = se + sp - 1.0
        if denom <= 0.05:
            return obs_or, meas_or, np.nan, np.nan
        n, p = rows[e]["n"], rows[e]["p"]
        a = (n * p - n * (1 - sp)) / denom
        a = min(max(a, 1.0), n - 1.0)
        corr[e] = (a, n - a)
    if corr[0][1] <= 0 or corr[1][1] <= 0:
        return obs_or, meas_or, np.nan, np.nan
    corr_or = ((corr[1][0] / corr[1][1]) / (corr[0][0] / corr[0][1]))
    return obs_or, meas_or, corr_or, se_all


# ---------------------------------------------------------------- data
def build_all() -> list[tuple[str, str, pd.DataFrame, str]]:
    out: list = []

    # ---- China prevalent (CHARLS / CHNS), reusing script 37
    try:
        from importlib import import_module
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        m37 = import_module("10_prevalent_china")
        c = m37.charls_cross()
        c = c.rename(columns={"smoke_current": "smoke"})
        out.append(("CHARLS 2011", "China", c, "smoke"))
        n = m37.chns_cross()
        n = n.rename(columns={"smoke_current": "smoke"})
        out.append(("CHNS 2009", "China", n, "smoke"))
    except Exception as e:  # noqa: BLE001
        print("  China block failed:", e)

    # ---- Mexico
    try:
        from importlib import import_module
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        m72 = import_module("13_differential_sensitivity")
        for name, d, ex in m72.ensanut():
            country = "Mexico"
            out.append((name, country, d, ex))
        for name, d, ex in m72.nhanes():
            out.append((name, "USA", d, ex))
    except Exception as e:  # noqa: BLE001
        print("  Mexico/USA block failed:", e)
        print("  (falling back to a direct build)")
        from importlib import import_module
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        m72 = import_module("13_differential_sensitivity")
        for name, d, ex in m72.ensanut():
            out.append((name, "Mexico", d, ex))
    return out


def main() -> None:
    print("=" * 92)
    print("MISCLASSIFICATION CORRECTION")
    print("=" * 92)
    frames = build_all()
    if not frames:
        print("no datasets built")
        return

    rows = []
    print(f"  {'dataset':<16}{'country':<9}{'n':>8}"
          f"{'OR meas':>9}{'OR self':>9}{'OR corr':>9}"
          f"{'Se':>7}{'Sp':>7}")
    for name, country, d, ex in frames:
        d = d.dropna(subset=["M", "S", ex]).copy()
        if len(d) < 200:
            continue
        obs, meas, corr, se = corrected(d, ex, use_differential=True)
        if not np.isfinite(corr):
            print(f"  {name:<16}{country:<9}{len(d):>8,}   correction not identifiable")
            continue
        _, sp = se_sp(d, ex)
        print(f"  {name:<16}{country:<9}{len(d):>8,}{meas:>9.2f}{obs:>9.2f}"
              f"{corr:>9.2f}{se:>7.3f}{sp:>7.3f}")
        rows.append({"dataset": name, "country": country, "n": len(d),
                     "OR_measured": round(float(meas), 3),
                     "OR_selfreport": round(float(obs), 3),
                     "OR_corrected": round(float(corr), 3),
                     "sensitivity": round(float(se), 3),
                     "specificity": round(float(sp), 3)})
    df = pd.DataFrame(rows)
    df.to_csv(HERE / "14_corrected_estimates.csv", index=False, encoding="utf-8-sig")

    print()
    print("=" * 92)
    print("BY COUNTRY  (smoking)")
    print("=" * 92)
    for c, g in df.groupby("country", sort=False):
        print(f"  {c:<9} n_analyses={len(g):>2}  "
              f"measured OR {g['OR_measured'].mean():.2f}  "
              f"self-report OR {g['OR_selfreport'].mean():.2f}  "
              f"corrected OR {g['OR_corrected'].mean():.2f}")
    print(f"\nwrote {HERE / '14_corrected_estimates.csv'}")


if __name__ == "__main__":
    sys.exit(main())
